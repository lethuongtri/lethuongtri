﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- DocData.h : include file for document specific data. An instance of this
//----- class is automatically created and managed by the AsdkDataManager class.
//----- See the AsdkDmgr.h / DocData.cpp for more datails
//-----------------------------------------------------------------------------
#pragma once

//-----------------------------------------------------------------------------
//----- Here you can store the document / database related data.
class CDocData {

	//----- TODO: here you can add your variables

public:
	CDocData () ;
	CDocData (const CDocData &data) ;
	~CDocData () ;
} ;

class TEP9K_CDoc :CDocData
{
public:
	TEP9K_CDoc();
	void ResetData();
	
public:
	bool m_bDataIsValid;	//Flag to mark whether to use valid data or temporary string.
	ads_real m_dDiameter;
	ads_real m_dSlope;
	int m_nSegment;
	
	CString m_strDiaTemp;
	CString m_strSegTemp;
	CString m_strSlopeTemp;
};

class PAFR_CDoc :CDocData
{
public:

	/// <summary>
	///------------Span Type-------------
	/// 1 : 一般部 
	///	2 : 端部
	/// 3 : 縦断勾配
	/// 4 : 平面角度
	/// </summary>
	int m_nSpanType;

	/// <summary>
	///------------End Side-------------
	/// 1 : Left
	///	2 : right
	/// </summary>
	int m_nEndSide;

	/// <summary>
	///------------End Type-------------
	/// 1 : 通しEP
	///	2 : 単品EP
	///	3 : 鋳物 
	/// </summary>
	int m_nEndType;

	//Span numbers:
	//1 : one span
	//2 : two span
	int m_nSpanNums;

	//Type in string:
	CString m_strType;

	//ComboBox 's list number :
	int m_nType_LstNo;//<- Type 's list number
	int m_nBa_LstNo;//<- Baluster 's list number
	int m_nFb_LstNo;//<- Fb 's list number
	int m_dH_LstNo;//<- use only for KR panel special
	// m_dH_LstNo : standard lines height 's list number 
	
	//Slope variables:
	bool m_bIsSlope1;
	ads_real m_dSlope,m_dSlope2;
	ads_real m_dUpAng1, m_dUpAng2;
	ads_real m_dDownAng1, m_dDownAng2;

	//Plane angle
	ads_real m_dPlaneAng;
	ads_real m_dCenDev;

	//Standard Line variables:
	bool m_bIsReal;
	ads_real m_dL1, m_dL2;
	ads_real m_dUpL1, m_dUpL2;

	ads_real m_dH1, m_dH2,m_dH3;
	ads_real m_dLMinus, m_dRMinus;

	//TopA variables:
	ads_real m_dHTA, m_dGap, m_dHStd;
	ads_real m_dTopALen1, m_dTopALen2,m_dtopAWidth;

	//TopB variables:
	ads_real m_dHTB_D, m_dHBR, m_dHTB_U;
	ads_real m_dTopBLen1, m_dTopBLen2,m_dtopBWidth;

	//TopPlate & FB variables:
	ads_real m_dTplLen, m_dFbLen;

	//Baluster variables:
	ads_real m_dBrW;

	ads_real m_dPit, m_dPit1, m_dPit2,m_dEPit,m_dEPit2;
	int m_nPitA, m_nPitA1, m_nPitA2;

	//Sleeve variables:
	ads_real m_dSlvLen, m_dSlvCen;
	ads_real m_dSlvLen2, m_dSlvCen2;
	ads_real m_dSlvGap, m_dSlvH;

	//Bottom variables:
	ads_real m_dHB,m_dBCen, m_dBGap;
	ads_real m_dBotLen1, m_dBotLen2,m_dBotWidth;

	//Polyca variables:
	int m_bPolyIsType1;//<- 1 : Type1 , 0 : Type2

	//EP & cast 's hole variables:
	ads_real m_depXU, m_depYU;
	ads_real m_depXD, m_depYD;
	ads_real m_dCastXU, m_dCastXD;
	ads_real m_dEHolDia;

	PAFR_CDoc();

	void setPolycaH();
	//void setPolycaH(ads_real slopeL, ads_real slopeR);
	void resetData();
};

class PolyCDoc :CDocData
{
public:
	PolyCDoc();
	ads_real m_dPGap1, m_dPGap2, m_dHP;
	ads_real m_dPGap1_R, m_dPGap2_R, m_dHP_R;
	bool m_bIsType1;
};
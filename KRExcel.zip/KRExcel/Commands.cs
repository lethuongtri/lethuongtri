﻿using ExcelDna.Integration;
using ExcelDna.IntelliSense;
using System.Runtime.InteropServices;
using ExcelDna.Integration.CustomUI;

namespace KRExcel.Utils
{
    public static class CommonDeclaration
    {
        public const double MaxDegMinSec = 60.0;
        public const double KRTolerance = 0.000001;
        public const string DegreeSymbol = "°";
        public const string MinuteSymbol = "'";
        public const string SecondSymbol = "\"";
        public const string Owner = "KR-Excel";
        public const string Designer = "LeThuongTri";
    }

    public static class HelpMethods
    {
        public static double RadianToDegree(double angRad)
        {
            return angRad * 180.0 / System.Math.PI;
        }

        public static double DegreeToRadian(double angDeg)
        {
            return angDeg * System.Math.PI / 180.0;
        }
    }
}

namespace KRExcel.GeneralCommands
{
    public static class Commands
    {
        [ExcelFunction(Description = "Convert slope(%) to angle in degrees/ radians.")]
        public static object SlopeToAngle(
            [ExcelArgument(Name = "Slope(%)", Description = "Slope(%) to convert.")]
            object slopeObj,
            [ExcelArgument(Name = "Return degree", Description = "Return value's type." +
                                                                "\nTRUE: return value in degrees." +
                                                               "\nFALSE: return value in radians." +
                                                               "\nBy default is TRUE")]
            object retDegObj)
        {
            //Initialize default return value:
            double retVal = 0.0;

            #region [Check input]

            //Check slope:
            double slope = 0.0;
            if (slopeObj is not double || slopeObj is ExcelDna.Integration.ExcelMissing)
            {
                //throw new ArgumentException();
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }
            else
            {
                slope = System.Convert.ToDouble(slopeObj);
            }

            //Check return type's flag:
            bool isDeg = false;
            if (retDegObj is ExcelDna.Integration.ExcelMissing)
            {
                isDeg = true;
            }
            else
            {
                if (retDegObj is not bool)
                {
                    //throw new ArgumentException();
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
                else
                {
                    isDeg = System.Convert.ToBoolean(retDegObj);
                }
            }
            #endregion

            //Calculate input:
            double tang = slope / 100.0;
            double angRad = System.Math.Atan(tang);
            double angDeg = KRExcel.Utils.HelpMethods.RadianToDegree(angRad);

            //Calculate return value:
            if (isDeg)
            {
                retVal = angDeg;
            }
            else
            {
                retVal = angRad;
            }

            return retVal;
        }

        [ExcelFunction(Description = "Convert angle(degrees) to format _°_'_''.")]
        public static object AngleToDMS(
            [ExcelArgument(Name = "Angle", Description = "Angle(degrees) to convert.")]
            object angle,
            [ExcelArgument(Name = "High precision", Description = "Precision level." +
                                                                "\nTRUE: return value in _°_'_''." +
                                                               "\nFALSE: return value in _°_'." +
                                                               "\nBy default is FALSE.")]
            object highPrecision)
        {
            //Initialize return value:
            string retVal = string.Empty;

            //Get degree:
            double deg = 0.0;
            if (angle is not double || angle is ExcelDna.Integration.ExcelMissing)
            {
                //throw new ArgumentException();
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }
            else
            {
                deg = System.Convert.ToDouble(angle);
            }

            //Check flag argument:
            bool isHighPre = false;
            if (highPrecision is ExcelDna.Integration.ExcelMissing)
            {
                isHighPre = false;
            }
            else
            {
                if (highPrecision is not bool)
                {
                    //throw new ArgumentException();
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
                else
                {
                    isHighPre = System.Convert.ToBoolean(highPrecision);
                }
            }
            
            double minute = (deg - System.Math.Truncate(deg)) * KRExcel.Utils.CommonDeclaration.MaxDegMinSec;
            double second = (minute - System.Math.Truncate(minute)) * KRExcel.Utils.CommonDeclaration.MaxDegMinSec;

            if (!isHighPre)
            {
                deg = System.Math.Truncate(deg);

                //System.Math.Round(second).Equals(CommonDeclaration.MaxDegMinSec / 2.0)
                //second.Equals(CommonDeclaration.MaxDegMinSec / 2.0)
                //second >= CommonDeclaration.MaxDegMinSec / 2.0)
                if (System.Math.Abs(second - KRExcel.Utils.CommonDeclaration.MaxDegMinSec / 2.0) <= KRExcel.Utils.CommonDeclaration.KRTolerance)
                {
                    minute = System.Math.Truncate(minute) + 1.0;
                }
                else
                {
                    minute = System.Math.Round(minute, 0, MidpointRounding.AwayFromZero);
                }

                if (minute.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    deg += 1.0;
                    minute = 0.0;
                }

                retVal = deg.ToString() + KRExcel.Utils.CommonDeclaration.DegreeSymbol +
                         minute.ToString() + KRExcel.Utils.CommonDeclaration.MinuteSymbol;
            }
            else
            {
                deg = System.Math.Truncate(deg);
                minute = System.Math.Truncate(minute);

                //double secondTail = System.Math.Round(second - System.Math.Truncate(second), 1 , 
                //    MidpointRounding.AwayFromZero);

                double secondTail = second - System.Math.Truncate(second);

                //secondTail.Equals(0.5)
                if (System.Math.Abs(secondTail - 0.5) <= KRExcel.Utils.CommonDeclaration.KRTolerance)
                {
                    second = System.Math.Truncate(second) + 1.0;
                }
                else
                {
                    second = System.Math.Round(second, 0, MidpointRounding.AwayFromZero);
                }

                if (second.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    minute += 1.0;
                    second = 0.0;
                }

                if (minute.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    deg += 1.0;
                    minute = 0.0;
                }

                retVal = deg.ToString() + KRExcel.Utils.CommonDeclaration.DegreeSymbol +
                         minute.ToString() + KRExcel.Utils.CommonDeclaration.MinuteSymbol +
                         second.ToString() + KRExcel.Utils.CommonDeclaration.SecondSymbol;
            }

            return retVal;
        }

        [ExcelFunction(Description = "Get number of bolts to assemble Bottom rail A & B in KR9K.")]
        public static object KR9K_BotAB_Bolt(
            [ExcelArgument(Name = "Baluster number", Description = "Baluster's number.")]
            object baCountObj)
        {
            int retVal = 0;

            //Check baluster input:
            int baCount = 0;
            if (baCountObj is not double || baCountObj is ExcelDna.Integration.ExcelMissing)
            {
                //throw new ArgumentException();
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }
            else
            {
                double testBaCount = System.Convert.ToDouble(baCountObj);

                if (!testBaCount.Equals(System.Math.Truncate(testBaCount)))
                {
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
                else
                {
                    baCount = System.Convert.ToInt32(testBaCount);

                    if (baCount <= 0)
                    {
                        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                    }
                }
            }

            int side = 2;
            int edgeHoleNum = 2;
            int midHoleNume = 0;
            int stepOver = 2;
            if (baCount > 2)
            {
                double divided = baCount / stepOver;

                if (Int32.IsOddInteger(baCount))
                {
                    midHoleNume = (int)Math.Truncate(divided);
                }
                else
                {
                    midHoleNume = (int)divided - 1;
                }
            }

            retVal = (midHoleNume + edgeHoleNum) * side;

            return retVal;
        }
    }

    public class IntelliSenseAddIn : IExcelAddIn
    {
        public void AutoOpen()
        {
            IntelliSenseServer.Install();
        }
        public void AutoClose()
        {
            IntelliSenseServer.Uninstall();
        }
    }
}

namespace KRExcel.Sample
{
    public static class Commands
    {
        [ExcelFunction(Description = "My first .NET function")]
        public static string SayHello(string name)
        {
            return "Hello " + name;
        }

        [ExcelFunction(Description = "A useful test function that adds two numbers, and returns the sum.")]
        public static double AddThem(
            [ExcelArgument(Name = "Augend", Description = "is the first number, to which will be added")]
            double v1,
            [ExcelArgument(Name = "Addend", Description = "is the second number that will be added")]
            double v2)
        {
            return v1 + v2;
        }
    }

    // Here is the helper class - add to it or change as you require
    internal static class Optional
    {
        internal static string Check(object arg, string defaultValue)
        {
            if (arg is string)
                return (string)arg;
            else if (arg is ExcelMissing)
                return defaultValue;
            else
                return arg.ToString();  // Or whatever you want to do here....

            // Perhaps check for other types and do whatever you think is right ....
            //else if (arg is double)
            //    return "Double: " + (double)arg;
            //else if (arg is bool)
            //    return "Boolean: " + (bool)arg;
            //else if (arg is ExcelError)
            //    return "ExcelError: " + arg.ToString();
            //else if (arg is object[,](,))
            //    // The object array returned here may contain a mixture of types,
            //    // reflecting the different cell contents.
            //    return string.Format("Array[{0},{1}]({0},{1})",
            //      ((object[,](,)(,))arg).GetLength(0), ((object[,](,)(,))arg).GetLength(1));
            //else if (arg is ExcelEmpty)
            //    return "<<Empty>>"; // Would have been null
            //else if (arg is ExcelReference)
            //  // Calling xlfRefText here requires IsMacroType=true for this function.
            //                return "Reference: " +
            //                     XlCall.Excel(XlCall.xlfReftext, arg, true);
            //            else
            //                return "!? Unheard Of ?!";
        }

        internal static double Check(object arg, double defaultValue)
        {
            if (arg is double)
                return (double)arg;
            else if (arg is ExcelMissing)
                return defaultValue;
            else
                throw new ArgumentException();  // Will return #VALUE to Excel

        }

        // This one is more tricky - we have to do the double->Date conversions ourselves
        internal static DateTime Check(object arg, DateTime defaultValue)
        {
            if (arg is double)
                return DateTime.FromOADate((double)arg);    // Here is the conversion
            else if (arg is string)
                return DateTime.Parse((string)arg);
            else if (arg is ExcelMissing)
                return defaultValue;

            else
                throw new ArgumentException();  // Or defaultValue or whatever
        }
    }
}

namespace KRExcel.Ribbon
{
    public static class Functions
    {
        public static string dnaRibbonTest()
        {
            return "Hello from the Ribbon Sample!";
        }
    }

    [ComVisible(true)]
    public class RibbonController : ExcelRibbon
    {
        private KRExcel.Sample.SampleFrm1 _SampleFrm1 = null;

        //https://bert-toolkit.com/imagemso-list.html
        public override string GetCustomUI(string RibbonID)
        {
            return @"
                  <customUI xmlns='http://schemas.microsoft.com/office/2006/01/customui'>
                  <ribbon>
                    <tabs>
                      <tab id='krExcelTab' label='KR-Excel' insertBeforeMso='TabHome'>
                        <group id='krUtilGrp' label='KR-Utility'>
                          <button id='projectBtn' label='物件管理' 
                                                  imageMso='ControlProperties'
                                                  screentip='Show/edit user settings'
                                                  onAction='OnProjectBtnPressed'
                        />

                        <button id='sampleFrmBtn' label='SampleForm' 
                                                  imageMso='DataFormSource'
                                                  screentip='Show sample form'
                                                  onAction='OnSampleFrmBtnPressed'
                        />

                        </group >
                      </tab>
                    </tabs>
                  </ribbon>
                </customUI>";
        }

        public void OnProjectBtnPressed(IRibbonControl control)
        {
            MessageBox.Show("Hello from KR-Project " + control.Id, 
                            KRExcel.Utils.CommonDeclaration.Owner ,
                            MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        public void OnSampleFrmBtnPressed(IRibbonControl control)
        {
            //MessageBox.Show("Hello from sample form.",
            //                KRExcel.Utils.CommonDeclaration.Owner,
            //                MessageBoxButtons.OK, MessageBoxIcon.Information);

            if(_SampleFrm1 == null || _SampleFrm1.IsDisposed)
            {
                _SampleFrm1 = new KRExcel.Sample.SampleFrm1();
            }

            if (!_SampleFrm1.Visible)
            {
                if (_SampleFrm1.ShowDialog() == DialogResult.Cancel)
                {
                    _SampleFrm1.Dispose();
                }
            }
            else
            {
                _SampleFrm1.Activate();
            }
        }
    }
}
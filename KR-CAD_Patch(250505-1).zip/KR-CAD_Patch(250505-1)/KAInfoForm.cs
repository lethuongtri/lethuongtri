﻿using System;
using System.Reflection;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Xml;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;    //For access database
using Zuby.ADGV;

//using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using AcAp = Autodesk.AutoCAD.ApplicationServices.Application;

//[assembly: CommandClass(typeof(AcadAddin.KAInfo.KAInfoForm))]
using static AcadAddin.CommonDeclaration;
using System.Windows.Controls;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
//using System.Windows.Controls;

namespace AcadAddin.KAInfo
{
    public partial class KAInfoForm : Form
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, Int32 wMsg, bool wParam, Int32 lParam);
        private const int WM_SETREDRAW = 11;

        #region [Fields]
        readonly bool _isReadyToshow = false;
        const string formOwner = AcadAddin.CommonDeclaration.Form_Owner;

        //string settingTable = "Setting_Link";
        string settingTable = "";   //For setting table name 
        string FenceTable = "";     //For Fence table name
        string ShapeTable = "";     //For Shape table name
        string shapePicsPath = "";  //For Shape pictures' path
        string colorPicsPath = "";  //For Color pictures' path
        string techDocsTb = "";     //For technical document table name
        string ColorTable = "";     //For color table name
        private const string contextCollectionName = "ACDB_ANNOTATIONSCALES";

        string xmlFileName ;
        string providerName;
        string assemblyFolder;
        string dbName;
        string conStr;

        string _productCache;
        string _shapeCache;
        string _colorCache;
        
        readonly List<string> shapeKW;
        readonly List<string> colorKW;

        BindingSource _productBindSrc = null;
        BindingSource _shapeBindSrc = null;
        BindingSource _colorBindSrc = null;

        //OleDbCommand dbCmd;
        //OleDbConnection dbCon;
        //OleDbDataAdapter dbDataAdap;

        PDFViewFrm _pdfForm;
        FindResFrm _findResForm;
        DataGridView _curDataGridView;

        #endregion

        #region [Help methods]
        //Method to set database connection link:
        private bool SettingLink()
        {
            try
            {
                //Get assemply folder path:
                assemblyFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

                //Read XML to get setting table name:
                xmlFileName = AcadAddin.CommonDeclaration.Setting_XML_Name;

                List<string> xmlInfoNames = new List<string>()
                {
                    nameof(providerName) , nameof(dbName) , nameof(settingTable)
                };

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(assemblyFolder + "\\" + xmlFileName);

                XmlNode xmlNode = null;
                for (int i = 0; i < xmlInfoNames.Count; i++)
                {
                    xmlNode = xmlDoc.DocumentElement.SelectSingleNode(xmlInfoNames[i]);
                    if (xmlNode != null)
                    {
                        //https://stackoverflow.com/questions/11824362/c-sharp-get-and-set-property-by-variable-name
                        switch (xmlInfoNames[i])
                        {
                            case nameof(providerName):
                                providerName = xmlNode.InnerText;
                                break;

                            case nameof(dbName):
                                dbName = xmlNode.InnerText;
                                break;

                            case nameof(settingTable):
                                settingTable = xmlNode.InnerText;
                                break;

                            default:
                                break;
                        }

                        xmlNode = null;
                    }
                    else
                    {
                        MessageBox.Show("Cannot get information from XML!", formOwner,
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Stop);
                        return false;
                    }
                }

                conStr = providerName + ";Data Source=" + assemblyFolder + "\\" + dbName;

                #region [Old codes]
                //Set database connection information:
                //providerName = "Provider=Microsoft.ACE.OLEDB.12.0";
                //assemblyFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                //dbName = "KR-CAD.accdb";
                //conStr = providerName + ";Data Source=" + assemblyFolder + "\\" + dbName;
                #endregion

                using (OleDbConnection dbCon = new OleDbConnection(conStr))
                {
                    dbCon.Open();

                    using (OleDbCommand dbCmd = new OleDbCommand("select * from " + settingTable, dbCon))
                    using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                    {
                        #region [Old codes]
                        //FenceTable = "FType";
                        //ShapeTable = "Shape";
                        //picsPath = "ShapePics";
                        #endregion

                        //Loop though access database:
                        while (dbDataRead.Read())
                        {
                            string rowKey = dbDataRead[0].ToString();
                            string rowValue = dbDataRead[1].ToString();

                            switch (rowKey)
                            {
                                case nameof(FenceTable):
                                    FenceTable = rowValue;
                                    break;

                                case nameof(ShapeTable):
                                    ShapeTable = rowValue;
                                    break;

                                case nameof(ColorTable):
                                    ColorTable = rowValue;
                                    break;

                                case nameof(techDocsTb):
                                    techDocsTb = rowValue;
                                    break;

                                case nameof(shapePicsPath):
                                    shapePicsPath = rowValue;
                                    break;

                                case nameof(colorPicsPath):
                                    colorPicsPath = rowValue;
                                    break;

                                default:
                                    break;
                            }
                        }

                        dbDataRead.Close();
                    }

                    dbCon.Close();
                }

                if (FenceTable != "" && ShapeTable != "" &&
                     techDocsTb != "" && ColorTable != "" &&
                     shapePicsPath != "" && colorPicsPath != "")
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("Fail to set up form!", formOwner,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Stop);
                    return false;
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Fail to set up form!\n" + ex.Message, formOwner,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Stop);
                return false;
            }
        }

        ////Method to get match pattern(Regex) from search value:
        //private string GetMatchPattern(string searchValue,bool isBound = false)
        //{
        //    if (!isBound)
        //    {
        //        //Source contains keyword at anywhere:
        //        return $"{searchValue}";
        //    }
        //    else
        //    {
        //        //Source contains keyword at the bound location only:
        //        return $"\\b{searchValue}\\b"; 
        //    }
        //}

        #region [Old codes
        ////Method to get source datatable:
        //private DataTable GetSourceDataTable(AdvancedDataGridView avDataGrid)
        //{
        //    DataTable dt;
        //    if (_dataTbCache == null) //On the first called
        //    {
        //        _dataTbCache = (DataTable)avDataGrid.DataSource;
        //    }

        //    if (avDataGrid.FilterString.Length > 0)
        //    {
        //        dt = (DataTable)avDataGrid.DataSource;
        //    }
        //    else//no filter data:
        //    {
        //        dt = _dataTbCache;
        //    }

        //    return dt;
        //}
        #endregion

        //Method to update Datagridview by value in list:
        private void UpdateDataGridView(DataGridView dataGrid, string typeToLoad)
        {
            //Connect Winform Vs Access (No sys file):
            //https://www.youtube.com/watch?v=svZ1vzy_c3c

            //Improve performance when load datatable to datagridview source:
            //https://stackoverflow.com/questions/4660420/slow-to-set-datagridview-datasource-to-datatable-in-c-sharp?fbclid=IwAR0CVTXHIoxvMl3BjffSy3hk981AiqomxyoMYq7l27jlmswRp0lA3p2sAXw
            try
            {
                using (OleDbConnection dbCon = new OleDbConnection(conStr))
                {
                    dbCon.Open();

                    //Clear datagrid's old datasource:
                    if (dataGrid.DataSource != null)
                    {
                        dataGrid.DataSource = null;
                        dataGrid.Rows.Clear();
                        dataGrid.Columns.Clear();
                    }

                    if (dataGrid.Equals(productDataGrid))
                    {
                        #region [Solution 1 - using auto fill datatable]
                        //using (OleDbCommand dbCmd = new OleDbCommand("select * from " + typeToLoad, dbCon))
                        //using (OleDbDataAdapter dbDataAdap = new OleDbDataAdapter(dbCmd))
                        //using (System.Data.DataTable dtTb = new System.Data.DataTable())
                        //{

                        //    dbDataAdap.Fill(dtTb);

                        //    #region [Old codes 1]
                        //    //for (int i = dtTb.Rows.Count -1 ; i >= 0; i--)
                        //    //{
                        //    //    DataRow dr = dtTb.Rows[i];
                        //    //    if (dr[0].ToString() == "")
                        //    //    {
                        //    //        dr.Delete();
                        //    //    }
                        //    //}
                        //    #endregion

                        //    #region [Old codes 2]
                        //    //if (dtTb.Rows.Count > 0 && dtTb.Columns.Count > 0)
                        //    //{
                        //    //    for (int i = 0; i < dtTb.Rows.Count; i++)
                        //    //    {
                        //    //        if (dtTb.Rows[i][0].ToString() == "")
                        //    //        {
                        //    //            dtTb.de
                        //    //        }

                        //    //    }
                        //    //}
                        //    #endregion

                        //    dataGrid.DataSource = dtTb;
                        //}
                        #endregion

                        

                        using (OleDbCommand dbCmd = new OleDbCommand("select * from " + typeToLoad, dbCon))
                        using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                        {
                            using (System.Data.DataTable _fullSrcData = new System.Data.DataTable())
                            {
                                //Add column:
                                for (int i = 0; i < dbDataRead.FieldCount; i++)
                                {
                                    //Add more column beside Shape no & material columns:
                                    _fullSrcData.Columns.Add(dbDataRead.GetName(i), dbDataRead.GetFieldType(i));
                                }

                                //Add datatable's rows:
                                while (dbDataRead.Read())
                                {
                                    object[] rowParams = new object[dbDataRead.FieldCount];
                                    for (int i = 0; i < rowParams.Length; i++)
                                    {
                                        rowParams[i] = dbDataRead[i];
                                    }

                                    _fullSrcData.Rows.Add(rowParams);
                                }

                                //Set sources:
                                //DataGridViewRowHeadersWidthSizeMode oldRowHeadersSizeMode = dataGrid.RowHeadersWidthSizeMode;
                                //dataGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
                                SendMessage(dataGrid.Handle, WM_SETREDRAW, false, 0);

                                _productBindSrc.RaiseListChangedEvents = false;
                                _productBindSrc.RemoveFilter();
                                if (_productBindSrc.IsSorted)
                                {
                                    _productBindSrc.RemoveSort();
                                }
                                _productBindSrc.DataSource = null;
                                _productBindSrc.DataSource = _fullSrcData;
                                dataGrid.DataSource = _productBindSrc;
                                _productBindSrc.ResetBindings(false);
                                _productBindSrc.RaiseListChangedEvents = true;

                                //dataGrid.RowHeadersWidthSizeMode = oldRowHeadersSizeMode;

                                //Sort datagridview by its first column:
                                dataGrid.Sort(dataGrid.Columns[0], ListSortDirection.Ascending);

                                SendMessage(dataGrid.Handle, WM_SETREDRAW, true, 0);
                                dataGrid.Refresh();
                            }

                            #region [Old codes
                            ////Set datargid's source:
                            ////We add some setting here to improve datagrid loading's performance:
                            ////https://stackoverflow.com/questions/10226992/slow-performance-in-populating-datagridview-with-large-data
                            //DockStyle oldDock = dataGrid.Dock;
                            //DataGridViewAutoSizeColumnsMode oldColsMode = dataGrid.AutoSizeColumnsMode;
                            //DataGridViewAutoSizeRowsMode  oldRowsMode= dataGrid.AutoSizeRowsMode;
                            //DataGridViewColumnHeadersHeightSizeMode oldColResizing = dataGrid.ColumnHeadersHeightSizeMode;

                            //dataGrid.Dock = DockStyle.None;
                            //dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
                            //dataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
                            //dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                            //dataGrid.SuspendLayout();

                            ////Set datagridview's source:
                            //dataGrid.DataSource = _fullSrcData;

                            ////Sort datagridview by its first column:
                            //dataGrid.Sort(dataGrid.Columns[0], ListSortDirection.Ascending);

                            //dataGrid.AutoSizeColumnsMode = oldColsMode;
                            //dataGrid.AutoSizeRowsMode = oldRowsMode;
                            //dataGrid.ColumnHeadersHeightSizeMode = oldColResizing;
                            //dataGrid.Dock = oldDock;
                            //dataGrid.ResumeLayout();
                            #endregion

                            //Close reader:
                            dbDataRead.Close();
                        }
                    }
                    else if (dataGrid.Equals(shapeDataGrid) || dataGrid.Equals(colorDataGrid))
                    {
                        //int colWidth = 0;
                        int rowHeight = 0;

                        if (dataGrid.Equals(shapeDataGrid))
                        {
                            //colWidth = 40;
                            rowHeight = 85;
                        }
                        else if (dataGrid.Equals(colorDataGrid))
                        {
                            //colWidth = 10;
                            rowHeight = 25;
                        }

                        using (OleDbCommand dbCmd = new OleDbCommand("select * from " + typeToLoad, dbCon))
                        using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                        {
                            if (typeToLoad.Contains("KRBotSheet"))
                            {
                                rowHeight = 120;
                            }

                            string picsPath = "";
                            if (dataGrid.Equals(shapeDataGrid))
                            {
                                picsPath = shapePicsPath;
                            }
                            else if (dataGrid.Equals(colorDataGrid))
                            {
                                picsPath = colorPicsPath;
                            }

                            string imgFolderPath = assemblyFolder + "\\" + picsPath + "\\";
                            string imgLink = "";

                            //Check type to load:
                            string[] splitStrs = typeToLoad.Split('_');
                            if (splitStrs == null || splitStrs.Length != 2)
                            {
                                MessageBox.Show("Type to load is not valid!", formOwner,
                                                            MessageBoxButtons.OK,
                                                            MessageBoxIcon.Error);
                                return;
                            }

                            //Get keywords list:
                            var folderNames = CustomSearcher.GetDirectories(imgFolderPath);

                            bool isError = false;
                            if (folderNames == null || folderNames.Count == 0)
                            {
                                isError = true;
                            }
                            else
                            {
                                var foundPath = folderNames.Find(x => x.Contains(splitStrs[1]));
                                if (foundPath == null)
                                {
                                    isError = true;
                                }
                                else
                                {
                                    imgLink = foundPath + "\\";
                                }
                            }

                            if (isError)
                            {
                                MessageBox.Show("Cannot get image folder!", formOwner,
                                                           MessageBoxButtons.OK,
                                                           MessageBoxIcon.Error);
                                return;
                            }

                            using (System.Data.DataTable _fullSrcData = new System.Data.DataTable())
                            {
                                //Define datatable's columns:
                                string imgColHeader = "Image";
                                int imgNameCol = -1;
                                for (int i = 0; i < dbDataRead.FieldCount; i++)
                                {
                                    //Add more column beside Shape no & material columns:
                                    if (dbDataRead.GetName(i) != imgColHeader)
                                    {
                                        _fullSrcData.Columns.Add(dbDataRead.GetName(i), dbDataRead.GetFieldType(i));
                                    }
                                    else
                                    {
                                        _fullSrcData.Columns.Add(dbDataRead.GetName(i), typeof(byte[]));
                                        imgNameCol = i;
                                    }
                                }

                                //Add datatable's rows:
                                while (dbDataRead.Read())
                                {
                                    //Add data from database to datagridview:
                                    System.Drawing.Image shapeImage;
                                    string imgFormatStr = ".PNG";
                                    try
                                    {
                                        shapeImage = System.Drawing.Image.FromFile(imgLink + dbDataRead[imgNameCol].ToString() + imgFormatStr);
                                        if (shapeImage == null)
                                        {
                                            shapeImage = Properties.Resources.KAInfoLogo;
                                        }
                                    }
                                    catch (System.Exception)
                                    {
                                        //shapeImage = null;
                                        shapeImage = Properties.Resources.KAInfoLogo;
                                    }

                                    System.Drawing.Imaging.ImageFormat imgFormat;
                                    if (imgFormatStr == ".PNG")
                                    {
                                        imgFormat = System.Drawing.Imaging.ImageFormat.Png;
                                    }
                                    else
                                    {
                                        imgFormat = System.Drawing.Imaging.ImageFormat.Gif;
                                    }


                                    byte[] imgBytes = ImageToByteArr(shapeImage, imgFormat);

                                    object[] rowParams = new object[dbDataRead.FieldCount];
                                    for (int i = 0; i < rowParams.Length; i++)
                                    {
                                        if (i != imgNameCol)
                                        {
                                            rowParams[i] = dbDataRead[i];
                                        }
                                        else
                                        {
                                            rowParams[i] = imgBytes;
                                        }
                                    }

                                    _fullSrcData.Rows.Add(rowParams);
                                }

                                //We add some setting here to improve datagrid loading's performance:
                                //https://10tec.com/articles/why-datagridview-slow.aspx
                                SendMessage(dataGrid.Handle, WM_SETREDRAW, false, 0);

                                BindingSource tempBindSrc;
                                if (dataGrid.Equals(shapeDataGrid))
                                {
                                    tempBindSrc = _shapeBindSrc;
                                }
                                else
                                {
                                    tempBindSrc = _colorBindSrc;
                                }

                                tempBindSrc.RaiseListChangedEvents = false;
                                tempBindSrc.RemoveFilter();
                                if (tempBindSrc.IsSorted)
                                {
                                    tempBindSrc.RemoveSort();
                                }
                                tempBindSrc.DataSource = null;
                                tempBindSrc.DataSource = _fullSrcData;
                                dataGrid.DataSource = tempBindSrc;
                                tempBindSrc.ResetBindings(false);
                                tempBindSrc.RaiseListChangedEvents = true;

                                //Modify image layout:
                                if (imgNameCol != -1)
                                {
                                    DataGridViewImageColumn datagridImgCol = dataGrid.Columns[imgNameCol] as
                                                                             DataGridViewImageColumn;

                                    datagridImgCol.ImageLayout = DataGridViewImageCellLayout.Stretch;
                                    (dataGrid as AdvancedDataGridView).DisableFilterChecklist(datagridImgCol);
                                }

                                //Modify datagridview's row height:
                                dataGrid.RowTemplate.Height = rowHeight;

                                //Sort datagridview by its first column:
                                dataGrid.Sort(dataGrid.Columns[0], ListSortDirection.Ascending);

                                SendMessage(dataGrid.Handle, WM_SETREDRAW, true, 0);
                                dataGrid.Refresh();
                            }

                            dbDataRead.Close();
                        }
                    }

                    //Freeze first column:
                    dataGrid.Columns[0].Frozen = true;

                    dbCon.Close();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, formOwner,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                return;
            }
        }

        //Method to convert image to byte array:
        private byte[] ImageToByteArr(System.Drawing.Image imgIn, System.Drawing.Imaging.ImageFormat imgFormat )
        {
            byte[] retVal;
            using (MemoryStream ms = new MemoryStream())
            {
                imgIn.Save(ms, imgFormat);
                retVal = ms.ToArray();
                return retVal;
            }
        }

        [Obsolete("Use FindAllPossibleValues instead !")]
        private void FindValueInDataGrid(DataGridView dataGrid, string searchValue)
        {
            //Sample of Regex:
            //https://stackoverflow.com/questions/63234767/find-exact-match-in-a-string-c-sharp

            string pattern = CommonCommands.GetMatchPattern(searchValue);

            if (searchValue != "")
            {
                #region [Old codes]
                //DataGridViewSelectionMode oldMode = dataGridView1.SelectionMode;

                //if (dataGridView1.SelectionMode != DataGridViewSelectionMode.FullRowSelect)
                //{
                //    dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                //}
                #endregion

                try
                {
                    bool founded = false;
                    foreach (DataGridViewRow row in dataGrid.Rows)
                    {
                        if (founded)
                        {
                            break;
                        }

                        for (int i = 0; i < row.Cells.Count; i++)
                        {
                            if (row.Cells[i] != null)
                            {
                                object tempObj = row.Cells[i].Value;    //Avoid bugs
                                if (tempObj != null)
                                {
                                    string tempStr = tempObj.ToString();

                                    if (Regex.IsMatch(tempStr, pattern, RegexOptions.IgnoreCase))
                                    {
                                        if (dataGrid.SelectionMode != DataGridViewSelectionMode.FullRowSelect)
                                        {
                                            dataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                                        }

                                        row.Selected = true;

                                        dataGrid.CurrentCell = row.Cells[i];
                                        dataGrid.FirstDisplayedScrollingRowIndex = row.Index;

                                        founded = true;

                                        break;
                                    }
                                    else
                                    {
                                        if (row.Selected == true)
                                        {
                                            row.Selected = false;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!founded)
                    {
                        MessageBox.Show("Value was not found!", formOwner,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }

                }
                catch (System.Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message, formOwner,
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Warning);
                }
            }
        }

        //Find value in datagrid + listbox by textbox's text:
        [Obsolete("Use FindAllPossibleValues instead !")]
        private bool FindValueInDataGrid(System.Windows.Forms.TextBox findTbx, 
            System.Windows.Forms.ListBox findLbx, System.Windows.Forms.DataGridView dataGrid)
        {
            string searchValue;
            searchValue = findTbx.Text;
            string pattern = CommonCommands.GetMatchPattern(searchValue);
            if (searchValue != "")
            {
                bool founded = false;

                int curIndex = findLbx.SelectedIndex;

                List<int> findIndexes = new List<int>();
                findIndexes.Add(curIndex);
                for (int i = 0; i < findLbx.Items.Count; i++)
                {
                    if (i != curIndex)
                    {
                        findIndexes.Add(i);
                    }
                }

                for (int i = 0; i < findIndexes.Count; i++)
                {
                    //Select item in listbox:
                    if (findLbx.SelectedIndex != findIndexes[i])
                    {
                        findLbx.SelectedIndex = findIndexes[i];
                    }

                    //Check matching:
                    try
                    {
                        foreach (DataGridViewRow row in dataGrid.Rows)
                        {
                            if (founded)
                            {
                                break;
                            }

                            for (int j = 0; j < row.Cells.Count; j++)
                            {
                                if (row.Cells[j] != null)
                                {
                                    object tempObj = row.Cells[j].Value;    //Avoid bugs
                                    if (tempObj != null)
                                    {
                                        string tempStr = tempObj.ToString();

                                        if (Regex.IsMatch(tempStr, pattern, RegexOptions.IgnoreCase))
                                        {
                                            if (dataGrid.SelectionMode != DataGridViewSelectionMode.FullRowSelect)
                                            {
                                                dataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                                            }

                                            row.Selected = true;

                                            dataGrid.CurrentCell = row.Cells[j];
                                            dataGrid.FirstDisplayedScrollingRowIndex = row.Index;

                                            founded = true;

                                            break;
                                        }
                                        else
                                        {
                                            if (row.Selected == true)
                                            {
                                                row.Selected = false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show("Error : " + ex.Message, formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                        return false;
                    }

                    //Break if key founded:
                    if (founded)
                    {
                        break;
                    }
                }

                //Message user if cannot value:
                if (!founded)
                {
                    MessageBox.Show("Cannot find value!", formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                    return false;
                }

                return true;
            }

            return true;
        }

        //Find value in datagrid + listbox by textbox's text, then reflect result into Find result form:
        // ---------
        // ---------
        // 1) Khi find cần trả về
        // table name , row , column
        // 2) double click vào record thì activate table name , row , column

        // Chế độ find multible áp dụng khi find bằng
        // + Product text box:
        // + Product cell's left click
        // + Shape find text box:

        // Với 2 TH Product text box & Product cell's left click
        // => khi find :
        // Trước hết tạo ra 1 List<tupple> , trong đó tupple<string , int , int> 
        // Dung SQL truy vấn trong KR-CAD databbase 
        // Điều kiện lọc là giá trị tìm kiếm , nơi lọc là tất cả các table thuộc shape
        // Tìm thấy giá trị thì kiểm tra List có chứa nó chưa , nếu chưa add vào list
        // Sau khi tìm hết mà List.Count > 0 thì khởi tạo form FindRes.

        //Select * from [table] where [Shape No] = findValue
        //https://www.programiz.com/sql/select#google_vignette

        //Help method for find value by listbox & matchpattern:
        //Return multiple values in form:
        private void FindAllPossibleValues (object sender)
        {
            try
            {
                using (OleDbConnection dbCon = new OleDbConnection(conStr))
                {
                    dbCon.Open();

                    //List for found items:
                    System.Collections.Generic.List<Tuple<string, int, int>> foundItems =
                         new List<Tuple<string, int, int>>();

                    #region [Get source listbox & match pattern]
                    System.Windows.Forms.ListBox lstBox = null;     //Listbox contains table name to find
                    string findVal = "";                            //string to find
                    string matchPattern = "";                       //match pattern which is created from 'string to find'
                    bool findAll = true;                            //Find option => find in all tables or find in current table
                                                                    //  => apply for finding within FType's tables ONLY

                    //Get listbox & match pattern:
                    if (sender.Equals(findProductTbx))
                    {
                        lstBox = productLbx;

                        if (!string.IsNullOrEmpty(findProductTbx.Text))
                        {
                            findVal = findProductTbx.Text;
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }

                        if (proFindCurRad.Checked)
                        {
                            findAll = false;
                        }
                    }
                    else if (sender.Equals(productDataGrid) && productDataGrid.CurrentCell != null)
                    {
                        lstBox = shapeLbx;

                        if (!string.IsNullOrEmpty(productDataGrid.CurrentCell.Value.ToString()))
                        {
                            findVal = productDataGrid.CurrentCell.Value.ToString();
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }
                    }
                    else if (sender.Equals(findShapeTbx))
                    {
                        lstBox = shapeLbx;

                        if (!string.IsNullOrEmpty(findShapeTbx.Text))
                        {
                            findVal = findShapeTbx.Text;
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }
                    }
                    else if (sender.Equals(findColorTbx))
                    {
                        lstBox = colorLbx;

                        if (!string.IsNullOrEmpty(findColorTbx.Text))
                        {
                            findVal = findColorTbx.Text;
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }
                    }

                    //Check listbox:
                    if (lstBox == null || lstBox.Items == null
                        || lstBox.Items.Count == 0)
                    {
                        MessageBox.Show("Cannot get list box !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        dbCon.Close();
                        return;
                    }
                    else if (string.IsNullOrEmpty(findVal) ||
                        findVal == "-")
                    {
                        MessageBox.Show("Cannot get find value !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        dbCon.Close();
                        return;
                    }
                    else if (string.IsNullOrEmpty(matchPattern))
                    {
                        MessageBox.Show("Cannot get match pattern !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        dbCon.Close();
                        return;
                    }
                    #endregion

                    //Find all table name that match 'matchPattern' then into 'foundItems':
                    if (findAll) //Iterate all members in listbox:
                    {
                        foreach (var lbxItem in lstBox.Items)
                        {
                            if (lbxItem == null)
                            {
                                MessageBox.Show("Cannot read listbox's item !",
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                dbCon.Close();
                                return;
                            }

                            //Get current table name:
                            string curTbName = lbxItem.ToString();

                            //Query all data from access database:
                            using (OleDbCommand dbCmd = new OleDbCommand("select * from " + curTbName, dbCon))
                            using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                            {
                                if (dbDataRead.HasRows)
                                {
                                    //Create datatable:
                                    using (System.Data.DataTable _fullSrcData = new System.Data.DataTable())
                                    {
                                        //Add column:
                                        for (int i = 0; i < dbDataRead.FieldCount; i++)
                                        {
                                            //Add more column beside Shape no & material columns:
                                            _fullSrcData.Columns.Add(dbDataRead.GetName(i), dbDataRead.GetFieldType(i));
                                        }

                                        //Fill datatable with data from data reader:
                                        while (dbDataRead.Read())
                                        {
                                            object[] rowParams = new object[dbDataRead.FieldCount];
                                            for (int i = 0; i < rowParams.Length; i++)
                                            {
                                                rowParams[i] = dbDataRead[i];
                                            }

                                            _fullSrcData.Rows.Add(rowParams);
                                        }

                                        //Sort datagridview by its first column:
                                        //https://www.codeproject.com/Questions/219205/How-To-Sort-Datatable-in-csharp-net
                                        _fullSrcData.DefaultView.Sort = dbDataRead.GetName(0) + " ASC";
                                        using (System.Data.DataTable sortedDtTb = _fullSrcData.DefaultView.ToTable())
                                        {
                                            //Iterate datatable then add found member to foundItems list:
                                            for (int i = 0; i < sortedDtTb.Rows.Count; i++)
                                            {
                                                for (int j = 0; j < sortedDtTb.Columns.Count; j++)
                                                {
                                                    if (dbDataRead.GetName(j) == "Image")
                                                    {
                                                        continue;
                                                    }
                                                    else
                                                    {
                                                        string tempStr = sortedDtTb.Rows[i][j].ToString();

                                                        if (Regex.IsMatch(tempStr, matchPattern, RegexOptions.IgnoreCase))
                                                        {
                                                            Tuple<string, int, int> foundMember = new Tuple<string, int, int>(
                                                                curTbName, i, j);

                                                            foundItems.Add(foundMember);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else //Partial find : find in listbox's selected item ONLY
                    {
                        if (lstBox.SelectedItem == null)
                        {
                            MessageBox.Show("Cannot read current listbox's item !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                            dbCon.Close();
                            return;
                        }

                        //Get current table name:
                        string curTbName = lstBox.SelectedItem.ToString();

                        //Query all data from access database:
                        using (OleDbCommand dbCmd = new OleDbCommand("select * from " + curTbName, dbCon))
                        using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                        {
                            if (dbDataRead.HasRows)
                            {
                                //Create datatable:
                                using (System.Data.DataTable _fullSrcData = new System.Data.DataTable())
                                {
                                    //Add column:
                                    for (int i = 0; i < dbDataRead.FieldCount; i++)
                                    {
                                        //Add more column beside Shape no & material columns:
                                        _fullSrcData.Columns.Add(dbDataRead.GetName(i), dbDataRead.GetFieldType(i));
                                    }

                                    //Fill datatable with data from data reader:
                                    while (dbDataRead.Read())
                                    {
                                        object[] rowParams = new object[dbDataRead.FieldCount];
                                        for (int i = 0; i < rowParams.Length; i++)
                                        {
                                            rowParams[i] = dbDataRead[i];
                                        }

                                        _fullSrcData.Rows.Add(rowParams);
                                    }

                                    //Sort datagridview by its first column:
                                    //https://www.codeproject.com/Questions/219205/How-To-Sort-Datatable-in-csharp-net
                                    _fullSrcData.DefaultView.Sort = dbDataRead.GetName(0) + " ASC";
                                    using (System.Data.DataTable sortedDtTb = _fullSrcData.DefaultView.ToTable())
                                    {
                                        //Iterate datatable then add found member to foundItems list:
                                        for (int i = 0; i < sortedDtTb.Rows.Count; i++)
                                        {
                                            for (int j = 0; j < sortedDtTb.Columns.Count; j++)
                                            {
                                                if (dbDataRead.GetName(j) == "Image")
                                                {
                                                    continue;
                                                }
                                                else
                                                {
                                                    string tempStr = sortedDtTb.Rows[i][j].ToString();

                                                    if (Regex.IsMatch(tempStr, matchPattern, RegexOptions.IgnoreCase))
                                                    {
                                                        Tuple<string, int, int> foundMember = new Tuple<string, int, int>(
                                                            curTbName, i, j);

                                                        foundItems.Add(foundMember);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //Show find result form:
                    if (foundItems.Count > 1)
                    {
                        //MessageBox.Show($"Found {foundItems.Count} item(s).", formOwner,
                        //       MessageBoxButtons.OK,
                        //       MessageBoxIcon.Information);

                        if (_findResForm == null)
                            _findResForm = new FindResFrm();
                        else if (_findResForm.IsDisposed == true)
                        {
                            //Clear old instance :
                            _findResForm = null;

                            //Create new instance :
                            _findResForm = new FindResFrm();
                        }

                        if (_findResForm.SetDataGridView(foundItems,findVal))
                        {
                            //Set this target listbox & datagridview for 'find result form':
                            _findResForm.TargetListBox = lstBox;
                            if (lstBox.Equals(productLbx))
                            {
                                _findResForm.TargetDataGrid = productDataGrid;
                            }
                            else if (lstBox.Equals(shapeLbx))
                            {
                                _findResForm.TargetDataGrid = shapeDataGrid;
                            }
                            else if (lstBox.Equals(colorLbx))
                            {
                                _findResForm.TargetDataGrid = colorDataGrid;
                            }
                            else
                            {
                                _findResForm.TargetDataGrid = null;
                            }

                            #region [Old codes]
                            //Set target listbox & datagridview.
                            //This is for user to activate later:
                            //if (!_findResForm.SetTargetActivate(ref lstBox,ref dataGrid))
                            //{
                            //    MessageBox.Show("Error: " + _findResForm.ErrorMessage,
                            //                                formOwner,
                            //                                MessageBoxButtons.OK,
                            //                                MessageBoxIcon.Error);

                            //    _findResForm.Dispose();
                            //    return;
                            //}
                            #endregion

                            //Show find result form:
                            if (_findResForm.Visible == false)
                            {
                                if(AcAp.ShowModalDialog(null, _findResForm, false) == DialogResult.Cancel)
                                {
                                    _findResForm.Dispose();
                                }
                            }
                            else
                            {
                                _findResForm.Activate();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error: " + _findResForm.ErrorMessage,
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                            _findResForm.Dispose();
                        }
                    }
                    else if(foundItems.Count == 1)
                    {
                        //Activate listbox's item :
                        lstBox.SelectedItem = foundItems[0].Item1;

                        //Set current datagridview :
                        System.Windows.Forms.DataGridView dataGrid;
                        if (lstBox.Equals(productLbx))
                        {
                            dataGrid = productDataGrid;
                        }
                        else if (lstBox.Equals(shapeLbx))
                        {
                            dataGrid = shapeDataGrid;
                        }
                        else if (lstBox.Equals(colorLbx))
                        {
                            dataGrid = colorDataGrid;
                        }
                        else
                        {
                            dataGrid = null;
                        }

                        if (dataGrid != null)
                        {
                            dataGrid.CurrentCell = dataGrid.Rows[foundItems[0].Item2].Cells[foundItems[0].Item3];
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot find value!", formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                    }

                    dbCon.Close();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, formOwner,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                return;
                //throw;
            }
        }

        private void FindAllPossibleValues_Modeless(object sender)
        {
            try
            {
                using (OleDbConnection dbCon = new OleDbConnection(conStr))
                {
                    dbCon.Open();

                    //List for found items:
                    System.Collections.Generic.List<Tuple<string, int, int>> foundItems =
                         new List<Tuple<string, int, int>>();

                    #region [Get source listbox & match pattern]
                    System.Windows.Forms.ListBox lstBox = null;     //Listbox contains table name to find
                    string findVal = "";                            //string to find
                    string matchPattern = "";                       //match pattern which is created from 'string to find'
                    bool findAll = true;                            //Find option => find in all tables or find in current table
                                                                    //  => apply for finding within FType's tables ONLY

                    //Get listbox & match pattern:
                    if (sender.Equals(findProductTbx))
                    {
                        lstBox = productLbx;

                        if (!string.IsNullOrEmpty(findProductTbx.Text))
                        {
                            findVal = findProductTbx.Text;
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }

                        if (proFindCurRad.Checked)
                        {
                            findAll = false;
                        }
                    }
                    else if (sender.Equals(productDataGrid) && productDataGrid.CurrentCell != null)
                    {
                        lstBox = shapeLbx;

                        if (!string.IsNullOrEmpty(productDataGrid.CurrentCell.Value.ToString()))
                        {
                            findVal = productDataGrid.CurrentCell.Value.ToString();
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }
                    }
                    else if (sender.Equals(findShapeTbx))
                    {
                        lstBox = shapeLbx;

                        if (!string.IsNullOrEmpty(findShapeTbx.Text))
                        {
                            findVal = findShapeTbx.Text;
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }
                    }
                    else if (sender.Equals(findColorTbx))
                    {
                        lstBox = colorLbx;

                        if (!string.IsNullOrEmpty(findColorTbx.Text))
                        {
                            findVal = findColorTbx.Text;
                            matchPattern = CommonCommands.GetMatchPattern(findVal);
                        }
                    }

                    //Check listbox:
                    if (lstBox == null || lstBox.Items == null
                        || lstBox.Items.Count == 0)
                    {
                        MessageBox.Show("Cannot get list box !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        dbCon.Close();
                        return;
                    }
                    else if (string.IsNullOrEmpty(findVal) ||
                        findVal == "-")
                    {
                        MessageBox.Show("Cannot get find value !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        dbCon.Close();
                        return;
                    }
                    else if (string.IsNullOrEmpty(matchPattern))
                    {
                        MessageBox.Show("Cannot get match pattern !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        dbCon.Close();
                        return;
                    }
                    #endregion

                    //Find all table name that match 'matchPattern' then into 'foundItems':
                    if (findAll) //Iterate all members in listbox:
                    {
                        foreach (var lbxItem in lstBox.Items)
                        {
                            if (lbxItem == null)
                            {
                                MessageBox.Show("Cannot read listbox's item !",
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                dbCon.Close();
                                return;
                            }

                            //Get current table name:
                            string curTbName = lbxItem.ToString();

                            //Query all data from access database:
                            using (OleDbCommand dbCmd = new OleDbCommand("select * from " + curTbName, dbCon))
                            using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                            {
                                if (dbDataRead.HasRows)
                                {
                                    //Create datatable:
                                    using (System.Data.DataTable _fullSrcData = new System.Data.DataTable())
                                    {
                                        //Add column:
                                        for (int i = 0; i < dbDataRead.FieldCount; i++)
                                        {
                                            //Add more column beside Shape no & material columns:
                                            _fullSrcData.Columns.Add(dbDataRead.GetName(i), dbDataRead.GetFieldType(i));
                                        }

                                        //Fill datatable with data from data reader:
                                        while (dbDataRead.Read())
                                        {
                                            object[] rowParams = new object[dbDataRead.FieldCount];
                                            for (int i = 0; i < rowParams.Length; i++)
                                            {
                                                rowParams[i] = dbDataRead[i];
                                            }

                                            _fullSrcData.Rows.Add(rowParams);
                                        }

                                        //Sort datagridview by its first column:
                                        //https://www.codeproject.com/Questions/219205/How-To-Sort-Datatable-in-csharp-net
                                        _fullSrcData.DefaultView.Sort = dbDataRead.GetName(0) + " ASC";
                                        using (System.Data.DataTable sortedDtTb = _fullSrcData.DefaultView.ToTable())
                                        {
                                            //Iterate datatable then add found member to foundItems list:
                                            for (int i = 0; i < sortedDtTb.Rows.Count; i++)
                                            {
                                                for (int j = 0; j < sortedDtTb.Columns.Count; j++)
                                                {
                                                    if (dbDataRead.GetName(j) == "Image")
                                                    {
                                                        continue;
                                                    }
                                                    else
                                                    {
                                                        string tempStr = sortedDtTb.Rows[i][j].ToString();

                                                        if (Regex.IsMatch(tempStr, matchPattern, RegexOptions.IgnoreCase))
                                                        {
                                                            Tuple<string, int, int> foundMember = new Tuple<string, int, int>(
                                                                curTbName, i, j);

                                                            foundItems.Add(foundMember);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else //Partial find : find in listbox's selected item ONLY
                    {
                        if (lstBox.SelectedItem == null)
                        {
                            MessageBox.Show("Cannot read current listbox's item !",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                            dbCon.Close();
                            return;
                        }

                        //Get current table name:
                        string curTbName = lstBox.SelectedItem.ToString();

                        //Query all data from access database:
                        using (OleDbCommand dbCmd = new OleDbCommand("select * from " + curTbName, dbCon))
                        using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                        {
                            if (dbDataRead.HasRows)
                            {
                                //Create datatable:
                                using (System.Data.DataTable _fullSrcData = new System.Data.DataTable())
                                {
                                    //Add column:
                                    for (int i = 0; i < dbDataRead.FieldCount; i++)
                                    {
                                        //Add more column beside Shape no & material columns:
                                        _fullSrcData.Columns.Add(dbDataRead.GetName(i), dbDataRead.GetFieldType(i));
                                    }

                                    //Fill datatable with data from data reader:
                                    while (dbDataRead.Read())
                                    {
                                        object[] rowParams = new object[dbDataRead.FieldCount];
                                        for (int i = 0; i < rowParams.Length; i++)
                                        {
                                            rowParams[i] = dbDataRead[i];
                                        }

                                        _fullSrcData.Rows.Add(rowParams);
                                    }

                                    //Sort datagridview by its first column:
                                    //https://www.codeproject.com/Questions/219205/How-To-Sort-Datatable-in-csharp-net
                                    _fullSrcData.DefaultView.Sort = dbDataRead.GetName(0) + " ASC";
                                    using (System.Data.DataTable sortedDtTb = _fullSrcData.DefaultView.ToTable())
                                    {
                                        //Iterate datatable then add found member to foundItems list:
                                        for (int i = 0; i < sortedDtTb.Rows.Count; i++)
                                        {
                                            for (int j = 0; j < sortedDtTb.Columns.Count; j++)
                                            {
                                                if (dbDataRead.GetName(j) == "Image")
                                                {
                                                    continue;
                                                }
                                                else
                                                {
                                                    string tempStr = sortedDtTb.Rows[i][j].ToString();

                                                    if (Regex.IsMatch(tempStr, matchPattern, RegexOptions.IgnoreCase))
                                                    {
                                                        Tuple<string, int, int> foundMember = new Tuple<string, int, int>(
                                                            curTbName, i, j);

                                                        foundItems.Add(foundMember);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //Show find result form:
                    if (foundItems.Count > 1)
                    {
                        //MessageBox.Show($"Found {foundItems.Count} item(s).", formOwner,
                        //       MessageBoxButtons.OK,
                        //       MessageBoxIcon.Information);

                        if (_findResForm == null)
                            _findResForm = new FindResFrm();
                        else if (_findResForm.IsDisposed == true)
                        {
                            //Clear old instance :
                            _findResForm = null;

                            //Create new instance :
                            _findResForm = new FindResFrm();
                        }

                        if (_findResForm.SetDataGridView(foundItems, findVal))
                        {
                            //Set this target listbox & datagridview for 'find result form':
                            _findResForm.TargetListBox = lstBox;
                            if (lstBox.Equals(productLbx))
                            {
                                _findResForm.TargetDataGrid = productDataGrid;
                            }
                            else if (lstBox.Equals(shapeLbx))
                            {
                                _findResForm.TargetDataGrid = shapeDataGrid;
                            }
                            else if (lstBox.Equals(colorLbx))
                            {
                                _findResForm.TargetDataGrid = colorDataGrid;
                            }
                            else
                            {
                                _findResForm.TargetDataGrid = null;
                            }

                            #region [Old codes]
                            //Set target listbox & datagridview.
                            //This is for user to activate later:
                            //if (!_findResForm.SetTargetActivate(ref lstBox,ref dataGrid))
                            //{
                            //    MessageBox.Show("Error: " + _findResForm.ErrorMessage,
                            //                                formOwner,
                            //                                MessageBoxButtons.OK,
                            //                                MessageBoxIcon.Error);

                            //    _findResForm.Dispose();
                            //    return;
                            //}
                            #endregion

                            //Show find result form:
                            if (_findResForm.Visible == false)
                            {
                                AcAp.ShowModelessDialog(null, _findResForm, false);
                            }
                            else
                            {
                                _findResForm.Activate();
                            }

                        }
                        else
                        {
                            MessageBox.Show("Error: " + _findResForm.ErrorMessage,
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                            _findResForm.Dispose();
                        }
                    }
                    else if (foundItems.Count == 1)
                    {
                        //Activate listbox's item :
                        lstBox.SelectedItem = foundItems[0].Item1;

                        //Set current datagridview :
                        System.Windows.Forms.DataGridView dataGrid;
                        if (lstBox.Equals(productLbx))
                        {
                            dataGrid = productDataGrid;
                        }
                        else if (lstBox.Equals(shapeLbx))
                        {
                            dataGrid = shapeDataGrid;
                        }
                        else if (lstBox.Equals(colorLbx))
                        {
                            dataGrid = colorDataGrid;
                        }
                        else
                        {
                            dataGrid = null;
                        }

                        if (dataGrid != null)
                        {
                            dataGrid.CurrentCell = dataGrid.Rows[foundItems[0].Item2].Cells[foundItems[0].Item3];
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cannot find value!", formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                    }

                    dbCon.Close();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, formOwner,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                return;
                //throw;
            }
        }

        private void FillDataToFindResult(ref string curTbName,ref string matchPattern
            , ref OleDbConnection dbCon,
              ref System.Collections.Generic.List<Tuple<string, int, int>> foundItems)
        {
            //Query all data from access database:
            using (OleDbCommand dbCmd = new OleDbCommand("select * from " + curTbName, dbCon))
            using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
            {
                if (dbDataRead.HasRows)
                {
                    //Create datatable:
                    using (System.Data.DataTable _fullSrcData = new System.Data.DataTable())
                    {
                        //Add column:
                        for (int i = 0; i < dbDataRead.FieldCount; i++)
                        {
                            //Add more column beside Shape no & material columns:
                            _fullSrcData.Columns.Add(dbDataRead.GetName(i), dbDataRead.GetFieldType(i));
                        }

                        //Fill datatable with data from data reader:
                        while (dbDataRead.Read())
                        {
                            object[] rowParams = new object[dbDataRead.FieldCount];
                            for (int i = 0; i < rowParams.Length; i++)
                            {
                                rowParams[i] = dbDataRead[i];
                            }

                            _fullSrcData.Rows.Add(rowParams);
                        }

                        //Sort datagridview by its first column:
                        //https://www.codeproject.com/Questions/219205/How-To-Sort-Datatable-in-csharp-net
                        _fullSrcData.DefaultView.Sort = dbDataRead.GetName(0) + " ASC";
                        using (System.Data.DataTable sortedDtTb = _fullSrcData.DefaultView.ToTable())
                        {
                            //Iterate datatable then add found member to foundItems list:
                            for (int i = 0; i < sortedDtTb.Rows.Count; i++)
                            {
                                for (int j = 0; j < sortedDtTb.Columns.Count; j++)
                                {
                                    if (dbDataRead.GetName(j) == "Image")
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        string tempStr = sortedDtTb.Rows[i][j].ToString();

                                        if (Regex.IsMatch(tempStr, matchPattern, RegexOptions.IgnoreCase))
                                        {
                                            Tuple<string, int, int> foundMember = new Tuple<string, int, int>(
                                                curTbName, i, j);

                                            foundItems.Add(foundMember);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }


        //Method to check file's path exist:
        private bool CheckPathExists(string path)
        {
            //https://stackoverflow.com/questions/26270873/check-if-file-or-folder-by-given-path-exists
            FileAttributes attributes;

            try
            {
                attributes = File.GetAttributes(path);
                switch (attributes)
                {
                    case FileAttributes.Directory:
                        if (Directory.Exists(path))
                            return true;
                        else
                            return false;

                    default:
                        if (File.Exists(path))
                            return true;
                        else
                            return false;
                }
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        //Method to make border of groupbox become invisible:
        private void PaintBorderlessGroupBox(object sender, PaintEventArgs p)
        {
            System.Windows.Forms.GroupBox box = (System.Windows.Forms.GroupBox)sender;
            p.Graphics.Clear(SystemColors.Control);
            p.Graphics.DrawString(box.Text, box.Font, Brushes.Black, 0, 0);
        }

        private void HideByModeless()
        {
            //Hide main form:
            this.Hide();

            // set focus to AutoCAD
            Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView();
        }

        private string GetUniqueName(string srcBlkName)
        {
            //Sample patterns:
            //string dateTime = System.DateTime.Now.ToString("yy/MM/dd/HH/mm/ss");  // => NG
            //string dateTime = System.DateTime.Now.ToString("yy_MM_dd_HH_mm_ss");  // => Ok
            //string dateTime = System.DateTime.Now.ToString("mm_ss");              // => Ok
            string suffix = System.DateTime.Now.ToString("yyMMddHHmmss");
            return srcBlkName + suffix;
        }
        #endregion

        #region [Properties]

        public bool IsReadyToShow
        {
            get { return _isReadyToshow; }
        }

        #endregion

        //Constructor:
        public KAInfoForm()
        {
            //Set links:
            if (!SettingLink())
            {
                return;
            }

            //Form set up:
            InitializeComponent();
            this.DoubleBuffered = true; //To improve load performance

            //Binding source:
            _productBindSrc = new BindingSource();
            _shapeBindSrc = new BindingSource();
            _colorBindSrc = new BindingSource();

            //Set up layout:
            mainTbPanel.SetColumnSpan(productDataGrid, 2);

            //Set find groupboxs' border to borderless:
            findShapeGrp.Paint += PaintBorderlessGroupBox;
            findColorGrp.Paint += PaintBorderlessGroupBox;

            #region [Set up buttons]
            Size smallSize = new Size(20, 20);

            settingBtn.Image = DialogFunctions.ResizeImage(AcadAddin.Properties.Resources.SettingLogo, smallSize);
            settingBtn.ImageAlign = ContentAlignment.MiddleLeft;
            settingBtn.TextAlign = ContentAlignment.MiddleRight;
            settingBtn.Width = 80;

            hideBtn.Image = DialogFunctions.ResizeImage(AcadAddin.Properties.Resources.HideLogo, smallSize);
            hideBtn.ImageAlign = ContentAlignment.MiddleLeft;
            hideBtn.TextAlign = ContentAlignment.MiddleRight;
            hideBtn.Width = 95;
            #endregion

            //Listbox :
            _productCache = "";
            _shapeCache = "";
            _colorCache = "";
            productLbx.HorizontalScrollbar = true;
            shapeLbx.HorizontalScrollbar = true;
            colorLbx.HorizontalScrollbar = true;

            //Datagrid :
            productDataGrid.SelectionMode = DataGridViewSelectionMode.CellSelect;
            shapeDataGrid.SelectionMode = DataGridViewSelectionMode.CellSelect;
            colorDataGrid.SelectionMode = DataGridViewSelectionMode.CellSelect;
            
            productDataGrid.MultiSelect = false;
            shapeDataGrid.MultiSelect = false;
            colorDataGrid.MultiSelect = false;

            productDataGrid.DataError += new DataGridViewDataErrorEventHandler(DataGrid_DataError);
            shapeDataGrid.DataError += new DataGridViewDataErrorEventHandler(DataGrid_DataError);
            colorDataGrid.DataError += new DataGridViewDataErrorEventHandler(DataGrid_DataError);

            productDataGrid.DataSource = _productBindSrc;
            shapeDataGrid.DataSource = _shapeBindSrc;
            colorDataGrid.DataSource = _colorBindSrc;

            //shapeDataGrid.SetFilterBuilderMode(AdvancedDataGridView.FilterBuilerMode.And);
            //colorDataGrid.SetFilterBuilderMode(AdvancedDataGridView.FilterBuilerMode.And);

            #region [Old codes]
            //productDataGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            //shapeDataGrid.RowHeadersWidthSizeMode = productDataGrid.RowHeadersWidthSizeMode;
            //colorDataGrid.RowHeadersWidthSizeMode = productDataGrid.RowHeadersWidthSizeMode;

            //shapeDataGrid.EnabledFilterChecklistNodesMax(false);
            //colorDataGrid.EnabledFilterChecklistNodesMax(false);
            //shapeDataGrid.GetColumnsFilteredStrings();
            #endregion

            #region [Tool tip's settings]
            //Set delay for tooltip (15 seconds):
            KAInfoTooltip.AutoPopDelay = 15000;

            //Add tooltip's informations:
            KAInfoTooltip.SetToolTip(settingBtn, "Edit tables.");

            KAInfoTooltip.SetToolTip(productLbx, "Fences' tables.");
            KAInfoTooltip.SetToolTip(shapeLbx, "Shapes' tables.");
            KAInfoTooltip.SetToolTip(colorLbx, "Colors' tables.");

            KAInfoTooltip.SetToolTip(findProductTbx, "Input fence code to find.");
            KAInfoTooltip.SetToolTip(findShapeTbx, "Input shape code to find.");
            KAInfoTooltip.SetToolTip(findColorTbx, "Input color code to find.");
            #endregion

            //Fill tables' name into listbox:
            try
            {
                using (OleDbConnection dbCon = new OleDbConnection(conStr))
                {
                    string[] restrictions = new string[4];
                    restrictions[3] = "Table";

                    dbCon.Open();

                    //Get list of user tables:
                    using (System.Data.DataTable userTables = dbCon.GetSchema("Tables", restrictions))
                    {
                        //List<string> tableNames = new List<string>();
                        for (int i = 0; i < userTables.Rows.Count; i++)
                        {
                            string tempStr = userTables.Rows[i][2].ToString();

                            if (tempStr.Contains(FenceTable))
                            {
                                productLbx.Items.Add(tempStr);
                            }
                            else if (tempStr.Contains(ShapeTable))
                            {
                                shapeLbx.Items.Add(tempStr);
                            }
                            else if (tempStr.Contains(ColorTable))
                            {
                                colorLbx.Items.Add(tempStr);
                            }
                        }
                    }

                    dbCon.Close();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, formOwner ,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                return;
            }

            //Set list box's value at '0' index:
            int initIndex = 0;
            if (productLbx.Items.Count > 0)
            {
                productLbx.SelectedIndex = initIndex;
                _productCache = productLbx.Items[initIndex].ToString();
                UpdateDataGridView(productDataGrid,_productCache);
            }

            if (shapeLbx.Items.Count > 0)
            {
                //https://stackoverflow.com/questions/6442098/how-to-clear-all-data-in-a-listbox
                //Sort item in listbox:
                #region [Sort items in listbox]
                try
                {
                    List<string> sortedList = new List<string>();
                    string[] separ = { "Shape", "_" };

                    for (int i = 0; i < shapeLbx.Items.Count - 1; i++)
                    {
                        for (int j = i + 1; j < shapeLbx.Items.Count; j++)
                        {
                            //Get this index:
                            int thisIndex;
                            string[] thisSplStrs = shapeLbx.Items[i].ToString().Split(separ,
                                                        StringSplitOptions.RemoveEmptyEntries);
                            if (thisSplStrs != null && thisSplStrs.Length > 1)
                            {
                                thisIndex = int.Parse(thisSplStrs[0]);
                            }
                            else
                            {
                                thisIndex = 0;
                            }

                            //Get next index:
                            int nextIndex;
                            string[] nextSplStrs = shapeLbx.Items[j].ToString().Split(separ, 
                                                        StringSplitOptions.RemoveEmptyEntries);
                            if (nextSplStrs != null && nextSplStrs.Length > 1)
                            {
                                nextIndex = int.Parse(nextSplStrs[0]);
                            }
                            else
                            {
                                nextIndex = 0;
                            }

                            //Swap if nescessary:
                            if (nextIndex < thisIndex)
                            {
                                object tempItem = shapeLbx.Items[i];
                                shapeLbx.Items[i] = shapeLbx.Items[j];
                                shapeLbx.Items[j] = tempItem;
                            }
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message, formOwner,
                      MessageBoxButtons.OK,
                      MessageBoxIcon.Error);
                    return;
                }

                #region [Old codes]
                //sortedList.Sort(new CustomStringComparer());
                //shapeLbx.DataSource = null;
                //shapeLbx.Items.Clear();

                //for (int i = 0; i < sortedList.Count; i++)
                //{
                //    shapeLbx.Items.Add(sortedList[i]);
                //}
                #endregion

                #endregion

                shapeKW = new List<string>();
                for (int i = 0; i < shapeLbx.Items.Count; i++)
                {
                    string[] splittedStrs = shapeLbx.Items[i].ToString().Split('_');
                    if (splittedStrs.Length == 2)
                    {
                        shapeKW.Add(splittedStrs[1]);
                    }
                }

                //shapeLbx.SelectedIndex = initIndex;
                _shapeCache = shapeLbx.Items[initIndex].ToString();
                //UpdateDataGridView(shapeDataGrid, _shapeCache);
            }

            if (colorLbx.Items.Count > 0)
            {
                colorKW = new List<string>();
                for (int i = 0; i < colorLbx.Items.Count; i++)
                {
                    string[] splittedStrs = colorLbx.Items[i].ToString().Split('_');
                    if (splittedStrs.Length == 2)
                    {
                        colorKW.Add(splittedStrs[1]);
                    }
                }

                //colorLbx.SelectedIndex = initIndex;
                _colorCache = colorLbx.Items[initIndex].ToString();
                //UpdateDataGridView(colorDataGrid, _colorCache);
            }

            //Mark this form is ready to show:
            _isReadyToshow = true;
        }

        //Handling Find menu's clicked:
        private void MenuToFind_Click(object sender, System.EventArgs e)
        {
            #region [Solution 1 - on hold]
            ////Activate shape tab:
            //if (detailTabs.SelectedTab != detailTabs.TabPages[0])
            //{
            //    detailTabs.SelectedTab = detailTabs.TabPages[0];
            //}

            //int currentCol = productDataGrid.CurrentCell.ColumnIndex;
            //string curHeaderTxt = productDataGrid.Columns[currentCol].HeaderText;
            //int matchIndex = 0;
            //for (int i = 0; i < shapeKW.Count; i++)
            //{
            //    if (curHeaderTxt.Contains(shapeKW[i]))
            //    {
            //        matchIndex = i;
            //        break;
            //    }
            //}

            //if (matchIndex != shapeLbx.SelectedIndex)
            //{
            //    shapeLbx.SelectedIndex = matchIndex;
            //}

            //string curTxt = productDataGrid.CurrentCell.Value.ToString();
            //List<string> invalidStr = new List<string>()
            //{
            //    "" ,"-", "Member"
            //};
            //if (!invalidStr.Contains(curTxt))
            //{
            //    FindValueInDataGrid(shapeDataGrid, curTxt);
            //}
            #endregion

            #region [Solution 2 - on running]

            //As this 'Menu' is designed for finding in Shape tables, so activate shape tab:
            if (detailTabs.SelectedTab != detailTabs.TabPages[0])
            {
                detailTabs.SelectedTab = detailTabs.TabPages[0];
            }

            FindAllPossibleValues(productDataGrid);

            #endregion

            #region [Old codes 1]
            //FindValueInDataGrid(shapeDataGrid, curTxt);

            //else
            //{
            //    FindValueInDataGrid(shapeDataGrid, curTxt);
            //}

            //string curShapeTb = shapeLbx.SelectedItem.ToString();

            //Match checkMatch = Regex.Match(curShapeTb, pattern);
            //if (checkMatch.Success)
            //{
            //    FindValueInDataGrid(shapeDataGrid, curTxt);
            //}
            //else
            //{
            //    MessageBox.Show("This feature is currently under development, " +
            //                    "please come back later!", formOwner,
            //                    MessageBoxButtons.OK,
            //                    MessageBoxIcon.Information);
            //}
            #endregion

            #region [Old codes 2]
            //if (curHeaderTxt.Contains("TopRail"))
            //{
            //    FindValueInDataGrid(shapeDataGrid, curTxt);
            //}
            //else if (curHeaderTxt.Contains("BotRail"))
            //{
            //    FindValueInDataGrid(shapeDataGrid, curTxt);
            //}
            //else
            //{
            //    MessageBox.Show("This feature is currently under development, " +
            //                    "please come back later!", formOwner,
            //                    MessageBoxButtons.OK,
            //                    MessageBoxIcon.Information);
            //}
            #endregion
        }

        //Handling OpenPDF menu's clicked:
        private void MenuToOpenPDF_Click(object sender,System.EventArgs e)
        {
            //Determine which tab is selected:
            DataGridView curDatagrid;
            if (detailTabs.SelectedTab == detailTabs.TabPages[0])
            {
                curDatagrid = shapeDataGrid;
            }
            else
            {
                curDatagrid = colorDataGrid;
            }

            //Determine datagrid contains 'Document' column:
            bool hasTechPage = false;
            int findCol = 0;
            for (int i = 0; i < curDatagrid.Columns.Count; i++)
            {
                if (curDatagrid.Columns[i].HeaderText.Contains("Document"))
                {
                    hasTechPage = true;
                    findCol = i;
                    break;
                }
            }

            if (!hasTechPage)
            {
                MessageBox.Show("No document found!", formOwner,
                      MessageBoxButtons.OK,
                      MessageBoxIcon.Stop);
                return;
            }
            else
            {
                try
                {
                    int curRow = curDatagrid.CurrentCell.RowIndex;
                    //int lastCol = shapeDataGrid.Columns.Count;

                    string pageToFind = curDatagrid.Rows[curRow].Cells[findCol].Value.ToString();

                    string[] splitStrs = pageToFind.Split('-');
                    int prePage = 1;
                    string docName = "";
                    if (splitStrs.Length == 2)
                    {
                        //Open database to read:
                        using (OleDbConnection dbCon = new OleDbConnection(conStr))
                        {
                            dbCon.Open();

                            using (OleDbCommand dbCmd = new OleDbCommand("select * from " + techDocsTb , dbCon))
                            using (OleDbDataReader dbDataRead = dbCmd.ExecuteReader())
                            {
                                //Read data:
                                while (dbDataRead.Read())
                                {
                                    if (dbDataRead[0].ToString() == splitStrs[0] && dbDataRead.FieldCount >= 3)
                                    {
                                        string prePageStr = dbDataRead[1].ToString();

                                        prePage = int.Parse(prePageStr);

                                        docName = dbDataRead[2].ToString();

                                        break;
                                    }
                                }

                                dbDataRead.Close();
                            }

                            dbCon.Close();
                        }

                        int pageIndex = int.Parse(splitStrs[1]) + prePage;
                        string pdfPath = assemblyFolder + "\\" + techDocsTb + "\\" + splitStrs[0] +
                            "\\" + docName;

                        //Test wrong path here:
                        if (!CheckPathExists(pdfPath))
                        {
                            MessageBox.Show("File's path doesn't exist!", formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                            return;
                        }

                        //Create new PDF viewer form:
                        if (_pdfForm == null)
                        {
                            _pdfForm = new PDFViewFrm();
                        }
                        else if (_pdfForm.IsDisposed == true)
                        {
                            //Clear old instance :
                            _pdfForm = null;

                            //Create new instance :
                            _pdfForm = new PDFViewFrm();
                        }

                        //Set source:
                        bool srcSet = false;

                        #region [Solution 1 - on hold(No memory safe)]
                        //srcSet = _pdfForm.SetSource(pdfPath, pageIndex);
                        //if (srcSet)
                        //{
                        //    //AcAp.ShowModalDialog(null, _pdfForm, false);
                        //    AcAp.ShowModalDialog(this.Handle, _pdfForm, false);
                        //}
                        //else
                        //{
                        //    _pdfForm.Dispose();
                        //}
                        #endregion

                        byte[] bytes = System.IO.File.ReadAllBytes(pdfPath);
                        using (MemoryStream stream = new MemoryStream(bytes))
                        {
                            srcSet = _pdfForm.SetSource(stream, pageIndex);
                            if (srcSet)
                            {
                                AcAp.ShowModalDialog(this.Handle, _pdfForm, false);
                            }
                            else
                            {
                                _pdfForm.Dispose();
                            }
                        }

                        #region [Old codes]

                        //if (_pdfForm.IsReadyToShow)
                        //{
                        //    //AcAp.ShowModalDialog(null, _pdfForm, false);
                        //    AcAp.ShowModalDialog(this.Handle, _pdfForm, false);
                        //}
                        //else
                        //{
                        //    _pdfForm.Dispose();
                        //}

                        #endregion
                    }
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message, formOwner,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                    return;
                }
            }
        }

        private void MenuToChangeSize_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (mainTbPanel.GetRowSpan(detailTabs) == 1)
                {
                    mainTbPanel.SetColumnSpan(productDataGrid, 1);
                    mainTbPanel.SetRowSpan(detailTabs, 2);
                }
                else
                {
                    mainTbPanel.SetColumnSpan(productDataGrid, 2);
                    mainTbPanel.SetRowSpan(detailTabs, 1);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message , formOwner,
                          MessageBoxButtons.OK,
                          MessageBoxIcon.Information);
            }
        }

        private void MenuToClearFilter_Click(object sender, System.EventArgs e)
        {
            Zuby.ADGV.AdvancedDataGridView avDataGrid;
            //BindingSource tempBindSrc;
            //ListBox linkedLbx;

            if (detailTabs.SelectedTab == detailTabs.TabPages[0])
            {
                avDataGrid = shapeDataGrid;
                //linkedLbx = shapeLbx;
                //tempBindSrc = _shapeBindSrc;
            }
            else
            {
                avDataGrid = colorDataGrid;
                //linkedLbx = colorLbx;
                //tempBindSrc = _colorBindSrc;
            }

            avDataGrid.CleanFilterAndSort();

            //tempBindSrc.Sort = "";
            //if (avDataGrid.FilterString.Length > 0)
            //{
            //    UpdateDataGridView(avDataGrid, linkedLbx.SelectedItem.ToString());
            //}
        }

        private void MenuToInsertShape_Click(object sender, System.EventArgs e)
        {
            //MessageForBeingBuildedModule();

            //Get folder path (...//StdShape):
            string folderPath = assemblyFolder + "\\" + CommonDeclaration.CadLib_Path +
                                "\\StdShape";

            string fileExt = ".dwg";

            //Get current DataGridView cell's value:
            string filePath;
            if (_curDataGridView == null || _curDataGridView.CurrentCell == null)
            {
                MessageBox.Show(CommonMessage.LOST_REF_TO("data"),
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                return;
            }
            else
            {
                filePath = folderPath + "\\" + _curDataGridView.CurrentCell.Value.ToString() + fileExt;
            }

            //Check file existence:
            if (!System.IO.File.Exists(filePath))
            {
                MessageBox.Show(CommonMessage.OBJECT_NOT_EXIST("data", true),
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                return;
            }
            else
            {
                HideByModeless();

                Document doc = AcAp.DocumentManager.MdiActiveDocument;
                Database db = doc.Database;
                Editor ed = doc.Editor;

                using (doc.LockDocument())
                {
                    //List system variable need to reset:
                    List<KeyValuePair<string, object>> resetList = new List<KeyValuePair<string, object>>()
                    {
                        new KeyValuePair<string, object>("ORTHOMODE",0),
                        new KeyValuePair<string, object>("CMDECHO",0)
                    };

                    //using (Transaction baseTr = db.TransactionManager.StartOpenCloseTransaction()) //Use this to roll back all
                    using (KRResetSystemVar myReset = new KRResetSystemVar(resetList))
                    {
                        string blkNameForInsertBlkRef = _curDataGridView.CurrentCell.Value.ToString() + fileExt;

                        //Check whether current document has duplicate BlockDefinition:
                        //If duplicate is found, try another block name:
                        try
                        {
                            using (Transaction curTr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = curTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                                if (bt.Has(blkNameForInsertBlkRef))
                                {
                                    blkNameForInsertBlkRef = GetUniqueName(blkNameForInsertBlkRef);
                                }

                                curTr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            return;
                        }

                        //Create new block definition.
                        //Then fill it with data from outer database:
                        ObjectId outerDbId = ObjectId.Null;
                        try
                        {
                            using (Database srcDb = new Database(false, true))
                            {
                                srcDb.ReadDwgFile(filePath, FileOpenMode.OpenForReadAndAllShare, true, "");

                                outerDbId = db.Insert(blkNameForInsertBlkRef, srcDb, true);

                                //Check outer database Id:
                                if (outerDbId == ObjectId.Null)
                                {
                                    MessageBox.Show(CommonMessage.FAIL_TO_DO("insert", "database", true),
                                                    formOwner,
                                                    MessageBoxButtons.OK,
                                                    MessageBoxIcon.Error);
                                    return;
                                }
                            }
                        }
                        catch (System.Exception ex)
                        {
                            MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            return;
                        }

                        //Add block reference:
                        try
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                                //Get current space:
                                BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                                //Create new instance of block reference:
                                BlockReference blkRef = new BlockReference(Point3d.Origin, bt[blkNameForInsertBlkRef]);

                                //double scaleFactor = System.Convert.ToDouble(scaleTbx.Text);
                                double scaleFactor = 1.0;

                                blkRef.ScaleFactors = new Scale3d(scaleFactor, scaleFactor, scaleFactor);
                                blkRef.TransformBy(ed.CurrentUserCoordinateSystem);

                                //Add it to database TEMPORARILY <= must do this for jigging attributes:
                                btr.AppendEntity(blkRef);
                                tr.AddNewlyCreatedDBObject(blkRef, true);

                                //Get block definition:
                                BlockTableRecord blkDef;
                                if (blkRef.IsDynamicBlock)
                                {
                                    blkDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                }
                                else
                                {
                                    blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                }

                                //This is used for what ???
                                if (blkDef.Annotative == AnnotativeStates.True)
                                {
                                    ObjectContextManager ocm = db.ObjectContextManager;
                                    ObjectContextCollection occ = ocm.GetContextCollection(contextCollectionName);
                                    blkRef.AddContext(occ.CurrentContext);
                                }

                                //Copy attributes from BlockDef => BlockRef:
                                Dictionary<AttributeReference, AttributeDefinition> dict =
                                    new Dictionary<AttributeReference, AttributeDefinition>();
                                if (blkDef.HasAttributeDefinitions)
                                {
                                    RXClass rxClass = RXClass.GetClass(typeof(AttributeDefinition));
                                    foreach (ObjectId id in blkDef)
                                    {
                                        if (id.ObjectClass == rxClass)
                                        {
                                            DBObject obj = tr.GetObject(id, OpenMode.ForRead);

                                            AttributeDefinition ad = obj as AttributeDefinition;
                                            AttributeReference ar = new AttributeReference();
                                            ar.SetAttributeFromBlock(ad, blkRef.BlockTransform);

                                            ////Ask user to input content for attributes:
                                            //ar.TextString = BlockAttributeJig.CollectAttributeText(ad);

                                            blkRef.AttributeCollection.AppendAttribute(ar);
                                            tr.AddNewlyCreatedDBObject(ar, true);

                                            dict.Add(ar, ad);
                                        }
                                    }
                                }

                                //Start jigging:
                                if (BlockAttributeJig.Jig(blkRef, dict))
                                {
                                    //Get all ObjectIds inside BlockTableRecord:
                                    ObjectIdCollection ids = new ObjectIdCollection();
                                    foreach (ObjectId id in blkDef)
                                    {
                                        if (id != ObjectId.Null && !ids.Contains(id))
                                        {
                                            ids.Add(id);
                                        }
                                    }

                                    //Create new mapping for deepclone:
                                    IdMapping mapping = new IdMapping();

                                    //Deepclone all entites inside BlockDefinition to BlockReference's owner:
                                    blkRef.Database.DeepCloneObjects(ids, blkRef.OwnerId, mapping, false);

                                    //Iterate and transform entities:
                                    foreach (IdPair pair in mapping)
                                    {
                                        if (pair.IsCloned && pair.IsPrimary)
                                        {
                                            DBObject tempDbObj = pair.Value.GetObject(OpenMode.ForWrite);
                                            if (tempDbObj != null && tempDbObj is Entity tempEnt)
                                            {
                                                tempEnt.TransformBy(blkRef.BlockTransform);
                                            }
                                        }
                                    }

                                    //"\nInsert is successful.\n"
                                    ed.WriteMessage("\n" + CommonMessage.GetStringFromCurResx("INSERT_SUCCESS") + "\n");
                                }

                                //Delete block reference:
                                blkRef.Erase(true);

                                blkDef.UpgradeOpen();
                                blkDef.Erase(true);

                                //Commit changes:
                                tr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            return;
                        }
                    }
                }
            }
        }

        ////Print message for being builded module:
        //private void MessageForBeingBuildedModule()
        //{
        //    MessageBox.Show(CommonMessage.GetStringFromCurResx("MODULE_ON_BUILD") +
        //                    "\n" + CommonMessage.GetStringFromCurResx("BACK_LATER"),
        //                    formOwner,
        //                    MessageBoxButtons.OK,
        //                    MessageBoxIcon.Information);
        //}

        //All datagridviews mouse click:
        private void DataGridView_MouseClick(object sender, MouseEventArgs e)
        {
            //https://stackoverflow.com/questions/1718389/right-click-context-menu-for-datagridview
            //https://stackoverflow.com/questions/34770756/add-click-event-to-menu-item
            //https://stackoverflow.com/questions/8931442/working-with-system-icons-in-c-sharp-application
            //https://stackoverflow.com/questions/6623672/how-to-put-an-icon-in-a-menuitem

            DataGridView dataGrid = sender as DataGridView;

            if (dataGrid.Equals(productDataGrid) && mainTbPanel.GetRowSpan(detailTabs) == 2)
            {
                MenuToChangeSize_Click(sender, e);
            }

            if (dataGrid.Equals(productDataGrid) && e.Button == MouseButtons.Right)
            {
                DataGridView.HitTestInfo hitInfo = dataGrid.HitTest(e.X, e.Y);
                if (hitInfo.RowIndex >= 0 && hitInfo.ColumnIndex >= 0) //skip when user click on header column or header row
                {
                    dataGrid.CurrentCell = dataGrid[hitInfo.ColumnIndex, hitInfo.RowIndex];

                    #region [Old codes]
                    ////Create menu:
                    //ContextMenu m = new ContextMenu();
                    //m.MenuItems.Add(new MenuItem("Find this", MenuToFind_Click));

                    ////Show menu on datagrid:
                    //m.Show(dataGrid, new Point(e.X, e.Y));
                    #endregion
                    ContextMenuStrip cms = new ContextMenuStrip();
                    cms.Items.Add(new ToolStripMenuItem("Find this", Properties.Resources.FindLogo,
                                                                    MenuToFind_Click));

                    cms.Items.Add(new ToolStripMenuItem("Hide form", Properties.Resources.HideLogo,
                                                                    HideBtn_Click));

                    //Show menu on datagrid:
                    cms.Show(dataGrid, new Point(e.X, e.Y));
                }
            }
            else if ((dataGrid.Equals(shapeDataGrid) || dataGrid.Equals(colorDataGrid)) && e.Button == MouseButtons.Right)
            {
                DataGridView.HitTestInfo hitInfo = dataGrid.HitTest(e.X, e.Y);
                if (hitInfo.RowIndex >=0 && hitInfo.ColumnIndex >= 0) //skip when user click on header column or header row
                {
                    dataGrid.CurrentCell = dataGrid[hitInfo.ColumnIndex, hitInfo.RowIndex];

                    ContextMenuStrip cms = new ContextMenuStrip();
                    
                    //Add open PDF button:
                    cms.Items.Add(new ToolStripMenuItem("Open PDF", AcadAddin.Properties.Resources.PDFLogo,
                                                                    MenuToOpenPDF_Click));

                    //Add size change button:
                    string sizeChangeType;
                    Bitmap sizeImg;
                    if (mainTbPanel.GetRowSpan(detailTabs) == 1)
                    {
                        sizeChangeType = "Expand";
                        sizeImg = AcadAddin.Properties.Resources.MaximizeLogo;
                    }
                    else
                    {
                        sizeChangeType = "Shrink";
                        sizeImg = AcadAddin.Properties.Resources.MinimizeLogo;
                    }
                    cms.Items.Add(new ToolStripMenuItem(sizeChangeType , sizeImg,
                                                                         MenuToChangeSize_Click));

                    cms.Items.Add(new ToolStripMenuItem("Clear all filters", AcadAddin.Properties.Resources.ClearFilterLogo,
                                                                        MenuToClearFilter_Click));

                    if (dataGrid.Columns[hitInfo.ColumnIndex].Name == "Shape No")
                    {
                        //Store current DataGridView:
                        _curDataGridView = dataGrid;

                        //Add insert Shape button:
                        cms.Items.Add(new ToolStripMenuItem("Insert shape", AcadAddin.Properties.Resources.InsertDwgIcon,
                                                                            MenuToInsertShape_Click));
                    }

                    //Add hide button:
                    cms.Items.Add(new ToolStripMenuItem("Hide form", Properties.Resources.HideLogo,
                                                                     HideBtn_Click));

                    //Show menu on datagrid:
                    cms.Show(dataGrid, new Point(e.X, e.Y));
                }
            }
        }

        //All datagridviews' cell on left click:
        private void DataCell_OnClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dataGrid = sender as DataGridView;

            if (dataGrid.SelectionMode != DataGridViewSelectionMode.CellSelect)
            {
                dataGrid.SelectionMode = DataGridViewSelectionMode.CellSelect;
                dataGrid.CurrentCell.Selected = true;
            }
        }

        //All listbox on selected change:
        private void TypeLbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.ListBox senderLbx = (System.Windows.Forms.ListBox)sender;

            //Prevent clicking on nothing in listbox:
            if (senderLbx == null || senderLbx.SelectedItem == null)
            {
                return;
            }

            string curItem = senderLbx.SelectedItem.ToString();

            if (senderLbx.Equals(productLbx))
            {
                if (_productCache != "")
                {
                    _productCache = curItem;
                    UpdateDataGridView(productDataGrid, _productCache);
                }
            }
            else if (senderLbx.Equals(shapeLbx))
            {
                if (_shapeCache != "")
                {
                    _shapeCache = curItem;
                    shapeDataGrid.CleanFilterAndSort();
                    UpdateDataGridView(shapeDataGrid, _shapeCache);
                }
            }
            else if (senderLbx.Equals(colorLbx))
            {
                if (_colorCache != "")
                {
                    _colorCache = curItem;
                    colorDataGrid.CleanFilterAndSort();
                    UpdateDataGridView(colorDataGrid, _colorCache);
                }
            }
        }

        //Product find textbox on keydown:
        private void ProFindTbx_KeyDown(object sender, KeyEventArgs e)
        {
            #region [Solution 1 - common using - on hold]
            //TextBox senderTbx = (TextBox)sender;

            //if (e.KeyCode == Keys.Enter)
            //{
            //    DataGridView dataToFind;

            //    if (senderTbx.Equals(findProductTbx))
            //    {
            //        dataToFind = productDataGrid;
            //    }
            //    else
            //    {
            //        dataToFind = shapeDataGrid;
            //    }

            //    FindValueInDataGrid(dataToFind, senderTbx.Text);

            //    e.Handled = true;

            //    e.SuppressKeyPress = true; //No beep ^^
            //}
            #endregion

            if (e.KeyCode == Keys.Enter)
            {
                #region [Solution 1 - on hold]
                //System.Windows.Forms.TextBox senderTbx = (System.Windows.Forms.TextBox)sender;
                //if (proFindCurRad.Checked)
                //{
                //    FindValueInDataGrid(productDataGrid, senderTbx.Text);
                //    e.Handled = true;
                //    e.SuppressKeyPress = true; //No beep ^^
                //}
                //else
                //{
                //    if (FindValueInDataGrid(sender as System.Windows.Forms.TextBox, productLbx, productDataGrid))
                //    {
                //        e.Handled = true;
                //        e.SuppressKeyPress = true; //No beep ^^
                //    }
                //}
                #endregion

                //Solution 2 - on running :
                FindAllPossibleValues(findProductTbx);
                e.Handled = true;
                e.SuppressKeyPress = true; //No beep ^^
            }
        }

        //Shape find textbox on keydown:
        private void ShapeFindTbx_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                #region [Solution 1 - on hold]
                //if (FindValueInDataGrid(sender as System.Windows.Forms.TextBox, shapeLbx, shapeDataGrid))
                //{
                //    e.Handled = true;
                //    e.SuppressKeyPress = true; //No beep ^^
                //}
                #endregion

                //Solution 2 - on running :
                FindAllPossibleValues(findShapeTbx);
                e.Handled = true;
                e.SuppressKeyPress = true; //No beep ^^
            }
        }

        //Color find textbox on keydown:
        private void ColorFindTbx_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                #region [Solution 1 - on hold]
                //if (FindValueInDataGrid(sender as System.Windows.Forms.TextBox, colorLbx, colorDataGrid))
                //{
                //    e.Handled = true;
                //    e.SuppressKeyPress = true; //No beep ^^
                //}
                #endregion

                //Solution 2 - on running :
                FindAllPossibleValues(findColorTbx);
                e.Handled = true;
                e.SuppressKeyPress = true; //No beep ^^
            }
        }

        //All find text box on focus:
        private void FindTbx_OnFocus(object sender, EventArgs e)
        {
            System.Windows.Forms.TextBox textBox = (System.Windows.Forms.TextBox)sender;
            textBox.SelectAll();
        }

        //Hide form:
        private void HideBtn_Click(object sender, EventArgs e)
        {
            HideByModeless();
        }

        //https://stackoverflow.com/questions/52709414/c-sharp-using-advanced-datagridview-adgv-filter-without-bindingsource
        //https://github.com/zzzprojects/System.Linq.Dynamic
        private void AvDataGrid_FilterStringChanged(object sender, AdvancedDataGridView.FilterEventArgs e)
        {
            #region [Old codes
            //AdvancedDataGridView avDataGrid = sender as AdvancedDataGridView;

            //DataTable dt = null;

            ////if (_fullSrcData == null)
            ////{
            ////    _fullSrcData = (DataTable)avDataGrid.DataSource;
            ////}

            //if (avDataGrid.FilterString.Length > 0)
            //{
            //    dt = (DataTable)avDataGrid.DataSource;
            //}
            //else//Clear Filter
            //{
            //    dt = _fullSrcData;
            //}

            //avDataGrid.DataSource = dt.Select(avDataGrid.FilterString).CopyToDataTable();
            #endregion

            #region [Old codes]
            //if (_fullSrcData != null)
            //{
            //    AdvancedDataGridView avDataGrid = sender as AdvancedDataGridView;

            //    string criteria = avDataGrid.FilterString;

            //    avDataGrid.DataSource = _fullSrcData.Select(criteria).CopyToDataTable();
            //}
            #endregion

            AdvancedDataGridView avDataGrid = sender as AdvancedDataGridView;
            if (avDataGrid.Equals(shapeDataGrid))
            {
                _shapeBindSrc.Filter = avDataGrid.FilterString;
            }
            else
            {
                _colorBindSrc.Filter = avDataGrid.FilterString;
            }

            DataGrid_SrcChanged(sender, e);
        }

        private void AvDataGrid_SortStrChanged(object sender, AdvancedDataGridView.SortEventArgs e)
        {
            #region [Old codes]
            //AdvancedDataGridView avDataGrid = sender as AdvancedDataGridView;

            //DataTable dt = null;

            ////if (_fullSrcData == null)
            ////{
            ////    _fullSrcData = (DataTable)avDataGrid.DataSource;
            ////}

            //if (avDataGrid.SortString.Length > 0)
            //{
            //    dt = (DataTable)avDataGrid.DataSource;
            //}
            //else//Clear Filter
            //{
            //    dt = _fullSrcData;
            //}

            //avDataGrid.DataSource = dt.Select(avDataGrid.SortString).CopyToDataTable();
            #endregion

            #region [Old codes
            //if (_fullSrcData != null)
            //{
            //    AdvancedDataGridView avDataGrid = sender as AdvancedDataGridView;

            //    string criteria = avDataGrid.SortString;

            //    avDataGrid.DataSource = _fullSrcData.Select(criteria).CopyToDataTable();
            //}
            #endregion

            AdvancedDataGridView avDataGrid = sender as AdvancedDataGridView;
            if (avDataGrid.Equals(shapeDataGrid))
            {
                _shapeBindSrc.Sort = avDataGrid.SortString;
            }
            else
            {
                _colorBindSrc.Sort = avDataGrid.SortString;
            }

            DataGrid_SrcChanged(sender, e);
        }

        //All datagridviews on datasource changed:
        private void DataGrid_SrcChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.Label targetLbl;

            if (sender.Equals(productDataGrid))
            {
                targetLbl = productTotalRowsLbl;
            }
            else if (sender.Equals(shapeDataGrid))
            {
                targetLbl = shapeTotalRowsLbl;
            }
            else
            {
                targetLbl = colorTotalRowsLbl;
            }

            targetLbl.Text = string.Format("Total rows : {0}", (sender as DataGridView).RowCount);

            #region [Old codes]
            ////Disable filter & sort for iamge column (shape datagrid / color datagrid ONLY):
            //if (sender.Equals(shapeDataGrid) || sender.Equals(colorDataGrid))
            //{
            //    AdvancedDataGridView avDataGrid = sender as AdvancedDataGridView;

            //    foreach (DataGridViewColumn col in avDataGrid.Columns)
            //    {
            //        if (col is DataGridViewImageColumn imgCol)
            //        {
            //            avDataGrid.DisableFilterAndSort(imgCol);
            //        }
            //    }
            //}
            #endregion
        }

        private void DataGrid_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }
    }

    public class CustomSearcher
    {
        public static List<string> GetDirectories(string path, string searchPattern = "*",
            SearchOption searchOption = SearchOption.AllDirectories)
        {
            if (searchOption == SearchOption.TopDirectoryOnly)
                return Directory.GetDirectories(path, searchPattern).ToList();

            var directories = new List<string>(GetDirectories(path, searchPattern));

            for (var i = 0; i < directories.Count; i++)
                directories.AddRange(GetDirectories(directories[i], searchPattern));

            return directories;
        }

        private static List<string> GetDirectories(string path, string searchPattern)
        {
            try
            {
                return Directory.GetDirectories(path, searchPattern).ToList();
            }
            catch (UnauthorizedAccessException)
            {
                return new List<string>();
            }
        }
    }

    #region [Old codes]

    //class DataGridViewSpeedUp : KRDispose
    //{
    //    bool _NeedToReleaseAgain = false;
    //    readonly DataGridView dataGrid = null;
    //    readonly DockStyle oldDock;
    //    readonly DataGridViewAutoSizeColumnsMode oldColsMode;
    //    readonly DataGridViewAutoSizeRowsMode oldRowsMode;

    //    public DataGridViewSpeedUp(DataGridView oDataGrid)
    //    {
    //        dataGrid = oDataGrid;

    //        //Set datargid's source:
    //        //We add some setting here to improve datagrid loading's performance:
    //        //https://stackoverflow.com/questions/10226992/slow-performance-in-populating-datagridview-with-large-data
    //        oldDock = dataGrid.Dock;
    //        oldColsMode = dataGrid.AutoSizeColumnsMode;
    //        oldRowsMode = dataGrid.AutoSizeRowsMode;
    //        //DataGridViewColumnHeadersHeightSizeMode oldColResizing = dataGrid.ColumnHeadersHeightSizeMode;

    //        dataGrid.Dock = DockStyle.None;
    //        dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
    //        dataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
    //        //dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
    //        dataGrid.SuspendLayout();
    //    }

    //    protected override void DisposeMangaged()
    //    {
    //        if (_NeedToReleaseAgain)
    //        {
    //            dataGrid.AutoSizeColumnsMode = oldColsMode;
    //            dataGrid.AutoSizeRowsMode = oldRowsMode;
    //            //dataGrid.ColumnHeadersHeightSizeMode = oldColResizing;
    //            dataGrid.Dock = oldDock;
    //            dataGrid.ResumeLayout();
    //        }
    //    }
    //}

    #endregion
}

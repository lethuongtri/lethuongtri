// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- TEP9KDlg.cpp : Implementation of TEP9KDlg
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "resource.h"
#include "TEP9KDlg.h"

//-----------------------------------------------------------------------------
IMPLEMENT_DYNAMIC (TEP9KDlg, CAdUiBaseDialog)

BEGIN_MESSAGE_MAP(TEP9KDlg, CAdUiBaseDialog)
	ON_MESSAGE(WM_ACAD_KEEPFOCUS, OnAcadKeepFocus)
	//ON_EN_KILLFOCUS(IDC_EDIT_DIA, &TEP9KDlg::OnKillfocusEditDia)
	//ON_EN_KILLFOCUS(IDC_EDIT_SEG, &TEP9KDlg::OnKillfocusEditSeg)
	//ON_EN_KILLFOCUS(IDC_EDIT_SLOPE, &TEP9KDlg::OnKillfocusEditSlope)
	//ON_BN_CLICKED(IDCANCEL, &TEP9KDlg::OnCancelClick)+
	ON_WM_CLOSE()
END_MESSAGE_MAP()

//-----------------------------------------------------------------------------
TEP9KDlg::TEP9KDlg (CWnd *pParent /*=NULL*/, HINSTANCE hInstance /*=NULL*/) : 
	CAdUiBaseDialog (TEP9KDlg::IDD, pParent, hInstance)
{
	/*if (!TEP9KInfo.m_strDiaTemp.IsEmpty())
	{
		m_strDia = TEP9KInfo.m_strDiaTemp;
		TEP9KInfo.m_strDiaTemp = _T("");
	}
	else
	{
		m_strDia = _T("90.0");
	}

	if (!TEP9KInfo.m_strSegTemp.IsEmpty())
	{
		m_strSeg = TEP9KInfo.m_strSegTemp;
		TEP9KInfo.m_strSegTemp = _T("");
	}
	else
	{
		m_strSeg = _T("16");
	}

	if (!TEP9KInfo.m_strSlopeTemp.IsEmpty())
	{
		m_strSlope = TEP9KInfo.m_strSlopeTemp;
		TEP9KInfo.m_strSlopeTemp = _T("");
	}
	else
	{
		m_strSlope = _T("50.0");
	}*/

	//m_strDia = _T("");
	//m_strSeg = _T("");
	//m_strSlope = _T("");
	//m_bClosing = false;

	m_bIsClosing = false;
}

//-----------------------------------------------------------------------------
void TEP9KDlg::DoDataExchange (CDataExchange *pDX) 
{
	CAdUiBaseDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_DIA, m_ctrlEdDia);
	DDX_Control(pDX, IDC_EDIT_SEG, m_ctrlEdSeg);
	DDX_Control(pDX, IDC_EDIT_SLOPE, m_ctrlEdSlope);
}

//-----------------------------------------------------------------------------
//----- Needed for modeless dialogs to keep focus.
//----- Return FALSE to not keep the focus, return TRUE to keep the focus
LRESULT TEP9KDlg::OnAcadKeepFocus (WPARAM, LPARAM) 
{
	return (TRUE) ;
}

BOOL TEP9KDlg::OnInitDialog()
{
	CAdUiBaseDialog::OnInitDialog();

	if (TEP9KInfo.m_bDataIsValid)
	{
		// TODO:  Add extra initialization here
		CString temp;
		int bufLen = 80;

		acdbRToS(TEP9KInfo.m_dDiameter, 2, 2, temp.GetBuffer(bufLen), bufLen);
		m_ctrlEdDia.SetWindowTextW(temp);

		acdbRToS(TEP9KInfo.m_dSlope, 2, 2, temp.GetBuffer(bufLen), bufLen);
		m_ctrlEdSlope.SetWindowTextW(temp);

		acdbRToS((ads_real)TEP9KInfo.m_nSegment, 2, 2, temp.GetBuffer(bufLen), bufLen);
		m_ctrlEdSeg.SetWindowTextW(temp);
	}
	else
	{
		m_ctrlEdDia.SetWindowTextW(TEP9KInfo.m_strDiaTemp);
		m_ctrlEdSeg.SetWindowTextW(TEP9KInfo.m_strSegTemp);
		m_ctrlEdSlope.SetWindowTextW(TEP9KInfo.m_strSlopeTemp);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

void TEP9KDlg::OnOK()
{
	// TODO: Add your specialized code here and/or call the base class
	if (!CheckInput())
	{
		/*CAdUiBaseDialog::OnCancel();*/
		return;
	}

	updateGlobalData(true);
	//TEP9KInfo.m_bProcessing = false;
	CAdUiBaseDialog::OnOK();
}

//void TEP9KDlg::OnCancelClick()
//{
//	
//}

void TEP9KDlg::OnCancel()
{
	/*TEP9KInfo.m_bProcessing = true;
	m_ctrlEdDia.GetWindowTextW(TEP9KInfo.m_strDiaTemp);
	m_ctrlEdSeg.GetWindowTextW(TEP9KInfo.m_strSegTemp);
	m_ctrlEdSlope.GetWindowTextW(TEP9KInfo.m_strSlopeTemp);*/

	/*TEP9KInfo.m_strDiaTemp = m_strDia;
	TEP9KInfo.m_strSegTemp = m_strSeg;
	TEP9KInfo.m_strSlopeTemp = m_strSlope;*/

	if (m_bIsClosing)
	{
		TEP9KInfo.ResetData();
	}
	else
	{
		updateGlobalData(false);
	}

	CAdUiBaseDialog::OnCancel();
}

//void TEP9KDlg::OnDestroy()
//{
//	//Clear all temp strings:
//
//	CAdUiBaseDialog::OnDestroy();
//}

void TEP9KDlg::OnClose()
{
	/*TEP9KInfo.m_bProcessing = false;
	TEP9KInfo.m_dDiameter = 90.0;
	TEP9KInfo.m_nSegment = 16;
	TEP9KInfo.m_dSlope = 50.0;
	TEP9KInfo.m_strDiaTemp = _T("");
	TEP9KInfo.m_strSegTemp = _T("");
	TEP9KInfo.m_strSlopeTemp = _T("");*/

	m_bIsClosing = true;

	CAdUiBaseDialog::OnClose();
}

//void TEP9KDlg::OnSysCommand(UINT nID, LPARAM lParam)
//{
//	if ((nID & 0xFFF0) == SC_CLOSE)
//	{
//		//AfxMessageBox(_T("User clicked the X button"));
//		TEP9KInfo.ResetData();
//		CAdUiBaseDialog::OnCancel(); // or EndDialog(IDCANCEL);
//	}
//	else
//	{
//		CAdUiBaseDialog::OnSysCommand(nID, lParam);
//	}
//}

void TEP9KDlg::OnKillfocusEditDia()
{
	//// TODO: Add your control notification handler code here
	//if (m_bClosing)
	//	return;

	//m_ctrlEdDia.Convert();
	//if (!m_ctrlEdDia.Validate())
	//{
	//	::AfxMessageBox(_T("Invalid data type.Must be a float number!"));
	//	m_ctrlEdDia.SetFocus();
	//	m_ctrlEdDia.SetSel(0, -1);
	//}
	//else
	//{
	//	updateGlobalData();
	//	if (TEP9KInfo.m_dDiameter < 0)
	//	{
	//		::AfxMessageBox(_T("Diameter cannot is a minus number!"));
	//		m_ctrlEdDia.SetFocus();
	//		m_ctrlEdDia.SetSel(0, -1);
	//	}
	//}
}

void TEP9KDlg::OnKillfocusEditSeg()
{
	//// TODO: Add your control notification handler code here
	//if (m_bClosing)
	//	return;

	//m_ctrlEdSeg.Convert();
	//if (!m_ctrlEdSeg.Validate())
	//{
	//	::AfxMessageBox(_T("Invalid data type.Must be an integer number!"));
	//	m_ctrlEdSeg.SetFocus();
	//	m_ctrlEdSeg.SetSel(0, -1);
	//}
	//else
	//{
	//	updateGlobalData();
	//	if (TEP9KInfo.m_nSegment > 128)
	//	{
	//		::AfxMessageBox(_T("Divided segment max is 128!"));
	//		m_ctrlEdSeg.SetFocus();
	//		m_ctrlEdSeg.SetSel(0, -1);
	//	}
	//	else if ((TEP9KInfo.m_nSegment % 4) != 0)
	//	{
	//		::AfxMessageBox(_T("Divided segment must be a multiple of 4!"));
	//		m_ctrlEdSeg.SetFocus();
	//		m_ctrlEdSeg.SetSel(0, -1);
	//	}
	//	else if (TEP9KInfo.m_nSegment <= 4)
	//	{
	//		::AfxMessageBox(_T("Divided segment must > 4!"));
	//		m_ctrlEdSeg.SetFocus();
	//		m_ctrlEdSeg.SetSel(0, -1);
	//	}
	//}
}

void TEP9KDlg::OnKillfocusEditSlope()
{
	//// TODO: Add your control notification handler code here
	//if (m_bClosing)
	//	return;

	//m_ctrlEdSlope.Convert();
	//if (!m_ctrlEdSlope.Validate())
	//{
	//	::AfxMessageBox(_T("Invalid data type.Must be a float number!"));
	//	m_ctrlEdSlope.SetFocus();
	//	m_ctrlEdSlope.SetSel(0, -1);
	//}
}

bool TEP9KDlg::CheckInput()
{
	//Check input for Diameter:
	m_ctrlEdDia.Convert();
	if (!m_ctrlEdDia.Validate())
	{
		::AfxMessageBox(_T("Invalid data type. Must be a number!"));
		m_ctrlEdDia.SetFocus();
		m_ctrlEdDia.SetSel(0, -1);
		return false;
	}
	else
	{
		m_ctrlEdDia.GetWindowTextW(m_strDia);
		double dia = atof((CStringA)m_strDia);
		if (dia < 0)
		{
			::AfxMessageBox(_T("Invalid data type. Must be a non-negative number!"));
			m_ctrlEdDia.SetFocus();
			m_ctrlEdDia.SetSel(0, -1);
			return false;
		}
	}

	//Check input for segment:
	m_ctrlEdSeg.Convert();
	if (!m_ctrlEdSeg.Validate())
	{
		::AfxMessageBox(_T("Invalid data type. Must be a number!"));
		m_ctrlEdSeg.SetFocus();
		m_ctrlEdSeg.SetSel(0, -1);
		return false;
	}
	else
	{
		m_ctrlEdSeg.GetWindowTextW(m_strSeg);
		int segMent = atoi((CStringA)m_strSeg);
		if (segMent != atof((CStringA)m_strSeg))
		{
			::AfxMessageBox(_T("Invalid data type. Must be an integer!"));
			m_ctrlEdSeg.SetFocus();
			m_ctrlEdSeg.SetSel(0, -1);
			return false;
		}
		
		if (segMent > 128)
		{
			::AfxMessageBox(_T("Divided segment max is 128!"));
			m_ctrlEdSeg.SetFocus();
			m_ctrlEdSeg.SetSel(0, -1);
			return false;
		}
		else if ((segMent % 4) != 0)
		{
			::AfxMessageBox(_T("Divided segment must be a multiple of 4!"));
			m_ctrlEdSeg.SetFocus();
			m_ctrlEdSeg.SetSel(0, -1);
			return false;
		}
		else if (segMent <= 4)
		{
			::AfxMessageBox(_T("Divided segment must be > 4!"));
			m_ctrlEdSeg.SetFocus();
			m_ctrlEdSeg.SetSel(0, -1);
			return false;
		}
	}

	//Check input for slope:
	m_ctrlEdSlope.Convert();
	if (!m_ctrlEdSlope.Validate())
	{
		::AfxMessageBox(_T("Invalid data type. Must be a number!"));
		m_ctrlEdSlope.SetFocus();
		m_ctrlEdSlope.SetSel(0, -1);
		return false;
	}

	return true;
}

void TEP9KDlg::updateGlobalData(bool bUpdateValidData)
{
	// TODO: Add your implementation code here.
	/*if (m_bClosing)
		return;*/

	if (!UpdateData(TRUE))
		return;

	m_ctrlEdDia.GetWindowTextW(m_strDia);
	m_ctrlEdSlope.GetWindowTextW(m_strSlope);
	m_ctrlEdSeg.GetWindowTextW(m_strSeg);

	if (bUpdateValidData)
	{
		TEP9KInfo.m_dDiameter = atof((CStringA)m_strDia);
		TEP9KInfo.m_nSegment = atoi((CStringA)m_strSeg);
		TEP9KInfo.m_dSlope = atof((CStringA)m_strSlope);
	}
	else
	{
		TEP9KInfo.m_strDiaTemp = m_strDia;
		TEP9KInfo.m_strSegTemp = m_strSeg;
		TEP9KInfo.m_strSlopeTemp = m_strSlope;
	}

	TEP9KInfo.m_bDataIsValid = bUpdateValidData;
}


﻿using ExcelDna.Integration;
using ExcelDna.IntelliSense;
using System.Runtime.InteropServices;
using ExcelDna.Integration.CustomUI;
using KRExcel.Utils;

namespace KRExcel.Plugin
{
    public class IntelliSenseAddIn : IExcelAddIn
    {
        public void AutoOpen()
        {
            IntelliSenseServer.Install();
        }
        public void AutoClose()
        {
            IntelliSenseServer.Uninstall();
        }
    }
}

namespace KRExcel.Utils
{
    public static class CommonDeclaration
    {
        public const double MaxDegMinSec = 60.0;
        public const double KRTolerance = 0.000001;
        public const string DegreeSymbol = "°";
        public const string MinuteSymbol = "'";
        public const string SecondSymbol = "\"";
        public const string Owner = "KR-Excel";
        public const string Designer = "LeThuongTri";
    }

    public static class HelpMethods
    {
        //Hide method from being seen:
        //https://groups.google.com/g/exceldna/c/4yRmJvvW5GI?pli=1
        //[ExcelFunction(IsHidden = true)]
        public static double RadianToDegree(double angRad)
        {
            return angRad * 180.0 / System.Math.PI;
        }

        //[ExcelFunction(IsHidden = true)]
        public static double DegreeToRadian(double angDeg)
        {
            return angDeg * System.Math.PI / 180.0;
        }

        public static bool GetBoolFromObject(object inputObject, out bool retBool , bool defaulValue)
        {
            retBool = defaulValue;

            if (inputObject is ExcelDna.Integration.ExcelMissing)
            {
                return true;
            }
            else
            {
                if (inputObject is not bool)
                {
                    return false;
                }
                else
                {
                    retBool = System.Convert.ToBoolean(inputObject);
                }
            }

            return true;
        }

        public static bool GetDoubleFromObject(object inputObject, out double retVal)
        {
            retVal = 0.0;

            if (inputObject is ExcelDna.Integration.ExcelMissing)
            {
                return false;
            }
            else
            {
                if (inputObject is not double)
                {
                    return false;
                }
                else
                {
                    retVal = System.Convert.ToDouble(inputObject);
                }
            }

            return true;
        }

        public static bool GetIntFromObject(object inputObject,out int retVal , bool isPositiveOnly = false)
        {
            retVal = 0;

            if (inputObject is not double || inputObject is ExcelDna.Integration.ExcelMissing)
            {
                //throw new ArgumentException();
                return false;
            }
            else
            {
                double testCount = System.Convert.ToDouble(inputObject);

                if (!testCount.Equals(System.Math.Truncate(testCount)))
                {
                    return false;
                }
                else
                {
                    retVal = System.Convert.ToInt32(testCount);

                    if (isPositiveOnly && retVal <= 0)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}

namespace KRExcel.GeneralCommands
{
    public static class Commands
    {
        [ExcelFunction(Description = "Convert slope(%) to angle in degrees/ radians.")]
        public static object SlopeToAngle(
            [ExcelArgument(Name = "Slope(%)", Description = "Slope(%) to convert.")]
            object slopeObj,
            [ExcelArgument(Name = "Return degree", Description = "Return value's type." +
                                                                "\nTRUE: return value in degrees." +
                                                               "\nFALSE: return value in radians." +
                                                               "\nBy default is TRUE.")]
            object retDegObj)
        {
            //Initialize default return value:
            double retVal = 0.0;

            #region [Check input]

            //Check slope:
            double slope;
            if (!KRExcel.Utils.HelpMethods.GetDoubleFromObject(slopeObj,out slope))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //double slope = 0.0;
            //if (slopeObj is not double || slopeObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    slope = System.Convert.ToDouble(slopeObj);
            //}

            #endregion

            //Check return type's flag:
            bool isDeg;
            if (!KRExcel.Utils.HelpMethods.GetBoolFromObject(retDegObj, out isDeg, true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //bool isDeg = false;
            //if (retDegObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    isDeg = true;
            //}
            //else
            //{
            //    if (retDegObj is not bool)
            //    {
            //        //throw new ArgumentException();
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        isDeg = System.Convert.ToBoolean(retDegObj);
            //    }
            //}

            #endregion

            #endregion

            //Calculate input:
            double tang = slope / 100.0;
            double angRad = System.Math.Atan(tang);
            double angDeg = KRExcel.Utils.HelpMethods.RadianToDegree(angRad);

            //Calculate return value:
            if (isDeg)
            {
                retVal = angDeg;
            }
            else
            {
                retVal = angRad;
            }

            return retVal;
        }

        [ExcelFunction(Description = "Convert angle(degrees) to format _°_'_''.")]
        public static object AngleToDMS(
            [ExcelArgument(Name = "Angle", Description = "Angle(degrees) to convert.")]
            object angle,
            [ExcelArgument(Name = "High precision", Description = "Precision level." +
                                                                "\nTRUE: return value in _°_'_''." +
                                                               "\nFALSE: return value in _°_'." +
                                                               "\nBy default is FALSE.")]
            object highPrecision)
        {
            //Initialize return value:
            string retVal = string.Empty;

            //Get degree:
            double deg;
            string angSign = string.Empty;

            if (!KRExcel.Utils.HelpMethods.GetDoubleFromObject(angle,out deg))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            if (deg < 0)
            {
                angSign = "-";
                deg = System.Math.Abs(deg);
            }

            #region [Old codes]

            //double deg = 0.0;
            //string angSign = string.Empty;

            //if (angle is not double || angle is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    deg = System.Convert.ToDouble(angle);

            //    if (deg < 0)
            //    {
            //        angSign = "-";
            //        deg = System.Math.Abs(deg);
            //    }
            //}

            #endregion

            //Check flag argument:
            bool isHighPre;
            if (!KRExcel.Utils.HelpMethods.GetBoolFromObject(highPrecision, out isHighPre, false))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //bool isHighPre = false;
            //if (highPrecision is ExcelDna.Integration.ExcelMissing)
            //{
            //    isHighPre = false;
            //}
            //else
            //{
            //    if (highPrecision is not bool)
            //    {
            //        //throw new ArgumentException();
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        isHighPre = System.Convert.ToBoolean(highPrecision);
            //    }
            //}

            #endregion

            double minute = (deg - System.Math.Truncate(deg)) * KRExcel.Utils.CommonDeclaration.MaxDegMinSec;

            double second = (minute - System.Math.Truncate(minute)) * KRExcel.Utils.CommonDeclaration.MaxDegMinSec;
            
            if (!isHighPre)
            {
                deg = System.Math.Truncate(deg);

                //System.Math.Round(second).Equals(CommonDeclaration.MaxDegMinSec / 2.0)
                //second.Equals(CommonDeclaration.MaxDegMinSec / 2.0)
                //second >= CommonDeclaration.MaxDegMinSec / 2.0)
                if (System.Math.Abs(second - KRExcel.Utils.CommonDeclaration.MaxDegMinSec / 2.0) <= KRExcel.Utils.CommonDeclaration.KRTolerance)
                {
                    minute = System.Math.Truncate(minute) + 1.0;
                }
                else
                {
                    minute = System.Math.Round(minute, 0, MidpointRounding.AwayFromZero);
                }

                if (minute.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    deg += 1.0;
                    minute = 0.0;
                }

                retVal = angSign + deg.ToString() + KRExcel.Utils.CommonDeclaration.DegreeSymbol +
                         minute.ToString() + KRExcel.Utils.CommonDeclaration.MinuteSymbol;
            }
            else
            {
                deg = System.Math.Truncate(deg);
                minute = System.Math.Truncate(minute);

                //double secondTail = System.Math.Round(second - System.Math.Truncate(second), 1 , 
                //    MidpointRounding.AwayFromZero);

                double secondTail = second - System.Math.Truncate(second);

                //secondTail.Equals(0.5)
                if (System.Math.Abs(secondTail - 0.5) <= KRExcel.Utils.CommonDeclaration.KRTolerance)
                {
                    second = System.Math.Truncate(second) + 1.0;
                }
                else
                {
                    second = System.Math.Round(second, 0, MidpointRounding.AwayFromZero);
                }

                if (second.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    minute += 1.0;
                    second = 0.0;
                }

                if (minute.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    deg += 1.0;
                    minute = 0.0;
                }

                retVal = angSign + deg.ToString() + KRExcel.Utils.CommonDeclaration.DegreeSymbol +
                         minute.ToString() + KRExcel.Utils.CommonDeclaration.MinuteSymbol +
                         second.ToString() + KRExcel.Utils.CommonDeclaration.SecondSymbol;
            }

            return retVal;
        }

        [ExcelFunction(Description = "Get number of bolts to assemble Bottom rail A & B in KR9K.")]
        public static object KR9K_BotAB_Bolt(
            [ExcelArgument(Name = "Baluster number", Description = "Baluster's number.")]
            object baCountObj)
        {
            int retVal = 0;

            //Check baluster input:
            int baCount;
            if(!KRExcel.Utils.HelpMethods.GetIntFromObject(baCountObj,out baCount,true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //int baCount = 0;
            //if (baCountObj is not double || baCountObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testBaCount = System.Convert.ToDouble(baCountObj);

            //    if (!testBaCount.Equals(System.Math.Truncate(testBaCount)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        baCount = System.Convert.ToInt32(testBaCount);

            //        if (baCount <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            int side = 2;
            int edgeHoleNum = 2;
            int midHoleNume = 0;
            int stepOver = 2;
            if (baCount > 2)
            {
                double divided = baCount / stepOver;

                if (Int32.IsOddInteger(baCount))
                {
                    midHoleNume = (int)Math.Truncate(divided);
                }
                else
                {
                    midHoleNume = (int)divided - 1;
                }
            }

            retVal = (midHoleNume + edgeHoleNum) * side;

            return retVal;
        }

        [ExcelFunction(Description = "Get number of bolts to assemble Baluster and Polyca plate.")]
        public static object KR9K_BaPo_Bolt(
            [ExcelArgument(Name = "Baluster number", Description = "Baluster's number.")]
            object baCountObj,

            [ExcelArgument(Name = "Bolts/ 1 baluster", Description = "Bolts per 1 Baluster.")]
            object boltPerBaObj
            )
        {
            int retVal = 0;

            //Check baluster input:
            int baCount;
            if (!KRExcel.Utils.HelpMethods.GetIntFromObject(baCountObj,out baCount, true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //int baCount = 0;
            //if (baCountObj is not double || baCountObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testBaCount = System.Convert.ToDouble(baCountObj);

            //    if (!testBaCount.Equals(System.Math.Truncate(testBaCount)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        baCount = System.Convert.ToInt32(testBaCount);

            //        if (baCount <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            //Check bolts per Baluster input:
            int boltPerBa = 2;
            if (!KRExcel.Utils.HelpMethods.GetIntFromObject(boltPerBaObj, out boltPerBa, true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //int boltPerBa = 2;
            //if (boltPerBaObj is not double || boltPerBaObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testBoltPerBa = System.Convert.ToDouble(boltPerBaObj);

            //    if (!testBoltPerBa.Equals(System.Math.Truncate(testBoltPerBa)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        boltPerBa = System.Convert.ToInt32(testBoltPerBa);

            //        if (boltPerBa <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            int edgeHoleNum = 2;
            int midHoleNume = 0;
            int stepOver = 2;
            if (baCount > 2)
            {
                double divided = baCount / stepOver - 1;
                midHoleNume = (int)System.Math.Truncate(divided);
            }

            retVal = (midHoleNume + edgeHoleNum) * boltPerBa;

            return retVal;
        }

        [ExcelFunction(Description = "Get number of bolts with spare to assemble Baluster and Polyca plate.")]
        public static object GetSpareTorxScrew(
            [ExcelArgument(Name = "Real amount", Description = "Real amount of Torx Screw.")]
            object realAmountObj,

            [ExcelArgument(Name = "High precision", Description = "Precision level." +
                                                                "\nTRUE: return value with high precision." +
                                                               "\nFALSE: return value with low precision." +
                                                               "\nBy default is TRUE.")]
            object highPrecisionObj
            )
        {
            int retVal = 0;

            //Check baluster input:
            int realCount;
            if(!KRExcel.Utils.HelpMethods.GetIntFromObject(realAmountObj,out realCount,true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //int realCount = 0;
            //if (realAmountObj is not double || realAmountObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testAmount = System.Convert.ToDouble(realAmountObj);

            //    if (!testAmount.Equals(System.Math.Truncate(testAmount)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        realCount = System.Convert.ToInt32(testAmount);

            //        if (realCount <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            bool isHighPrecision;
            if (!KRExcel.Utils.HelpMethods.GetBoolFromObject(highPrecisionObj, out isHighPrecision, true))
            {
                //throw new ArgumentException();
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //if (highPrecisionObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    isHighPrecision = true;
            //}
            //else
            //{
            //    if (highPrecisionObj is not bool)
            //    {
            //        //throw new ArgumentException();
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        isHighPrecision = System.Convert.ToBoolean(highPrecisionObj);
            //    }
            //}

            #endregion

            if (!isHighPrecision)
            {
                double spareMin = realCount * 1.05;
                double spareMax = realCount * 1.1;
                double spareMid = (spareMin + spareMax) / 2.0;
                //retVal = (int)System.Math.Round(spareMid, MidpointRounding.ToPositiveInfinity);
                retVal = (int)(System.Math.Ceiling(spareMid * 0.2) / 0.2);
            }
            else
            {
                int spareCount = 0;
                if (realCount <= 0)
                {
                    spareCount = 0;
                }
                else if (realCount > 0 && realCount <= 20)
                {
                    spareCount = 0;
                }
                else if (realCount > 20 && realCount <= 100)
                {
                    spareCount = 5;
                }
                else if (realCount > 100 && realCount < 200)
                {
                    spareCount = 10;
                }
                else
                {
                    spareCount = 20;
                }

                retVal = realCount + spareCount;

                retVal = (int)(System.Math.Ceiling(retVal * 0.2) / 0.2);
            }

            return retVal;
        }
    }
}

namespace KRExcel.Sample
{
    public static class Commands
    {
        [ExcelFunction(Description = "My first .NET function")]
        public static string SayHello(string name)
        {
            return "Hello " + name;
        }

        [ExcelFunction(Description = "A useful test function that adds two numbers, and returns the sum.")]
        public static double AddThem(
            [ExcelArgument(Name = "Augend", Description = "is the first number, to which will be added")]
            double v1,
            [ExcelArgument(Name = "Addend", Description = "is the second number that will be added")]
            double v2)
        {
            return v1 + v2;
        }
    }

    // Here is the helper class - add to it or change as you require
    internal static class Optional
    {
        internal static string Check(object arg, string defaultValue)
        {
            if (arg is string)
                return (string)arg;
            else if (arg is ExcelMissing)
                return defaultValue;
            else
                return arg.ToString();  // Or whatever you want to do here....

            // Perhaps check for other types and do whatever you think is right ....
            //else if (arg is double)
            //    return "Double: " + (double)arg;
            //else if (arg is bool)
            //    return "Boolean: " + (bool)arg;
            //else if (arg is ExcelError)
            //    return "ExcelError: " + arg.ToString();
            //else if (arg is object[,](,))
            //    // The object array returned here may contain a mixture of types,
            //    // reflecting the different cell contents.
            //    return string.Format("Array[{0},{1}]({0},{1})",
            //      ((object[,](,)(,))arg).GetLength(0), ((object[,](,)(,))arg).GetLength(1));
            //else if (arg is ExcelEmpty)
            //    return "<<Empty>>"; // Would have been null
            //else if (arg is ExcelReference)
            //  // Calling xlfRefText here requires IsMacroType=true for this function.
            //                return "Reference: " +
            //                     XlCall.Excel(XlCall.xlfReftext, arg, true);
            //            else
            //                return "!? Unheard Of ?!";
        }

        internal static double Check(object arg, double defaultValue)
        {
            if (arg is double)
                return (double)arg;
            else if (arg is ExcelMissing)
                return defaultValue;
            else
                throw new ArgumentException();  // Will return #VALUE to Excel

        }

        // This one is more tricky - we have to do the double->Date conversions ourselves
        internal static DateTime Check(object arg, DateTime defaultValue)
        {
            if (arg is double)
                return DateTime.FromOADate((double)arg);    // Here is the conversion
            else if (arg is string)
                return DateTime.Parse((string)arg);
            else if (arg is ExcelMissing)
                return defaultValue;

            else
                throw new ArgumentException();  // Or defaultValue or whatever
        }
    }
}

namespace KRExcel.Ribbon
{
    //public static class Functions
    //{
    //    public static string dnaRibbonTest()
    //    {
    //        return "Hello from the Ribbon Sample!";
    //    }
    //}

    //[ComVisible(true)]
    //public class RibbonController : ExcelRibbon
    //{
    //    private KRExcel.Sample.SampleFrm1 _SampleFrm1 = null;

    //    //https://bert-toolkit.com/imagemso-list.html
    //    public override string GetCustomUI(string RibbonID)
    //    {
    //        return @"
    //              <customUI xmlns = 'http://schemas.microsoft.com/office/2006/01/customui' >
    //              < ribbon >
    //                < tabs >
    //                  < tab id='krExcelTab' label='KR-Excel' insertBeforeMso='TabHome'>
    //                    <group id = 'krUtilGrp' label='KR-Utility'>
    //                      <button id = 'projectBtn' label='物件管理' 
    //                                              imageMso='ControlProperties'
    //                                              screentip='Show/edit user settings'
    //                                              onAction='OnProjectBtnPressed'
    //                    />

    //                    <button id = 'sampleFrmBtn' label='SampleForm' 
    //                                              imageMso='DataFormSource'
    //                                              screentip='Show sample form'
    //                                              onAction='OnSampleFrmBtnPressed'
    //                    />

    //                    </group >
    //                  </tab>
    //                </tabs>
    //              </ribbon>
    //            </customUI>";
    //    }

    //    public void OnProjectBtnPressed(IRibbonControl control)
    //    {
    //        MessageBox.Show("Hello from KR-Project " + control.Id,
    //                        KRExcel.Utils.CommonDeclaration.Owner,
    //                        MessageBoxButtons.OK, MessageBoxIcon.Information);
    //    }

    //    public void OnSampleFrmBtnPressed(IRibbonControl control)
    //    {
    //        //MessageBox.Show("Hello from sample form.",
    //        //                KRExcel.Utils.CommonDeclaration.Owner,
    //        //                MessageBoxButtons.OK, MessageBoxIcon.Information);

    //        if (_SampleFrm1 == null || _SampleFrm1.IsDisposed)
    //        {
    //            _SampleFrm1 = new KRExcel.Sample.SampleFrm1();
    //        }

    //        if (!_SampleFrm1.Visible)
    //        {
    //            if (_SampleFrm1.ShowDialog() == DialogResult.Cancel)
    //            {
    //                _SampleFrm1.Dispose();
    //            }
    //        }
    //        else
    //        {
    //            _SampleFrm1.Activate();
    //        }
    //    }
    //}
}
﻿using System;
using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
//using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using System.Xml;

using AcAp = Autodesk.AutoCAD.ApplicationServices.Application;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using BlockView.NET;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.GraphicsInterface;
//using Autodesk.AutoCAD.GraphicsSystem;
using Autodesk.AutoCAD.Runtime;
//using AcadAddin.KAInfo;
using AcadAddin.KRSInsert;
using System.Text.RegularExpressions;
//using Autodesk.AutoCAD.Internal.Calculator;
//using SampleNestedBlock;
//using System.Windows.Controls;
//using Autodesk.Windows;
//using System.Xml.Linq;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace AcadAddin.CAV_BlockView
{
    public partial class CAV_BView : Form
    {
        #region [Fields]
        //long SimpleModeMax = 0; //Max of file size for simple mode view
        //readonly Autodesk.AutoCAD.Colors.Color cadBGColor;  //Cad background color
        //readonly Image defaultImg;
        //Image srcImage;
        //AcadAddin.DwgDetailView.DwgDetailView _dwgDetailView;

        readonly string formOwner = AcadAddin.CommonDeclaration.Form_Owner;
        private string _FormLang = string.Empty;
        readonly bool _isReadyToShow = false;         
        
        private string _folderPath = "";       //Source folder path
        private string _SrcDwgFullName = "";   //Source drawing path to preview 

        //Assembly folder path:
        readonly string assemblyFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        //XML information:
        readonly string xmlFileName = AcadAddin.CommonDeclaration.Log_XML_Name;
        readonly string _settingXmlFileName = AcadAddin.CommonDeclaration.Setting_XML_Name;

        readonly string xmlFullPath;        //Last left location of selected folder
        readonly string _XMLNodeLocation;   //Node for last left location of selected folder
        private string _settingXmlFullPath; //XML setting file's full path

        private const char _kwSplitter = ',';   
        readonly string _DwgExt = "*.dwg";              //file extenstion
        private string _PreviewLoading = "Status: loading";   //load status => obsolete
        private string _PreviewLoaded = "Status: ok";         //load status => obsolete
        private string _PreviewError = "Status: error";       //load status => obsolete
        private string _CountFilesPrefix = "Total file(s): "; //count files' prefix
        private string _CountBlksPrefix = "Total block(s): "; //count blocks' prefix
        private const string contextCollectionName = "ACDB_ANNOTATIONSCALES";

        //Found shape form:
        private AcadAddin.KRSInsert.KRSI_FindFrm _findResForm;

        // list of opened drawing files to be disposed of
        private List<Database> dwgs = new List<Database>();

        // list of temporary spheres added to the gsView, these are not handled by autocad so must me disposed ourselves
        private List<Solid3d> spheres = new List<Solid3d>();

        // Form member to show blocks inside drawing:
        //private AcadAddin.CAV_BlockView.CAV_BlocksDetail_Frm _blksDetailFrm;
        private System.Collections.Generic.List<float> blkLstWidths;

        //BlockDetail form:
        private AcadAddin.CAV_BlockView.CAV_BlocksDetail_Frm _BlkDetailFrm = null;

        //List to contain names of detail information block:
        System.Collections.Generic.List<string> _DetalInfoBlkNames;

        //Declare suffix for Detail information:
        //In future consider transfer it in to setting XML file:
        readonly string _SuffixForDetailInfo = "DetailInfo";

        private string _LastSaveAsPath = string.Empty;

        private ViewTableRecord _originalView;      //Save original view to prevent user from zoom out.
        //private const double _maxZoomFactor = 1.0;

        private Editor _edOnViewChangedLockH;       //Temporary editor reference, stored to use for OnViewChangedLockH.
        private const double _safePanbuffer = 0.4;  
        private double[] _maxPan = { 0.0, 0.0};     //Limit for panning while inserting CAD

        #endregion

        #region [Properties]

        public bool IsReadyToShow
        {
            get { return _isReadyToShow; }
        }

        public static bool IsDesignMode
        {
            get
            {
                return GsPreviewCtrl.IsDesignMode;
            }
        }

        #endregion

        #region [Help methods]

        //Method to set language:
        private void SetLanguage()
        {
            if (_FormLang != CommonMessage.GetCurLanguage())
            {
                _FormLang = CommonMessage.GetCurLanguage();

                labelGrp.Text = CommonMessage.GetStringFromCurResx("control");

                workingFdrGrp.Text = CommonMessage.GetStringFromCurResx("workingfolder");

                useLibChkBox.Text = CommonMessage.GetStringFromCurResx("uselibrary");

                folderPickerBtn.Text = CommonMessage.GetStringFromCurResx("SELECT_FOLDER");
                if (_FormLang == "ja-JP")
                {
                    folderPickerBtn.Width = 110;
                }
                else if(_FormLang == "en-US")
                {
                    folderPickerBtn.Width = 110;
                }
                else if (_FormLang == "vi-VN")
                {
                    folderPickerBtn.Width = 120;
                }

                //folderPathLbl.Text = CommonMessage.GetStringFromCurResx("path");

                OverrideCbx.Text = CommonMessage.GetStringFromCurResx("override");

                insertCadBtn.Text = CommonMessage.GetStringFromCurResx("INSERT_TO_UCS",false);
                if (_FormLang == "ja-JP")
                {
                    insertCadBtn.Width = 120;
                }
                else if (_FormLang == "en-US")
                {
                    insertCadBtn.Width = 120;
                }
                else if (_FormLang == "vi-VN")
                {
                    insertCadBtn.Width = 130;
                }

                hideBtn.Text = CommonMessage.GetStringFromCurResx("hide");

                //_PreviewLoading = CommonMessage.GetStringFromCurResx("STATUS_LOADING");
                //_PreviewLoaded = CommonMessage.GetStringFromCurResx("STATUS_OK");
                //_PreviewError = CommonMessage.GetStringFromCurResx("STATUS_ERROR");
                //statusLbl.Text = CommonMessage.GetStringFromCurResx(statusLbl.Text);

                fileGrpBox.Text = CommonMessage.GetStringFromCurResx("file");

                findLbl.Text = CommonMessage.GetStringFromCurResx("searchitem");
                if (_FormLang == "ja-JP")
                {
                    findLbl.Width = 85;
                }
                else if (_FormLang == "en-US")
                {
                    findLbl.Width = 100;
                }
                else if (_FormLang == "vi-VN")
                {
                    findLbl.Width = 105;
                }

                findBlkLbl.Text = findLbl.Text;
                findBlkLbl.Width = findLbl.Width;

                _CountFilesPrefix = CommonMessage.GetStringFromCurResx("total") + ": ";
                fileCountLbl.Text = _CountFilesPrefix + fileLstBox.Items.Count.ToString();

                _CountBlksPrefix = _CountFilesPrefix;
                blkCountLbl.Text = _CountBlksPrefix + blkLstBox.Items.Count.ToString();

                blkPreviewCBox.Text = CommonMessage.GetStringFromCurResx("PREVIEW_BLOCK");

                blkGrpBox.Text = CommonMessage.GetStringFromCurResx("block");

                //Call set language for MenuStrip:
                SetLanguage_MenuStrip();
            }
        }

        //Method to set language for MenuStrip:
        private void SetLanguage_MenuStrip()
        {
            //---Order--
            //MenuItem
            //  => menuItemF1
            //      => menuItemF2
            ToolStripMenuItem menuItem;
            ToolStripMenuItem menuItemF1;
            ToolStripMenuItem menuItemF2;

            #region [FILE]

            ////--------------------FILE-----------------////
            ////-----------------------------------------////
            menuItem = menuStrip1.Items["fileToolStripMenuItem"] as ToolStripMenuItem;
            menuItem.Text = CommonMessage.GetStringFromCurResx("file") + "(F)";

            //if (_FormLang == "ja-JP")
            //{
            //    if (menuItem.Font != null)
            //    {
            //        menuItem.Font.Dispose();
            //        //menuItem.Font = null;
            //    }

            //    menuItem.Font = new System.Drawing.Font("Microsoft Sans Serif",
            //        9F, System.Drawing.FontStyle.Regular,
            //        System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //}

            //FileOpenMenuItem
            menuItemF1 = menuItem.DropDownItems["FileOpenMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("SELECT_FOLDER");

            //OutputImageMenuItem
            menuItemF1 = menuItem.DropDownItems["OutputImageMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("OUT_TO_IMAGE");

            //ExitMenuItem
            menuItemF1 = menuItem.DropDownItems["ExitMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("exit");

            #endregion

            #region [VIEW]

            ////--------------------VIEW-----------------////
            ////-----------------------------------------////
            menuItem = menuStrip1.Items["viewToolStripMenuItem"] as ToolStripMenuItem;
            menuItem.Text = CommonMessage.GetStringFromCurResx("view") + "(V)";
            //if (_FormLang == "ja-JP")
            //{
            //    if (menuItem.Font != null)
            //    {
            //        menuItem.Font.Dispose();
            //        //menuItem.Font = null;
            //    }

            //    menuItem.Font = new System.Drawing.Font("Microsoft Sans Serif",
            //        9F, System.Drawing.FontStyle.Regular,
            //        System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //}

            //Zoom:
            menuItemF1 = menuItem.DropDownItems["zoomToolStripMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("zoom");

            //ZoomWindowMenuItem
            menuItemF2 = menuItemF1.DropDownItems["ZoomWindowMenuItem"] as ToolStripMenuItem;
            menuItemF2.Text = CommonMessage.GetStringFromCurResx("zoomwindow");

            //ZoomExtentsMenuItem
            menuItemF2 = menuItemF1.DropDownItems["ZoomExtentsMenuItem"] as ToolStripMenuItem;
            menuItemF2.Text = CommonMessage.GetStringFromCurResx("zoomextents");

            //ZoomInMenuItem
            menuItemF2 = menuItemF1.DropDownItems["ZoomInMenuItem"] as ToolStripMenuItem;
            menuItemF2.Text = CommonMessage.GetStringFromCurResx("zoomin");

            //ZoomOutMenuItem
            menuItemF2 = menuItemF1.DropDownItems["ZoomOutMenuItem"] as ToolStripMenuItem;
            menuItemF2.Text = CommonMessage.GetStringFromCurResx("zoomout");

            //View style:
            menuItemF1 = menuItem.DropDownItems["viewStyleToolStripMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("viewstyle");

            //Settings:
            menuItemF1 = menuItem.DropDownItems["settingsToolStripMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("settings");

            //showToolStripMenuItem1
            menuItemF2 = menuItemF1.DropDownItems["showToolStripMenuItem1"] as ToolStripMenuItem;
            menuItemF2.Text = CommonMessage.GetStringFromCurResx("show");

            #endregion

            #region [TOOLS-ON HOLD]

            //////--------------------TOOLS----------------////
            //////-----------------------------------------////
            //menuItem = menuStrip1.Items["toolsToolStripMenuItem"] as ToolStripMenuItem;
            //menuItem.Text = CommonMessage.GetStringFromCurResx("tools") + "(T)";
            //if (_FormLang == "ja-JP")
            //{
            //    menuItem.Font = new System.Drawing.Font("Microsoft Sans Serif",
            //        9F, System.Drawing.FontStyle.Regular,
            //        System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //}

            #endregion

            #region [ABOUT]

            ////--------------------ABOUT----------------////
            ////-----------------------------------------////
            menuItem = menuStrip1.Items["aboutToolStripMenuItem"] as ToolStripMenuItem;
            menuItem.Text = CommonMessage.GetStringFromCurResx("about") + "(A)";
            //if (_FormLang == "ja-JP")
            //{
            //    if (menuItem.Font != null)
            //    {
            //        menuItem.Font.Dispose();
            //        //menuItem.Font = null;
            //    }

            //    menuItem.Font = new System.Drawing.Font("Microsoft Sans Serif",
            //        9F, System.Drawing.FontStyle.Regular,
            //        System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            //}

            //createdByToolStripMenuItem
            menuItemF1 = menuItem.DropDownItems["createdByToolStripMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("designer") + ": " +
                                CommonMessage.GetStringFromCurResx(CommonDeclaration.KR_CAD_Author, false);

            //emailToolStripMenuItem
            menuItemF1 = menuItem.DropDownItems["emailToolStripMenuItem"] as ToolStripMenuItem;
            menuItemF1.Text = CommonMessage.GetStringFromCurResx("email") + ": " +
                                CommonMessage.GetStringFromCurResx(CommonDeclaration.KR_CAD_Email, false);

            #endregion
        }

        //Method to construct preview control(run time):
        bool RuntimeConstruct()
        {
            try
            {
                InitializeRenderModeMenuItems();

                InitializeViewStyleMenuItems();

                //Get current document:
                //Document document = AcAp.DocumentManager.MdiActiveDocument;
                Document document = GetSrcDocForGS();

                //By default load control with current document:
                if (document != null)
                {
                    ////Must be in ModelSpace before initialize preview:
                    //SwitchToModelSpace();
                    if (!InitDrawingControl(document, document.Database))
                    {
                        return false;
                    }
                }

                //Set clean up method:
                base.Disposed += new EventHandler(OnDisposed);

                return true;
            }
            catch (System.Exception ex)
            {
                //"Error when initializing preview control."
                //$"\nError: {ex.Message}"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("init","GSPreview")+
                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return false;
            }
        }

        private void RuntimeSetControlEvent()
        {
            // FileOpenMenuItem
            this.FileOpenMenuItem.Click += new System.EventHandler(this.FileOpenMenuItem_Click);

            // OutputImageMenuItem
            this.OutputImageMenuItem.Click += new System.EventHandler(this.OutputImageMenuItem_Click);

            // ExitMenuItem
            this.ExitMenuItem.Click += new System.EventHandler(this.ExitMenuItem_Click);

            // ZoomWindowMenuItem
            this.ZoomWindowMenuItem.Click += new System.EventHandler(this.ZoomWindowMenuItem_Click);

            // ZoomExtentsMenuItem
            this.ZoomExtentsMenuItem.Click += new System.EventHandler(this.ZoomExtentsMenuItem_Click);

            // ZoomInMenuItem
            this.ZoomInMenuItem.Click += new System.EventHandler(this.ZoomInMenuItem_Click);

            // ZoomOutMenuItem
            this.ZoomOutMenuItem.Click += new System.EventHandler(this.ZoomOutMenuItem_Click);

            // showLinetypesToolStripMenuItem
            this.showLinetypesToolStripMenuItem.Click += new System.EventHandler(this.showLinetypesToolStripMenuItem_Click);

            // showSectioningToolStripMenuItem
            this.showSectioningToolStripMenuItem.Click += new System.EventHandler(this.showSectioningToolStripMenuItem_Click);

            // RemapColoursNormalMenuItem
            this.RemapColoursNormalMenuItem.Click += new System.EventHandler(this.RemapColoursNormalMenuItem_Click);

            // RemapColoursCustomMenuItem
            this.RemapColoursCustomMenuItem.Click += new System.EventHandler(this.RemapColoursCustomMenuItem_Click);

            // AddTempEntityMenuItem
            this.AddTempEntityMenuItem.Click += new System.EventHandler(this.AddTempEntityMenuItem_Click);

            // AddEntityToDwgMenuItem
            this.AddEntityToDwgMenuItem.Click += new System.EventHandler(this.AddEntityToDwgMenuItem_Click);

            //GSPreview:
            this.mPreviewCtrl.MouseClick += new System.Windows.Forms.MouseEventHandler(this.GSPreview_MouseClick);
        }

        private void RuntimeSetControlIcon()
        {
            DialogFunctions.SetButtonImage(ref folderPickerBtn, AcadAddin.Properties.Resources.RbFolder);
            DialogFunctions.SetButtonImage(ref hideBtn, AcadAddin.Properties.Resources.HideLogo);
            DialogFunctions.SetButtonImage(ref insertCadBtn, AcadAddin.Properties.Resources.InsertDwgIcon);
            DialogFunctions.SetLabelImage(ref findLbl, AcadAddin.Properties.Resources.FindLogo);
            DialogFunctions.SetLabelImage(ref findBlkLbl, AcadAddin.Properties.Resources.FindLogo);

            #region [Old codes]
            ////Standard size for icon:
            //Size smallSize = new Size(20, 20);

            ////Folder picker:
            //folderPickerBtn.Image = DialogFunctions.ResizeImage(AcadAddin.Properties.Resources.RbFolder, smallSize);
            //folderPickerBtn.ImageAlign = ContentAlignment.MiddleLeft;
            //folderPickerBtn.TextAlign = ContentAlignment.MiddleRight;

            ////Hide button:
            //hideBtn.Image = DialogFunctions.ResizeImage(AcadAddin.Properties.Resources.HideLogo, smallSize);
            //hideBtn.ImageAlign = ContentAlignment.MiddleLeft;
            //hideBtn.TextAlign = ContentAlignment.MiddleRight;

            ////Insert CAD button:
            //insertCadBtn.Image = DialogFunctions.ResizeImage(AcadAddin.Properties.Resources.InsertDwgIcon, smallSize);
            //insertCadBtn.ImageAlign = ContentAlignment.MiddleLeft;
            //insertCadBtn.TextAlign = ContentAlignment.MiddleRight;

            ////Setting find file label:
            //findLbl.Image = DialogFunctions.ResizeImage(AcadAddin.Properties.Resources.FindLogo, smallSize);
            //findLbl.ImageAlign = ContentAlignment.MiddleLeft;
            //findLbl.TextAlign = ContentAlignment.MiddleRight;

            ////Setting find block label:
            //findBlkLbl.Image = DialogFunctions.ResizeImage(AcadAddin.Properties.Resources.FindLogo, smallSize);
            //findBlkLbl.ImageAlign = ContentAlignment.MiddleLeft;
            //findBlkLbl.TextAlign = ContentAlignment.MiddleRight;
            #endregion
        }

        //Method to get source document for GraphicsSystem:
        private Autodesk.AutoCAD.ApplicationServices.Document GetSrcDocForGS()
        {
            //Get current document:
            Autodesk.AutoCAD.ApplicationServices.Document curDoc = AcAp.DocumentManager.MdiActiveDocument;

            //Return value:
            Autodesk.AutoCAD.ApplicationServices.Document retDoc = null;

            //Get source document full name:
            //string srcDocFullName = CommonDeclaration.GetTempPath() + "\\" + AcadAddin.CommonDeclaration.CAV_GSSrcDoc;
            string srcDocFullName = assemblyFolder + "\\" + AcadAddin.CommonDeclaration.CadLib_Path 
                                                   + "\\" + AcadAddin.CommonDeclaration.CAV_GSSrcDoc;

            //Check document full name:
            if (!File.Exists(srcDocFullName))
            {
                string showMsg = "Source document for GraphicsSystem doesn't exist!" +
                                "\nThe command will continue with current document.";

                if (_FormLang == "ja-JP")
                {
                    showMsg = "GraphicsSystemのソースドキュメントが存在しません!" +
                                "\nコマンドは現在のドキュメントで続行されます。";
                }
                else if (_FormLang == "vi-VN")
                {
                    showMsg = "Tài liệu nguồn cho GraphicsSystem không tồn tại!" +
                                "\nLệnh sẽ tiếp tục với tài liệu hiện tại.";
                }

                MessageBox.Show(showMsg,
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                return curDoc;
            }

            //Get all current documents:
            DocumentCollection acDocMgr = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager;

            //Store old activate mode:
            bool oldDocActivateMode = acDocMgr.DocumentActivationEnabled;

            try
            {
                if (!acDocMgr.DocumentActivationEnabled)
                {
                    acDocMgr.DocumentActivationEnabled = true;
                }

                foreach (Document memDoc in acDocMgr)
                {
                    if (memDoc.Name == srcDocFullName)
                    {
                        return memDoc;
                    }
                }

                //If come to this, then open(Readonly) + set:
                retDoc = acDocMgr.Open(srcDocFullName, true);
                if (retDoc != null)
                {
                    //Do it to keep current document is activated after get source doc:
                    if (AcAp.DocumentManager.MdiActiveDocument != curDoc)
                    {
                        AcAp.DocumentManager.MdiActiveDocument = curDoc;
                    }

                    return retDoc;
                }
                else
                {
                    return curDoc;
                }
            }
            catch (System.Exception ex)
            {
                string showMsg = "Fail when getting source document for GraphicsSystem!" +
                                $"\nError: {ex.Message}" +
                                "\nThe command will continue with current document.";

                if (_FormLang == "ja-JP")
                {
                    showMsg = "GraphicsSystemのソースドキュメントの取得に失敗しました!" +
                                $"\nエラー: {ex.Message}" +
                                "\nコマンドは現在なドキュメントで続行されます。";
                }
                else if (_FormLang == "vi-VN")
                {
                    showMsg = "Thất bại khi lấy tài liệu nguồn cho GraphicsSystem!" +
                                $"\nLỗi: {ex.Message}" +
                                "\nLệnh sẽ tiếp tục với tài liệu hiện tại.";
                }

                MessageBox.Show(showMsg,
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                return curDoc;
            }
            finally
            {
                //Remember to reset document activation mode:
                if (acDocMgr.DocumentActivationEnabled != oldDocActivateMode)
                {
                    acDocMgr.DocumentActivationEnabled = oldDocActivateMode;
                }
            }
        }

        //Load all layouts in database to ComboBox:
        private bool LoadLayoutsComboBox(Database srcDb)
        {
            try
            {
                if (layoutsCoBx == null)
                {
                    //"Lost reference to layouts' ComboBox!"
                    MessageBox.Show(CommonMessage.LOST_REF_TO("ComboBox"),
                                   formOwner,
                                   MessageBoxButtons.OK,
                                   MessageBoxIcon.Error);

                    return false;
                }

                //Clear old items in layout ComboBox:
                if (layoutsCoBx.Items.Count > 0)
                {
                    layoutsCoBx.Items.Clear();
                }

                //Add items to ComboBox:
                using (Transaction tr = srcDb.TransactionManager.StartTransaction())
                {
                    //Get layouts' dictionary:
                    DBDictionary layouts = tr.GetObject(srcDb.LayoutDictionaryId, OpenMode.ForRead) as DBDictionary;

                    foreach (DBDictionaryEntry layout in layouts)
                    {
                        if (!layoutsCoBx.Items.Contains(layout.Key))
                        {
                            layoutsCoBx.Items.Add(layout.Key);
                        }
                    }
                    // Abort the changes to the database: 
                    tr.Abort();
                }

                //Check layous contains ModelSpace(MUST):
                if (!layoutsCoBx.Items.Contains("Model"))
                {
                    //"Error when loading ModelSpace!"
                    MessageBox.Show(CommonMessage.FAIL_TO_DO("load","ModelSpace"),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (System.Exception ex)
            {
                //"Cannot load layouts!"
                //$"\nError: {ex.Message}"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("load","Layout") +
                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                               formOwner,
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);

                return false;
            }
        }

        //Read setting XML file then 
        //return list of keywords for DrawingBlock:
        private System.Collections.Generic.List<string> GetKwsForDwgBlk()
        {
            //Initialize return value:
            System.Collections.Generic.List<string> retVal = new System.Collections.Generic.List<string>();

            //Read setting's XML file:
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(_settingXmlFullPath);

            XmlNode xmlNode = null;
            xmlNode = xmlDoc.DocumentElement.SelectSingleNode(AcadAddin.CommonDeclaration.CadViewer);
            if (xmlNode != null)
            {
                string innerTxt = xmlNode["DwgBlk"].InnerText;

                if (!string.IsNullOrEmpty(innerTxt) && 
                    !string.IsNullOrWhiteSpace(innerTxt))
                {
                    //Get keywords' raw information:
                    string rawKws = string.Join("", innerTxt.Split('\t', '\r', '\n'));

                    //Get keywords' keyvalue:
                    string[] kws = rawKws.Split(_kwSplitter);
                    if (kws != null && kws.Length > 0)
                    {
                        for (int i = 0; i < kws.Length; i++)
                        {
                            if (!retVal.Contains(kws[i]) &&
                                !string.IsNullOrEmpty(kws[i]) &&
                                !string.IsNullOrWhiteSpace(kws[i]))
                            {
                                retVal.Add(kws[i]);
                            }
                        }
                    }
                }
            }

            return retVal;
        }

        //private void docDestroyed(object obj,
        //                     DocumentDestroyedEventArgs acDocDesEvtArgs)
        //{
        //    // Determine if the menu item already exists and the number of documents open
        //    if (AcAp.DocumentManager.Count == 0)
        //    {
        //        MessageBox.Show("This command cannot be used in no document mode." +
        //                        $"\nOpen new drawing then try again.",
        //                        formOwner,
        //                        MessageBoxButtons.OK,
        //                        MessageBoxIcon.Information);

        //        ExitMenuItem_Click(new object(), new EventArgs());
        //    }
        //}

        //Help method to update source XML file:
        private void UpdateXml(string newText)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlFullPath);

            XmlNode xmlNode = null;
            xmlNode = xmlDoc.DocumentElement.SelectSingleNode(_XMLNodeLocation);
            if (xmlNode != null)
            {
                xmlNode.InnerText = newText;
                xmlDoc.Save(xmlFullPath);
            }
        }

        //Help method to add items into listbox:
        private void AddFilesListBox(string path)
        {
            try
            {
                var fileNameList = Directory.GetFiles(path, _DwgExt, SearchOption.TopDirectoryOnly);
                if (fileNameList != null)
                {
                    if (fileNameList.Length > 0)
                    {
                        //Add files' name to listbox:
                        foreach (var item in fileNameList)
                        {
                            fileLstBox.Items.Add(Path.GetFileName(item));
                        }
                    }
                }

                //Sort list box:
                fileLstBox.Sorted = true;

                //Update count text for files:
                fileCountLbl.Text = _CountFilesPrefix + fileLstBox.Items.Count.ToString();
            }
            catch (System.Exception ex)
            {
                //"Error : " + ex.Message
                MessageBox.Show(CommonMessage.ERROR_MES(ex.Message), 
                        formOwner,
                       MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
        }

        //Method to add block name into block ListBox:
        private bool LoadBlockList(string srcDwgFullName)
        {
            #region [Old codes]

            //MessageForBeingBuildedModule();
            //Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            //bool openForWrite = false;
            //if (doc.Name == srcDwgFullName && doc.IsReadOnly == false)
            //{
            //    openForWrite = true;
            //}

            //using (Database OuterDB = new Database(false, true))
            //{
            //    OuterDB.ReadDwgFile(srcDwgFullName, FileOpenMode.OpenForReadAndAllShare, false, "");

            //    //Current document database:
            //    Database curDb = doc.Database;

            //    //Database to process:
            //    Database db;
            //    if (openForWrite)
            //    {
            //        db = curDb;
            //    }
            //    else
            //    {
            //        db = OuterDB;
            //    }

            //    using (Transaction tr = db.TransactionManager.StartTransaction())
            //    {
            //        BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

            //        foreach (ObjectId id in bt)
            //        {
            //            BlockTableRecord btr = tr.GetObject(id, OpenMode.ForRead) as BlockTableRecord;
            //            if (!btr.IsLayout && !btr.IsAnonymous)
            //            {
            //                if (!this.blkLstBox.Items.Contains(btr.Name))
            //                {
            //                    this.blkLstBox.Items.Add(btr.Name);
            //                }
            //            }
            //        }

            //        tr.Commit();
            //    }
            //}

            #endregion

            //Clear old names of detail information block:
            _DetalInfoBlkNames.Clear();

            //Check source database:
            Database srcDb = dwgs[dwgs.Count - 1];
            if (srcDb == null || srcDb.IsDisposed)
            {
                //"Lost reference to source database!"
                MessageBox.Show(CommonMessage.LOST_REF_TO("database"),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                return false;
            }

            //Main process:
            try
            {
                using (Transaction tr = srcDb.TransactionManager.StartTransaction())
                {
                    BlockTable bt = tr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;

                    //Get keywords for DrawingBlock:
                    System.Collections.Generic.List<string> kwsForDwgBlk = GetKwsForDwgBlk();

                    foreach (ObjectId id in bt)
                    {
                        BlockTableRecord btr = tr.GetObject(id, OpenMode.ForRead) as BlockTableRecord;
                        if (!btr.IsLayout && !btr.IsAnonymous)
                        {
                            //Check block is Block for detail information => skip it:
                            if (btr.Name.Contains(_SuffixForDetailInfo))
                            {
                                continue;
                            }

                            if (!this.blkLstBox.Items.Contains(btr.Name))
                            {
                                //Flag for keywords matching:
                                bool isFounded = false;

                                if (kwsForDwgBlk.Count > 0)
                                {
                                    //Check whether block name is in keywords.
                                    //Cause we ONLY add block name match keywords.
                                    for (int i = 0; i < kwsForDwgBlk.Count; i++)
                                    {
                                        if (Regex.IsMatch(btr.Name, CommonCommands.GetMatchPattern(kwsForDwgBlk[i]), RegexOptions.IgnoreCase))
                                        {
                                            isFounded = true;
                                            break;
                                        }
                                    }

                                    if (isFounded)
                                    {
                                        this.blkLstBox.Items.Add(btr.Name);
                                    }
                                }
                                else //In case keywords contain nothing => add any block we have in source drawing.
                                {
                                    this.blkLstBox.Items.Add(btr.Name);
                                }

                                #region [Store names of detail information block]

                                //Do something to store names of detail information block with
                                //standard format is "KRCAD-XXX-DetailInfo"
                                int stdSplitSeg = 3;           
                                string stdPrefix = "KRCAD";
                                //string stdSuffix = "DetailInfo";
                                char stdSplitChar = '-';
                                foreach (ObjectId entId in btr)
                                {
                                    if (entId != ObjectId.Null)
                                    {
                                        Entity ent = tr.GetObject(entId, OpenMode.ForRead) as Entity;
                                        if (ent != null && ent is BlockReference blkRef)
                                        {
                                            BlockTableRecord blkRefDef = null;
                                            if (blkRef.IsDynamicBlock)
                                            {
                                                blkRefDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                            }
                                            else
                                            {
                                                blkRefDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                            }

                                            if (blkRefDef == null || !blkRefDef.HasAttributeDefinitions)
                                            {
                                                continue;
                                            }

                                            //Check name by splitting it by split character:
                                            string[] splittedStr = blkRefDef.Name.Split(stdSplitChar);
                                            if (splittedStr == null || splittedStr.Length != stdSplitSeg)
                                            {
                                                continue;
                                            }

                                            if (splittedStr[0] == stdPrefix && splittedStr[1] == _SuffixForDetailInfo &&
                                                !_DetalInfoBlkNames.Contains(blkRefDef.Name))
                                            {
                                                _DetalInfoBlkNames.Add(blkRefDef.Name);
                                            }
                                        }
                                    }
                                }

                                #endregion
                            }
                        }
                    }

                    //https://spiderinnet1.typepad.com/blog/2012/01/autocad-net-commit-transaction-or-not-when-reading.html
                    //No need to commit when reading but do this for increasing performance:
                    tr.Commit();
                }

                //Sort list:
                blkLstBox.Sorted = true;

                //Update block count label:
                if (blkLstBox != null && blkLstBox.Items.Count > 0)
                {
                    blkCountLbl.Text = _CountBlksPrefix + blkLstBox.Items.Count.ToString();
                }

                return true;
            }
            catch (System.Exception ex)
            {
                //"Error when loading block's list!"
                //$"\nError: {ex.Message}"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("load","block",true) +
                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                return false;
            }
        }

        ////Method to get match pattern(Regex) from search value:
        //private string GetMatchPattern(string searchValue, bool isBound = false)
        //{
        //    if (!isBound)
        //    {
        //        //Source contains keyword at anywhere:
        //        return $"{searchValue}";
        //    }
        //    else
        //    {
        //        //Source contains keyword at the bound location only:
        //        return $"\\b{searchValue}\\b";
        //    }
        //}

        //Get unique name for temp block:

        private string GetUniqueName(string srcBlkName)
        {
            //Sample patterns:
            //string dateTime = System.DateTime.Now.ToString("yy/MM/dd/HH/mm/ss");  // => NG
            //string dateTime = System.DateTime.Now.ToString("yy_MM_dd_HH_mm_ss");  // => Ok
            //string dateTime = System.DateTime.Now.ToString("mm_ss");              // => Ok
            string suffix = System.DateTime.Now.ToString("yyMMddHHmmss");
            return srcBlkName + suffix;
        }

        //Hide method for modeless dialog:
        private void HideByModeless()
        {
            //Hide main form:
            this.Hide();

            // set focus to AutoCAD
            Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView();
        }

        //Print message for being builded module:
        private void MessageForBeingBuildedModule()
        {
            //MODULE_ON_BUILD
            //"This module is still being builded." +
            //                            "\nPlease come back later!"
            MessageBox.Show(CommonMessage.GetStringFromCurResx("MODULE_ON_BUILD") + 
                            "\n" + CommonMessage.GetStringFromCurResx("BACK_LATER"), 
                            formOwner,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        //Keep modelspace always be activated:
        [Obsolete("In method GSUtil.GetActiveViewPortInfo we do temporary switch to model " +
            "when nescessary then switch back to origin!")]
        private void SwitchToModelSpace()
        {
            ////Check model or paper space?
            //if (!CommonCommands.IsInModel())
            //{
            //    Document curDoc = AcAp.DocumentManager.MdiActiveDocument;

            //    using (curDoc.LockDocument())
            //    {
            //        //https://forums.autodesk.com/t5/net/how-to-select-model-space-tab/td-p/5478438

            //        //Update current document to modelspace:
            //        LayoutManager.Current.CurrentLayout = "Model";
            //        //AcAp.SetSystemVariable("TILEMODE", 1);
            //        //ed.SwitchToModelSpace();
            //    }
            //}

            #region [Old codes]
            //int cvPort = System.Convert.ToInt32(AcAp.GetSystemVariable("CVPORT"));
            //if (cvPort <= 1)
            //{
            //    Editor ed = curDoc.Editor;
            //    ed.WriteMessage($"\n{cvPort}");

            //    using (curDoc.LockDocument())
            //    {
            //        //Update current document to modelspace:
            //        LayoutManager.Current.CurrentLayout = "Model";
            //        //AcAp.SetSystemVariable("TILEMODE", 1);
            //        //ed.SwitchToModelSpace();
            //    }
            //}
            #endregion
        }

        //Method to make border of groupbox become invisible:
        private void PaintBorderlessGroupBox(object sender, PaintEventArgs p)
        {
            System.Windows.Forms.GroupBox box = (System.Windows.Forms.GroupBox)sender;
            p.Graphics.Clear(SystemColors.Control);
            p.Graphics.DrawString(box.Text, box.Font, Brushes.Black, 0, 0);
        }

        //Method to override all same name blocks:
        private bool OverrideSameNameBlocks()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;

            //Get reference to source database:
            Database srcDb = null;
            if (dwgs == null || dwgs.Count < 1)
            {
                //"Lost reference to source database!"
                MessageBox.Show(CommonMessage.LOST_REF_TO("database"),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }
            else
            {
                srcDb = dwgs[dwgs.Count - 1];
                if (srcDb == null)
                {
                    //"Cannot read source database!"
                    MessageBox.Show(CommonMessage.FAIL_TO_DO("read","database",true),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                    return false;
                }
            }

            try
            {
                //System.Collections.Generic.List<string> blkNamesToAttSyn = new System.Collections.Generic.List<string>();

                using (Transaction curTr = db.TransactionManager.StartTransaction())    //Transaction for current database       
                {
                    //Get current document's BlockTable:
                    BlockTable curDocBlt = curTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                    using (Transaction srcTr = srcDb.TransactionManager.StartTransaction())     //Transaction for source database
                    {
                        //Get source database's BlockTable:
                        BlockTable srcBlt = srcTr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;

                        //Create container to store blocks' id which need to be overlap:
                        ObjectIdCollection overlapBlkIds = new ObjectIdCollection();

                        //Populate information for container:
                        if (!blkPreviewCBox.Checked)    //Override all inside BlockTable
                        {
                            //Iterate source Blocktable and add blocks which id is overlapped with
                            //one in current document Blocktable:
                            foreach (ObjectId srcBltrId in srcBlt)
                            {
                                if (srcBltrId != ObjectId.Null)
                                {
                                    BlockTableRecord srcBltr = null;
                                    srcBltr = srcTr.GetObject(srcBltrId, OpenMode.ForRead) as BlockTableRecord;
                                    if (srcBltr == null)
                                    {
                                        //"Cannot read BlockTableRecord!"
                                        MessageBox.Show(CommonMessage.FAIL_TO_DO("read","BlockTableRecord"),
                                                        formOwner,
                                                        MessageBoxButtons.OK,
                                                        MessageBoxIcon.Error);
                                        srcTr.Abort();
                                        curTr.Abort();
                                        return false;
                                    }
                                    else
                                    {
                                        if (!srcBltr.IsAnonymous && !srcBltr.IsLayout &&
                                            curDocBlt.Has(srcBltr.Name))
                                        {
                                            if (!overlapBlkIds.Contains(srcBltrId))
                                            {
                                                overlapBlkIds.Add(srcBltrId);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else //Override all member inside BlockDefinition
                        {
                            //Get source block name:
                            string blockName = blkLstBox.SelectedItem.ToString();

                            //Check whether BlockDefinition exist?
                            if (!srcBlt.Has(blockName))
                            {
                                //"BlockDefinition doesn't exist!"
                                MessageBox.Show(CommonMessage.OBJECT_NOT_EXIST("BlockDefinition"),
                                                formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                                srcTr.Abort();
                                curTr.Abort();
                                return false;
                            }

                            //Get BlockDefinition:
                            BlockTableRecord srcBltr = null;

                            srcBltr = srcTr.GetObject(srcBlt[blockName], OpenMode.ForRead) as BlockTableRecord;
                            if (srcBltr == null)
                            {
                                //"Cannot read BlockDefinition!"
                                MessageBox.Show(CommonMessage.FAIL_TO_DO("read", "BlockDefinition"),
                                                formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                                srcTr.Abort();
                                curTr.Abort();
                                return false;
                            }

                            //Create container to store all nested block's name & id inside BlockDefinition:
                            System.Collections.Generic.Dictionary<string, ObjectId> blkDefNames = new Dictionary<string, ObjectId>();
                            blkDefNames.Add(srcBltr.Name, srcBlt[blockName]);   //Always have root block information

                            //Populate information for container of nested blocks:
                            foreach (ObjectId id in srcBltr)
                            {
                                if (id != ObjectId.Null)
                                {
                                    Entity ent = srcTr.GetObject(id, OpenMode.ForRead) as Entity;

                                    if (ent != null && ent is BlockReference blkRef)
                                    {
                                        if (!GetAllBlkDefIds(srcTr, blkRef, ref blkDefNames))
                                        {
                                            continue;
                                        }
                                    }
                                }
                            }

                            //Populate information for container of needing overridden:
                            if (blkDefNames.Count > 0)
                            {
                                foreach (var blkDefName in blkDefNames)
                                {
                                    if (curDocBlt.Has(blkDefName.Key) &&
                                        !overlapBlkIds.Contains(blkDefName.Value))
                                    {
                                        overlapBlkIds.Add(blkDefName.Value);
                                    }
                                }
                            }
                        }

                        //Start to override when needed:
                        if (overlapBlkIds.Count > 0)
                        {
                            //Do override:
                            IdMapping mapping = new IdMapping();

                            srcDb.WblockCloneObjects(overlapBlkIds, db.BlockTableId, mapping,
                                                           DuplicateRecordCloning.Replace, false);

                            //Update graphics for dynamic block and
                            //mark block name having attributes:
                            foreach (ObjectId id in overlapBlkIds)
                            {
                                BlockTableRecord blkDef = curTr.GetObject(mapping[id].Value, OpenMode.ForRead)
                                    as BlockTableRecord;
                                if (blkDef.IsDynamicBlock)
                                {
                                    blkDef.UpgradeOpen();
                                    blkDef.UpdateAnonymousBlocks();
                                    blkDef.DowngradeOpen();
                                }

                                //if (blkDef.HasAttributeDefinitions)
                                //{
                                //    blkDef.SynchronizeAttributes();
                                //}

                                #region [Old codes]

                                //if (blkDef.HasAttributeDefinitions &&
                                //        !blkNamesToAttSyn.Contains(blkDef.Name))
                                //{
                                //    blkNamesToAttSyn.Add(blkDef.Name);
                                //}

                                #endregion
                            }

                            #region [Old codes]
                            //foreach (IdPair item in mapping)
                            //{
                            //    if (item.IsPrimary && item.IsCloned)
                            //    {
                            //        BlockTableRecord blkDef = curTr.GetObject(item.Value, OpenMode.ForRead) 
                            //            as BlockTableRecord;
                            //        if (blkDef.IsDynamicBlock)
                            //        {
                            //            blkDef.UpgradeOpen();
                            //            blkDef.UpdateAnonymousBlocks();
                            //            blkDef.DowngradeOpen();
                            //        }

                            //        if (blkDef.HasAttributeDefinitions && 
                            //            !blkNamesToAttSyn.Contains(blkDef.Name))
                            //        {
                            //            blkNamesToAttSyn.Add(blkDef.Name);
                            //        }
                            //    }
                            //}
                            #endregion
                        }

                        srcTr.Commit();
                    }

                    curTr.Commit();
                }

                #region [Old codes]
                ////Silently send 'ATTSYNC' :
                //if (blkNamesToAttSyn.Count > 0)
                //{
                //    Editor ed = doc.Editor;
                //    using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
                //    {
                //        foreach (string blkName in blkNamesToAttSyn)
                //        {
                //            try
                //            {
                //                ed.Command("ATTSYNC", "Name", blkName);
                //            }
                //            catch (System.Exception ex)
                //            {
                //                ed.WriteMessage("//----------//---------//");
                //                ed.WriteMessage($"\nFailed when synchronizing Attributes for block '{blkName}'!");
                //                ed.WriteMessage(ex.Message);
                //                ed.WriteMessage("//----------//---------//");
                //            }
                //        }
                //    }
                //}
                #endregion

                return true;
            }
            catch (System.Exception ex)
            {
                //"Fail when trying to override block definiton."
                //$"\nError: {ex.Message}"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("override","BlockDefinition") +
                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }
        }

        //Get all nested blocks' name & id inside BlockReference:
        private bool GetAllBlkDefIds(Transaction tr, BlockReference blkRef,
                             ref System.Collections.Generic.Dictionary<string, ObjectId> blkDefNameIds)
        {
            try
            {
                BlockTableRecord blkDef = null;
                if (blkRef.IsDynamicBlock)
                {
                    blkDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                }
                else
                {
                    blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                }

                if (blkDef == null)
                {
                    return false;
                }
                else
                {
                    if (blkDef.IsLayout || blkDef.IsAnonymous)
                    {
                        return false;
                    }
                }

                if (blkDef.ObjectId != ObjectId.Null)
                {
                    if (!blkDefNameIds.ContainsKey(blkDef.Name))
                    {
                        blkDefNameIds.Add(blkDef.Name, blkDef.ObjectId);
                    }
                    else //Already contains so return;
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                //recursion:
                foreach (ObjectId id in blkDef)
                {
                    if (id != ObjectId.Null)
                    {
                        Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
                        if (ent != null && ent is BlockReference blkRefChild)
                        {
                            if (!GetAllBlkDefIds(tr, blkRefChild, ref blkDefNameIds))
                            {
                                continue;
                            }
                        }
                    }
                }

                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        ////Method to make border of groupbox become bold style:
        //private void PaintBorderBoldGroupBox(object sender, PaintEventArgs p)
        //{
        //    System.Windows.Forms.GroupBox box = (System.Windows.Forms.GroupBox)sender;
        //    p.Graphics.Clear(SystemColors.Control);
        //    p.Graphics.DrawString(box.Text, box.Font, Brushes.Black, 0, 0);
        //}

        #endregion

        //Constructor:
        public CAV_BView()
        {
            _isReadyToShow = false;

            InitializeComponent();
            
            if (!this.IsDesignMode())
            {
                if (!RuntimeConstruct())
                {
                    return;
                }
            }

            //Set language:
            SetLanguage();

            //Hide status label:
            //statusLbl.Visible = false;
            statusLbl.Text = _PreviewLoaded;
            fileCountLbl.Text = _CountFilesPrefix + "0";
            blkCountLbl.Text = _CountBlksPrefix + "0";
            fileLstBox.HorizontalScrollbar = true;
            blkLstBox.HorizontalScrollbar = true;

            //Merge table panel cells:
            //mainTbPanel.SetColumnSpan(labelGrp, 2);
            mainTbPanel.SetRowSpan(mPreviewCtrl, 3);
            mainTbPanel.SetRowSpan(fileGrpBox, 2);
            mainTbPanel.SetRowSpan(blkGrpBox, 3);

            //Initialize list for blocklist's width:
            blkLstWidths = new System.Collections.Generic.List<float>();
            blkLstWidths.Add(0);
            blkLstWidths.Add(274);
            mainTbPanel.ColumnStyles[2].Width = blkLstWidths[0];  //By default doesn't show block list

            //Get XML setting file's full path:
            _settingXmlFullPath = assemblyFolder + "\\" + _settingXmlFileName;

            //Set event for controls:
            RuntimeSetControlEvent();

            #region [Getting last leave path]
            xmlFullPath = assemblyFolder + "\\" + xmlFileName;
            _XMLNodeLocation = "CAV_" + AcadAddin.CommonDeclaration.Last_Path;

            //Load xml document by its path:
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlFullPath);

            XmlNode xmlNode = null;
            xmlNode = xmlDoc.DocumentElement.SelectSingleNode(_XMLNodeLocation);
            if (xmlNode != null)
            {
                //Get last path:
                string lastPath = xmlNode.InnerText;

                //Check it exist ?
                if (Directory.Exists(lastPath))
                {
                    _folderPath = lastPath;
                    folderBrwDlg.SelectedPath = _folderPath;
                }
                else
                {
                    //Reset XML node's text = "":
                    xmlNode.InnerText = "";
                    xmlDoc.Save(xmlFullPath);
                }
            }
            else
            {
                //"Cannot get main form's log."
                //"\nCommand ended!"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("read","last_left",true) , 
                        formOwner,
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                _isReadyToShow = false;
                return;
            }
            #endregion

            //Set icon for controls:
            RuntimeSetControlIcon();

            //Set border for group boxex to invisible:
            //labelGrp.Paint += PaintBorderlessGroupBox;
            //fileGrpBox.Paint += PaintBorderlessGroupBox;

            //DocumentCollection acDocMgr = AcAp.DocumentManager;
            //acDocMgr.DocumentDestroyed += new DocumentDestroyedEventHandler(docDestroyed);

            //Create list to contain names of detail information block:
            _DetalInfoBlkNames = new System.Collections.Generic.List<string>();

            //Mark everything ok, form is ready to show:
            _isReadyToShow = true;
        }

        //Method to clean up all resources for GSPreview:
        void OnDisposed(object sender, EventArgs e)
        {
            if (!this.IsDesignMode())
            {
                // clean up
                if (mPreviewCtrl != null)
                {
                    mPreviewCtrl.ClearAll();
                    mPreviewCtrl.Dispose();
                    mPreviewCtrl = null;
                }

                if (spheres != null)
                {
                    spheres.DisposeItems();
                    spheres = null;
                }

                if (dwgs != null)
                {
                    dwgs.DisposeItems();
                    dwgs = null;
                }

                //DocumentCollection acDocMgr = AcAp.DocumentManager;
                //acDocMgr.DocumentDestroyed -= new DocumentDestroyedEventHandler(docDestroyed);
            }
        }

        #region FileMenu
        private void FileOpenMenuItem_Click(object sender, EventArgs e)
        {
            //Open single file then update GSPreview:
            //OpenSingleFile();

            //Call folder picker:
            FolderPickerBtn_Click(new object(), new EventArgs());
        }

        private void OutputImageMenuItem_Click(object sender, EventArgs e)
        {
            #region [On building]
            //// pick the place where o output the image type
            //Autodesk.AutoCAD.Windows.SaveFileDialog dialog = new Autodesk.AutoCAD.Windows.SaveFileDialog("RenderToImage", null, "jpg;png;tif;bmp", "BlockViewSnapshotBrowseDialog", Autodesk.AutoCAD.Windows.SaveFileDialog.SaveFileDialogFlags.AllowAnyExtension);

            //// if all is ok?
            //if (DialogResult.OK == dialog.ShowDialog())
            //{
            //    // create an offscreen device
            //    using (Device device = new Device())
            //    {
            //        // get the size of the GS view
            //        Size size = mPreviewCtrl.ClientRectangle.Size;

            //        // resize the device to this
            //        device.OnSize(size);
            //        device.BackgroundColor = Color.Black;
            //        device.SetLogicalPalette(GSUtil.MyAcadColorMs);
            //        device.OnRealizeBackgroundPalette();
            //        device.OnRealizeForegroundPalette();

            //        // make a copy of the gs view
            //        using (Autodesk.AutoCAD.GraphicsSystem.View view = mPreviewCtrl.mpView.Clone(true, true))
            //        {
            //            try
            //            {
            //                // add it to the device
            //                device.Add(view);
            //                // now render the image to a bitmap

            //                //using( System.Drawing.Bitmap bitmap = view.RenderToImage() )
            //                //{
            //                // now save it out!!
            //                //bitmap.Save( dialog.Filename );
            //                //}
            //                using (Bitmap bitmap = view.GetSnapshot(mPreviewCtrl.ClientRectangle))
            //                {
            //                    bitmap.Save(dialog.Filename);
            //                }
            //            }
            //            finally
            //            {
            //                // do a clear up
            //                device.EraseAll();
            //            }
            //        }
            //    }
            //}
            #endregion

            MessageForBeingBuildedModule();
        }

        private void ExitMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

            // set focus to AutoCAD
            Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView();
        }
        #endregion

        #region [ViewMenu]

        #region Zooming
        private void ZoomWindowMenuItem_Click(object sender, EventArgs e)
        {
            // set that we now want zoom window mode
            mPreviewCtrl.mZooming = true;
        }

        private void ZoomExtentsMenuItem_Click(object sender, EventArgs e)
        {
            ////Check inside document is null or disposed?
            //if (mPreviewCtrl.InternalDocument.IsDisposed || mPreviewCtrl.InternalDocument == null)
            //{
            //    Autodesk.AutoCAD.ApplicationServices.Document curDoc = Autodesk.AutoCAD.ApplicationServices.
            //                                                    Application.DocumentManager.MdiActiveDocument;

            //    InitDrawingControl(curDoc, dwgs[dwgs.Count - 1]);

            //    return;
            //}

            // check to make sure it's valid
            if (mPreviewCtrl.mpView != null)
            {
                //mPreviewCtrl.mpView.ZoomExtents(mPreviewCtrl.mCurrentDwg.Extmin, mPreviewCtrl.mCurrentDwg.Extmax);
                //refreshView();

                if (!blkPreviewCBox.Checked) //Zoom extents for all database
                {
                    mPreviewCtrl.mpView.ZoomExtents(mPreviewCtrl.mCurrentDwg.Extmin, mPreviewCtrl.mCurrentDwg.Extmax);
                    refreshView();
                }
                else
                {
                    if (blkLstBox.Items.Count > 0 && blkLstBox.SelectedItem != null)
                    {
                        mPreviewCtrl.mpView.ZoomExtents(mPreviewCtrl.MinBlkPoint, mPreviewCtrl.MaxBlkPoint);
                        refreshView();
                    }
                }
            }
        }

        private void ZoomInMenuItem_Click(object sender, EventArgs e)
        {
            // check to make sure it's valid
            if (mPreviewCtrl.mpView != null)
            {
                // zoom in a bit
                mPreviewCtrl.mpView.Zoom(1.5);

                // refresh the view
                refreshView();
            }

        }

        private void ZoomOutMenuItem_Click(object sender, EventArgs e)
        {
            // check to make sure it's valid
            if (mPreviewCtrl.mpView != null)
            {
                // zoom out a bit
                mPreviewCtrl.mpView.Zoom(0.5);

                // refresh the view
                refreshView();
            }
        }

        #endregion Zooming

        #region [RandomShowSettings]
        private void showLinetypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // find out what the setting was before
            bool isChecked = this.showLinetypesToolStripMenuItem.Checked;
            // toggle it
            isChecked = !isChecked;
            this.showLinetypesToolStripMenuItem.Checked = isChecked;

            // now set the apt values in the gsview
            mPreviewCtrl.mpModel.LinetypesEnabled = isChecked;
            // refresh
            refreshView();
        }

        private void showSectioningToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // find out what the setting was before
            bool isChecked = this.showSectioningToolStripMenuItem.Checked;
            // toggle it
            isChecked = !isChecked;
            this.showSectioningToolStripMenuItem.Checked = isChecked;

            // now set the apt values in the gsview
            mPreviewCtrl.mpModel.EnableSectioning = isChecked;
            // refresh
            refreshView();
        }
        #endregion

        #region [RenderMode]

        void InitializeRenderModeMenuItems()
        {

        }

        #endregion

        #region [VisualStyle]

        void InitializeViewStyleMenuItems()
        {
            viewStyleToolStripMenuItem.DropDown.Items.AddRange(
                EnumToolStripMenuItem.CreateItems<VisualStyleType>(ViewStyleMenuItemClick));
        }

        // pass a view style you want, the gs view will update to it
        public void ChangeViewStyleTo(VisualStyleType vs)
        {
            VisualStyle oldVs = mPreviewCtrl.mpView.VisualStyle;
            mPreviewCtrl.mpView.VisualStyle = new VisualStyle(vs);
            if (oldVs != null)
                oldVs.Dispose();
            EnumToolStripMenuItem.UpdateCheckedState(viewStyleToolStripMenuItem.DropDown.Items, vs);
            refreshView();
        }

        void ViewStyleMenuItemClick(object sender, EventArgs e)
        {
            EnumToolStripMenuItem item = sender as EnumToolStripMenuItem;
            if (item != null && item.Value is VisualStyleType)
            {
                ChangeViewStyleTo((VisualStyleType)item.Value);
            }
        }
        #endregion

        #endregion

        #region [ToolMenu]
        private void RemapColoursNormalMenuItem_Click(object sender, EventArgs e)
        {
            //// get the current background color
            //Color color = mPreviewCtrl.mpDevice.BackgroundColor;
            //// now change it to black
            //color = Color.Black;
            //// and update it
            //mPreviewCtrl.mpDevice.BackgroundColor = color;
            //// finally set the logical palette
            //mPreviewCtrl.mpDevice.SetLogicalPalette(GSUtil.MyAcadColorMs);

            //// now update the gs view
            //refreshView();

            MessageForBeingBuildedModule();
        }

        private void RemapColoursCustomMenuItem_Click(object sender, EventArgs e)
        {
            //// get the current background color
            //Color color = mPreviewCtrl.mpDevice.BackgroundColor;

            //// now change it to black
            //color = Color.White;
            //// and update it
            //mPreviewCtrl.mpDevice.BackgroundColor = color;
            //// finally set the logical palette
            //mPreviewCtrl.mpDevice.SetLogicalPalette(GSUtil.MyAcadColorPs);

            //// now update the gs view
            //refreshView();

            MessageForBeingBuildedModule();
        }

        private Solid3d CreateSphere()
        {
            // create the sphere
            Solid3d sphere = new Solid3d();
            sphere.SetDatabaseDefaults();
            // let's create a random number generator for the sphere
            Random randomGenerator = new Random();
            double radius = randomGenerator.NextDouble() * 50;
            // create the sphere 
            sphere.CreateSphere(radius);
            // randomize the position using the randomizer!
            Matrix3d randomMover;
            double xVec = randomGenerator.NextDouble() * 500;
            double yVec = randomGenerator.NextDouble() * 400;
            double zVec = randomGenerator.NextDouble() * 300;
            randomMover = Matrix3d.Displacement(new Vector3d(xVec, yVec, zVec));
            // now apply the the transform to the sphere
            sphere.TransformBy(randomMover);

            // set the material name
            const string matname = "Sitework.Paving - Surfacing.Riverstone.Mortared";
            using (DBDictionary matdict = mPreviewCtrl.mCurrentDwg.MaterialDictionaryId.Open(OpenMode.ForRead) as DBDictionary)
            {
                // if we have found the material, set it to the sphere
                if (matdict.Contains(matname))
                    sphere.Material = matname;
                else
                {
                    // get the editor object
                    Editor ed = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor;
                    ed.WriteMessage("\nMaterial (" + matname + ") not found" + " - sphere will be rendered without it.", matname);
                }
            }

            return sphere;
        }
        
        private void AddTempEntityMenuItem_Click(object sender, EventArgs e)
        {
            //// add a random sphere
            //spheres.Add(CreateSphere());
            //mPreviewCtrl.mpView.Add(spheres[spheres.Count - 1], mPreviewCtrl.mpModel);

            MessageForBeingBuildedModule();
        }

        private void AddEntityToDwgMenuItem_Click(object sender, EventArgs e)
        {
            //// this time add a new object to the current drawing
            //using (Solid3d sphere = CreateSphere())
            //{
            //    // next add it to the current space
            //    using (BlockTableRecord curSpace = mPreviewCtrl.mCurrentDwg.CurrentSpaceId.Open(OpenMode.ForWrite) as BlockTableRecord)
            //        curSpace.AppendEntity(sphere);

            //    // then add to the gs view
            //    mPreviewCtrl.mpView.Add(sphere, mPreviewCtrl.mpModel);
            //}

            MessageForBeingBuildedModule();
        }

        #endregion

        #region [BlockViewSpecific]

        //Initializes the GsPreViewCtrl by model space:
        public bool InitDrawingControl(Document doc, Database db)
        {
            bool retVal = false;

            // initialize the control
            mPreviewCtrl.Init(doc, db);

            // now find out what the current view is and set the GsPreviewCtrl to the same
            retVal = SetViewTo(mPreviewCtrl.mpView, db);
            if (!retVal)
            {
                return retVal;
            }

            // now add the current space to the GsView
            //using (BlockTableRecord curSpace = db.CurrentSpaceId.Open(OpenMode.ForRead, true, true) as BlockTableRecord)
            //    mPreviewCtrl.mpView.Add(curSpace, mPreviewCtrl.mpModel);
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                ////Using current database:
                //BlockTableRecord curSpace = tr.GetObject(db.CurrentSpaceId, OpenMode.ForRead) as BlockTableRecord;
                //mPreviewCtrl.mpView.Add(curSpace, mPreviewCtrl.mpModel);

                //Always using modelspace:
                BlockTable blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord modelSpace = tr.GetObject(blt[BlockTableRecord.ModelSpace], OpenMode.ForRead) as BlockTableRecord;

                //Clear all old drawable in view:
                mPreviewCtrl.mpView.EraseAll();

                //Draw new drawable in view:
                mPreviewCtrl.mpView.Add(modelSpace, mPreviewCtrl.mpModel);

                //Do this to improve performace:
                tr.Commit();
            }

            // set the view style to basic
            ChangeViewStyleTo(VisualStyleType.Basic);

            //Mark everything is ok:
            retVal = true;

            return retVal;
        }

        //Init the GsPreViewCtrl for block by its name:
        private bool InitDrawingControl(string blkName)
        {
            bool retVal = false;

            ////// initialize the control
            //mPreviewCtrl.Init(doc, db);

            //Set the GsPreviewCtrl view by block name:
            retVal = SetViewTo(mPreviewCtrl.mpView, blkName);
            if (!retVal)
            {
                //"Cannot set view for GSPreview!"
                MessageBox.Show("GSPreview: " +
                                "\n" + CommonMessage.FAIL_TO_DO("set","view",true), formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return retVal;
            }

            Database srcDb = dwgs[dwgs.Count - 1];
            if (srcDb == null || srcDb.IsDisposed)
            {
                //"Lost reference to source database!"
                MessageBox.Show(CommonMessage.LOST_REF_TO("database"), formOwner,
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);

                return false;
            }

            using (Transaction tr = srcDb.TransactionManager.StartTransaction())
            {
                //Always using modelspace:
                BlockTable blt = tr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord blkDef = tr.GetObject(blt[blkName], OpenMode.ForRead) as BlockTableRecord;

                //Clear all old drawable in view:
                mPreviewCtrl.mpView.EraseAll();

                //Draw new drawable in view:
                mPreviewCtrl.mpView.Add(blkDef, mPreviewCtrl.mpModel);

                tr.Commit();
            }

            // set the view style to basic
            ChangeViewStyleTo(VisualStyleType.Basic);

            //Mark everything is ok:
            retVal = true;

            return retVal;
        }

        // sets a GsView to the active viewport data held by the database
        public bool SetViewTo(Autodesk.AutoCAD.GraphicsSystem.View view, Database db)
        {
            bool retVal = false;

            // just check we have valid extents
            if (db.Extmax.X < db.Extmin.X || db.Extmax.Y < db.Extmin.Y || db.Extmax.Z < db.Extmax.Z)
            {
                db.Extmin = new Point3d(0, 0, 0);
                db.Extmax = new Point3d(400, 400, 400);
            }
            // get the dwg extents
            Point3d extMax = db.Extmax;
            Point3d extMin = db.Extmin;

            // now the active viewport info
            double height = 0.0, width = 0.0, viewTwist = 0.0;
            Point3d targetView = new Point3d();
            Vector3d viewDir = new Vector3d();

            retVal = GSUtil.GetActiveViewPortInfo(ref height, ref width, ref targetView, ref viewDir, ref viewTwist, true);
            if (!retVal)
            {
                return retVal;
            }
            else
            {
                //Do this to keep focus on main form:
                this.Focus();
            }

            // from the data returned let's work out the viewmatrix
            viewDir = viewDir.GetNormal();
            Vector3d viewXDir = viewDir.GetPerpendicularVector().GetNormal();
            viewXDir = viewXDir.RotateBy(viewTwist, -viewDir);
            Vector3d viewYDir = viewDir.CrossProduct(viewXDir);
            Point3d boxCenter = extMin + 0.5 * (extMax - extMin);
            Matrix3d viewMat;
            viewMat = Matrix3d.AlignCoordinateSystem(boxCenter, Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
              boxCenter, viewXDir, viewYDir, viewDir).Inverse();
            Extents3d wcsExtents = new Extents3d(extMin, extMax);
            Extents3d viewExtents = wcsExtents;
            viewExtents.TransformBy(viewMat);
            double xMax = System.Math.Abs(viewExtents.MaxPoint.X - viewExtents.MinPoint.X);
            double yMax = System.Math.Abs(viewExtents.MaxPoint.Y - viewExtents.MinPoint.Y);
            Point3d eye = boxCenter + viewDir;

            // finally set the Gs view to the dwg view
            view.SetView(eye, boxCenter, viewYDir, xMax, yMax);

            // now update
            refreshView();

            //Mark everything is ok:
            retVal = true;

            return retVal;
        }

        // sets a GsView to the active viewport data held by the database
        public bool SetViewTo(Autodesk.AutoCAD.GraphicsSystem.View view, string blkName)
        {
            bool retVal = false;

            //Get source database:
            Database srcDb = dwgs[dwgs.Count - 1];
            if (srcDb == null || srcDb.IsDisposed)
            {
                return false;
            }

            //Get block definition extents:
            //Add BlockDefinition to GSPreview:
            Point3d extMax;
            Point3d extMin;
            using (Transaction tr = srcDb.TransactionManager.StartTransaction())
            {
                BlockTable blt = tr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord blkDef = tr.GetObject(blt[blkName], OpenMode.ForRead) as BlockTableRecord;

                //Create extents collection:
                Extents3d extents = new Extents3d();

                //Iterate all entities inside BlockDefinition
                // then add extents to collection:
                foreach (ObjectId id in blkDef)
                {
                    Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;

                    try
                    {
                        Extents3d ex = ent.GeometricExtents;

                        if (ex != null)
                        {
                            extents.AddExtents(ex);
                        }
                    }
                    catch (System.Exception)
                    {
                        continue;
                    }
                }

                //Get max, min extents:
                extMin = extents.MinPoint;
                extMax = extents.MaxPoint;

                tr.Commit();
            }

            if (extMin == extMax)
            {
                return false;
            }
            else
            {
                //Store extents point for block:
                mPreviewCtrl.SetBlockExtentsPoint(extMin, extMax);
            }

            // now the active viewport info
            double height = 0.0, width = 0.0, viewTwist = 0.0;
            Point3d targetView = new Point3d();
            Vector3d viewDir = new Vector3d();

            retVal = GSUtil.GetActiveViewPortInfo(ref height, ref width, ref targetView, ref viewDir, ref viewTwist, true);
            if (!retVal)
            {
                return retVal;
            }
            else
            {
                //Do this to keep focus on main form:
                this.Focus();
            }

            // from the data returned let's work out the viewmatrix
            viewDir = viewDir.GetNormal();
            Vector3d viewXDir = viewDir.GetPerpendicularVector().GetNormal();
            viewXDir = viewXDir.RotateBy(viewTwist, -viewDir);
            Vector3d viewYDir = viewDir.CrossProduct(viewXDir);
            Point3d boxCenter = extMin + 0.5 * (extMax - extMin);
            Matrix3d viewMat;
            viewMat = Matrix3d.AlignCoordinateSystem(boxCenter, Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
              boxCenter, viewXDir, viewYDir, viewDir).Inverse();
            Extents3d wcsExtents = new Extents3d(extMin, extMax);
            Extents3d viewExtents = wcsExtents;
            viewExtents.TransformBy(viewMat);
            double xMax = System.Math.Abs(viewExtents.MaxPoint.X - viewExtents.MinPoint.X);
            double yMax = System.Math.Abs(viewExtents.MaxPoint.Y - viewExtents.MinPoint.Y);
            Point3d eye = boxCenter + viewDir;

            // finally set the Gs view to the dwg view
            view.SetView(eye, boxCenter, viewYDir, xMax, yMax);

            // now update
            refreshView();

            //Mark everything is ok:
            retVal = true;

            return retVal;
        }

        //Method to update view after set view:
        //*** Must control document memory well here to no generate Access violation:
        public void refreshView()
        {
            try
            {
                if (!IsDesignMode)
                {
                    mPreviewCtrl.mpView.Invalidate();
                    mPreviewCtrl.mpView.Update();
                }
            }
            catch (System.Exception ex)
            {
                //"Cannot refresh view!"
                //$"\nError: {ex.Message}"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("refresh","view",true)+ 
                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }
        }

        #endregion

        //Method to open single dwg file and update GSPrevew:
        [Obsolete("Use OpenFolder")]
        private void OpenSingleFile()
        {
            // pick the place where o output the image type
            Autodesk.AutoCAD.Windows.OpenFileDialog dialog = new Autodesk.AutoCAD.Windows.OpenFileDialog("Open DWG File", null, "dwg", "OpenDWGFileDialog", Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.NoUrls);

            // if all is ok?
            if (DialogResult.OK == dialog.ShowDialog())
            {
                // clear the preview control
                mPreviewCtrl.mpView.EraseAll();

                //// create a new database
                //dwgs.Add( new Database( false, true ) );

                #region Modified code
                // create a new database
                if (dwgs.Count > 0)
                {
                    // Dispose the earlier database.
                    dwgs[0].Dispose();

                    // Create a new database for the existing one
                    dwgs[0] = new Database(false, true);
                }
                else
                    dwgs.Add(new Database(false, true));
                #endregion

                // now read it in
                _SrcDwgFullName = dialog.Filename;

                Document curDoc = AcAp.DocumentManager.MdiActiveDocument;

                if (!string.IsNullOrEmpty(_SrcDwgFullName) &&
                    !string.IsNullOrWhiteSpace(_SrcDwgFullName))
                {
                    dwgs[dwgs.Count - 1].ReadDwgFile(_SrcDwgFullName, FileOpenMode.OpenForReadAndReadShare, true, "");
                }
                else
                {
                    dwgs[dwgs.Count - 1] = curDoc.Database;

                }

                // initialising the drawing control, pass the existing document still as the gs view still refers to it
                InitDrawingControl(curDoc, dwgs[dwgs.Count - 1]);
            }
        }

        private void UseCadLib_CheckedChanged(object sender, EventArgs e)
        {
            //Clear folder path text:
            folderPathTbx.Text = "";

            System.Windows.Forms.CheckBox chkBox = (System.Windows.Forms.CheckBox)sender;

            //Clear file list box:
            if (fileLstBox.Items != null && fileLstBox.Items.Count > 0)
            {
                fileLstBox.Items.Clear();
                fileCountLbl.Text = _CountFilesPrefix + "0";
            }

            //Change folder browser selected path:
            if (chkBox.Checked)
            {
                folderBrwDlg.SelectedPath = assemblyFolder + "\\" + CommonDeclaration.CadLib_Path;
            }
            else
            {
                folderBrwDlg.SelectedPath = _folderPath;
            }
        }

        //Method to let user select folder then
        // - populate listbox:
        // - select first item in listbox:
        // - update GSPreview:
        private void FolderPickerBtn_Click(object sender, EventArgs e)
        {
            //Ask user to select folder by dialog:
            //then fill out listbox:
            if (folderBrwDlg.ShowDialog() == DialogResult.OK)
            {
                //Clear old list:
                fileLstBox.Items.Clear();
                fileCountLbl.Text = _CountFilesPrefix + "0";

                if (!useLibChkBox.Checked)
                {
                    //Folder path:
                    _folderPath = folderBrwDlg.SelectedPath;

                    //Update XML file:
                    UpdateXml(_folderPath);
                }

                //Set folder path's textbox:
                //folderPathLbl.Text = "Path : " + folderBrwDlg.SelectedPath;
                folderPathTbx.Text = folderBrwDlg.SelectedPath;

                //Add items to file list box:
                AddFilesListBox(folderBrwDlg.SelectedPath);
            }

            //Select first item in listbox:
            if (fileLstBox != null && fileLstBox.Items.Count > 0)
            {
                fileLstBox.SelectedIndex = 0;
            }
        }

        private void FileLstBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Temporary disable event handler for BlockPreview's checkbox,
                //then change check value to false, clear listbox, reactivate event handler.
                blkPreviewCBox.CheckedChanged -= new System.EventHandler(PreviewBlock_CheckedChanged);
                blkPreviewCBox.Checked = false;
                if (blkLstBox != null && blkLstBox.Items.Count > 0)
                {
                    blkLstBox.Items.Clear();
                    blkCountLbl.Text = _CountBlksPrefix + "0";
                }
                blkPreviewCBox.CheckedChanged += new System.EventHandler(PreviewBlock_CheckedChanged);

                statusLbl.Text = _PreviewLoading;

                //Update source file name:
                _SrcDwgFullName = folderBrwDlg.SelectedPath + "\\" + fileLstBox.SelectedItem.ToString();

                // clear the preview control
                mPreviewCtrl.mpView.EraseAll();

                #region [Modified code]

                // create a new database
                if (dwgs.Count > 0)
                {
                    #region [Old codes 1]
                    //// Dispose the earlier database.
                    //dwgs[0].Dispose();
                    #endregion

                    #region [Old codes 2]
                    //Dispose all earlier databases:
                    //foreach (var tempDb in dwgs)
                    //{
                    //    if (tempDb != null && !tempDb.IsDisposed)
                    //    {
                    //        try
                    //        {
                    //            tempDb.Dispose();
                    //        }
                    //        catch (System.Exception ex)
                    //        {
                    //            MessageBox.Show("Cannot dispose earlier database(s)!" +
                    //                            $"\nError: {ex.Message}",
                    //                            formOwner,
                    //                            MessageBoxButtons.OK,
                    //                            MessageBoxIcon.Error);
                    //            return;
                    //        }
                    //    }
                    //}
                    #endregion

                    //Dispose all earlier databases:
                    for (int i = 0; i < dwgs.Count; i++)
                    {
                        if (dwgs[i] != null && !dwgs[i].IsDisposed)
                        {
                            try
                            {
                                dwgs[i].Dispose();
                                dwgs[i] = null;
                            }
                            catch (System.Exception ex)
                            {
                                //"Cannot dispose earlier database(s)!"
                                //$"\nError: {ex.Message}"
                                MessageBox.Show(CommonMessage.FAIL_TO_DO("dispose","database",true) +
                                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                                formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }

                    // Create a new database for the existing one
                    dwgs[0] = new Database(false, true);
                }
                else
                    dwgs.Add(new Database(false, true));

                #endregion

                //Get reference to current document:
                Document curDoc = AcAp.DocumentManager.MdiActiveDocument;
                if (curDoc == null)
                {
                    //"Lost reference to current document!"
                    MessageBox.Show(CommonMessage.LOST_REF_TO("currentdwg"),
                               formOwner,
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);

                    statusLbl.Text = _PreviewError;

                    return;
                }

                //Load document to drawing container by its full name:
                // *** remember to check full name exists and it is not null, empty or whitespace
                if (!string.IsNullOrEmpty(_SrcDwgFullName) &&
                    !string.IsNullOrWhiteSpace(_SrcDwgFullName) &&
                    File.Exists(_SrcDwgFullName)
                    )
                {
                    //dwgs[dwgs.Count - 1].ReadDwgFile(_SrcDwgFullName, FileOpenMode.OpenForReadAndReadShare, true, "");
                    dwgs[dwgs.Count - 1].ReadDwgFile(_SrcDwgFullName, FileOpenMode.OpenForReadAndAllShare, true, "");
                }
                else
                {
                    dwgs[dwgs.Count - 1] = curDoc.Database;
                }

                #region [Old codes - 1]
                //if (!CommonCommands.IsInModel())
                //{
                //    MessageBox.Show("This function must be used in ModelSpace." +
                //                     "\nPlease switch to ModelSpace then try again!",
                //                     formOwner,
                //                     MessageBoxButtons.OK,
                //                     MessageBoxIcon.Error);

                //    statusLbl.Text = _PreviewError;

                //    return;
                //}
                #endregion

                #region [Old codes - 2]
                ////Check model or paper space?
                //int cvPort = System.Convert.ToInt32(AcAp.GetSystemVariable("CVPORT"));
                //if (cvPort <= 1)
                //{
                //    MessageBox.Show("This function must be used in ModelSpace." +
                //                    "\nPlease switch to ModelSpace then try again!",
                //                    formOwner,
                //                    MessageBoxButtons.OK,
                //                    MessageBoxIcon.Error);

                //    statusLbl.Text = _PreviewError;

                //    return;
                //}
                #endregion

                //// initialising the drawing control, pass the existing document still as the gs view still refers to it
                //InitDrawingControl(curDoc, dwgs[dwgs.Count - 1]);

                #region [On bulding (240630)]

                //Check ComboBox is null?
                if (layoutsCoBx == null)
                {
                    //"Lost reference to layouts' ComboBox!"
                    MessageBox.Show(CommonMessage.LOST_REF_TO("ComboBox"),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                    statusLbl.Text = _PreviewError;
                    return;
                }

                //Load combobox for layouts:
                if (!LoadLayoutsComboBox(dwgs[dwgs.Count - 1]))
                {
                    statusLbl.Text = _PreviewError;
                    return;
                }

                //Activate ModelSpace by default:
                layoutsCoBx.SelectedItem = "Model";

                #endregion

                //Mark that preview control was loaded:
                statusLbl.Text = _PreviewLoaded;
            }
            catch (System.Exception ex)
            {
                statusLbl.Text = _PreviewError;

                //"Error when loading preview."
                //$"\nError: {ex.Message}"
                //"\nRemember to use this form in MODELSPACE only!"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("load","preview",true) +
                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }
        }

        //When layouts'ComboBox change its selected item,
        //Update GSPreviewControl accordingly to that item:
        private void LayoutsCoBx_SelectedIndexChanged(object sender, EventArgs e)
        {
            Document curDoc = AcAp.DocumentManager.MdiActiveDocument;

            if (layoutsCoBx.SelectedItem.ToString() == "Model")
            {
                #region [Solution 1 - database first(on hold)]

                ////By default preview full drawing => consider to preview block
                ////if drawing contains multiple of standard blocks.
                ////In case preview full drawing, initialising the drawing control.
                ////Pass the existing document still as the GSView still refers to it
                //InitDrawingControl(curDoc, dwgs[dwgs.Count - 1]);

                #endregion

                #region [Solution - member block first]

                blkPreviewCBox.Checked = true;  //=> render block members

                //Check block list, in case no member is found => render all database:
                if (blkLstBox.Items.Count == 0)
                {
                    blkPreviewCBox.Checked = false; //=> render all database:
                }

                //Change LayoutTablePanel width:
                if (blkPreviewCBox.Checked)
                {
                    if (mainTbPanel.ColumnStyles[2].Width == blkLstWidths[0])
                    {
                        mainTbPanel.ColumnStyles[2].Width = blkLstWidths[1];
                        mPreviewCtrl.Invalidate();
                    }
                }
                else
                {
                    if (mainTbPanel.ColumnStyles[2].Width == blkLstWidths[1])
                    {
                        mainTbPanel.ColumnStyles[2].Width = blkLstWidths[0];
                        mPreviewCtrl.Invalidate();
                    }
                }

                #endregion
            }
            else
            {
                MessageForBeingBuildedModule();
                return;
            }
        }

        private void PreviewBlock_CheckedChanged(object sender, EventArgs e)
        {
            if (blkPreviewCBox.Checked)
            {
                #region [Check input]

                //Check reference to folder path:
                if (folderPathTbx == null)
                {
                    //"Lost reference to folder path!"
                    MessageBox.Show(CommonMessage.LOST_REF_TO("folderpath"), formOwner,
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                //Check folder path is valid:
                if (string.IsNullOrEmpty(folderPathTbx.Text) ||
                    string.IsNullOrWhiteSpace(folderPathTbx.Text))
                {
                    return;
                }

                //Check reference to file ListBox:
                if (fileLstBox == null)
                {
                    //"Lost reference to file list!"
                    MessageBox.Show(CommonMessage.LOST_REF_TO("filelistbox"), formOwner,
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    return;
                }

                //Check file ListBox's items:
                if (fileLstBox.Items.Count == 0)
                {
                    //"File list contains nothing!"
                    MessageBox.Show(CommonMessage.OBJECT_CONTAIN_NOTHING("filelistbox"), formOwner,
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    return;
                }

                //Check selected item:
                if (fileLstBox.SelectedItem == null)
                {
                    //"Lost reference to selected file!"
                    MessageBox.Show(CommonMessage.LOST_REF_TO("selectedfile"), formOwner,
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    return;
                }

                //Get source file name:
                string srcDwgFullName = folderPathTbx.Text + "\\" + fileLstBox.SelectedItem.ToString();

                //Check file exist?
                if (!File.Exists(srcDwgFullName))
                {
                    //"Source file doesn't exist or was deleted!"
                    MessageBox.Show(CommonMessage.LOST_REF_TO("sourcedata"), formOwner,
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    return;
                }
                
                #endregion

                //Update GSPreview's current database.
                if (dwgs.Count >= 1)
                {
                    this.mPreviewCtrl.mCurrentDwg = dwgs[dwgs.Count - 1];
                }
                else
                {
                    MessageBox.Show(CommonMessage.LOST_REF_TO("database") +
                                    "\n" + CommonMessage.GetStringFromCurResx("FORM_NEED_CLOSE"),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                    this.Close();
                    return;
                }

                //Clear old block's list:
                if (blkLstBox != null && blkLstBox.Items.Count > 0)
                {
                    blkLstBox.Items.Clear();
                    blkCountLbl.Text = _CountBlksPrefix + "0";
                }

                //Load block list:
                if (!LoadBlockList(srcDwgFullName))
                {
                    return;
                }

                //Select first item in block list:
                if (this.blkLstBox != null &&
                    this.blkLstBox.Items.Count > 0)
                {
                    this.blkLstBox.SelectedIndex = 0;
                }
            }
            else
            {
                if (blkLstBox != null && blkLstBox.Items.Count > 0)
                {
                    blkLstBox.Items.Clear();
                    blkCountLbl.Text = _CountBlksPrefix + "0";
                }

                if (dwgs.Count >= 1)
                {
                    Database srcDb = dwgs[dwgs.Count - 1];

                    if (srcDb != null && !srcDb.IsDisposed)
                    {
                        #region [Old codes]

                        ////Check current file selected listbox equal with source database.
                        ////If so then return. We don't want to update 
                        //if (!string.IsNullOrEmpty(folderPathTbx.Text) &&
                        //    !string.IsNullOrWhiteSpace(folderPathTbx.Text) &&
                        //    fileLstBox.SelectedItem != null)
                        //{
                        //    string curDwgSrcPath = folderPathTbx.Text + "\\" + fileLstBox.SelectedItem.ToString();
                        //    if (System.IO.File.Exists(curDwgSrcPath) &&
                        //        curDwgSrcPath == srcDb.Filename)
                        //    {
                        //        return;
                        //    }
                        //}

                        #endregion

                        //Preview source drawing file:
                        Document curDoc = AcAp.DocumentManager.MdiActiveDocument;
                        InitDrawingControl(curDoc, srcDb);
                    }
                }
            }
        }

        private void BlockLstBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (blkPreviewCBox.Checked &&
                blkLstBox != null &&
                blkLstBox.SelectedItem != null)
            {
                //Do preview for block
                string blkName = blkLstBox.SelectedItem.ToString();

                if (!InitDrawingControl(blkName))
                {
                    return;
                }
            }
        }

        private void GSPreview_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                ContextMenuStrip cms = new ContextMenuStrip();

                //CommonMessage.GetStringFromCurResx("")
                //"Zoom window"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("zoomwindow"), 
                                                    AcadAddin.Properties.Resources.ZoomWindowIcon,
                                                    ZoomWindowMenuItem_Click));
                //"Zoom extents"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("zoomextents"), 
                                                    AcadAddin.Properties.Resources.ZoomFitLogo,
                                                    ZoomExtentsMenuItem_Click));
                //"Insert to UCS"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("INSERT_TO_UCS",false), 
                                                    AcadAddin.Properties.Resources.InsertDwgIcon,
                                                    InsertCadBtn_Click));

                if (this.mainTbPanel.ColumnStyles[2].Width == blkLstWidths[0])
                {
                    //"Show block list"
                    cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("SHOW_BLOCK_LIST"), 
                                                        AcadAddin.Properties.Resources.MaximizeLogo,
                                                        HideOrShowBlkLstMenuItem_Click));
                }
                else
                {
                    //"Hide block list"
                    cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("HIDE_BLOCK_LIST"), 
                                                        AcadAddin.Properties.Resources.MinimizeLogo,
                                                        HideOrShowBlkLstMenuItem_Click));
                }

                //"Hide form"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("hide"), 
                                                    AcadAddin.Properties.Resources.HideLogo,
                                                    HideBtn_Click));

                //Show menu on datagrid:
                cms.Show(sender as System.Windows.Forms.Control, new Point(e.X, e.Y));
            }
        }

        [Obsolete("No need to create nested form for block view!")]
        private void BlocksDetailBtnOld_Click(object sender, EventArgs e)
        {
            //MessageForBeingBuildedModule();

            //if (_blksDetailFrm == null)
            //    _blksDetailFrm = new CAV_BlocksDetail_Frm();
            //else if (_blksDetailFrm.IsDisposed == true)
            //{
            //    //Clear old instance :
            //    _blksDetailFrm = null;

            //    //Create new instance :
            //    _blksDetailFrm = new CAV_BlocksDetail_Frm();
            //}

            //if (_blksDetailFrm.IsReadyToShow)
            //{
            //    Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            //    Editor ed = doc.Editor;

            //    try
            //    {
            //        //Show/ activate form:
            //        if (_blksDetailFrm.Visible == false)
            //        {
            //            //AcAp.ShowModelessDialog(null, _Form, false);
            //            if (AcAp.ShowModalDialog(null, _blksDetailFrm, false) == DialogResult.Cancel)
            //            {
            //                _blksDetailFrm.Dispose();
            //            }

            //        }
            //        else
            //        {
            //            _blksDetailFrm.Activate();
            //        }

            //    }
            //    catch (System.Exception ex)
            //    {
            //        MessageBox.Show($"Cannot initialize form. Error: {ex.Message}",
            //                        formOwner,
            //                        MessageBoxButtons.OK,
            //                        MessageBoxIcon.Error);

            //        _blksDetailFrm.Dispose();

            //        return;
            //    }
            //}
            //else
            //{
            //    _blksDetailFrm.Dispose();
            //}
        }

        //Zoom in out preview on mouse wheeling:
        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            if (!IsDesignMode)
            {
                // if we are wheeling down
                if (e.Delta < 0)
                    mPreviewCtrl.mpView.Zoom(0.5);
                else
                    // wheel up!
                    mPreviewCtrl.mpView.Zoom(1.5);

                refreshView();
            }
        }

        //Find all possible values:
        private void FindTbx_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = (sender as System.Windows.Forms.TextBox).Text;
                string pattern = CommonCommands.GetMatchPattern(searchValue);

                //Dictionary contains found item + its index:
                Dictionary<string, int> foundDic = new Dictionary<string, int>();

                System.Windows.Forms.ListBox lstBoxToFind;

                if (sender == findTbx)
                {
                    lstBoxToFind = fileLstBox;
                }
                else if(sender == findBlkTbx)
                {
                    lstBoxToFind = blkLstBox;
                }
                else
                {
                    //"Lost reference between textbox and listbox!"
                    MessageBox.Show(CommonMessage.FAIL_TO_DO("link", "sourcedata",true), 
                            formOwner,
                            MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }

                if (lstBoxToFind.Items.Count == 0)
                {
                    //"Listbox contains nothing!"
                    MessageBox.Show(CommonMessage.OBJECT_CONTAIN_NOTHING("listbox"), 
                             formOwner,
                             MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    return;
                }

                for (int i = 0; i < lstBoxToFind.Items.Count; i++)
                {
                    if (Regex.IsMatch(lstBoxToFind.Items[i].ToString(), pattern, RegexOptions.IgnoreCase))
                    {
                        foundDic.Add(lstBoxToFind.Items[i].ToString(), i);
                    }
                }

                if (foundDic.Count == 0)
                {
                    //"Value was not found!"
                    MessageBox.Show(CommonMessage.VALUE_NOT_FOUND(), 
                            formOwner,
                            MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    e.Handled = true;
                    e.SuppressKeyPress = true; //No beep ^^

                    if (foundDic.Count == 1)
                    {
                        lstBoxToFind.SelectedIndex = foundDic.ElementAt(0).Value;
                    }
                    else
                    {
                        //Create found result form:
                        if (_findResForm == null)
                            _findResForm = new KRSI_FindFrm();
                        else if (_findResForm.IsDisposed == true)
                        {
                            //Clear old instance :
                            _findResForm = null;

                            //Create new instance :
                            _findResForm = new KRSI_FindFrm();
                        }

                        //Set up form base caption:
                        _findResForm.FormBaseCaption = "CAV_Find";
                        //if (sender == findBlkTbx)
                        //{
                        //    _findResForm.FormBaseCaption = "CAV_Find" + "(Block)";
                        //}

                        //Set up datagridview for form:
                        if (!_findResForm.SetUpDataGridView(foundDic, lstBoxToFind, searchValue))
                        {
                            //"Error when loading data for Datagridview."
                            string errMsg = CommonMessage.FAIL_TO_DO("load", "DataGridView");

                            if (string.IsNullOrEmpty(_findResForm.ErrorMessage) ||
                                string.IsNullOrWhiteSpace(_findResForm.ErrorMessage))
                            {
                                //"\nError: unknown!"
                                errMsg += "\n" + CommonMessage.GetStringFromCurResx("ERROR_UNKNOWN");
                            }
                            else
                            {
                                //$"\nError: {_findResForm.ErrorMessage}"
                                errMsg += "\n" + CommonMessage.ERROR_MES(_findResForm.ErrorMessage);
                            }

                            MessageBox.Show(errMsg, formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);

                            lstBoxToFind.SelectedIndex = foundDic.ElementAt(0).Value;

                            return;
                        }
                        else
                        {
                            try
                            {
                                //Show find result form:
                                if (_findResForm.Visible == false)
                                {
                                    if (Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(null, _findResForm, false) == DialogResult.Cancel)
                                    {
                                        _findResForm.Dispose();
                                    }
                                }
                                else
                                {
                                    _findResForm.Activate();
                                }
                            }
                            catch (System.Exception ex)
                            {
                                //"Error when showing found items."
                                //$"\nError: {ex.Message}"
                                MessageBox.Show(CommonMessage.FAIL_TO_DO("show","item",true) +
                                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                                formOwner,
                                                MessageBoxButtons.OK,MessageBoxIcon.Error);
                                _findResForm.Dispose();
                                return;
                            }
                        }
                    }
                }
            }
        }

        private void FileLstBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && fileLstBox.SelectedItem != null)
            {
                //Create new context menu:
                ContextMenuStrip cms = new ContextMenuStrip();

                //"Open or activate"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("openactive"), 
                                                    AcadAddin.Properties.Resources.DwgIcon,
                                                    MenuOpenOrActivate_Click));

                //"Save as"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("SAVE_AS"),
                                                    AcadAddin.Properties.Resources.SaveAsIcon,
                                                    MenuSaveAs_Click));

                //"Refresh"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("refresh"), 
                                                    Properties.Resources.RefreshLogo,
                                                    MenuToRefresh_Click));

                //Show menu:
                cms.Show(fileLstBox, new Point(e.X, e.Y));
            }
        }

        private void MenuOpenOrActivate_Click(object sender, EventArgs e)
        {
            //Check listbox count:
            if (this.fileLstBox.Items.Count == 0)
            {
                MessageBox.Show("Listbox contains nothing!" 
                                , formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }

            //Check listbox's selected item:
            if (this.fileLstBox.SelectedItem == null)
            {
                MessageBox.Show("Lost reference to selected item!"
                                , formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }

            //Check dwg full name:
            if (!File.Exists(_SrcDwgFullName))
            {
                MessageBox.Show("File doesn't exist!"
                                , formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }

            //Hide form:
            HideBtn_Click(sender, e);

            //Get all current documents:
            DocumentCollection acDocMgr = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager;

            //Store old activate mode:
            bool oldDocActivateMode = acDocMgr.DocumentActivationEnabled;

            try
            {
                if (!acDocMgr.DocumentActivationEnabled)
                {
                    acDocMgr.DocumentActivationEnabled = true;
                }

                foreach (Document memDoc in acDocMgr)
                {
                    if (memDoc.Name == _SrcDwgFullName)
                    {
                        //Activate document:
                        Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument = memDoc;

                        return;
                    }
                }

                //If come to this, then open + activate:
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument = acDocMgr.Open(_SrcDwgFullName, false);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error when trying to open/ activate source file." +
                                $"\nError: {ex.Message}"
                                , formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }
            finally
            {
                //Remember to reset document activation mode:
                if (acDocMgr.DocumentActivationEnabled != oldDocActivateMode)
                {
                    acDocMgr.DocumentActivationEnabled = oldDocActivateMode;
                }
            }
        }

        private void MenuSaveAs_Click(object sender, EventArgs e)
        {
            //MessageForBeingBuildedModule();
            //return;

            //Check selected item in file's ListBox:
            if (fileLstBox.SelectedItem == null)
            {
                MessageBox.Show(CommonMessage.LOST_REF_TO("selected_item"),
                                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get source file path:
            string srcFilePath = folderPathTbx.Text + "\\" + fileLstBox.SelectedItem;
            if (!System.IO.File.Exists(srcFilePath))
            {
                MessageBox.Show(CommonMessage.FILE_NOT_EXIST(srcFilePath),
                                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get default file name:
            string defaultFileName;
            try
            {
                if (string.IsNullOrEmpty(_LastSaveAsPath) ||
                    string.IsNullOrWhiteSpace(_LastSaveAsPath) ||
                    !System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(_LastSaveAsPath)))
                {
                    defaultFileName = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" +
                                    fileLstBox.SelectedItem;
                }
                else
                {
                    defaultFileName = System.IO.Path.GetDirectoryName(_LastSaveAsPath) + "\\" +
                                    fileLstBox.SelectedItem;
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                formOwner,MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            //Create new instance of 'SaveFileDialog':
            Autodesk.AutoCAD.Windows.SaveFileDialog.SaveFileDialogFlags saveFileFlag =
                Autodesk.AutoCAD.Windows.SaveFileDialog.SaveFileDialogFlags.DoNotWarnIfFileExist 
                //| Autodesk.AutoCAD.Windows.SaveFileDialog.SaveFileDialogFlags.NoUrls
                | Autodesk.AutoCAD.Windows.SaveFileDialog.SaveFileDialogFlags.ForceDefaultFolder
                | Autodesk.AutoCAD.Windows.SaveFileDialog.SaveFileDialogFlags.DoNotTransferRemoteFiles;

            Autodesk.AutoCAD.Windows.SaveFileDialog saveAsDlg = new Autodesk.AutoCAD.Windows.SaveFileDialog(
                CommonMessage.GetStringFromCurResx("SAVE_AS"), defaultFileName , "dwg", formOwner, saveFileFlag);

            //Show 'SaveFileDialog':
            bool? diaRet = saveAsDlg.ShowModal();
            if (diaRet == true)
            {
                string saveAsdirectory = System.IO.Path.GetDirectoryName(saveAsDlg.Filename);
                string saveAsFileNameWithoutExt = System.IO.Path.GetFileNameWithoutExtension(saveAsDlg.Filename);
                string saveAsExt = System.IO.Path.GetExtension(saveAsDlg.Filename);

                //File full name to save as:
                string saveAsPath = string.Empty;

                if (System.IO.File.Exists(saveAsDlg.Filename))
                {
                    //Ask user to override or not:
                    DialogResult diaRes = MessageBox.Show(CommonMessage.GetStringFromCurResx("FILE_EXIST") +
                                        "\n" + CommonMessage.GetStringFromCurResx("ASK_OVERRIDE"),
                                        formOwner, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                    if (diaRes == DialogResult.Yes)
                    {
                        saveAsPath = saveAsDlg.Filename;
                    }
                    else if(diaRes == DialogResult.No)  //Loop to find new name
                    {
                        int countSuffix = 1;
                        saveAsPath = saveAsdirectory + "\\" + saveAsFileNameWithoutExt + saveAsExt;
                        while (System.IO.File.Exists(saveAsPath))
                        {
                            saveAsPath = saveAsdirectory + "\\" + saveAsFileNameWithoutExt + 
                                        $"({countSuffix})" + saveAsExt;
                            countSuffix += 1;
                        }
                    }   
                    else if (diaRes == DialogResult.Cancel) //user want to exit
                    {
                        return;
                    }
                    else //Unknown issue => exit
                    {
                        return;
                    }
                }
                else
                {
                    saveAsPath = saveAsDlg.Filename;
                }

                //Final check save as path before proceed it:
                if (string.IsNullOrEmpty(saveAsPath) || 
                    string.IsNullOrWhiteSpace(saveAsPath))
                {
                    MessageBox.Show(CommonMessage.OBJECT_NOT_VALID(saveAsPath),
                                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                //Now start to save as:
                try
                {
                    #region [Solution 1 - No preview icon - on hold]

                    //Database srcDb = dwgs[dwgs.Count - 1];

                    //srcDb.SaveAs(saveAsPath, DwgVersion.Current);

                    #endregion

                    //Save as drawing with preview icon:
                    System.IO.File.Copy(dwgs[dwgs.Count - 1].Filename , saveAsPath ,true);

                    _LastSaveAsPath = saveAsPath;

                    //Activate or open save as folder ?

                    ////Message out process successful:
                    //MessageBox.Show(CommonMessage.SUCCEED_TO_DO("SAVE_AS", "file", true),
                    //                formOwner,
                    //                MessageBoxButtons.OK,
                    //                MessageBoxIcon.Information);
                }
                catch (System.Exception ex)
                {
                    //Message out process failed:
                    MessageBox.Show(CommonMessage.FAIL_TO_DO("SAVE_AS", "file", true) +
                                    "\n" + CommonMessage.ERROR_MES(ex.Message),
                                    formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            //else 
            //{
            //    //In case cannot show dialog, message out:
            //    MessageBox.Show(CommonMessage.FAIL_TO_DO("show", "SaveAs Dialog"),
            //                    formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}
        }

        private void MenuToRefresh_Click(object sender, System.EventArgs e)
        {
            //Clear old list:
            fileLstBox.Items.Clear();
            fileCountLbl.Text = _CountFilesPrefix + "0";

            //Update listboxes:
            AddFilesListBox(folderPathTbx.Text);

            //Select first item in listbox:
            if (fileLstBox != null && fileLstBox.Items.Count > 0)
            {
                fileLstBox.SelectedIndex = 0;
            }
        }

        private void HideOrShowBlkLstMenuItem_Click(object sender, EventArgs e)
        {
            if (this.mainTbPanel.ColumnStyles[2].Width == blkLstWidths[0])
            {
                this.mainTbPanel.ColumnStyles[2].Width = blkLstWidths[1];
                mPreviewCtrl.Invalidate();
            }
            else
            {
                this.mainTbPanel.ColumnStyles[2].Width = blkLstWidths[0];
                mPreviewCtrl.Invalidate();
            }
        }

        private void Form_Activated(object sender, EventArgs e)
        {
            #region [Check source database]

            //Check reference to folder textbox:
            if (folderPathTbx == null)
            {
                //"Lost reference to folder path's Textbox!"
                //"\nForm need to exit."
                MessageBox.Show(CommonMessage.GetStringFromCurResx("folderpath") + ":" +
                                "\n" + CommonMessage.LOST_REF_TO("listbox") +
                                "\n" + CommonMessage.GetStringFromCurResx("FORM_CLOSE"),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                ExitMenuItem_Click(new object(), new EventArgs());

                return;
            }

            //Check whether database lost reference or was deleted: 
            if (!string.IsNullOrEmpty(folderPathTbx.Text) &&
                !string.IsNullOrWhiteSpace(folderPathTbx.Text) &&
                fileLstBox != null &&
                fileLstBox.Items.Count > 0 &&
                fileLstBox.SelectedItem != null)
            {
                string srcDbFullPath = folderPathTbx.Text + "\\" + fileLstBox.SelectedItem.ToString();

                if (!File.Exists(srcDbFullPath))
                {
                    //Lost reference to database or
                    //"\nIt was deleted!"
                    //"\nForm need to exit."
                    MessageBox.Show(CommonMessage.LOST_REF_TO("database") +
                                    "\n" + CommonMessage.GetStringFromCurResx("FORM_CLOSE"),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                    ExitMenuItem_Click(new object(), new EventArgs());

                    return;
                }
            }
            #endregion

            //Check no document state:
            if (AcAp.DocumentManager.Count == 0)
            {
                MessageBox.Show("This command cannot be used in no drawing mode." +
                                $"\nOpen a new drawing then try again.",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                //ExitMenuItem_Click(new object(), new EventArgs());
                this.Close();

                return;
            }

            //Check if form need to reload(Source document changed)
            if (mPreviewCtrl.SourceDocument.IsDisposed == true || 
                mPreviewCtrl.SourceDocument == null)
            {
                DialogResult diaRes;
                diaRes = MessageBox.Show("Source document has changed." +
                                        "\nForm need to be reloaded or exit." + 
                                        "\nDo you want to reload ?",
                                        formOwner,
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Question);

                if (diaRes == DialogResult.Yes)
                {
                    //Re initialize Preview control by current document & database:
                    //Autodesk.AutoCAD.ApplicationServices.Document curDoc = Autodesk.AutoCAD.ApplicationServices.
                    //                    Application.DocumentManager.MdiActiveDocument;      //Current document

                    Autodesk.AutoCAD.ApplicationServices.Document doc = GetSrcDocForGS();   //Source document for GS

                    using (doc.LockDocument())
                    {
                        InitDrawingControl(doc, doc.Database);
                    }

                    //Check reference to folder textbox:
                    if (folderPathTbx == null)
                    {
                        MessageBox.Show("Fail to reload form." +
                                        "\nError: Lost reference to folder path's Textbox!" +
                                        "\nForm need to exit.",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                        ExitMenuItem_Click(new object(), new EventArgs());

                        //// set focus to AutoCAD
                        //Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView();

                        return;
                    }

                    //Check folder path is valid and exist:
                    if (string.IsNullOrEmpty(folderPathTbx.Text) ||
                        string.IsNullOrWhiteSpace(folderPathTbx.Text))
                    {
                        #region [Old codes}
                        //MessageBox.Show("Fail to reload form." +
                        //        "\nError: folder path is not valid!" +
                        //        "\nForm need to exit.",
                        //        formOwner,
                        //        MessageBoxButtons.OK,
                        //        MessageBoxIcon.Error);

                        //ExitMenuItem_Click(new object(), new EventArgs());

                        //return;
                        #endregion

                        //Form has just initialized, so set focus:
                        this.Focus();

                        //Set language:
                        SetLanguage();

                        return;
                    }
                    else
                    {
                        //Check folder path exist or not?
                        if (!Directory.Exists(folderPathTbx.Text))
                        {
                            MessageBox.Show("Fail to reload form." +
                                "\nError: folder path doesn't exist!" +
                                "\nForm need to exit.",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                            ExitMenuItem_Click(new object(), new EventArgs());

                            //// set focus to AutoCAD
                            //Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView();

                            return;
                        }
                    }

                    //Everything seems ok => refresh then focus form:
                    MenuToRefresh_Click(new object(), new EventArgs());
                    this.Focus();
                }
                else
                {
                    ExitMenuItem_Click(new object(), new EventArgs());

                    //// set focus to AutoCAD
                    //Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView();

                    return;
                }
            }

            //Set language:
            SetLanguage();
        }

        private void Form_Resized(object sender, EventArgs e)
        {
            mPreviewCtrl.Invalidate();
        }

        //Backup version for Form_Activated:
        [Obsolete("Old version for Form_Activated")]
        private void Form_Activated_Old(object sender, EventArgs e)
        {
            //SwitchToModelSpace();

            #region [Old codes]
            //int cvPort = System.Convert.ToInt32(AcAp.GetSystemVariable("CVPORT"));
            //if (cvPort <= 1)
            //{
            //    Editor ed = curDoc.Editor;
            //    ed.WriteMessage($"\n{cvPort}");

            //    using (curDoc.LockDocument())
            //    {
            //        //Update current document to modelspace:
            //        LayoutManager.Current.CurrentLayout = "Model";
            //        //AcAp.SetSystemVariable("TILEMODE", 1);
            //        //ed.SwitchToModelSpace();
            //    }
            //}
            #endregion
        }

        private void HideBtn_Click(object sender, EventArgs e)
        {
            HideByModeless();
        }

        /// <summary>
        /// Method to Insert outside drawing into active document's current space.
        /// This method support Jigging blocks with attributes.
        /// ***This method is used for modeless dialog.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// https://forums.autodesk.com/t5/net/insert-dwg-file/td-p/7916191
        /// https://forums.autodesk.com/t5/net/insert-block-from-another-file/td-p/3527080
        private void InsertCadBtn_Click(object sender, EventArgs e)
        {
            #region [Check input]

            //Check reference to file's ListBox:
            if (fileLstBox == null)
            {
                MessageBox.Show(CommonMessage.LOST_REF_TO("filelistbox"),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }

            //Check file's ListBox items:
            if (fileLstBox.Items.Count == 0)
            {
                MessageBox.Show(CommonMessage.NOTHING_TO_INSERT("file"),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            //Check selected item in file's ListBox:
            if (fileLstBox.SelectedItem == null)
            {
                //"Lost reference to selected file!"
                MessageBox.Show(CommonMessage.LOST_REF_TO("selectedfile"),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }

            //Check input data for block's ListBox:
            if (blkPreviewCBox.Checked)
            {
                //Check reference to block's ListBox:
                if (blkLstBox == null)
                {
                    //Lost reference to block's ListBox!
                    MessageBox.Show(CommonMessage.LOST_REF_TO("blocklistbox"),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                    return;
                }

                //Check block's ListBox items:
                if (blkLstBox.Items.Count == 0)
                {
                    MessageBox.Show(CommonMessage.NOTHING_TO_INSERT("block"),
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                    return;
                }

                //Check selected item in block's ListBox:
                if (blkLstBox.SelectedItem == null)
                {
                    //"Lost reference to selected block!
                    MessageBox.Show(CommonMessage.LOST_REF_TO("selectedblock"),
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                    return;
                }
            }
            #endregion

            #region [Insert CAD]

            //Hide modeless dialog then focus autocad:
            HideByModeless();

            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Autodesk.AutoCAD.Internal.Utils.FlushGraphics();
            _edOnViewChangedLockH = ed;
            _originalView = ed.GetCurrentView();
            _maxPan[0] = _originalView.Width * _safePanbuffer;
            _maxPan[1] = _originalView.Height * _safePanbuffer;
            try
            {
                doc.ViewChanged += OnViewChangedLockH;

                using (doc.LockDocument())
                {
                    ////Regen drawing again with turning off some field updates for good performance.
                    //using (KRResetSystemVar myReset = new KRResetSystemVar("FIELDEVAL", 4))
                    //{
                    //    ed.Regen();
                    //}

                    //List system variable need to reset:
                    List<KeyValuePair<string, object>> resetList = new List<KeyValuePair<string, object>>()
                    {
                        new KeyValuePair<string, object>("ORTHOMODE",0),
                        new KeyValuePair<string, object>("CMDECHO",0)
                    };

                    //using (Transaction baseTr = db.TransactionManager.StartOpenCloseTransaction()) //Use this to roll back all
                    using (KRResetSystemVar myReset = new KRResetSystemVar(resetList))
                    {
                        //Override when needed:
                        if (OverrideCbx.Checked)
                        {
                            if (!OverrideSameNameBlocks())
                            {
                                //baseTr.Abort();
                                return;
                            }
                        }

                        //Check source database:
                        if (dwgs == null || dwgs.Count < 1)
                        {
                            //"Lost reference to source database!"
                            MessageBox.Show(CommonMessage.LOST_REF_TO("database"),
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            //baseTr.Abort();
                            return;
                        }

                        //Get reference to source database:
                        Database srcDb = null;
                        srcDb = dwgs[dwgs.Count - 1];
                        if (srcDb == null)
                        {
                            //"Cannot read source database!"
                            MessageBox.Show(CommonMessage.FAIL_TO_DO("read", "database", true),
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            //baseTr.Abort();
                            return;
                        }

                        //Block name for inserting BlockReference:
                        string blkNameForInsertBlkRef = "";

                        //Get BlockDefinition's name then insert BlockDefinition
                        if (!blkPreviewCBox.Checked)
                        {
                            blkNameForInsertBlkRef = fileLstBox.SelectedItem.ToString();

                            //Check whether current document has duplicate BlockDefinition:
                            //If duplicate is found, try another block name:
                            try
                            {
                                using (Transaction curTr = db.TransactionManager.StartTransaction())
                                {
                                    BlockTable bt = curTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                                    if (bt.Has(blkNameForInsertBlkRef))
                                    {
                                        blkNameForInsertBlkRef = GetUniqueName(blkNameForInsertBlkRef);
                                    }

                                    curTr.Commit();
                                }
                            }
                            catch (System.Exception ex)
                            {
                                //$"Error: {ex.Message}"
                                MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                                formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                                //baseTr.Abort();
                                return;
                            }

                            //Create new block definition.
                            //Then fill it with data from outer database:
                            ObjectId outerDbId = ObjectId.Null;
                            try
                            {
                                outerDbId = db.Insert(blkNameForInsertBlkRef, srcDb, true);

                                //Check outer database Id:
                                if (outerDbId == ObjectId.Null)
                                {
                                    //"Cannot import database!"
                                    MessageBox.Show(CommonMessage.FAIL_TO_DO("insert", "database", true),
                                                    formOwner,
                                                    MessageBoxButtons.OK,
                                                    MessageBoxIcon.Error);
                                    //baseTr.Abort();
                                    return;
                                }

                            }
                            catch (System.Exception ex)
                            {
                                //$"Error: {ex.Message}"
                                MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                                formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                                //baseTr.Abort();
                                return;
                            }
                        }
                        else
                        {
                            //Insert member block:
                            string srcBlkName = blkLstBox.SelectedItem.ToString();
                            blkNameForInsertBlkRef = GetUniqueName(srcBlkName);

                            try
                            {
                                using (Transaction srcTr = srcDb.TransactionManager.StartTransaction())
                                {
                                    //Source BlockTable:
                                    BlockTable srcBlt = srcTr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                                    if (!srcBlt.Has(srcBlkName))
                                    {
                                        //"BlockDefinition doesn't exist in source!"
                                        MessageBox.Show(CommonMessage.OBJECT_NOT_EXIST("srcblkdef", true),
                                                        formOwner,
                                                        MessageBoxButtons.OK,
                                                        MessageBoxIcon.Error);
                                        //curTr.Abort();
                                        srcTr.Abort();
                                        //baseTr.Abort();
                                        return;
                                    }

                                    //Source BlockTableRecord:
                                    BlockTableRecord srcBlkDef = null;
                                    srcBlkDef = srcTr.GetObject(srcBlt[srcBlkName], OpenMode.ForRead) as BlockTableRecord;
                                    if (srcBlkDef == null)
                                    {
                                        //"Cannot read BlockDefinition from source!"
                                        MessageBox.Show(CommonMessage.FAIL_TO_DO("read", "srcblkdef", true),
                                                        formOwner,
                                                        MessageBoxButtons.OK,
                                                        MessageBoxIcon.Error);

                                        //curTr.Abort();
                                        srcTr.Abort();
                                        //baseTr.Abort();
                                        return;
                                    }

                                    using (Transaction curTr = db.TransactionManager.StartTransaction())
                                    {
                                        if (!srcBlkDef.IsAnonymous && !srcBlkDef.IsLayout)
                                        {
                                            IdMapping mapping = new IdMapping();
                                            ObjectIdCollection blockIds = new ObjectIdCollection();

                                            //Get Current blocktable:
                                            BlockTable curBlt = curTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                                            //Check whether current BlockTable contains BlockTableRecord in source file:
                                            if (curBlt.Has(srcBlkName))
                                            {
                                                BlockTableRecord curBlkDef = curTr.GetObject(curBlt[srcBlkName], OpenMode.ForWrite)
                                                    as BlockTableRecord;
                                                curBlkDef.Name = blkNameForInsertBlkRef + "Swap";

                                                blockIds.Add(srcBlkDef.ObjectId);
                                                srcDb.WblockCloneObjects(blockIds, db.BlockTableId, mapping,
                                                                   DuplicateRecordCloning.Ignore, false);

                                                if (!curBlt.Has(srcBlkName))
                                                {
                                                    //"Fail when inserting block from source!"
                                                    MessageBox.Show(CommonMessage.FAIL_TO_DO("insert", "block", true),
                                                                    formOwner,
                                                                    MessageBoxButtons.OK,
                                                                    MessageBoxIcon.Error);
                                                    curTr.Abort();
                                                    srcTr.Abort();
                                                    //baseTr.Abort();
                                                    return;
                                                }
                                                else
                                                {
                                                    BlockTableRecord insertedBlkDef = curTr.GetObject(curBlt[srcBlkName], OpenMode.ForWrite)
                                                        as BlockTableRecord;
                                                    insertedBlkDef.Name = blkNameForInsertBlkRef;
                                                    curBlkDef.Name = srcBlkName;
                                                }
                                            }
                                            else
                                            {
                                                blockIds.Add(srcBlkDef.ObjectId);
                                                srcDb.WblockCloneObjects(blockIds, db.BlockTableId, mapping,
                                                                   DuplicateRecordCloning.Ignore, false);
                                                if (!curBlt.Has(srcBlkName))
                                                {
                                                    //"Fail when inserting block from source!"
                                                    MessageBox.Show(CommonMessage.FAIL_TO_DO("insert", "block", true),
                                                                    formOwner,
                                                                    MessageBoxButtons.OK,
                                                                    MessageBoxIcon.Error);
                                                    curTr.Abort();
                                                    srcTr.Abort();
                                                    //baseTr.Abort();
                                                    return;
                                                }
                                                else
                                                {
                                                    //Rename inserted block so that we can remove it after using:
                                                    BlockTableRecord insertedBlkDef = curTr.GetObject(curBlt[srcBlkName], OpenMode.ForWrite)
                                                        as BlockTableRecord;
                                                    insertedBlkDef.Name = blkNameForInsertBlkRef;
                                                }
                                            }
                                        }

                                        curTr.Commit();
                                    }

                                    srcTr.Commit();
                                }
                            }
                            catch (System.Exception ex)
                            {
                                //$"Error: {ex.Message}"
                                MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                                formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);
                                //baseTr.Abort();
                                return;
                            }
                        }

                        //Add block reference:
                        try
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                                ////Check whether block definition is successful inserted:
                                //if (!bt.Has(blkNameForInsertBlkRef))
                                //{
                                //    //"Cannot read block definiton!"
                                //    MessageBox.Show(CommonMessage.FAIL_TO_DO("read", "srcblkdef",true),
                                //                    formOwner,
                                //                    MessageBoxButtons.OK,
                                //                    MessageBoxIcon.Error);
                                //    tr.Abort();
                                //    baseTr.Abort();
                                //    return;
                                //}

                                //Get current space:
                                BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                                //Create new instance of block reference:
                                BlockReference blkRef = new BlockReference(Point3d.Origin, bt[blkNameForInsertBlkRef]);

                                //double scaleFactor = System.Convert.ToDouble(scaleTbx.Text);
                                double scaleFactor = 1.0;

                                blkRef.ScaleFactors = new Scale3d(scaleFactor, scaleFactor, scaleFactor);
                                blkRef.TransformBy(ed.CurrentUserCoordinateSystem);

                                //Add it to database TEMPORARILY <= must do this for jigging attributes:
                                btr.AppendEntity(blkRef);
                                tr.AddNewlyCreatedDBObject(blkRef, true);

                                //Get block definition:
                                BlockTableRecord blkDef;
                                if (blkRef.IsDynamicBlock)
                                {
                                    blkDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                }
                                else
                                {
                                    blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                }

                                //This is used for what ???
                                if (blkDef.Annotative == AnnotativeStates.True)
                                {
                                    ObjectContextManager ocm = db.ObjectContextManager;
                                    ObjectContextCollection occ = ocm.GetContextCollection(contextCollectionName);
                                    blkRef.AddContext(occ.CurrentContext);
                                }

                                //Copy attributes from BlockDef => BlockRef:
                                Dictionary<AttributeReference, AttributeDefinition> dict =
                                    new Dictionary<AttributeReference, AttributeDefinition>();
                                if (blkDef.HasAttributeDefinitions)
                                {
                                    RXClass rxClass = RXClass.GetClass(typeof(AttributeDefinition));
                                    foreach (ObjectId id in blkDef)
                                    {
                                        if (id.ObjectClass == rxClass)
                                        {
                                            DBObject obj = tr.GetObject(id, OpenMode.ForRead);

                                            AttributeDefinition ad = obj as AttributeDefinition;
                                            AttributeReference ar = new AttributeReference();
                                            ar.SetAttributeFromBlock(ad, blkRef.BlockTransform);

                                            ////Ask user to input content for attributes:
                                            //ar.TextString = BlockAttributeJig.CollectAttributeText(ad);

                                            blkRef.AttributeCollection.AppendAttribute(ar);
                                            tr.AddNewlyCreatedDBObject(ar, true);

                                            dict.Add(ar, ad);
                                        }
                                    }
                                }

                                //Start jigging:
                                if (BlockAttributeJig.Jig(blkRef, dict))
                                {
                                    #region [Solution 1 - Depricated]
                                    ////In case source drawing contains array.
                                    ////this solution will make array become strange behavior.
                                    ////Ex: Array by path => path and array will be splitted away.

                                    ////Explode block:
                                    //blkRef.ExplodeToOwnerSpace();

                                    ////Delete block reference:
                                    //blkRef.Erase(true);

                                    //tr.Commit();

                                    //ed.WriteMessage("\nInsert is successful.\n");
                                    #endregion

                                    #region [Solution 2 - running]
                                    //https://forums.autodesk.com/t5/net/get-all-entities-inside-a-blockreference/td-p/10771795

                                    //Get all ObjectIds inside BlockTableRecord:
                                    ObjectIdCollection ids = new ObjectIdCollection();
                                    foreach (ObjectId id in blkDef)
                                    {
                                        if (id != ObjectId.Null && !ids.Contains(id))
                                        {
                                            ids.Add(id);
                                        }
                                    }

                                    //Create new mapping for deepclone:
                                    IdMapping mapping = new IdMapping();

                                    //Deepclone all entites inside BlockDefinition to BlockReference's owner:
                                    blkRef.Database.DeepCloneObjects(ids, blkRef.OwnerId, mapping, false);

                                    //Iterate and transform entities:
                                    foreach (IdPair pair in mapping)
                                    {
                                        if (pair.IsCloned && pair.IsPrimary)
                                        {
                                            DBObject tempDbObj = pair.Value.GetObject(OpenMode.ForWrite);
                                            if (tempDbObj != null && tempDbObj is Entity tempEnt)
                                            {
                                                tempEnt.TransformBy(blkRef.BlockTransform);
                                            }
                                        }
                                    }

                                    #region [Old codes]
                                    //foreach (ObjectId id in ids)
                                    //{
                                    //    if (mapping[id].IsCloned)
                                    //    {
                                    //        DBObject tempDbObj = tr.GetObject(mapping[id].Value, OpenMode.ForWrite);

                                    //        if (tempDbObj is Entity tempEnt)
                                    //        {
                                    //            tempEnt.TransformBy(blkRef.BlockTransform);
                                    //        }
                                    //    }
                                    //}
                                    #endregion

                                    //"\nInsert is successful.\n"
                                    ed.WriteMessage("\n" + CommonMessage.GetStringFromCurResx("INSERT_SUCCESS") + "\n");

                                    #endregion

                                    #region [Old codes 1]
                                    //DBObjectCollection dbObjCol = new DBObjectCollection();
                                    //blkRef.Explode(dbObjCol);

                                    //BlockTableRecord blkRefOwner = tr.GetObject(blkRef.OwnerId, OpenMode.ForWrite) as BlockTableRecord;
                                    //foreach (var item in dbObjCol)
                                    //{
                                    //    if (item is Entity tempEnt)
                                    //    {
                                    //        blkRefOwner.AppendEntity(tempEnt);
                                    //        tr.AddNewlyCreatedDBObject(tempEnt, true);
                                    //    }
                                    //}

                                    ////Delete block reference:
                                    //blkRef.Erase(true);

                                    //tr.Commit();

                                    //ed.WriteMessage("\nInsert is successful.\n");
                                    #endregion

                                    #region [Old codes 2]
                                    //IEnumerable<Entity> entInsideBlk = GetEntitiesWithinBlock(blkRef);
                                    //ExplodeBlkRefToCurrentSpace(tr, blkRef);

                                    ////Delete block reference:
                                    //blkRef.Erase(true);

                                    //tr.Commit();

                                    //ed.WriteMessage("\nInsert is successful.\n");

                                    //Point3d oldPosition = blkRef.Position;
                                    //blkRef.Position = Point3d.Origin;
                                    //Vector3d transBackVec = oldPosition - blkRef.Position;
                                    #endregion
                                }

                                //Delete block reference:
                                blkRef.Erase(true);

                                blkDef.UpgradeOpen();
                                blkDef.Erase(true);

                                //Commit changes:
                                tr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            //$"Error: {ex.Message}"
                            MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            //baseTr.Abort();
                            return;
                        }

                        #region [Old codes]

                        ////Attsyn + Remove block definition too:
                        //try
                        //{
                        //    using (Transaction tr = db.TransactionManager.StartTransaction())
                        //    {
                        //        BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                        //        if (bt.Has(blkNameForInsertBlkRef))
                        //        {
                        //            BlockTableRecord tempBtr = tr.GetObject(bt[blkNameForInsertBlkRef], OpenMode.ForRead) 
                        //                as BlockTableRecord;

                        //            #region [Attsync - On Hold]

                        //            //if (!OverrideCbx.Checked)
                        //            //{
                        //            //    //Create container to store all nested block's name & id inside BlockDefinition:
                        //            //    System.Collections.Generic.Dictionary<string, ObjectId> blkDefNames = new Dictionary<string, ObjectId>();
                        //            //    //blkDefNames.Add(blkNameForInsertBlkRef, bt[blkNameForInsertBlkRef]);   //Always have root block information

                        //            //    //Populate information for container of nested blocks:
                        //            //    foreach (ObjectId id in tempBtr)
                        //            //    {
                        //            //        if (id != ObjectId.Null)
                        //            //        {
                        //            //            Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;

                        //            //            if (ent != null && ent is BlockReference blkRef)
                        //            //            {
                        //            //                if (!GetAllBlkDefIds(tr, blkRef, ref blkDefNames))
                        //            //                {
                        //            //                    continue;
                        //            //                }
                        //            //            }
                        //            //        }
                        //            //    }

                        //            //    //Populate information for container:
                        //            //    if (blkDefNames.Count > 0)
                        //            //    {
                        //            //        foreach (var item in blkDefNames)
                        //            //        {
                        //            //            BlockTableRecord btr = tr.GetObject(item.Value, OpenMode.ForWrite) as BlockTableRecord;
                        //            //            if (btr != null)
                        //            //            {
                        //            //                btr.SynchronizeAttributes();
                        //            //            }
                        //            //        }
                        //            //    }
                        //            //}

                        //            #endregion

                        //            tempBtr.UpgradeOpen();
                        //            tempBtr.Erase();

                        //            #region [Old codes]
                        //            ////Check openmode before erase:
                        //            //if (tempBtr.IsReadEnabled)
                        //            //{
                        //            //    tempBtr.UpgradeOpen();
                        //            //    tempBtr.Erase();
                        //            //    tempBtr.DowngradeOpen();
                        //            //}
                        //            //else
                        //            //{
                        //            //    tempBtr.Erase();
                        //            //}
                        //            #endregion
                        //        }

                        //        tr.Commit();
                        //    }
                        //}
                        //catch (System.Exception ex)
                        //{
                        //    //"Cannot remove temp block after inserting!" +
                        //    //$"\nError: {ex.Message}"
                        //    MessageBox.Show(CommonMessage.FAIL_TO_DO("delete", "temp_block", true) +
                        //                    "\n" + CommonMessage.ERROR_MES(ex.Message),
                        //                    formOwner,
                        //                    MessageBoxButtons.OK,
                        //                    MessageBoxIcon.Error);
                        //    baseTr.Abort();
                        //    return;
                        //}

                        ////Zoom extent:
                        //dynamic acadApp = Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication;
                        //acadApp.ZoomExtents();

                        //baseTr.Commit();

                        #endregion
                    }

                    ////Regen drawing again with turning off some field updates for good performance.
                    //using (KRResetSystemVar myReset = new KRResetSystemVar("FIELDEVAL", 4))
                    //{
                    //    ed.Regen();
                    //}
                }
            }
            finally
            {
                doc.ViewChanged -= OnViewChangedLockH;
            }

            #endregion
        }

        private void OnViewChangedLockH(object sender, EventArgs e)
        {
            if (_edOnViewChangedLockH == null || _originalView == null)
            {
                return;
            }

            if (_maxPan[0] == 0.0 && _maxPan[1] == 0.0)
            {
                return;
            }

            ViewTableRecord currentView = _edOnViewChangedLockH.GetCurrentView();
            if (currentView.Height > _originalView.Height)
            {
                _edOnViewChangedLockH.SetCurrentView(_originalView);
                //Application.ShowAlertDialog("Zoom limit reached.");
                return;
            }

            if (currentView.Width > _originalView.Width)
            {
                _edOnViewChangedLockH.SetCurrentView(_originalView);
                //Application.ShowAlertDialog("Zoom limit reached.");
                return;
            }

            //double curSpanDist = currentView.CenterPoint.GetDistanceTo(_originalView.CenterPoint);
            //if (curSpanDist > 100.0)
            //{
            //    _edOnViewChangedLockH.SetCurrentView(_originalView);
            //}
            
            Vector2d delta = currentView.CenterPoint - _originalView.CenterPoint;
            if (Math.Abs(delta.X) > _maxPan[0] || Math.Abs(delta.Y) > _maxPan[1])
            {
                _edOnViewChangedLockH.SetCurrentView(_originalView);
                //Application.ShowAlertDialog("Panning limit reached to avoid regeneration.");
                return;
            }
        }

        #region [Old versions]

        private void InsertCadBtn_Click_Old3(object sender, EventArgs e)
        {
            #region [Check input]

            //Check reference to file's ListBox:
            if (fileLstBox == null)
            {
                MessageBox.Show("Lost reference to file's ListBox!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }

            //Check file's ListBox items:
            if (fileLstBox.Items.Count == 0)
            {
                MessageBox.Show("There is no file to insert!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                return;
            }

            //Check selected item in file's ListBox:
            if (fileLstBox.SelectedItem == null)
            {
                MessageBox.Show("Lost reference to selected file!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }

            //Check input data for block's ListBox:
            if (blkPreviewCBox.Checked)
            {
                //Check reference to block's ListBox:
                if (blkLstBox == null)
                {
                    MessageBox.Show("Lost reference to block's ListBox!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                    return;
                }

                //Check block's ListBox items:
                if (blkLstBox.Items.Count == 0)
                {
                    MessageBox.Show("There is no block to insert!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                    return;
                }

                //Check selected item in block's ListBox:
                if (blkLstBox.SelectedItem == null)
                {
                    MessageBox.Show("Lost reference to selected block!",
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                    return;
                }
            }
            #endregion

            #region [Insert CAD]
            //Hide modeless dialog then focus autocad:
            HideByModeless();

            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            using (doc.LockDocument())
            {
                //List system variable need to reset:
                List<KeyValuePair<string, object>> resetList = new List<KeyValuePair<string, object>>()
                    {
                        new KeyValuePair<string, object>("ORTHOMODE",0),
                        new KeyValuePair<string, object>("CMDECHO",0)
                    };

                using (Transaction baseTr = db.TransactionManager.StartTransaction()) //Use this to roll back all
                using (KRResetSystemVar myReset = new KRResetSystemVar(resetList))
                {
                    //Override when needed:
                    if (OverrideCbx.Checked)
                    {
                        if (!OverrideSameNameBlocks())
                        {
                            baseTr.Abort();
                            return;
                        }
                    }

                    //Check source database:
                    if (dwgs == null || dwgs.Count < 1)
                    {
                        MessageBox.Show("Lost reference to source database!",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                        baseTr.Abort();
                        return;
                    }

                    //Get reference to source database:
                    Database srcDb = null;
                    srcDb = dwgs[dwgs.Count - 1];
                    if (srcDb == null)
                    {
                        MessageBox.Show("Cannot read source database!",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                        baseTr.Abort();
                        return;
                    }

                    //Block name for inserting BlockReference:
                    string blkNameForInsertBlkRef = "";

                    //Get BlockDefinition's name then insert BlockDefinition
                    if (!blkPreviewCBox.Checked)
                    {
                        blkNameForInsertBlkRef = fileLstBox.SelectedItem.ToString();

                        //Check whether current document has duplicate BlockDefinition:
                        //If duplicate is found, try another block name:
                        try
                        {
                            using (Transaction curTr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = curTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                                if (bt.Has(blkNameForInsertBlkRef))
                                {
                                    blkNameForInsertBlkRef = GetUniqueName(blkNameForInsertBlkRef);
                                }

                                curTr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            baseTr.Abort();
                            return;
                        }

                        //Create new block definition.
                        //Then fill it with data from outer database:
                        ObjectId outerDbId = ObjectId.Null;
                        try
                        {
                            outerDbId = db.Insert(blkNameForInsertBlkRef, srcDb, true);

                            //Check outer database Id:
                            if (outerDbId == ObjectId.Null)
                            {
                                MessageBox.Show("Cannot get source id!",
                                                formOwner,
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Error);

                                baseTr.Abort();
                                return;
                            }

                        }
                        catch (System.Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }
                    }
                    else
                    {
                        //Insert member block:
                        string srcBlkName = blkLstBox.SelectedItem.ToString();
                        blkNameForInsertBlkRef = GetUniqueName(srcBlkName);

                        try
                        {
                            using (Transaction srcTr = srcDb.TransactionManager.StartTransaction())
                            {
                                using (Transaction curTr = db.TransactionManager.StartTransaction())
                                {
                                    //Source BlockTable:
                                    BlockTable srcBlt = srcTr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;
                                    if (!srcBlt.Has(srcBlkName))
                                    {
                                        MessageBox.Show("BlockDefinition doesn't exist in source!",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                                        curTr.Abort();
                                        srcTr.Abort();
                                        baseTr.Abort();
                                        return;
                                    }

                                    //Source BlockTableRecord:
                                    BlockTableRecord srcBlkDef = null;
                                    srcBlkDef = srcTr.GetObject(srcBlt[srcBlkName], OpenMode.ForRead) as BlockTableRecord;
                                    if (srcBlkDef == null)
                                    {
                                        MessageBox.Show("Cannot read BlockDefinition from source!",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                                        curTr.Abort();
                                        srcTr.Abort();
                                        baseTr.Abort();
                                        return;
                                    }

                                    //////Import dynamic blocks from source BlockTableRecord into current database:
                                    //BlockTable curBlt = curTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                                    //IdMapping dyBlkMap = new IdMapping();
                                    //ObjectIdCollection dyBlkIds = new ObjectIdCollection();

                                    //using (Transaction tempTr = srcDb.TransactionManager.StartTransaction())
                                    //{
                                    //    foreach (ObjectId srcBtrId in srcBlt)
                                    //    {
                                    //        if (srcBtrId != ObjectId.Null)
                                    //        {
                                    //            BlockTableRecord memBlkDef = tempTr.GetObject(srcBtrId, OpenMode.ForRead) as BlockTableRecord;

                                    //            if (memBlkDef != null && memBlkDef.IsDynamicBlock &&
                                    //                !curBlt.Has(memBlkDef.Name))
                                    //            {
                                    //                dyBlkIds.Add(memBlkDef.ObjectId);
                                    //            }
                                    //        }
                                    //    }

                                    //    srcDb.WblockCloneObjects(dyBlkIds, db.BlockTableId, dyBlkMap,
                                    //                           DuplicateRecordCloning.Ignore, false);

                                    //    tempTr.Commit();
                                    //}

                                    if (!srcBlkDef.IsAnonymous && !srcBlkDef.IsLayout)
                                    {
                                        IdMapping mapping = new IdMapping();
                                        ObjectIdCollection blockIds = new ObjectIdCollection();

                                        //Get Current blocktable:
                                        BlockTable curBlt = curTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                                        //Check whether current BlockTable contains BlockTableRecord in source file:
                                        if (curBlt.Has(srcBlkName))
                                        {
                                            BlockTableRecord curBlkDef = curTr.GetObject(curBlt[srcBlkName], OpenMode.ForWrite) as BlockTableRecord;
                                            curBlkDef.Name = blkNameForInsertBlkRef + "Swap";

                                            blockIds.Add(srcBlkDef.ObjectId);
                                            srcDb.WblockCloneObjects(blockIds, db.BlockTableId, mapping,
                                                               DuplicateRecordCloning.Ignore, false);

                                            if (!curBlt.Has(srcBlkName))
                                            {
                                                //ed.WriteMessage($"\nError : {ex.Message}");
                                                MessageBox.Show("Fail when inserting block from source!",
                                                                formOwner,
                                                                MessageBoxButtons.OK,
                                                                MessageBoxIcon.Error);
                                                curTr.Abort();
                                                srcTr.Abort();
                                                baseTr.Abort();
                                                return;
                                            }
                                            else
                                            {
                                                BlockTableRecord insertedBlkDef = curTr.GetObject(curBlt[srcBlkName], OpenMode.ForWrite)
                                                    as BlockTableRecord;
                                                insertedBlkDef.Name = blkNameForInsertBlkRef;
                                                curBlkDef.Name = srcBlkName;
                                            }
                                        }
                                        else
                                        {
                                            blockIds.Add(srcBlkDef.ObjectId);
                                            srcDb.WblockCloneObjects(blockIds, db.BlockTableId, mapping,
                                                               DuplicateRecordCloning.Ignore, false);

                                            if (!curBlt.Has(srcBlkName))
                                            {
                                                //ed.WriteMessage($"\nError : {ex.Message}");
                                                MessageBox.Show("Fail when inserting block from source!",
                                                                formOwner,
                                                                MessageBoxButtons.OK,
                                                                MessageBoxIcon.Error);
                                                curTr.Abort();
                                                srcTr.Abort();
                                                baseTr.Abort();
                                                return;
                                            }
                                            else
                                            {
                                                BlockTableRecord insertedBlkDef = curTr.GetObject(curBlt[srcBlkName], OpenMode.ForWrite)
                                                    as BlockTableRecord;
                                                insertedBlkDef.Name = blkNameForInsertBlkRef;
                                            }
                                        }
                                    }

                                    curTr.Commit();
                                }

                                srcTr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                            baseTr.Abort();
                            return;
                        }
                    }

                    //Add block reference:
                    try
                    {
                        using (Transaction tr = db.TransactionManager.StartTransaction())
                        {
                            BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                            //Check whether block definition is successful inserted:
                            if (!bt.Has(blkNameForInsertBlkRef))
                            {
                                //ed.WriteMessage("\nCannot read block definiton!");
                                MessageBox.Show("Cannot read block definiton!",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                                tr.Abort();
                                baseTr.Abort();
                                return;
                            }

                            //Get current space:
                            BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                            //Create new instance of block reference:
                            BlockReference blkRef = new BlockReference(Point3d.Origin, bt[blkNameForInsertBlkRef]);

                            //double scaleFactor = System.Convert.ToDouble(scaleTbx.Text);
                            double scaleFactor = 1.0;

                            blkRef.ScaleFactors = new Scale3d(scaleFactor, scaleFactor, scaleFactor);
                            blkRef.TransformBy(ed.CurrentUserCoordinateSystem);

                            //Add it to database TEMPORARILY <= must do this for jigging attributes:
                            btr.AppendEntity(blkRef);
                            tr.AddNewlyCreatedDBObject(blkRef, true);

                            //Get block definition:
                            BlockTableRecord blkDef;
                            if (blkRef.IsDynamicBlock)
                            {
                                blkDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                            }
                            else
                            {
                                blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                            }

                            //THis is used for what ???
                            if (blkDef.Annotative == AnnotativeStates.True)
                            {
                                ObjectContextManager ocm = db.ObjectContextManager;
                                ObjectContextCollection occ = ocm.GetContextCollection(contextCollectionName);
                                blkRef.AddContext(occ.CurrentContext);
                            }

                            Dictionary<AttributeReference, AttributeDefinition> dict =
                                new Dictionary<AttributeReference, AttributeDefinition>();
                            if (blkDef.HasAttributeDefinitions)
                            {
                                RXClass rxClass = RXClass.GetClass(typeof(AttributeDefinition));
                                foreach (ObjectId id in blkDef)
                                {
                                    if (id.ObjectClass == rxClass)
                                    {
                                        DBObject obj = tr.GetObject(id, OpenMode.ForRead);

                                        AttributeDefinition ad = obj as AttributeDefinition;
                                        AttributeReference ar = new AttributeReference();
                                        ar.SetAttributeFromBlock(ad, blkRef.BlockTransform);

                                        ////Ask user to input content for attributes:
                                        //ar.TextString = BlockAttributeJig.CollectAttributeText(ad);

                                        blkRef.AttributeCollection.AppendAttribute(ar);
                                        tr.AddNewlyCreatedDBObject(ar, true);

                                        dict.Add(ar, ad);
                                    }
                                }
                            }

                            if (BlockAttributeJig.Jig(blkRef, dict))
                            {
                                #region [Solution 1 - Depricated]
                                ////In case source drawing contains array.
                                ////this solution will make array become strange behavior.
                                ////Ex: Array by path => path and array will be splitted away.

                                ////Explode block:
                                //blkRef.ExplodeToOwnerSpace();

                                ////Delete block reference:
                                //blkRef.Erase(true);

                                //tr.Commit();

                                //ed.WriteMessage("\nInsert is successful.\n");
                                #endregion

                                #region [Solution 2 - running]
                                //https://forums.autodesk.com/t5/net/get-all-entities-inside-a-blockreference/td-p/10771795

                                //Get all ObjectIds inside BlockTableRecord:
                                //ObjectIdCollection ids = new ObjectIdCollection(blkDef.Cast<ObjectId>().ToArray());
                                ObjectIdCollection ids = new ObjectIdCollection();
                                foreach (ObjectId id in blkDef)
                                {
                                    if (id != ObjectId.Null && !ids.Contains(id))
                                    {
                                        ids.Add(id);
                                    }
                                }

                                //Create new mapping for deepclone:
                                IdMapping mapping = new IdMapping();

                                //Deepclone all entites inside BlockDefinition to BlockReference's owner:
                                blkRef.Database.DeepCloneObjects(ids, blkRef.OwnerId, mapping, false);

                                //Iterate and transform entities:
                                foreach (IdPair pair in mapping)
                                {
                                    if (pair.IsCloned && pair.IsPrimary)
                                    {
                                        DBObject tempDbObj = pair.Value.GetObject(OpenMode.ForWrite);

                                        if (tempDbObj is Entity tempEnt)
                                        {
                                            tempEnt.TransformBy(blkRef.BlockTransform);
                                        }
                                    }
                                }

                                #region [Old codes]
                                //foreach (ObjectId id in ids)
                                //{
                                //    if (mapping[id].IsCloned)
                                //    {
                                //        DBObject tempDbObj = tr.GetObject(mapping[id].Value, OpenMode.ForWrite);

                                //        if (tempDbObj is Entity tempEnt)
                                //        {
                                //            tempEnt.TransformBy(blkRef.BlockTransform);
                                //        }
                                //    }
                                //}
                                #endregion

                                //Delete block reference:
                                blkRef.Erase(true);

                                tr.Commit();

                                ed.WriteMessage("\nInsert is successful.\n");
                                #endregion

                                #region [Old codes 1]
                                //DBObjectCollection dbObjCol = new DBObjectCollection();
                                //blkRef.Explode(dbObjCol);

                                //BlockTableRecord blkRefOwner = tr.GetObject(blkRef.OwnerId, OpenMode.ForWrite) as BlockTableRecord;
                                //foreach (var item in dbObjCol)
                                //{
                                //    if (item is Entity tempEnt)
                                //    {
                                //        blkRefOwner.AppendEntity(tempEnt);
                                //        tr.AddNewlyCreatedDBObject(tempEnt, true);
                                //    }
                                //}

                                ////Delete block reference:
                                //blkRef.Erase(true);

                                //tr.Commit();

                                //ed.WriteMessage("\nInsert is successful.\n");
                                #endregion

                                #region [Old codes 2]
                                //IEnumerable<Entity> entInsideBlk = GetEntitiesWithinBlock(blkRef);
                                //ExplodeBlkRefToCurrentSpace(tr, blkRef);

                                ////Delete block reference:
                                //blkRef.Erase(true);

                                //tr.Commit();

                                //ed.WriteMessage("\nInsert is successful.\n");

                                //Point3d oldPosition = blkRef.Position;
                                //blkRef.Position = Point3d.Origin;
                                //Vector3d transBackVec = oldPosition - blkRef.Position;
                                #endregion
                            }
                            else
                            {
                                blkRef.Dispose();

                                foreach (KeyValuePair<AttributeReference, AttributeDefinition> entry in dict)
                                {
                                    //blkRef.Dispose();
                                    entry.Key.Dispose();
                                }

                                tr.Abort();
                                baseTr.Abort();

                                return;
                            }
                        }
                    }
                    catch (System.Exception ex)
                    {
                        //ed.WriteMessage($"\nError: {ex.Message}");
                        MessageBox.Show($"Error: {ex.Message}",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                        baseTr.Abort();
                        return;
                    }

                    //Remove block definition too:
                    try
                    {
                        using (Transaction tr = db.TransactionManager.StartTransaction())
                        {
                            BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                            if (bt.Has(blkNameForInsertBlkRef))
                            {
                                BlockTableRecord tempBtr = tr.GetObject(bt[blkNameForInsertBlkRef], OpenMode.ForWrite) as BlockTableRecord;
                                tempBtr.Erase();
                            }

                            tr.Commit();
                        }
                    }
                    catch (System.Exception ex)
                    {
                        //ed.WriteMessage("\nCannot delete source block. Please do it manually!.\n" +
                        //        $"Error : {ex.Message}");
                        MessageBox.Show("Cannot delete source block. Please do it manually!" +
                                        $"\nError: {ex.Message}",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);

                        baseTr.Abort();
                        return;
                    }

                    ////Zoom extent:
                    //dynamic acadApp = Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication;
                    //acadApp.ZoomExtents();

                    baseTr.Commit();
                }
            }
            #endregion
        }

        //Get all nested blocks' name & id inside BlockReference:
        bool GetAllBlkDefIds_Old(Transaction tr, BlockReference blkRef,
                             ref System.Collections.Generic.Dictionary<string, ObjectId> blkDefNameIds)
        {
            try
            {
                BlockTableRecord blkDef = null;

                if (blkRef.IsDynamicBlock)
                {
                    blkDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                }
                else
                {
                    blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                }


                if (blkDef == null)
                {
                    return false;
                }
                else
                {
                    if (blkDef.IsLayout ||
                        (blkDef.IsAnonymous && !blkDef.IsDynamicBlock))
                    {
                        return false;
                    }
                }

                if (blkDef.ObjectId != ObjectId.Null)
                {
                    if (!blkDefNameIds.ContainsKey(blkDef.Name))
                    {
                        blkDefNameIds.Add(blkDef.Name, blkDef.ObjectId);
                    }
                    else //Already contains so return;
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                //recursion:
                foreach (ObjectId id in blkDef)
                {
                    if (id != ObjectId.Null)
                    {
                        Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
                        if (ent != null && ent is BlockReference blkRefChild)
                        {
                            if (!GetAllBlkDefIds(tr, blkRefChild, ref blkDefNameIds))
                            {
                                continue;
                            }
                        }
                    }
                }

                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        //Back up version for InsertCad:
        private void InsertCadBtn_Click_Old2(object sender, EventArgs e)
        {
            #region [Check input]

            //Check reference to file's ListBox:
            if (fileLstBox == null)
            {
                MessageBox.Show("Lost reference to file's ListBox!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }

            //Check file's ListBox items:
            if (fileLstBox.Items.Count == 0)
            {
                MessageBox.Show("There is no file to insert!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                return;
            }

            //Check selected item in file's ListBox:
            if (fileLstBox.SelectedItem == null)
            {
                MessageBox.Show("Lost reference to selected file!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return;
            }

            if (blkPreviewCBox.Checked)
            {
                //Check reference to block's ListBox:
                if (blkLstBox == null)
                {
                    MessageBox.Show("Lost reference to block's ListBox!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                    return;
                }

                //Check block's ListBox items:
                if (blkLstBox.Items.Count == 0)
                {
                    MessageBox.Show("There is no block to insert!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);

                    return;
                }

                //Check selected item in block's ListBox:
                if (blkLstBox.SelectedItem == null)
                {
                    MessageBox.Show("Lost reference to selected block!",
                                    formOwner,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                    return;
                }
            }
            #endregion

            #region [Insert CAD]

            HideByModeless();

            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            using (doc.LockDocument())
            {
                //List system variable need to reset:
                List<KeyValuePair<string, object>> resetList = new List<KeyValuePair<string, object>>()
                    {
                        new KeyValuePair<string, object>("ORTHOMODE",0),
                        new KeyValuePair<string, object>("CMDECHO",0)
                    };

                using (Transaction baseTr = db.TransactionManager.StartTransaction()) //Use this to roll back all
                using (KRResetSystemVar myReset = new KRResetSystemVar(resetList))
                {
                    //Override if nessecesory:
                    if (OverrideCbx.Checked)
                    {
                        if (!OverrideSameNameBlocks())
                        {
                            baseTr.Abort();
                            return;
                        }
                    }

                    //Get source drawing's full path:
                    //string dwgFullPath = folderBrwDlg.SelectedPath + "\\" + fileLstBox.SelectedItem.ToString();

                    //Database srcDb = dwgs[dwgs.Count - 1];

                    //https://forums.autodesk.com/t5/net/insert-block-from-another-file/td-p/3527080
                    string blkDefName;
                    string srcBlkName;
                    string blkNameForInsertBlkRef;

                    //Get reference to source database:
                    Database srcDb = null;

                    //Check source database:
                    if (dwgs == null || dwgs.Count < 1)
                    {
                        MessageBox.Show("Lost reference to source database!",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                        baseTr.Abort();

                        return;
                    }
                    else
                    {
                        srcDb = dwgs[dwgs.Count - 1];

                        if (srcDb == null)
                        {
                            MessageBox.Show("Lost reference to source database!",
                                                                    formOwner,
                                                                    MessageBoxButtons.OK,
                                                                    MessageBoxIcon.Error);

                            baseTr.Abort();

                            return;
                        }
                    }

                    //Get BlockDefName(Insert all source database) / BlockSourceName(Insert 1 drawing from source database)
                    //Then Create/ Insert BlockDefinition:

                    ObjectId outerDbId = ObjectId.Null;

                    if (!blkPreviewCBox.Checked)
                    {
                        srcBlkName = "";
                        blkDefName = fileLstBox.SelectedItem.ToString();
                        blkNameForInsertBlkRef = blkDefName;

                        //Check whether current document has duplicate BlockDefinition:
                        //If duplicate is found, try another block name:
                        try
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                                if (bt.Has(blkDefName))
                                {
                                    //string dateTime = System.DateTime.Now.ToString("yy/MM/dd/HH/mm/ss");

                                    string dateTime = System.DateTime.Now.ToString("mm_ss");
                                    blkDefName += dateTime;
                                }

                                tr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            //ed.WriteMessage($"\nError: {ex.Message}");
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }

                        //Create new block definition.
                        //Then fill it with data from outer database:

                        try
                        {
                            outerDbId = db.Insert(blkDefName, srcDb, true);
                        }
                        catch (System.Exception ex)
                        {
                            //ed.WriteMessage($"\nError : {ex.Message}");
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }

                        //Check outer database Id:
                        if (outerDbId == ObjectId.Null)
                        {
                            //ed.WriteMessage("\nCannot get source id!");
                            MessageBox.Show("Cannot get source id!",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }
                    }
                    else
                    {
                        srcBlkName = blkLstBox.SelectedItem.ToString();
                        blkDefName = "";
                        //blkNameForInsertBlkRef = srcBlkName;
                        string dateTime = System.DateTime.Now.ToString("mm_ss");
                        blkNameForInsertBlkRef = srcBlkName + dateTime;

                        try
                        {
                            //IdMapping mapping = new IdMapping();

                            //ObjectIdCollection blockIds = new ObjectIdCollection();

                            //using (Transaction srcTr = srcDb.TransactionManager.StartTransaction())
                            //{
                            //    BlockTable srcBlt = srcTr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;

                            //    BlockTableRecord srcBlkDef = srcTr.GetObject(srcBlt[srcBlkName], OpenMode.ForRead) as BlockTableRecord;

                            //    if (!srcBlkDef.IsAnonymous && !srcBlkDef.IsLayout)
                            //    {
                            //        blockIds.Add(srcBlkDef.ObjectId);
                            //        srcDb.WblockCloneObjects(blockIds, db.BlockTableId, mapping,
                            //                           DuplicateRecordCloning.Ignore, false);
                            //    }

                            //    srcTr.Commit();
                            //}

                            #region [Test]
                            //using (Transaction tr = srcDb.TransactionManager.StartTransaction())
                            //{
                            //    BlockTable srcBlt = tr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;

                            //    if (srcBlt.Has(srcBlkName))
                            //    {

                            //        BlockTableRecord btrTest = tr.GetObject(srcBlt[srcBlkName], OpenMode.ForRead) as BlockTableRecord;

                            //        int testCount = 0;
                            //        foreach (var item in btrTest)
                            //        {
                            //            testCount += 1;
                            //        }

                            //        MessageBox.Show($"Items inside{testCount}",
                            //                    formOwner,
                            //                    MessageBoxButtons.OK,
                            //                    MessageBoxIcon.Information);
                            //    }
                            //    else
                            //    {
                            //        MessageBox.Show("Block not found",
                            //                    formOwner,
                            //                    MessageBoxButtons.OK,
                            //                    MessageBoxIcon.Error);

                            //    }

                            //    tr.Commit();
                            //}
                            #endregion

                            //using (Transaction tr = db.TransactionManager.StartTransaction())
                            //{
                            //    BlockTable curBlt = tr.GetObject(db.BlockTableId, OpenMode.ForWrite) as BlockTable;

                            //    using (BlockTableRecord testBlk = new BlockTableRecord())
                            //    {
                            //        testBlk.Name = blkNameForInsertBlkRef;
                            //        curBlt.Add(testBlk);
                            //        tr.AddNewlyCreatedDBObject(testBlk, true);
                            //    }


                            //    tr.Commit();

                            //    outerDbId = db.Insert(srcBlkName, blkNameForInsertBlkRef, srcDb, true);
                            //}



                            // Create a temporary database to read the source DWG file
                            using (Database sourceDb = new Database(false, true))
                            {
                                //Get source drawing's full path:
                                string dwgFullPath = folderBrwDlg.SelectedPath + "\\" + fileLstBox.SelectedItem.ToString();

                                sourceDb.ReadDwgFile(dwgFullPath, FileOpenMode.OpenForReadAndAllShare, true, "");

                                // Insert the block from the source database into the current database
                                outerDbId = db.Insert(srcBlkName, blkNameForInsertBlkRef, sourceDb, true);

                                ed.WriteMessage("\nBlock inserted successfully.");
                            }

                            //outerDbId = db.Insert(srcBlkName, blkNameForInsertBlkRef, srcDb , true);
                        }
                        catch (System.Exception ex)
                        {
                            //ed.WriteMessage($"\nError : {ex.Message}");
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }

                        //Check outer database Id:
                        if (outerDbId == ObjectId.Null)
                        {
                            //ed.WriteMessage("\nCannot get source id!");
                            MessageBox.Show("Cannot get source id!",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }
                    }

                    //Add block reference:
                    try
                    {
                        using (Transaction tr = db.TransactionManager.StartTransaction())
                        {
                            BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                            //Check whether block definition is successful inserted:
                            if (!bt.Has(outerDbId))
                            {
                                //ed.WriteMessage("\nCannot read block definiton!");
                                MessageBox.Show("Cannot read block definiton!",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                                tr.Abort();
                                baseTr.Abort();
                                return;
                            }

                            //Get current space:
                            BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                            //Create new instance of block reference:
                            BlockReference blkRef = new BlockReference(Point3d.Origin, outerDbId);

                            //double scaleFactor = System.Convert.ToDouble(scaleTbx.Text);
                            double scaleFactor = 1.0;

                            blkRef.ScaleFactors = new Scale3d(scaleFactor, scaleFactor, scaleFactor);
                            blkRef.TransformBy(ed.CurrentUserCoordinateSystem);

                            //Add it to database TEMPORARILY <= must do this for jigging attributes:
                            btr.AppendEntity(blkRef);
                            tr.AddNewlyCreatedDBObject(blkRef, true);

                            //Get block definition:
                            BlockTableRecord blkDef;
                            if (blkRef.IsDynamicBlock)
                            {
                                blkDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                            }
                            else
                            {
                                blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                            }

                            //THis is used for what ???
                            if (blkDef.Annotative == AnnotativeStates.True)
                            {
                                ObjectContextManager ocm = db.ObjectContextManager;
                                ObjectContextCollection occ = ocm.GetContextCollection(contextCollectionName);
                                blkRef.AddContext(occ.CurrentContext);
                            }

                            Dictionary<AttributeReference, AttributeDefinition> dict =
                                new Dictionary<AttributeReference, AttributeDefinition>();
                            if (blkDef.HasAttributeDefinitions)
                            {
                                RXClass rxClass = RXClass.GetClass(typeof(AttributeDefinition));
                                foreach (ObjectId id in blkDef)
                                {
                                    if (id.ObjectClass == rxClass)
                                    {
                                        DBObject obj = tr.GetObject(id, OpenMode.ForRead);

                                        AttributeDefinition ad = obj as AttributeDefinition;
                                        AttributeReference ar = new AttributeReference();
                                        ar.SetAttributeFromBlock(ad, blkRef.BlockTransform);

                                        ////Ask user to input content for attributes:
                                        //ar.TextString = BlockAttributeJig.CollectAttributeText(ad);

                                        blkRef.AttributeCollection.AppendAttribute(ar);
                                        tr.AddNewlyCreatedDBObject(ar, true);

                                        dict.Add(ar, ad);
                                    }
                                }
                            }

                            if (BlockAttributeJig.Jig(blkRef, dict))
                            {
                                #region [Solution 1 - Depricated]
                                ////In case source drawing contains array.
                                ////this solution will make array become strange behavior.
                                ////Ex: Array by path => path and array will be splitted away.

                                ////Explode block:
                                //blkRef.ExplodeToOwnerSpace();

                                ////Delete block reference:
                                //blkRef.Erase(true);

                                //tr.Commit();

                                //ed.WriteMessage("\nInsert is successful.\n");
                                #endregion

                                #region [Solution 2 - running]
                                //https://forums.autodesk.com/t5/net/get-all-entities-inside-a-blockreference/td-p/10771795

                                //Get all ObjectIds inside BlockTableRecord:
                                //ObjectIdCollection ids = new ObjectIdCollection(blkDef.Cast<ObjectId>().ToArray());
                                ObjectIdCollection ids = new ObjectIdCollection();
                                foreach (ObjectId id in blkDef)
                                {
                                    if (id != ObjectId.Null && !ids.Contains(id))
                                    {
                                        ids.Add(id);
                                    }
                                }

                                //Create new mapping for deepclone:
                                IdMapping mapping = new IdMapping();

                                //Deepclone all entites inside BlockDefinition to BlockReference's owner:
                                blkRef.Database.DeepCloneObjects(ids, blkRef.OwnerId, mapping, false);

                                //Iterate and transform entities:
                                foreach (IdPair pair in mapping)
                                {
                                    if (pair.IsCloned && pair.IsPrimary)
                                    {
                                        DBObject tempDbObj = pair.Value.GetObject(OpenMode.ForWrite);

                                        if (tempDbObj is Entity tempEnt)
                                        {
                                            tempEnt.TransformBy(blkRef.BlockTransform);
                                        }
                                    }
                                }

                                #region [Old codes]
                                //foreach (ObjectId id in ids)
                                //{
                                //    if (mapping[id].IsCloned)
                                //    {
                                //        DBObject tempDbObj = tr.GetObject(mapping[id].Value, OpenMode.ForWrite);

                                //        if (tempDbObj is Entity tempEnt)
                                //        {
                                //            tempEnt.TransformBy(blkRef.BlockTransform);
                                //        }
                                //    }
                                //}
                                #endregion

                                //Delete block reference:
                                blkRef.Erase(true);

                                tr.Commit();

                                ed.WriteMessage("\nInsert is successful.\n");
                                #endregion

                                #region [Old codes 1]
                                //DBObjectCollection dbObjCol = new DBObjectCollection();
                                //blkRef.Explode(dbObjCol);

                                //BlockTableRecord blkRefOwner = tr.GetObject(blkRef.OwnerId, OpenMode.ForWrite) as BlockTableRecord;
                                //foreach (var item in dbObjCol)
                                //{
                                //    if (item is Entity tempEnt)
                                //    {
                                //        blkRefOwner.AppendEntity(tempEnt);
                                //        tr.AddNewlyCreatedDBObject(tempEnt, true);
                                //    }
                                //}

                                ////Delete block reference:
                                //blkRef.Erase(true);

                                //tr.Commit();

                                //ed.WriteMessage("\nInsert is successful.\n");
                                #endregion

                                #region [Old codes 2]
                                //IEnumerable<Entity> entInsideBlk = GetEntitiesWithinBlock(blkRef);
                                //ExplodeBlkRefToCurrentSpace(tr, blkRef);

                                ////Delete block reference:
                                //blkRef.Erase(true);

                                //tr.Commit();

                                //ed.WriteMessage("\nInsert is successful.\n");

                                //Point3d oldPosition = blkRef.Position;
                                //blkRef.Position = Point3d.Origin;
                                //Vector3d transBackVec = oldPosition - blkRef.Position;
                                #endregion
                            }
                            else
                            {
                                blkRef.Dispose();

                                foreach (KeyValuePair<AttributeReference, AttributeDefinition> entry in dict)
                                {
                                    //blkRef.Dispose();
                                    entry.Key.Dispose();
                                }

                                tr.Abort();
                                baseTr.Abort();
                                return;
                            }
                        }
                    }
                    catch (System.Exception ex)
                    {
                        //ed.WriteMessage($"\nError: {ex.Message}");
                        MessageBox.Show($"Error: {ex.Message}",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                        baseTr.Abort();
                        return;
                    }

                    //Remove block definition too:
                    try
                    {
                        using (Transaction tr = db.TransactionManager.StartTransaction())
                        {
                            BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                            if (bt.Has(blkNameForInsertBlkRef))
                            {
                                BlockTableRecord tempBtr = tr.GetObject(bt[blkNameForInsertBlkRef], OpenMode.ForWrite) as BlockTableRecord;
                                tempBtr.Erase();
                            }

                            tr.Commit();
                        }
                    }
                    catch (System.Exception ex)
                    {
                        //ed.WriteMessage("\nCannot delete source block. Please do it manually!.\n" +
                        //        $"Error : {ex.Message}");
                        MessageBox.Show("Cannot delete source block. Please do it manually!" +
                                        $"\nError: {ex.Message}",
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);

                        baseTr.Abort();
                        return;
                    }

                    ////Zoom extent:
                    //dynamic acadApp = Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication;
                    //acadApp.ZoomExtents();

                    baseTr.Commit();
                }
            }
            #endregion
        }

        //Back up version for InsertCad:
        private void InsertCadBtn_Click_Old1(object sender, EventArgs e)
        {
            if (fileLstBox.Items != null && fileLstBox.Items.Count > 0 &&
                fileLstBox.SelectedItem != null)
            {
                //this.Hide();
                //this.DialogResult = DialogResult.OK;

                HideByModeless();

                Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
                Database db = doc.Database;
                Editor ed = doc.Editor;

                using (doc.LockDocument())
                {
                    //List system variable need to reset:
                    List<KeyValuePair<string, object>> resetList = new List<KeyValuePair<string, object>>()
                    {
                        new KeyValuePair<string, object>("ORTHOMODE",0),
                        new KeyValuePair<string, object>("CMDECHO",0)
                    };

                    using (Transaction baseTr = db.TransactionManager.StartTransaction()) //Use this to roll back all
                    using (KRResetSystemVar myReset = new KRResetSystemVar(resetList))
                    {
                        //Override if nessecesory:
                        if (OverrideCbx.Checked)
                        {
                            if (!OverrideSameNameBlocks())
                            {
                                baseTr.Abort();
                                return;
                            }
                        }

                        //Get source drawing's full path:
                        string dwgFullPath = folderBrwDlg.SelectedPath + "\\" + fileLstBox.SelectedItem.ToString();

                        //https://forums.autodesk.com/t5/net/insert-block-from-another-file/td-p/3527080
                        string blkDefName = Path.GetFileNameWithoutExtension(dwgFullPath) + "_KR-CAD_Insert";

                        //Check whether current document has duplicate BlockDefinition:
                        //If duplicate is found, try another block name:
                        try
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                                if (bt.Has(blkDefName))
                                {
                                    string dateTime = System.DateTime.Now.ToString("yy/MM/dd/HH/mm/ss");
                                    blkDefName += dateTime;
                                }

                                tr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            //ed.WriteMessage($"\nError: {ex.Message}");
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }

                        //Create new block definition.
                        //Then fill it with data from outer database:
                        ObjectId outerDbId = ObjectId.Null;
                        try
                        {
                            using (Database outerDb = new Database(false, true))
                            {
                                outerDb.ReadDwgFile(dwgFullPath, FileOpenMode.OpenForReadAndAllShare, true, "");
                                outerDbId = db.Insert(blkDefName, outerDb, true);
                            }
                        }
                        catch (System.Exception ex)
                        {
                            //ed.WriteMessage($"\nError : {ex.Message}");
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }

                        //Check outer database Id:
                        if (outerDbId == ObjectId.Null)
                        {
                            //ed.WriteMessage("\nCannot get source id!");
                            MessageBox.Show("Cannot get source id!",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }

                        //Add block reference:
                        try
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                                //Check whether block definition is successful inserted:
                                if (!bt.Has(outerDbId))
                                {
                                    //ed.WriteMessage("\nCannot read block definiton!");
                                    MessageBox.Show("Cannot read block definiton!",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                                    tr.Abort();
                                    baseTr.Abort();
                                    return;
                                }

                                //Get current space:
                                BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                                //Create new instance of block reference:
                                BlockReference blkRef = new BlockReference(Point3d.Origin, outerDbId);

                                //double scaleFactor = System.Convert.ToDouble(scaleTbx.Text);
                                double scaleFactor = 1.0;

                                blkRef.ScaleFactors = new Scale3d(scaleFactor, scaleFactor, scaleFactor);
                                blkRef.TransformBy(ed.CurrentUserCoordinateSystem);

                                //Add it to database TEMPORARILY <= must do this for jigging attributes:
                                btr.AppendEntity(blkRef);
                                tr.AddNewlyCreatedDBObject(blkRef, true);

                                //Get block definition:
                                BlockTableRecord blkDef;
                                if (blkRef.IsDynamicBlock)
                                {
                                    blkDef = tr.GetObject(blkRef.DynamicBlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                }
                                else
                                {
                                    blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;
                                }

                                //THis is used for what ???
                                if (blkDef.Annotative == AnnotativeStates.True)
                                {
                                    ObjectContextManager ocm = db.ObjectContextManager;
                                    ObjectContextCollection occ = ocm.GetContextCollection(contextCollectionName);
                                    blkRef.AddContext(occ.CurrentContext);
                                }

                                Dictionary<AttributeReference, AttributeDefinition> dict =
                                    new Dictionary<AttributeReference, AttributeDefinition>();
                                if (blkDef.HasAttributeDefinitions)
                                {
                                    RXClass rxClass = RXClass.GetClass(typeof(AttributeDefinition));
                                    foreach (ObjectId id in blkDef)
                                    {
                                        if (id.ObjectClass == rxClass)
                                        {
                                            DBObject obj = tr.GetObject(id, OpenMode.ForRead);

                                            AttributeDefinition ad = obj as AttributeDefinition;
                                            AttributeReference ar = new AttributeReference();
                                            ar.SetAttributeFromBlock(ad, blkRef.BlockTransform);

                                            ////Ask user to input content for attributes:
                                            //ar.TextString = BlockAttributeJig.CollectAttributeText(ad);

                                            blkRef.AttributeCollection.AppendAttribute(ar);
                                            tr.AddNewlyCreatedDBObject(ar, true);

                                            dict.Add(ar, ad);
                                        }
                                    }
                                }

                                if (BlockAttributeJig.Jig(blkRef, dict))
                                {
                                    #region [Solution 1 - Depricated]
                                    ////In case source drawing contains array.
                                    ////this solution will make array become strange behavior.
                                    ////Ex: Array by path => path and array will be splitted away.

                                    ////Explode block:
                                    //blkRef.ExplodeToOwnerSpace();

                                    ////Delete block reference:
                                    //blkRef.Erase(true);

                                    //tr.Commit();

                                    //ed.WriteMessage("\nInsert is successful.\n");
                                    #endregion

                                    #region [Solution 2 - running]
                                    //https://forums.autodesk.com/t5/net/get-all-entities-inside-a-blockreference/td-p/10771795

                                    //Get all ObjectIds inside BlockTableRecord:
                                    //ObjectIdCollection ids = new ObjectIdCollection(blkDef.Cast<ObjectId>().ToArray());
                                    ObjectIdCollection ids = new ObjectIdCollection();
                                    foreach (ObjectId id in blkDef)
                                    {
                                        if (id != ObjectId.Null && !ids.Contains(id))
                                        {
                                            ids.Add(id);
                                        }
                                    }

                                    //Create new mapping for deepclone:
                                    IdMapping mapping = new IdMapping();

                                    //Deepclone all entites inside BlockDefinition to BlockReference's owner:
                                    blkRef.Database.DeepCloneObjects(ids, blkRef.OwnerId, mapping, false);

                                    //Iterate and transform entities:
                                    foreach (IdPair pair in mapping)
                                    {
                                        if (pair.IsCloned && pair.IsPrimary)
                                        {
                                            DBObject tempDbObj = pair.Value.GetObject(OpenMode.ForWrite);

                                            if (tempDbObj is Entity tempEnt)
                                            {
                                                tempEnt.TransformBy(blkRef.BlockTransform);
                                            }
                                        }
                                    }

                                    #region [Old codes]
                                    //foreach (ObjectId id in ids)
                                    //{
                                    //    if (mapping[id].IsCloned)
                                    //    {
                                    //        DBObject tempDbObj = tr.GetObject(mapping[id].Value, OpenMode.ForWrite);

                                    //        if (tempDbObj is Entity tempEnt)
                                    //        {
                                    //            tempEnt.TransformBy(blkRef.BlockTransform);
                                    //        }
                                    //    }
                                    //}
                                    #endregion

                                    //Delete block reference:
                                    blkRef.Erase(true);

                                    tr.Commit();

                                    ed.WriteMessage("\nInsert is successful.\n");
                                    #endregion

                                    #region [Old codes 1]
                                    //DBObjectCollection dbObjCol = new DBObjectCollection();
                                    //blkRef.Explode(dbObjCol);

                                    //BlockTableRecord blkRefOwner = tr.GetObject(blkRef.OwnerId, OpenMode.ForWrite) as BlockTableRecord;
                                    //foreach (var item in dbObjCol)
                                    //{
                                    //    if (item is Entity tempEnt)
                                    //    {
                                    //        blkRefOwner.AppendEntity(tempEnt);
                                    //        tr.AddNewlyCreatedDBObject(tempEnt, true);
                                    //    }
                                    //}

                                    ////Delete block reference:
                                    //blkRef.Erase(true);

                                    //tr.Commit();

                                    //ed.WriteMessage("\nInsert is successful.\n");
                                    #endregion

                                    #region [Old codes 2]
                                    //IEnumerable<Entity> entInsideBlk = GetEntitiesWithinBlock(blkRef);
                                    //ExplodeBlkRefToCurrentSpace(tr, blkRef);

                                    ////Delete block reference:
                                    //blkRef.Erase(true);

                                    //tr.Commit();

                                    //ed.WriteMessage("\nInsert is successful.\n");

                                    //Point3d oldPosition = blkRef.Position;
                                    //blkRef.Position = Point3d.Origin;
                                    //Vector3d transBackVec = oldPosition - blkRef.Position;
                                    #endregion
                                }
                                else
                                {
                                    blkRef.Dispose();

                                    foreach (KeyValuePair<AttributeReference, AttributeDefinition> entry in dict)
                                    {
                                        //blkRef.Dispose();
                                        entry.Key.Dispose();
                                    }

                                    tr.Abort();
                                    baseTr.Abort();
                                    return;
                                }
                            }
                        }
                        catch (System.Exception ex)
                        {
                            //ed.WriteMessage($"\nError: {ex.Message}");
                            MessageBox.Show($"Error: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);

                            baseTr.Abort();
                            return;
                        }

                        //Remove block definition too:
                        try
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                                if (bt.Has(outerDbId))
                                {
                                    BlockTableRecord tempBtr = tr.GetObject(outerDbId, OpenMode.ForWrite) as BlockTableRecord;
                                    tempBtr.Erase();
                                }

                                tr.Commit();
                            }
                        }
                        catch (System.Exception ex)
                        {
                            //ed.WriteMessage("\nCannot delete source block. Please do it manually!.\n" +
                            //        $"Error : {ex.Message}");
                            MessageBox.Show("Cannot delete source block. Please do it manually!" +
                                            $"\nError: {ex.Message}",
                                            formOwner,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);

                            baseTr.Abort();
                            return;
                        }

                        ////Zoom extent:
                        //dynamic acadApp = Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication;
                        //acadApp.ZoomExtents();

                        baseTr.Commit();
                    }
                }
            }
            else
            {
                MessageBox.Show("There is no data to insert!",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
        }

        //Back up version for OverrideSameNameBlocks:
        private bool OverrideSameNameBlocks_Old1()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            //Editor ed = doc.Editor;
            Database db = doc.Database;

            try
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Get current document's Blocktable:
                    BlockTable curDocBlt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                    using (Database srcDb = new Database(false, true))
                    {
                        //Read source database:
                        srcDb.ReadDwgFile(_SrcDwgFullName, FileOpenMode.OpenForReadAndAllShare, true, "");

                        using (Transaction srcTr = srcDb.TransactionManager.StartTransaction())
                        {
                            //Get source database's Blocktable:
                            BlockTable srcBlt = srcTr.GetObject(srcDb.BlockTableId, OpenMode.ForRead) as BlockTable;

                            //Create container to store blocks' id which are overlapped:
                            ObjectIdCollection overlapBlkIds = new ObjectIdCollection();

                            //Iterate source Blocktable and add blocks which id is overlapped with
                            //one in current document Blocktable:
                            foreach (ObjectId srcBltrId in srcBlt)
                            {
                                BlockTableRecord srcBltr = srcTr.GetObject(srcBltrId, OpenMode.ForRead) as BlockTableRecord;
                                if (!srcBltr.IsAnonymous && !srcBltr.IsLayout && curDocBlt.Has(srcBltr.Name))
                                {
                                    if (!overlapBlkIds.Contains(srcBltrId))
                                    {
                                        overlapBlkIds.Add(srcBltrId);
                                    }
                                }
                            }

                            if (overlapBlkIds.Count > 0)
                            {
                                //Do override:
                                IdMapping mapping = new IdMapping();

                                srcDb.WblockCloneObjects(overlapBlkIds, db.BlockTableId, mapping,
                                                               DuplicateRecordCloning.Replace, false);
                            }

                            srcTr.Commit();
                        }
                    }

                    tr.Commit();
                }

                return true;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Fail when trying to override block definiton." +
                                $"\nError: {ex.Message}",
                                formOwner,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                return false;
            }
        }

        #endregion

        private void FolderPathTbx_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (!string.IsNullOrEmpty(this.folderPathTbx.Text) && 
                !string.IsNullOrWhiteSpace(this.folderPathTbx.Text)&&
                Directory.Exists(this.folderPathTbx.Text))
            {
                ContextMenuStrip cms = new ContextMenuStrip();

                //"Open or activate folder"
                cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("openactive"), 
                                                    AcadAddin.Properties.Resources.RbFolder,
                                                    MenuOpenOrActivateFolder_Click));

                //Show menu on datagrid:
                cms.Show(sender as System.Windows.Forms.Control, new Point(e.X, e.Y));
            }
        }

        //https://stackoverflow.com/questions/32395163/how-can-i-open-a-folder-in-windows-explorer
        private void MenuOpenOrActivateFolder_Click(object sender, EventArgs e)
        {
            try
            {
                using (System.Diagnostics.Process.Start(this.folderPathTbx.Text))
                {

                }
            }
            catch (System.Exception ex)
            {
                //"Failed when opening or activating folder!"
                //$"\nError: {ex.Message}"
                MessageBox.Show(CommonMessage.FAIL_TO_DO("openactive","folder",true) + 
                                "\n" + CommonMessage.ERROR_MES(ex.Message),
                                formOwner,
                                MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
        }

        private void BlockLstBox_MouseUp(object sender, MouseEventArgs e)
        {
            #region [Check input]

            if (e.Button != MouseButtons.Right)
            {
                return;
            }

            if (_DetalInfoBlkNames.Count == 0)
            {
                return;
            }

            if (fileLstBox == null)
            {
                MessageBox.Show(CommonMessage.LOST_REF_TO("filelistbox"),
                                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            if (fileLstBox.Items.Count == 0)
            {
                //MessageBox.Show(CommonMessage.OBJECT_CONTAIN_NOTHING("file's ListBox"),
                //                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (fileLstBox.SelectedItem == null)
            {
                MessageBox.Show(CommonMessage.LOST_REF_TO("selectedfile"),
                                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            if (blkLstBox == null)
            {
                MessageBox.Show(CommonMessage.LOST_REF_TO("blocklistbox"),
                                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            if (blkLstBox.Items.Count == 0)
            {
                //MessageBox.Show(CommonMessage.OBJECT_CONTAIN_NOTHING("block's ListBox"),
                //                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (blkLstBox.SelectedItem == null)
            {
                MessageBox.Show(CommonMessage.LOST_REF_TO("selectedblock"),
                                formOwner, MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            #endregion

            #region [Show menu]
            ContextMenuStrip cms = new ContextMenuStrip();

            //"Show block detail"
            cms.Items.Add(new ToolStripMenuItem(CommonMessage.GetStringFromCurResx("SHOW_BLOCK_DETAIL"), 
                                AcadAddin.Properties.Resources.ViewListIcon,
                                MenuShowBlockDetail_Click));

            //Show menu on datagrid:
            cms.Show(sender as System.Windows.Forms.Control, new Point(e.X, e.Y));
            #endregion
        }

        private void MenuShowBlockDetail_Click(object sender, EventArgs e)
        {
            if (_BlkDetailFrm == null)
            {
                _BlkDetailFrm = new AcadAddin.CAV_BlockView.CAV_BlocksDetail_Frm();
            }

            if (_BlkDetailFrm.IsDisposed)
            {
                _BlkDetailFrm = null;

                _BlkDetailFrm = new AcadAddin.CAV_BlockView.CAV_BlocksDetail_Frm();
            }

            if (_BlkDetailFrm.IsReadyToShow)
            {
                if (!_BlkDetailFrm.Visible)
                {
                    //Get drawing path:
                    string srcDwgPath = folderPathTbx.Text + "\\" + fileLstBox.SelectedItem.ToString();
                    if (!File.Exists(srcDwgPath))
                    {
                        MessageBox.Show(CommonMessage.FILE_NOT_EXIST(srcDwgPath),formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                        _BlkDetailFrm.Dispose();
                        return;
                    }

                    if (_DetalInfoBlkNames.Count == 0)
                    {
                        //"Detail information was not set!"
                        MessageBox.Show(CommonMessage.OBJECT_NOT_EXIST("detail_info", true),
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                        _BlkDetailFrm.Dispose();
                        return;
                    }

                    if (_DetalInfoBlkNames.Count > 1)
                    {
                        //"Detail information is inconsistent!"
                        MessageBox.Show(CommonMessage.IS_A("detail_info", "inconsistent"),
                                        formOwner,
                                        MessageBoxButtons.OK,MessageBoxIcon.Error);
                        _BlkDetailFrm.Dispose();
                        return;
                    }

                    //Set source data for detail information form:
                    if (!_BlkDetailFrm.SetSourceData(blkLstBox , srcDwgPath , _DetalInfoBlkNames[0], out string returnMsg))
                    {
                        //"Failed to load detailed information for blocks!"
                        //$"\nError: {returnMsg}"
                        MessageBox.Show(CommonMessage.FAIL_TO_DO("load", "detail_info",true) +
                                        "\n" + CommonMessage.ERROR_MES(returnMsg),
                                        formOwner,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                        _BlkDetailFrm.Dispose();
                        return;
                    }

                    //Dispose form when user click X
                    if (AcAp.ShowModalDialog(null, _BlkDetailFrm, false) == DialogResult.Cancel)
                    {
                        _BlkDetailFrm.Dispose();
                        return;
                    }
                }
                else
                {
                    _BlkDetailFrm.Activate();
                }
            }
            else
            {
                _BlkDetailFrm.Dispose();
            }
        }
    }
}

//Do below or not???
//In case drawing contains blocks which overlapping with current drawing.
//Change all blocks' name.

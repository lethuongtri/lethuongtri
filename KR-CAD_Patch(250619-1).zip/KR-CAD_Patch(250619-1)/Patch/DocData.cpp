﻿// (C) Copyright 2002-2012 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- DocData.cpp : Implementation file
//-----------------------------------------------------------------------------
#include "StdAfx.h"

#pragma region [Base Doc] // base document 

//-----------------------------------------------------------------------------
//----- The one and only document manager object. You can use the DocVars object to retrieve
//----- document specific data throughout your application
AcApDataManager<CDocData> DocVars ;

//-----------------------------------------------------------------------------
//----- Implementation of the document data class.
CDocData::CDocData () {
}

//-----------------------------------------------------------------------------
CDocData::CDocData (const CDocData &data) {
}

//-----------------------------------------------------------------------------
CDocData::~CDocData () {
}

#pragma endregion

//_______________________________________________________________________________ //
//------------------- Below we declare some document objects ---------------------//
//																				  //
//These objects are used for transfer data from Dialog/ Form -> logic process     //
//  -----------------										-----------------     //
//  |  User input   |  <- Document 's member variables ->	| Logic process |	  //
//  -----------------										-----------------     //
//_______________________________________________________________________________ //

#pragma region [単品EP 9000]

//Main object :
AcApDataManager<TEP9K_CDoc> TEP9KDocVars;

//Class 's constructor :
TEP9K_CDoc::TEP9K_CDoc()
{
	/*m_nSegment = 16;
	m_dDiameter = 90.00;
	m_dSlope = 50.00;
	
	m_bDataIsValid = true;
	m_strDiaTemp = _T("");
	m_strSegTemp = _T("");
	m_strSlopeTemp = _T("");*/

	ResetData();
}

void TEP9K_CDoc::ResetData()
{
	m_bDataIsValid = true;
	m_dDiameter = 90.00;
	m_dSlope = 50.00;
	m_nSegment = 16;
	
	m_strDiaTemp = _T("");
	m_strSegTemp = _T("");
	m_strSlopeTemp = _T("");
}

#pragma endregion

#pragma region [KR-12xx Panel]

//Main object :
AcApDataManager<PAFR_CDoc> PAFRDocVars;

//Class 's constructor :
PAFR_CDoc::PAFR_CDoc()
{
	resetData();
}

//Method to reset member data :
//We call this method when change type to draw :
void PAFR_CDoc::resetData()
{
	m_nSpanType = 1;
	m_nEndSide = 1;
	m_nEndType = 1;
	m_nSpanNums = 1;

	//ComboBox
	m_strType = _T("");
	m_nType_LstNo = 0;
	m_nBa_LstNo = 0;
	m_nFb_LstNo = 1;
	m_dH_LstNo = 0;

	//Slope Specification
	m_bIsSlope1 = true;
	m_dSlope =  25.0;
	m_dSlope2 = 0.0;
	m_dUpAng1 = m_dUpAng2 = 0.0;
	m_dDownAng1 = m_dDownAng2 = 0.0;

	//Plane Angle
	m_dPlaneAng = 180.0;
	m_dCenDev = 0.0;

	//Standard Lines Specification
	m_bIsReal = true;
	m_dL1 = m_dL2 = 1000.0;
	m_dUpL1 = m_dUpL2 =0.0;

	m_dH1 = m_dH2 = m_dH3 = 850.0;
	m_dLMinus = m_dRMinus = 49.0;

	//TopA Specification
	m_dHTA = 70.0;
	m_dGap = 5.0;
	m_dHStd = 16.0;
	m_dTopALen1 = m_dTopALen2 = m_dtopAWidth = 0.0;

	//TopB Specification
	m_dHTB_D = 16.5;
	m_dHBR = 22.0;
	m_dHTB_U = 25.0;
	m_dTopBLen1 = m_dTopBLen2 = m_dtopBWidth = 0.0;

	//Baluster Specification
	m_dBrW = 14.0;
	m_dPit = m_dPit1 = m_dPit2 = -1.0;
	m_nPitA = m_nPitA1 = m_nPitA2 = 10;
	m_dEPit = m_dEPit2 = 0.0;

	//Sleeve Specification
	m_dSlvLen = 200.0;
	m_dSlvCen = 160.0;
	m_dSlvLen2 = 200.0;
	m_dSlvCen2 = 160.0;
	m_dSlvGap = 4.0;
	m_dSlvH = 45.0;

	//Bottom Specification
	m_dHB = 40.0;
	m_dBCen = 39.0;
	m_dBGap = 4.0;
	m_dBotLen1 = m_dBotLen2 = m_dBotWidth = 0.0;

	//Polyca Specification
	m_bPolyIsType1 = 1;

	//EP & cast 's hole:
	m_depXU = 10.0;
	m_depYU = 27.0;
	m_depXD = 10.0;
	m_depYD = 20.0;
	m_dCastXU = m_dCastXD = 10.0;
	m_dEHolDia = 4.0;//<- M4皿孔
}

//Method to set polyca height :
//Call this onlywhen (H1 = H2 = H3)
//Other case : user draw it by themself .
void PAFR_CDoc::setPolycaH()
{
	ads_real upAngle1 = atan(this->m_dSlope / 100.0);
	ads_real upAngle2 = atan(this->m_dSlope2 / 100.0);

	if ((this->m_bPolyIsType1) == 1)
	{
		PolyInfo.m_dPGap2 = (this->m_dH1) - (this->m_dHTA) / cos(upAngle1) 
			- PolyInfo.m_dHP
			- PolyInfo.m_dPGap1 / cos(upAngle1);

		PolyInfo.m_dPGap2_R = (this->m_dH1) - (this->m_dHTA) / cos(upAngle2) 
			- PolyInfo.m_dHP
			- PolyInfo.m_dPGap1_R / cos(upAngle2);
	}
	else
	{
		PolyInfo.m_dHP = (this->m_dH1) - ((this->m_dHTA) + PolyInfo.m_dPGap2) / cos(upAngle1)
			- PolyInfo.m_dPGap1 / cos(upAngle1);

		PolyInfo.m_dHP_R = (this->m_dH1) - ((this->m_dHTA) + PolyInfo.m_dPGap2_R) / cos(upAngle2)
			- PolyInfo.m_dPGap1_R / cos(upAngle2);
	}
}

#pragma endregion

#pragma region [Polyca] // For 'KR-12xx'

//Main object :
AcApDataManager<PolyCDoc> PolyDocVars;

//Constructor :
PolyCDoc::PolyCDoc()
{
	m_bIsType1 = true;
	m_dPGap1 = m_dPGap2 = 5.0;
	m_dPGap1_R = m_dPGap2_R = 5.0;
	m_dHP= m_dHP_R = 400.0;
}

#pragma endregion

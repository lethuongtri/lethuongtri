﻿using System.Runtime.InteropServices;
using ExcelDna.Integration;
using ExcelDna.IntelliSense;
using ExcelDna.Integration.CustomUI;
using Microsoft.Extensions.FileProviders;
using System.Reflection;
using System.Resources;
using NetExcel = Microsoft.Office.Interop.Excel;
using System.Runtime.Versioning;
using System.Security;
using Autodesk.AutoCAD.Interop;
using Autodesk.AutoCAD.Interop.Common;
using System.Globalization;
using KRExcel.Multilingual;

//using System.Globalization;
//using System.Windows;
//using NetExcel = NetOffice.ExcelApi;
//using KRExcel.Utils;
//using Application = NetOffice.ExcelApi.Application;
//https://www.codeproject.com/Articles/5379436/ASP-NET-8-Multilingual-Application-with-single-R-4
//https://learn.microsoft.com/en-us/office/vba/Language/Reference/user-interface-help/getobject-function

namespace KRExcel.Plugin
{
    public class IntelliSenseAddIn : IExcelAddIn
    {
        public void AutoOpen()
        {
            IntelliSenseServer.Install();
        }
        public void AutoClose()
        {
            IntelliSenseServer.Uninstall();
        }
    }
}

namespace KRExcel.Multilingual
{
    public static class LocalizationHelper
    {
        private static ResourceManager resourceManager =
            new ResourceManager("KRExcel.Resources.Lang", 
            typeof(LocalizationHelper).Assembly);

        public static string GetString(string key, string culture)
        {
            CultureInfo cultureInfo = new CultureInfo(culture);
            return resourceManager.GetString(key, cultureInfo);
        }
    }

    #region [Old codes]

    //public class Language
    //{
    //    private static string _Lang = string.Empty;
    //    private static CultureInfo culture = null;
    //    private static ResourceManager resManager = null;

    //    public static string GetCurLanguage()
    //    {
    //        return _Lang;
    //    }

    //    #region [Old codes]

    //    //public void SetCulture(string culture)
    //    //{
    //    //    CultureInfo.CurrentCulture = new CultureInfo(culture);
    //    //    CultureInfo.CurrentUICulture = new CultureInfo(culture);
    //    //}

    //    #endregion

    //    public static bool SetLanguage(string langKey)
    //    {
    //        try
    //        {
    //            _Lang = langKey;
    //            culture = CultureInfo.CreateSpecificCulture(langKey);
    //            //resManager = new ResourceManager("AcadAddin.Lang.Resources",
    //            //    typeof(AcadAddin.CommonMessage).Assembly);

    //            return true;
    //        }
    //        catch (System.Exception ex)
    //        {
    //            MessageBox.Show("Failed to set up language!" +
    //                            $"\nError: {ex.Message}",
    //                            KRExcel.Utils.CommonDeclaration.Owner,
    //                            MessageBoxButtons.OK,
    //                            MessageBoxIcon.Error);
    //            return false;
    //        }
    //    }

    //    //Get string from current resources:
    //    public static string GetStringFromCurResx(string keyStr, bool isBeginOfSentence = true)
    //    {
    //        if (resManager != null && culture != null)
    //        {
    //            try
    //            {
    //                string transStr = resManager.GetString(keyStr, culture);

    //                if (isBeginOfSentence && _Lang != "ja-JP")
    //                {
    //                    //return culture.TextInfo.ToTitleCase(resManager.GetString(keyStr, culture).ToLower());
    //                    if (transStr.Length > 1)
    //                    {
    //                        transStr = transStr.ToLower();
    //                        transStr = transStr.Substring(0, 1).ToUpper() + transStr.Substring(1, transStr.Length - 1);
    //                        return transStr;
    //                    }
    //                    else if (transStr.Length == 1)
    //                    {
    //                        return transStr.ToUpper();
    //                    }
    //                    else
    //                    {
    //                        return transStr;
    //                    }
    //                }
    //                else
    //                {
    //                    return transStr;
    //                }
    //            }
    //            catch (System.Exception)
    //            {
    //                return keyStr;
    //            }
    //        }
    //        else
    //        {
    //            return keyStr;
    //        }
    //    }
    //}

    #endregion
}

namespace KRExcel.Utils
{
    public static class CommonDeclaration
    {
        public const double MaxDegMinSec = 60.0;
        public const double KRTolerance = 0.000001;
        public const string DegreeSymbol = "°";
        public const string MinuteSymbol = "'";
        public const string SecondSymbol = "\"";
        public const string Owner = "KR-Excel";
        public const string Designer = "LeThuongTri";
    }

    public static class Win32Declaration
    {
        public const int VK_NUMLOCK = 0x90;
    }

    public static class HelpMethods
    {
        public static double RadianToDegree(double angRad)
        {
            return angRad * 180.0 / System.Math.PI;
        }

        public static double DegreeToRadian(double angDeg)
        {
            return angDeg * System.Math.PI / 180.0;
        }

        //Get bool from user input with default value:
        public static bool GetBoolFromObject(object inputObject, out bool retBool , bool defaulValue)
        {
            //Initialize return value as default:
            retBool = defaulValue;

            if (inputObject is ExcelDna.Integration.ExcelMissing)
            {
                return true;
            }
            else
            {
                if (inputObject is not bool)
                {
                    return false;
                }
                else
                {
                    retBool = System.Convert.ToBoolean(inputObject);
                    return true;
                }
            }
        }

        //Get double from user input:
        public static bool GetDoubleFromObject(object inputObject, out double retVal)
        {
            retVal = 0.0;

            if (inputObject is ExcelDna.Integration.ExcelMissing)
            {
                return false;
            }
            else
            {
                if (inputObject is not double)
                {
                    return false;
                }
                else
                {
                    retVal = System.Convert.ToDouble(inputObject);
                    return true;
                }
            }
        }

        //Get integer from user input:
        public static bool GetIntFromObject(object inputObject,out int retVal , bool isPositiveOnly = false)
        {
            retVal = 0;

            if (inputObject is not double || inputObject is ExcelDna.Integration.ExcelMissing)
            {
                //throw new ArgumentException();
                return false;
            }
            else
            {
                double testCount = System.Convert.ToDouble(inputObject);

                if (!testCount.Equals(System.Math.Truncate(testCount)))
                {
                    return false;
                }
                else
                {
                    retVal = System.Convert.ToInt32(testCount);

                    if (isPositiveOnly && retVal <= 0)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
        }
    }

    public static class Win32Methods
    {
        //Help method to set a specific app window to foreground:
        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
        public static extern short GetKeyState(int keyCode);
    }

    public static class MarshalForCore
    {
        internal const String OLEAUT32 = "oleaut32.dll";
        internal const String OLE32 = "ole32.dll";

        [DllImport(OLE32, PreserveSig = false)]
        [ResourceExposure(ResourceScope.None)]
        [SuppressUnmanagedCodeSecurity]
        [System.Security.SecurityCritical]
        private static extern void CLSIDFromProgIDEx([MarshalAs(UnmanagedType.LPWStr)] String progId, out Guid clsid);


        [DllImport(OLE32, PreserveSig = false)]
        [ResourceExposure(ResourceScope.None)]
        [SuppressUnmanagedCodeSecurity]
        [System.Security.SecurityCritical]
        private static extern void CLSIDFromProgID([MarshalAs(UnmanagedType.LPWStr)] String progId, out Guid clsid);

        [DllImport(OLEAUT32, PreserveSig = false)]
        [ResourceExposure(ResourceScope.None)]
        [SuppressUnmanagedCodeSecurity]
        [System.Security.SecurityCritical]
        private static extern void GetActiveObject(ref Guid rclsid, IntPtr reserved, [MarshalAs(UnmanagedType.Interface)] out Object ppunk);
        
        [System.Security.SecurityCritical]
        public static Object GetActiveObject(String progID)
        {
            Object obj = null;
            Guid clsid;

            try
            {
                CLSIDFromProgIDEx(progID, out clsid);
            }
            catch (Exception)
            {
                CLSIDFromProgID(progID, out clsid);
            }

            try
            {
                GetActiveObject(ref clsid, IntPtr.Zero, out obj);
            }
            catch (Exception)
            {
                //MessageBox.Show("Cannot get active Autocad application!",
                //    KRExcel.Utils.CommonDeclaration.Owner,
                //    MessageBoxButtons.OK, MessageBoxIcon.Error);
                obj = null;
                return obj;
            }
            //catch (COMException ex) when (ex.ErrorCode == unchecked((int)0x800401E3))
            //{
            //    //// Handle the specific error
            //    //Console.WriteLine("COM object not available. Ensure the application is running.");
            //    MessageBox.Show("Cannot get active Autocad application!",
            //        KRExcel.Utils.CommonDeclaration.Owner,
            //        MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}

            return obj;
        }
    }
}

namespace KRExcel.UDF.CommonFormula
{
    public static class Commands
    {
        [ExcelFunction(Description = "勾配(%)を度・ラジアン単位に変換する。")]
        public static object SlopeToAngle(
            [ExcelArgument(Name = "勾配(%)", Description = "変化する勾配。")]
            object slopeObj,
            [ExcelArgument(Name = "度単位で返すか", Description = "返す値の型。" +
                                                                "\nTRUE: 度単位で値を返す。" +
                                                               "\nFALSE: ラジアン単位で値を返す。" +
                                                               "\nデフォルトではTRUE。")]
            object retDegObj)
        {
            //Initialize default return value:
            double retVal = 0.0;

            #region [Check input]

            //Check slope:
            double slope;
            if (!KRExcel.Utils.HelpMethods.GetDoubleFromObject(slopeObj,out slope))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //double slope = 0.0;
            //if (slopeObj is not double || slopeObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    slope = System.Convert.ToDouble(slopeObj);
            //}

            #endregion

            //Check return type's flag:
            bool isDeg;
            if (!KRExcel.Utils.HelpMethods.GetBoolFromObject(retDegObj, out isDeg, true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //bool isDeg = false;
            //if (retDegObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    isDeg = true;
            //}
            //else
            //{
            //    if (retDegObj is not bool)
            //    {
            //        //throw new ArgumentException();
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        isDeg = System.Convert.ToBoolean(retDegObj);
            //    }
            //}

            #endregion

            #endregion

            //Calculate input:
            double tang = slope / 100.0;
            double angRad = System.Math.Atan(tang);
            double angDeg = KRExcel.Utils.HelpMethods.RadianToDegree(angRad);

            //Calculate return value:
            if (isDeg)
            {
                retVal = angDeg;
            }
            else
            {
                retVal = angRad;
            }

            return retVal;
        }

        [ExcelFunction(Description = "角度(°)を_°_''_''の形式に変換する。")]
        public static object AngleToDMS(
            [ExcelArgument(Name = "角度(°)", Description = "変化する角度。")]
            object angle,
            [ExcelArgument(Name = "高精度か", Description = "精度レベル" +
                                                                "\nTRUE: _°_''_''の形式に変換する。" +
                                                               "\nFALSE: _°_''の形式に変換する。" +
                                                               "\nデフォルトではFALSE。")]
            object highPrecision)
        {
            //Initialize return value:
            string retVal = string.Empty;

            //Get degrees:
            double deg;
            string angSign = string.Empty;
            if (!KRExcel.Utils.HelpMethods.GetDoubleFromObject(angle,out deg))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            if (deg < 0)
            {
                angSign = "-";
                deg = System.Math.Abs(deg);
            }

            #region [Old codes]

            //double deg = 0.0;
            //string angSign = string.Empty;

            //if (angle is not double || angle is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    deg = System.Convert.ToDouble(angle);

            //    if (deg < 0)
            //    {
            //        angSign = "-";
            //        deg = System.Math.Abs(deg);
            //    }
            //}

            #endregion

            //Check flag argument:
            bool isHighPre;
            if (!KRExcel.Utils.HelpMethods.GetBoolFromObject(highPrecision, out isHighPre, false))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //bool isHighPre = false;
            //if (highPrecision is ExcelDna.Integration.ExcelMissing)
            //{
            //    isHighPre = false;
            //}
            //else
            //{
            //    if (highPrecision is not bool)
            //    {
            //        //throw new ArgumentException();
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        isHighPre = System.Convert.ToBoolean(highPrecision);
            //    }
            //}

            #endregion

            double minute = (deg - System.Math.Truncate(deg)) * KRExcel.Utils.CommonDeclaration.MaxDegMinSec;

            double second = (minute - System.Math.Truncate(minute)) * KRExcel.Utils.CommonDeclaration.MaxDegMinSec;
            
            if (!isHighPre)
            {
                deg = System.Math.Truncate(deg);

                //System.Math.Round(second).Equals(CommonDeclaration.MaxDegMinSec / 2.0)
                //second.Equals(CommonDeclaration.MaxDegMinSec / 2.0)
                //second >= CommonDeclaration.MaxDegMinSec / 2.0)
                if (System.Math.Abs(second - KRExcel.Utils.CommonDeclaration.MaxDegMinSec / 2.0) <= KRExcel.Utils.CommonDeclaration.KRTolerance)
                {
                    minute = System.Math.Truncate(minute) + 1.0;
                }
                else
                {
                    minute = System.Math.Round(minute, 0, MidpointRounding.AwayFromZero);
                }

                if (minute.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    deg += 1.0;
                    minute = 0.0;
                }

                retVal = angSign + deg.ToString() + KRExcel.Utils.CommonDeclaration.DegreeSymbol +
                         minute.ToString() + KRExcel.Utils.CommonDeclaration.MinuteSymbol;
            }
            else
            {
                deg = System.Math.Truncate(deg);
                minute = System.Math.Truncate(minute);

                //double secondTail = System.Math.Round(second - System.Math.Truncate(second), 1 , 
                //    MidpointRounding.AwayFromZero);

                double secondTail = second - System.Math.Truncate(second);

                //secondTail.Equals(0.5)
                if (System.Math.Abs(secondTail - 0.5) <= KRExcel.Utils.CommonDeclaration.KRTolerance)
                {
                    second = System.Math.Truncate(second) + 1.0;
                }
                else
                {
                    second = System.Math.Round(second, 0, MidpointRounding.AwayFromZero);
                }

                if (second.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    minute += 1.0;
                    second = 0.0;
                }

                if (minute.Equals(KRExcel.Utils.CommonDeclaration.MaxDegMinSec))
                {
                    deg += 1.0;
                    minute = 0.0;
                }

                retVal = angSign + deg.ToString() + KRExcel.Utils.CommonDeclaration.DegreeSymbol +
                         minute.ToString() + KRExcel.Utils.CommonDeclaration.MinuteSymbol +
                         second.ToString() + KRExcel.Utils.CommonDeclaration.SecondSymbol;
            }

            return retVal;
        }

        [ExcelFunction(Description = "反対辺(mm)")]
        public static object GetFrontEdgeFromAngle(
            [ExcelArgument(Name = "側辺1(mm)", Description = "側辺1(mm)。")]
            object sideEdge1Obj,
            [ExcelArgument(Name = "側辺2(mm)", Description = "側辺2(mm)。")]
            object sideEdge2Obj,
            [ExcelArgument(Name = "真ん中角度(°)", Description = "真ん中角度(°)。" +
                                                                "\nデフォルトでは90°")]
            object angObj
            )
        {
            double retVal = 0.0;

            double sideEdge1;
            if (!KRExcel.Utils.HelpMethods.GetDoubleFromObject(sideEdge1Obj, out sideEdge1))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }
            else
            {
                if (sideEdge1 <= 0)
                {
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
            }

            double sideEdge2;
            if (!KRExcel.Utils.HelpMethods.GetDoubleFromObject(sideEdge2Obj, out sideEdge2))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }
            else
            {
                if (sideEdge2 <= 0)
                {
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
            }

            double ang;
            if (angObj is ExcelDna.Integration.ExcelMissing)
            {
                ang = 90.0;
            }
            else
            {
                if (!KRExcel.Utils.HelpMethods.GetDoubleFromObject(angObj, out ang))
                {
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
            }

            retVal = System.Math.Sqrt(System.Math.Pow(sideEdge1, 2) +
                System.Math.Pow(sideEdge2, 2) -
                2.0 * sideEdge1 * sideEdge2 * System.Math.Cos(
                    KRExcel.Utils.HelpMethods.DegreeToRadian(ang)));

            return retVal;
        }
    }
}

namespace KRExcel.UDF.KR9K_Bolt_Count
{
    public static class Commands
    {
        [ExcelFunction(Description = "KR9000タイプではボトムレールA、Bを取り付けるボルト数を計算する。")]
        public static object KR9K_BotAB_Bolt(
            [ExcelArgument(Name = "バラスター数(本)", Description = "バラスター数(本)。")]
            object baCountObj)
        {
            int retVal = 0;

            //Check baluster input:
            int baCount;
            if (!KRExcel.Utils.HelpMethods.GetIntFromObject(baCountObj, out baCount, false))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }
            else
            {
                if (baCount < 0)
                {
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
            }

            #region [Old codes]

            //int baCount = 0;
            //if (baCountObj is not double || baCountObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testBaCount = System.Convert.ToDouble(baCountObj);

            //    if (!testBaCount.Equals(System.Math.Truncate(testBaCount)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        baCount = System.Convert.ToInt32(testBaCount);

            //        if (baCount <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            int side = 2;
            int edgeHoleNum = 2;
            int midHoleNume = 0;
            int stepOver = 2;
            if (baCount > 2)
            {
                double divided = baCount / stepOver;

                if (Int32.IsOddInteger(baCount))
                {
                    midHoleNume = (int)Math.Truncate(divided);
                }
                else
                {
                    midHoleNume = (int)divided - 1;
                }
            }

            retVal = (midHoleNume + edgeHoleNum) * side;

            return retVal;
        }

        [ExcelFunction(Description = "バラスター、ポリカー板を取り付けるボルト数を計算する。")]
        public static object KR9K_BaPo_Bolt(
            [ExcelArgument(Name = "バラスター数(本)", Description = "バラスター数(本)。")]
            object baCountObj,

            [ExcelArgument(Name = "ボルト数/ 1 バラスター", Description = "ボルト数/ 1 バラスター。")]
            object boltPerBaObj
            )
        {
            int retVal = 0;

            //Check baluster input:
            int baCount;
            if (!KRExcel.Utils.HelpMethods.GetIntFromObject(baCountObj, out baCount, true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }
            else
            {
                if (baCount == 1)
                {
                    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
                }
            }

            #region [Old codes]

            //int baCount = 0;
            //if (baCountObj is not double || baCountObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testBaCount = System.Convert.ToDouble(baCountObj);

            //    if (!testBaCount.Equals(System.Math.Truncate(testBaCount)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        baCount = System.Convert.ToInt32(testBaCount);

            //        if (baCount <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            //Check bolts per Baluster input:
            int boltPerBa;
            if (!KRExcel.Utils.HelpMethods.GetIntFromObject(boltPerBaObj, out boltPerBa, true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //int boltPerBa = 2;
            //if (boltPerBaObj is not double || boltPerBaObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testBoltPerBa = System.Convert.ToDouble(boltPerBaObj);

            //    if (!testBoltPerBa.Equals(System.Math.Truncate(testBoltPerBa)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        boltPerBa = System.Convert.ToInt32(testBoltPerBa);

            //        if (boltPerBa <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            int edgeHoleNum = 2;
            int midHoleNume = 0;
            int stepOver = 2;
            if (baCount > 2)
            {
                double divided = baCount / stepOver - 1;
                midHoleNume = (int)System.Math.Truncate(divided);
            }

            retVal = (midHoleNume + edgeHoleNum) * boltPerBa;

            return retVal;
        }

        [ExcelFunction(Description = "バラスター、ポリカー板を取り付けるボルト数(予備含み)を計算する。")]
        public static object GetSpareTorxScrew(
            [ExcelArgument(Name = "実数量(本)", Description = "トルクスの実数量(本)。")]
            object realAmountObj,

            [ExcelArgument(Name = "高精度か", Description = "精度レベル" +
                                                            "\nTRUE: 高精度。" +
                                                            "\nFALSE: 低精度。" +
                                                            "\nデフォルトではTRUE。")]
            object highPrecisionObj
            )
        {
            int retVal = 0;

            //Check baluster input:
            int realCount;
            if (!KRExcel.Utils.HelpMethods.GetIntFromObject(realAmountObj, out realCount, true))
            {
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //int realCount = 0;
            //if (realAmountObj is not double || realAmountObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    //throw new ArgumentException();
            //    return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //}
            //else
            //{
            //    double testAmount = System.Convert.ToDouble(realAmountObj);

            //    if (!testAmount.Equals(System.Math.Truncate(testAmount)))
            //    {
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        realCount = System.Convert.ToInt32(testAmount);

            //        if (realCount <= 0)
            //        {
            //            return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //        }
            //    }
            //}

            #endregion

            bool isHighPrecision;
            if (!KRExcel.Utils.HelpMethods.GetBoolFromObject(highPrecisionObj, out isHighPrecision, true))
            {
                //throw new ArgumentException();
                return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            }

            #region [Old codes]

            //if (highPrecisionObj is ExcelDna.Integration.ExcelMissing)
            //{
            //    isHighPrecision = true;
            //}
            //else
            //{
            //    if (highPrecisionObj is not bool)
            //    {
            //        //throw new ArgumentException();
            //        return ExcelDna.Integration.ExcelError.ExcelErrorValue;
            //    }
            //    else
            //    {
            //        isHighPrecision = System.Convert.ToBoolean(highPrecisionObj);
            //    }
            //}

            #endregion

            if (!isHighPrecision)
            {
                double spareMin = realCount * 1.05;
                double spareMax = realCount * 1.1;
                double spareMid = (spareMin + spareMax) / 2.0;
                //retVal = (int)System.Math.Round(spareMid, MidpointRounding.ToPositiveInfinity);
                retVal = (int)(System.Math.Ceiling(spareMid * 0.2) / 0.2);
            }
            else
            {
                int spareCount = 0;
                if (realCount <= 20)
                {
                    spareCount = 0;
                }
                else if (realCount > 20 && realCount <= 100)
                {
                    spareCount = 5;
                }
                else if (realCount > 100 && realCount < 200)
                {
                    spareCount = 10;
                }
                else
                {
                    spareCount = 20;
                }

                retVal = (int)(System.Math.Ceiling((realCount + spareCount) * 0.2) / 0.2);
            }

            return retVal;
        }
    }
}

namespace KRExcel.Ribbon
{
    //https://stackoverflow.com/questions/38762368/embedded-resource-in-net-core-libraries
    //https://chuongmep.com/posts/2024-05-02-use-com-api-autocad-netcore.html
    //[ComVisible(false)]
    [ComVisible(true)]
    public class KRExcelRibbon : ExcelRibbon
    {
        private const string ribbonName = "KRExcelRibbon.xml";
        private const string imageExt = ".png";
        //private const string ribbonName = "SampleRibbon.xml";

        //Called automaticly from Ribbon:
        public override string GetCustomUI(string ribbonID)
        {
            string ribbonXml = GetCustomRibbonXML(ribbonName);

            return ribbonXml;
        }

        private string GetCustomRibbonXML(string ribbonXmlName)
        {
            string ribbonXml;
            var thisAssembly = Assembly.GetExecutingAssembly();
            var embeddedProvider = new EmbeddedFileProvider(thisAssembly);
            using (var stream = embeddedProvider.GetFileInfo(ribbonXmlName).CreateReadStream())
            {
                using (var streamReader = new StreamReader(stream))
                {
                    // some logic with stream reader
                    ribbonXml = streamReader.ReadToEnd();
                }
            }

            #region [Old codes]

            ////var thisAssembly = typeof(KRExcelRibbon).Assembly;
            ////var resourceName = typeof(KRExcelRibbon).Namespace + ".KRExcelRibbon.xml";
            //Assembly thisAssembly = Assembly.GetExecutingAssembly();
            //string resourceName = "Resources.KRExcelRibbon.xml";

            //using (Stream stream = thisAssembly.GetManifestResourceStream(resourceName))
            //{
            //    if (stream != null)
            //    {
            //        using (StreamReader reader = new StreamReader(stream))
            //        {
            //            ribbonXml = reader.ReadToEnd();
            //        }
            //    }
            //    else
            //    {
            //        ribbonXml = string.Empty;
            //    }
            //}

            #endregion

            if (string.IsNullOrEmpty(ribbonXml) ||
                string.IsNullOrWhiteSpace(ribbonXml))
            {
                throw new MissingManifestResourceException(ribbonXmlName);
            }
            else
            {
                return ribbonXml;
            }

            //if (ribbonXml == null || ribbonXml == string.Empty)
            //{
            //    throw new MissingManifestResourceException(ribbonXmlName);
            //}
        }

        //Called automaticly from Ribbon:
        public Bitmap? GetImage(IRibbonControl control)
        {
            return LoadImage(control.Id) as Bitmap;
        }

        public override object? LoadImage(string imageId)
        {
            string imagePath = "Resources.Icons." + imageId + imageExt;
            var thisAssembly = Assembly.GetExecutingAssembly();
            var embeddedProvider = new EmbeddedFileProvider(thisAssembly);

            IFileInfo fileInfo = embeddedProvider.GetFileInfo(imagePath);
            if (fileInfo.Exists)
            {
                using (var stream = fileInfo.CreateReadStream())
                {
                    return new Bitmap(stream);
                }
            }
            else
            {
                return null;
            }

            #region [Old codes]

            //if (imageId == "SlopeToAngle")
            //{

            //}
            //else
            //{
            //    return null;
            //}

            #endregion
        }

        #region [Help methods]

        //public bool IsStartFormula()
        //{
        //    var excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
        //    var activeCell = (NetExcel.Range)excelApp.ActiveCell;

        //    if (activeCell != null)
        //    {
        //        string cellValue = (string)activeCell.Formula;
        //        //return cellValue != null && cellValue.StartsWith("=");

        //        if (cellValue == null)
        //        {
        //            return true;
        //        }
        //        else
        //        {
        //            if (cellValue.StartsWith("="))
        //            {
        //                return true;
        //            }
        //            else
        //            {
        //                return false;
        //            }
        //        }
        //    }

        //    return false;
        //}

        //Call UDF function:
        private bool CallUDF(string funcName)
        {
            //Get Excel Application:
            NetExcel.Application excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
            if (excelApp == null)
            {
                MessageBox.Show("Cannot get Excel Application!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            //Get ActiveCell:
            NetExcel.Range activeCell = null;
            try
            {
                activeCell = excelApp.ActiveCell;
                if (activeCell == null)
                {
                    MessageBox.Show("Cannot get Excel ActiveCell!",
                            KRExcel.Utils.CommonDeclaration.Owner,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot get Excel ActiveCell!" +
                            $"\nError: {ex.Message}",
                            KRExcel.Utils.CommonDeclaration.Owner,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            // Check Num Lock state
            bool numLockOn = (KRExcel.Utils.Win32Methods.GetKeyState(
                KRExcel.Utils.Win32Declaration.VK_NUMLOCK) & 1) == 1;

            try
            {
                excelApp.SendKeys("{F2}");
                string funcString = funcName + "{(}";
                excelApp.SendKeys(funcString);

                //string currentEditVal = (string)activeCell.Value2;
                //if (currentEditVal.StartsWith('='))
                //{
                //    funcString = "=" + funcString;
                //}

                //excelApp.SendKeys("{F2}");
                //activeCell.Formula = "=" + funcName;

                //activeCell.Formula = "=" + funcName;
                //excelApp.SendKeys("{F2}");
                //excelApp.SendKeys("{(}");

                //excelApp.SendKeys("{F2}");
                //if (IsStartFormula())
                //{
                //    excelApp.SendKeys("=" + funcName + "{(}");
                //}
                //else
                //{
                //    excelApp.SendKeys(funcName + "{(}");
                //}

                //if (activeCell.Text.Length > 0)
                //{
                //    excelApp.SendKeys(funcName + "{(}");
                //}
                //else
                //{
                //    excelApp.SendKeys("=" + funcName + "{(}");
                //}

                //if (!IsCellInEditMode())
                //{
                //    activeCell.Formula = "=" + funcName;
                //    excelApp.SendKeys("{F2}");
                //    excelApp.SendKeys("{(}");
                //}
                //else
                //{
                //    excelApp.SendKeys("{F2}");
                //    excelApp.SendKeys("=" + funcName + "{(}");
                //}

                //activeCell.Formula = "=" + funcName;
                //excelApp.SendKeys("{F2}");
                //activeCell.Select();
                //excelApp.SendKeys("{F2}");
                //excelApp.SendKeys("{(}");
                //app.SendKeys("{LEFT}");
                //app.SendKeys("{RIGHT}");
                //app.Run("KR9K_BotAB_Bolt");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot insert formula for ActiveCell!" +
                            $"\nError: {ex.Message}",
                            KRExcel.Utils.CommonDeclaration.Owner,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }
            finally
            {
                // Restore Num Lock state if it was on
                if (numLockOn != ((KRExcel.Utils.Win32Methods.GetKeyState(
                    KRExcel.Utils.Win32Declaration.VK_NUMLOCK) & 1) == 1))
                {
                    excelApp.SendKeys("{NUMLOCK}");
                }
            }
            
            return true;
        }

        #endregion

        public void LangSetting_BtnPressed(IRibbonControl control)
        {
            //string userLanguage = "vi-VN";

            //CultureInfo.CurrentCulture = new CultureInfo(userLanguage);
            //CultureInfo.CurrentUICulture = new CultureInfo(userLanguage);

            //string testLocalized = LocalizationHelper.GetString("angle", CultureInfo.CurrentCulture.Name);

            //MessageBox.Show(testLocalized);

            MessageBox.Show("This module is being builded." + 
                            "\nPlease come back later.",
                            KRExcel.Utils.CommonDeclaration.Owner, 
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void SlopeToAngle_BtnPressed(IRibbonControl control)
        {
            if (!CallUDF("SlopeToAngle"))
            {
                return;
            }
        }

        public void AngleToDMS_BtnPressed(IRibbonControl control)
        {
            if (!CallUDF("AngleToDMS"))
            {
                return;
            }
        }

        public void GetFrontEdgeFromAngle_BtnPressed(IRibbonControl control)
        {
            if (!CallUDF("GetFrontEdgeFromAngle"))
            {
                return;
            }
        }

        public void KR9K_BotAB_Bolt_BtnPressed(IRibbonControl control)
        {
            if (!CallUDF("KR9K_BotAB_Bolt"))
            {
                return;
            }
        }

        public void KR9K_BaPo_Bolt_BtnPressed(IRibbonControl control)
        {
            if (!CallUDF("KR9K_BaPo_Bolt"))
            {
                return;
            }
        }

        public void GetSpareTorxScrew_BtnPressed(IRibbonControl control)
        {
            if (!CallUDF("GetSpareTorxScrew"))
            {
                return;
            }
        }
    }
}

namespace KRExcel.Sample
{
    public static class Commands
    {
        //[ExcelFunction(Description = "My first .NET function")]
        public static string SayHello(string name)
        {
            return "Hello " + name;
        }

        //[ExcelFunction(Description = "A useful test function that adds two numbers, and returns the sum.")]
        public static double AddThem(
            [ExcelArgument(Name = "Augend", Description = "is the first number, to which will be added")]
            double v1,
            [ExcelArgument(Name = "Addend", Description = "is the second number that will be added")]
            double v2)
        {
            return v1 + v2;
        }
    }

    // Here is the helper class - add to it or change as you require
    internal static class Optional
    {
        internal static string Check(object arg, string defaultValue)
        {
            if (arg is string)
                return (string)arg;
            else if (arg is ExcelMissing)
                return defaultValue;
            else
                return arg.ToString();  // Or whatever you want to do here....

            // Perhaps check for other types and do whatever you think is right ....
            //else if (arg is double)
            //    return "Double: " + (double)arg;
            //else if (arg is bool)
            //    return "Boolean: " + (bool)arg;
            //else if (arg is ExcelError)
            //    return "ExcelError: " + arg.ToString();
            //else if (arg is object[,](,))
            //    // The object array returned here may contain a mixture of types,
            //    // reflecting the different cell contents.
            //    return string.Format("Array[{0},{1}]({0},{1})",
            //      ((object[,](,)(,))arg).GetLength(0), ((object[,](,)(,))arg).GetLength(1));
            //else if (arg is ExcelEmpty)
            //    return "<<Empty>>"; // Would have been null
            //else if (arg is ExcelReference)
            //  // Calling xlfRefText here requires IsMacroType=true for this function.
            //                return "Reference: " +
            //                     XlCall.Excel(XlCall.xlfReftext, arg, true);
            //            else
            //                return "!? Unheard Of ?!";
        }

        internal static double Check(object arg, double defaultValue)
        {
            if (arg is double)
                return (double)arg;
            else if (arg is ExcelMissing)
                return defaultValue;
            else
                throw new ArgumentException();  // Will return #VALUE to Excel

        }

        // This one is more tricky - we have to do the double->Date conversions ourselves
        internal static DateTime Check(object arg, DateTime defaultValue)
        {
            if (arg is double)
                return DateTime.FromOADate((double)arg);    // Here is the conversion
            else if (arg is string)
                return DateTime.Parse((string)arg);
            else if (arg is ExcelMissing)
                return defaultValue;

            else
                throw new ArgumentException();  // Or defaultValue or whatever
        }
    }
}

namespace KRExcel.Sample.Ribbon
{
    [ComVisible(false)]
    //[ComVisible(true)]
    public class SampleRibbon : ExcelRibbon
    {
        private const string ribbonName = "SampleRibbon.xml";

        public override string GetCustomUI(string ribbonID)
        {
            string ribbonXml = GetCustomRibbonXML(ribbonName);

            return ribbonXml;
        }
        private string GetCustomRibbonXML(string ribbonXmlName)
        {
            string ribbonXml;
            var thisAssembly = Assembly.GetExecutingAssembly();
            var embeddedProvider = new EmbeddedFileProvider(thisAssembly);
            using (var stream = embeddedProvider.GetFileInfo(ribbonXmlName).CreateReadStream())
            {
                using (var streamReader = new StreamReader(stream))
                {
                    // some logic with stream reader
                    ribbonXml = streamReader.ReadToEnd();
                }
            }

            if (ribbonXml == null || ribbonXml == string.Empty)
            {
                throw new MissingManifestResourceException(ribbonXmlName);
            }

            return ribbonXml;
        }

        public void OnCountAcadModelBtnPressed(IRibbonControl control)
        {
            //MessageBox.Show("Hello from KR-Project!",
            //    KRExcel.Utils.CommonDeclaration.Owner,
            //    MessageBoxButtons.OK, MessageBoxIcon.Information);

            string progId = "AutoCAD.Application";
            //dynamic acApp = null;
            AcadApplication acApp = null;
            acApp = (AcadApplication)KRExcel.Utils.MarshalForCore.GetActiveObject(progId);
            if (acApp == null)
            {
                if (MessageBox.Show("Autocad hasn't opened yet." +
                                "\nDo you want to open?",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    //Try to create new instance of Autocad:
                    try
                    {
                        acApp = (AcadApplication)Microsoft.VisualBasic.Interaction.CreateObject(progId);
                        if (acApp == null)
                        {
                            MessageBox.Show("Cannot create new instance of Autocad!",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        else
                        {
                            if (!acApp.Visible)
                            {
                                acApp.Visible = true;
                            }

                            // Bring Excel to the foreground
                            NetExcel.Application excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
                            IntPtr hwnd = new IntPtr(excelApp.Hwnd);
                            KRExcel.Utils.Win32Methods.SetForegroundWindow(hwnd);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Cannot create new instance of Autocad!"
                                + $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }

            ////Message out Acad app full name:
            //MessageBox.Show($"{acApp.FullName}",
            //    KRExcel.Utils.CommonDeclaration.Owner,
            //    MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Get current document:
            AcadDocument activeDoc = null;
            if (acApp.Documents.Count == 0)
            {
                MessageBox.Show("No document is currently opened in Autocad Application!",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                activeDoc = acApp.ActiveDocument;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fail to read Autocad's ActiveDocument!" +
                                $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (activeDoc == null)
            {
                MessageBox.Show("Cannot get ActiveDocument!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get ModelSpace:
            AcadModelSpace modelSpace = null;
            modelSpace = activeDoc.ModelSpace;
            if (modelSpace == null)
            {
                MessageBox.Show("Cannot get ModelSpace!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ////Message out number of entites in ModelSpace:
            //MessageBox.Show($"Number of entities in ModelSpace: {modelSpace.Count}",
            //    KRExcel.Utils.CommonDeclaration.Owner,
            //    MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Message out number of entites in ModelSpace:
            if (MessageBox.Show($"Number of entities in ModelSpace: {modelSpace.Count}" +
                "\nActivate Autocad?", KRExcel.Utils.CommonDeclaration.Owner,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Bring AutoCAD to the foreground
                IntPtr hwnd = new IntPtr(acApp.HWND);
                KRExcel.Utils.Win32Methods.SetForegroundWindow(hwnd);
                acApp.WindowState = AcWindowState.acMax;
            }
        }

        public void OnExcelDrawAcadLinesBtnPressed(IRibbonControl control)
        {
            string validWsName = "DrawLines";
            string progId = "AutoCAD.Application";
            AcadApplication acApp = null;
            AcadDocument activeDoc = null;
            AcadModelSpace modelSpace = null;
            NetExcel.Application excelApp = null;

            #region [Get Excel object]

            excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
            if (excelApp == null)
            {
                MessageBox.Show("Cannot get Excel Application!",
                   KRExcel.Utils.CommonDeclaration.Owner,
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            NetExcel.Worksheet activeSheet = null;
            //= excelApp.ActiveSheet;
            try
            {
                activeSheet = excelApp.Worksheets[validWsName];
                if (activeSheet == null)
                {
                    MessageBox.Show("Lost reference to ActiveSheet!",
                       KRExcel.Utils.CommonDeclaration.Owner,
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    activeSheet.Activate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Cannot get WorkSheet'{validWsName}'" +
                                $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            NetExcel.Range usedRange = activeSheet.UsedRange;
            int rowCount = usedRange.Rows.Count;
            int colCount = usedRange.Columns.Count;
            if (colCount != 3 || rowCount <= 1)
            {
                MessageBox.Show("Wrong column/ row format!",
                   KRExcel.Utils.CommonDeclaration.Owner,
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Create list of points then read Excel data:
            System.Collections.Generic.List<double[]> drawPoints = new System.Collections.Generic.List<double[]>();
            for (int i = 2; i < rowCount + 1; i++)
            {
                double[] tempPnt = new double[colCount];
                for (int j = 1; j < colCount + 1; j++)
                {
                    if (usedRange.Cells[i, j].Value is not double)
                    {
                        MessageBox.Show("Wrong cell data type!",
                                         KRExcel.Utils.CommonDeclaration.Owner,
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    tempPnt[j - 1] = usedRange.Cells[i, j].Value;
                }

                drawPoints.Add(tempPnt);
            }

            #endregion

            #region [Get Autocad objects]

            //dynamic acApp = null;
            acApp = (AcadApplication)KRExcel.Utils.MarshalForCore.GetActiveObject(progId);
            if (acApp == null)
            {
                if (MessageBox.Show("Autocad hasn't opened yet." +
                                "\nDo you want to open?",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    //Try to create new instance of Autocad:
                    try
                    {
                        acApp = (AcadApplication)Microsoft.VisualBasic.Interaction.CreateObject(progId);
                        if (acApp == null)
                        {
                            MessageBox.Show("Cannot create new instance of Autocad!",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        else
                        {
                            if (!acApp.Visible)
                            {
                                acApp.Visible = true;
                            }

                            // Bring Excel to the foreground
                            IntPtr hwnd = new IntPtr(excelApp.Hwnd);
                            KRExcel.Utils.Win32Methods.SetForegroundWindow(hwnd);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Cannot create new instance of Autocad!"
                                + $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }

            //Get current document:
            if (acApp.Documents.Count == 0)
            {
                MessageBox.Show("No document is currently opened in Autocad Application!",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                activeDoc = acApp.ActiveDocument;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fail to read Autocad's ActiveDocument!" +
                                $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (activeDoc == null)
            {
                MessageBox.Show("Cannot get ActiveDocument!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get ModelSpace:
            modelSpace = activeDoc.ModelSpace;
            if (modelSpace == null)
            {
                MessageBox.Show("Cannot get ModelSpace!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            #endregion

            if (drawPoints.Count >= 2)
            {
                if (modelSpace.Count > 0)
                {
                    //Clear all old entities in ModelSpace:
                    foreach (AcadEntity ent in modelSpace)
                    {
                        ent.Delete();
                    }
                }

                //Draw new lines:
                for (int i = 0; i < drawPoints.Count - 1; i++)
                {
                    modelSpace.AddLine(drawPoints[i], drawPoints[i + 1]);
                }

                //Message out process is finished:
                if (MessageBox.Show("Processing finished." +
                    "\nActivate Autocad?", KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Bring AutoCAD to the foreground
                    IntPtr hwnd = new IntPtr(acApp.HWND);
                    KRExcel.Utils.Win32Methods.SetForegroundWindow(hwnd);
                    acApp.WindowState = AcWindowState.acMax;
                }
            }
        }

        public void OnExcelDrawAcadCirclesBtnPressed(IRibbonControl control)
        {
            string validWsName = "DrawCircles";
            string progId = "AutoCAD.Application";
            AcadApplication acApp = null;
            AcadDocument activeDoc = null;
            AcadModelSpace modelSpace = null;
            NetExcel.Application excelApp = null;

            #region [Get Excel object]

            excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
            if (excelApp == null)
            {
                MessageBox.Show("Cannot get Excel Application!",
                   KRExcel.Utils.CommonDeclaration.Owner,
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            NetExcel.Worksheet activeSheet = null;
            //= excelApp.ActiveSheet;
            try
            {
                activeSheet = excelApp.Worksheets[validWsName];
                if (activeSheet == null)
                {
                    MessageBox.Show("Lost reference to ActiveSheet!",
                       KRExcel.Utils.CommonDeclaration.Owner,
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    activeSheet.Activate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Cannot get WorkSheet'{validWsName}'" +
                                $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            NetExcel.Range usedRange = activeSheet.UsedRange;
            int rowCount = usedRange.Rows.Count;
            int colCount = usedRange.Columns.Count;
            if (colCount != 4 || rowCount <= 1)
            {
                MessageBox.Show("Wrong column/ row format!",
                   KRExcel.Utils.CommonDeclaration.Owner,
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Create list of points then read Excel data:
            System.Collections.Generic.List<double[]> drawPoints = new System.Collections.Generic.List<double[]>();
            for (int i = 2; i < rowCount + 1; i++)
            {
                double[] tempPnt = new double[colCount];
                for (int j = 1; j < colCount + 1; j++)
                {
                    if (usedRange.Cells[i, j].Value is not double)
                    {
                        MessageBox.Show("Wrong cell data type!",
                                         KRExcel.Utils.CommonDeclaration.Owner,
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    tempPnt[j - 1] = usedRange.Cells[i, j].Value;
                }

                drawPoints.Add(tempPnt);
            }

            #endregion

            #region [Get Autocad objects]

            //dynamic acApp = null;
            acApp = (AcadApplication)KRExcel.Utils.MarshalForCore.GetActiveObject(progId);
            if (acApp == null)
            {
                if (MessageBox.Show("Autocad hasn't opened yet." +
                                "\nDo you want to open?",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    //Try to create new instance of Autocad:
                    try
                    {
                        acApp = (AcadApplication)Microsoft.VisualBasic.Interaction.CreateObject(progId);
                        if (acApp == null)
                        {
                            MessageBox.Show("Cannot create new instance of Autocad!",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        else
                        {
                            if (!acApp.Visible)
                            {
                                acApp.Visible = true;
                            }

                            // Bring Excel to the foreground
                            IntPtr hwnd = new IntPtr(excelApp.Hwnd);
                            KRExcel.Utils.Win32Methods.SetForegroundWindow(hwnd);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Cannot create new instance of Autocad!"
                                + $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }

            //Get current document:
            if (acApp.Documents.Count == 0)
            {
                MessageBox.Show("No document is currently opened in Autocad Application!",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                activeDoc = acApp.ActiveDocument;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fail to read Autocad's ActiveDocument!" +
                                $"\nError: {ex.Message}",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (activeDoc == null)
            {
                MessageBox.Show("Cannot get ActiveDocument!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get ModelSpace:
            modelSpace = activeDoc.ModelSpace;
            if (modelSpace == null)
            {
                MessageBox.Show("Cannot get ModelSpace!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            #endregion

            if (drawPoints.Count >= 1)
            {
                if (modelSpace.Count > 0)
                {
                    //Clear all old entities in ModelSpace:
                    foreach (AcadEntity ent in modelSpace)
                    {
                        ent.Delete();
                    }
                }

                //Draw new:
                for (int i = 0; i < drawPoints.Count; i++)
                {
                    //modelSpace.AddLine(drawPoints[i], drawPoints[i + 1]);
                    double[] drawCoors = new double[3] { drawPoints[i][0],
                        drawPoints[i][1], drawPoints[i][2] };

                    AcadCircle acCir = modelSpace.AddCircle(drawCoors, drawPoints[i][3]);
                    acCir.color = ACAD_COLOR.acRed;

                    if (i + 1 < drawPoints.Count)
                    {
                        double[] drawCoors2 = new double[3] { drawPoints[i+1][0],
                        drawPoints[i+1][1], drawPoints[i+1][2] };

                        AcadLine acLine = modelSpace.AddLine(drawCoors, drawCoors2);
                        acLine.color = ACAD_COLOR.acYellow;
                    }
                }

                //Message out process is finished:
                if (MessageBox.Show("Processing finished." +
                    "\nActivate Autocad?", KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    // Bring AutoCAD to the foreground
                    IntPtr hwnd = new IntPtr(acApp.HWND);
                    KRExcel.Utils.Win32Methods.SetForegroundWindow(hwnd);
                    acApp.WindowState = AcWindowState.acMax;
                }
            }
        }

        public void OnChangeActiveCellBtnPressed(IRibbonControl control)
        {
            //Get root Excel Application:
            NetExcel.Application excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
            if (excelApp == null)
            {
                MessageBox.Show("Lost reference to Excel Application!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get ActiveCell:
            NetExcel.Range activeCell = excelApp.ActiveCell;
            if (activeCell == null)
            {
                MessageBox.Show("Lost reference to ActiveCell!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            activeCell.Font.Bold = true;
            activeCell.Font.Italic = true;
            activeCell.Font.ColorIndex = 3;
            activeCell.HorizontalAlignment = NetExcel.XlHAlign.xlHAlignCenter;
            activeCell.VerticalAlignment = NetExcel.XlVAlign.xlVAlignCenter;
            if (!activeCell.WrapText)
            {
                activeCell.WrapText = true;
            }
            else
            {
                activeCell.WrapText = false;
            }
        }

        public void OnCopyBtnPressed(IRibbonControl control)
        {
            //Get root Excel Application:
            NetExcel.Application excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
            if (excelApp == null)
            {
                MessageBox.Show("Lost reference to Excel Application!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get ActiveCell:
            NetExcel.Range activeRng = excelApp.Selection;
            if (activeRng == null)
            {
                MessageBox.Show("Lost reference to selection!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                activeRng.Copy();
            }
        }

        public void OnPasteBtnPressed(IRibbonControl control)
        {
            //Get root Excel Application:
            NetExcel.Application excelApp = (NetExcel.Application)ExcelDnaUtil.Application;
            if (excelApp == null)
            {
                MessageBox.Show("Lost reference to Excel Application!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get ActiveCell:
            NetExcel.Range activeCell = excelApp.ActiveCell;
            if (activeCell == null)
            {
                MessageBox.Show("Lost reference to ActiveCell!",
                    KRExcel.Utils.CommonDeclaration.Owner,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                NetExcel.Worksheet curWs = excelApp.ActiveSheet;
                if (curWs == null)
                {
                    MessageBox.Show("Lost reference to ActiveSheet!",
                                    KRExcel.Utils.CommonDeclaration.Owner,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                curWs.Paste();
            }
        }

        public void OnProjectBtnPressed_SampleActiveCell(IRibbonControl control)
        {
            //Get Excel application:
            NetExcel.Application excelApp = (NetExcel.Application)ExcelDnaUtil.Application;

            NetExcel.Range curCell = excelApp.ActiveCell;
            if (curCell == null)
            {
                MessageBox.Show("Cannot get reference to active cell!",
                                KRExcel.Utils.CommonDeclaration.Owner,
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                MessageBox.Show($"Active cell's address: {curCell.Address}" +
                                $"\nActive cell's local address: {curCell.AddressLocal}",
                               KRExcel.Utils.CommonDeclaration.Owner,
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void OnProjectBtnPressed_SampleWbWs(IRibbonControl control)
        {
            //MessageBox.Show("Hello from KR-Project " + control.Id,
            //                KRExcel.Utils.CommonDeclaration.Owner,
            //                MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Get Excel application:
            NetExcel.Application excelApp = (NetExcel.Application)ExcelDnaUtil.Application;

            int wbCount = excelApp.Workbooks.Count;
            if (wbCount == 0)
            {
                MessageBox.Show("No workbook is being opened!",
                            KRExcel.Utils.CommonDeclaration.Owner,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get reference to active workbook:
            NetExcel.Workbook curWb = excelApp.ActiveWorkbook;
            if (curWb == null)
            {
                MessageBox.Show("Cannot get reference to active workbook!",
                            KRExcel.Utils.CommonDeclaration.Owner,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get reference to active worksheet:
            NetExcel.Worksheet curWs = curWb.ActiveSheet;
            if (curWs == null)
            {
                MessageBox.Show("Cannot get reference to active worksheet!",
                            KRExcel.Utils.CommonDeclaration.Owner,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show($"Current worksheet's name: {curWs.Name}",
                            KRExcel.Utils.CommonDeclaration.Owner,
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private KRExcel.Sample.SampleFrm1 _SampleFrm1 = null;

        public void OnSampleFrmBtnPressed(IRibbonControl control)
        {
            //MessageBox.Show("Hello from sample form.",
            //                KRExcel.Utils.CommonDeclaration.Owner,
            //                MessageBoxButtons.OK, MessageBoxIcon.Information);

            if (_SampleFrm1 == null || _SampleFrm1.IsDisposed)
            {
                _SampleFrm1 = new KRExcel.Sample.SampleFrm1();
            }

            if (!_SampleFrm1.Visible)
            {
                if (_SampleFrm1.ShowDialog() == DialogResult.Cancel)
                {
                    _SampleFrm1.Dispose();
                }
            }
            else
            {
                _SampleFrm1.Activate();
            }
        }
    }

    #region [Old codes - 1]

    //public static class Functions
    //{
    //    public static string dnaRibbonTest()
    //    {
    //        return "Hello from the Ribbon Sample!";
    //    }
    //}

    //[ComVisible(true)]
    //public class RibbonController : ExcelRibbon
    //{
    //    private KRExcel.Sample.SampleFrm1 _SampleFrm1 = null;

    //    //https://bert-toolkit.com/imagemso-list.html
    //    public override string GetCustomUI(string RibbonID)
    //    {
    //        return @"
    //  <customUI xmlns = 'http://schemas.microsoft.com/office/2006/01/customui' >
    //  < ribbon >
    //    < tabs >
    //      < tab id='krExcelTab' label='KR-Excel' insertBeforeMso='TabHome'>
    //        <group id = 'krUtilGrp' label='KR-Utility'>
    //          <button id = 'projectBtn' label='物件管理' 
    //                                  imageMso='ControlProperties'
    //                                  screentip='Show/edit user settings'
    //                                  onAction='OnProjectBtnPressed'
    //        />

    //        <button id = 'sampleFrmBtn' label='SampleForm' 
    //                                  imageMso='DataFormSource'
    //                                  screentip='Show sample form'
    //                                  onAction='OnSampleFrmBtnPressed'
    //        />

    //        </group >
    //      </tab>
    //    </tabs>
    //  </ribbon>
    //</customUI>";
    //    }

    //    public void OnProjectBtnPressed(IRibbonControl control)
    //    {
    //        MessageBox.Show("Hello from KR-Project " + control.Id,
    //                        KRExcel.Utils.CommonDeclaration.Owner,
    //                        MessageBoxButtons.OK, MessageBoxIcon.Information);
    //    }

    //    public void OnSampleFrmBtnPressed(IRibbonControl control)
    //    {
    //        //MessageBox.Show("Hello from sample form.",
    //        //                KRExcel.Utils.CommonDeclaration.Owner,
    //        //                MessageBoxButtons.OK, MessageBoxIcon.Information);

    //        if (_SampleFrm1 == null || _SampleFrm1.IsDisposed)
    //        {
    //            _SampleFrm1 = new KRExcel.Sample.SampleFrm1();
    //        }

    //        if (!_SampleFrm1.Visible)
    //        {
    //            if (_SampleFrm1.ShowDialog() == DialogResult.Cancel)
    //            {
    //                _SampleFrm1.Dispose();
    //            }
    //        }
    //        else
    //        {
    //            _SampleFrm1.Activate();
    //        }
    //    }
    //}

    #endregion

    #region [Old codes - 2]

    //[ComVisible(true)]
    //public class CustomRibbon : ExcelRibbon
    //{
    //    private Application _excel;
    //    private IRibbonUI _thisRibbon;

    //    public override string GetCustomUI(string ribbonId)
    //    {
    //        _excel = new Application(null, ExcelDna.Integration.ExcelDnaUtil.Application);
    //        string ribbonXml = GetCustomRibbonXML();
    //        return ribbonXml;
    //    }

    //    private string GetCustomRibbonXML()
    //    {
    //        string ribbonXml;
    //        var thisAssembly = typeof(CustomRibbon).Assembly;
    //        var resourceName = typeof(CustomRibbon).Namespace + ".CustomRibbon.xml";

    //        using (Stream stream = thisAssembly.GetManifestResourceStream(resourceName))
    //        using (StreamReader reader = new StreamReader(stream))
    //        {
    //            ribbonXml = reader.ReadToEnd();
    //        }

    //        if (ribbonXml == null)
    //        {
    //            throw new MissingManifestResourceException(resourceName);
    //        }
    //        return ribbonXml;
    //    }

    //    public void OnLoad(IRibbonUI ribbon)
    //    {
    //        if (ribbon == null)
    //        {
    //            throw new ArgumentNullException(nameof(ribbon));
    //        }

    //        _thisRibbon = ribbon;

    //        _excel.WorkbookActivateEvent += OnInvalidateRibbon;
    //        _excel.WorkbookDeactivateEvent += OnInvalidateRibbon;
    //        _excel.SheetActivateEvent += OnInvalidateRibbon;
    //        _excel.SheetDeactivateEvent += OnInvalidateRibbon;

    //        if (_excel.ActiveWorkbook == null)
    //        {
    //            _excel.Workbooks.Add();
    //        }
    //    }

    //    private void OnInvalidateRibbon(object obj)
    //    {
    //        _thisRibbon.Invalidate();
    //    }
    //}

    #endregion
}

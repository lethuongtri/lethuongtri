// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- TEP9KDlg.h : Declaration of the TEP9KDlg
//-----------------------------------------------------------------------------
#pragma once

//-----------------------------------------------------------------------------
#include "adui.h"
#include "resource.h"

//-----------------------------------------------------------------------------
class TEP9KDlg : public CAdUiBaseDialog {
	DECLARE_DYNAMIC (TEP9KDlg)

public:
	TEP9KDlg (CWnd *pParent =NULL, HINSTANCE hInstance =NULL) ;
	enum { IDD = IDD_TEP9KDLG} ;

protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange (CDataExchange *pDX) ;
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg LRESULT OnAcadKeepFocus (WPARAM, LPARAM) ;
	afx_msg void OnKillfocusEditDia();
	afx_msg void OnKillfocusEditSeg();
	afx_msg void OnKillfocusEditSlope();
	afx_msg void OnClose();
	//virtual void TEP9KDlg::OnSysCommand(UINT nID, LPARAM lParam);
	//afx_msg void OnCancelClick();
	//virtual void OnDestroy();
	DECLARE_MESSAGE_MAP()

private:
	CAcUiNumericEdit m_ctrlEdDia;
	CAcUiNumericEdit m_ctrlEdSeg;
	CAcUiNumericEdit m_ctrlEdSlope;
	CString m_strDia;
	CString m_strSeg;
	CString m_strSlope;
	bool m_bIsClosing;
	bool CheckInput();
	void updateGlobalData(bool bUpdateValidData = true);
} ;


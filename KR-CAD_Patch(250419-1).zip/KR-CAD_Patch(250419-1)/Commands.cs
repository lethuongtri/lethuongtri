﻿#region [System 's core]
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
//using System.Text;
//using System.Threading.Tasks;
#endregion

#region [Autocad 's core]
using Autodesk.AutoCAD.Geometry;
using AcAp = Autodesk.AutoCAD.ApplicationServices.Application;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.GraphicsInterface;
#endregion

#region [Static members]
using static AcadAddin.CommonCommands;
using static AcadAddin.KRGet;
using static Autodesk.AutoCAD.ApplicationServices.Core.Application;
using static System.Convert;
#endregion

//For precision format :
using System.Globalization;

//For using math :
using static System.Math;

#region [Interop]
using Autodesk.AutoCAD.Interop;
using System.Runtime.InteropServices;
#endregion

#region [Mechanical COM's library]
using AcadmAuto;
using SymBBAuto;
using GEAuto;
using Autodesk.AutoCAD.Interop.Common;
using System.Net;
using ACSMCOMPONENTS23Lib;
using AcadAddin.Sheetset;
//using System.Windows.Forms;
#endregion

////Tăng hiệu suất tải file DLL.
////Tạo ngỏ vào để gọi phương thức của class từ câu lệnh trong CAD:
////When using, add '[assembly: CommandClass(typeof( 'Namespace' . 'Classname' ))]'

[assembly: CommandClass(typeof(AcadAddin.OverrudeCmd.Commands))]
[assembly: CommandClass(typeof(AcadAddin.LayerCmd.Commands))]
[assembly: CommandClass(typeof(AcadAddin.GeneralCmd.Commands))]
[assembly: CommandClass(typeof(AcadAddin.JigCmd.Commands))]
[assembly: CommandClass(typeof(AcadAddin.UcsCmd.Commands))]
[assembly: CommandClass(typeof(TestCOM.Commands))]
[assembly: CommandClass(typeof(AcadAddin.Sheetset.Commands))]

//[assembly: CommandClass(typeof(AcadAddin.PractiseCmd.Commands))]
//[assembly: CommandClass(typeof(AcadAddin.OverrudeCmd.SelectionHighlightOverrule.Commands))]

namespace TestCOM
{
    //Help class for COM's base interface:
    class AcComBase
    {
        #region [Fields]
        private AcadApplication acApp;
        private AcadmApplication acMApp;
        private AcadDocument acDoc;
        private IMcad2DStructureMgr mgr;
        private bool _isCreated = false;
        private string _errMsg;
        #endregion

        #region [Properties]
        public bool IsCreated
        {
            get { return _isCreated; }
        }

        public string ErrorMsg
        {
            get { return _errMsg; }
        }

        public AcadApplication AcCom
        {
            get { return acApp; }
        }

        public AcadmApplication AcmCom
        {
            get { return acMApp; }
        }

        public AcadDocument DocCom
        {
            get { return acDoc; }
        }

        public IMcad2DStructureMgr StrMgrCom
        {
            get { return mgr; }
        }

        #endregion

        //Constructor:
        public AcComBase()
        {
            try
            {
                //Get acad interface:
                acApp = (AcadApplication)AcAp.AcadApplication;

                //Get mechanical interface:
                acMApp = acApp.GetInterfaceObject("AcadmAuto.AcadmApplication");

                //Get document interface:
                acDoc = acApp.ActiveDocument;

                //Get structures:
                mgr = acMApp.ActiveDocument.StructureMgr2D;

                _isCreated = true;
            }
            catch (System.Exception ex)
            {
                _errMsg = ex.Message;
            }
        }
    }

    //Class for call commands:
    class Commands
    {
        #region [Fields]
        private AcadApplication acApp;
        private AcadmApplication acMApp;
        private AcadDocument acDoc;
        private IMcad2DStructureMgr mgr;
        private McadFolderDefinition rootDef;
        private McadHideSituations hideSituations;
        #endregion

        //Command to check drawing contain hide situation or not(Mechanical only).
        [CommandMethod("CheckHide")]
        public void CmdCheckHide()
        {
            Document doc = AcadAddin.CommonCommands.doc();
            Editor ed = doc.Editor;

            //Check current cad is mechanical or not:
            if (!AcadAddin.IsCadMechanical.Status())
            {
                ed.WriteMessage("\nThis command cannot be used for non mechanical cad!");
                return;
            }

            //Main process:
            try
            {
                //Get acad interface:
                acApp = (AcadApplication)AcAp.AcadApplication;

                //Get mechanical interface:
                acMApp = acApp.GetInterfaceObject("AcadmAuto.AcadmApplication");

                //Get document interface:
                acDoc = acApp.ActiveDocument;

                //Get structures:
                mgr = acMApp.ActiveDocument.StructureMgr2D;

                //Try to get RootView & Hide situations:
                try
                {
                    //Get root definition:
                    rootDef = mgr.RootViewDefinition[acDoc.Database];

                    //Get hide situations:
                    hideSituations = rootDef.HideSituations;
                    if (hideSituations.Count == 0)
                    {
                        ed.WriteMessage("\nThis drawing contains no hide situation!");
                        return;
                    }
                    else
                    {
                        PromptSelectionResult psr = ed.GetSelection();
                        if (psr.Status != PromptStatus.OK || psr.Value.Count == 0)
                        {
                            ed.WriteMessage("\nYou select nothing!");
                            return;
                        }

                        Database db = doc.Database;
                        int hideEntNum = 0;

                        //Main transaction:
                        using (Transaction tr = db.TransactionManager.StartTransaction())
                        {
                            foreach (SelectedObject sObj in psr.Value)
                            {
                                if (sObj != null)
                                {
                                    //Get Com entity from ObjectId:
                                    try
                                    {
                                        AXDBLib.AcadEntity comEnt = acDoc.ObjectIdToObject((long)sObj.ObjectId.OldIdPtr);
                                        if (HasHideSituation(comEnt))
                                        {
                                            hideEntNum += 1;
                                        }
                                    }
                                    catch (System.Exception ex)
                                    {
                                        ed.WriteMessage(ex.Message);
                                        tr.Abort();
                                        return;
                                    }
                                }
                            }

                            //Commit changes:
                            tr.Commit();
                        }

                        //Print out information:
                        if (hideEntNum == 0)
                        {
                            ed.WriteMessage("\nSelectionSet contains no entity with hide.");
                        }
                        else if (hideEntNum == 1)
                        {
                            ed.WriteMessage("\nSelectionSet contains 1 entity with hide.");
                        }
                        else
                        {
                            ed.WriteMessage($"\nSelectionSet contains {hideEntNum} entities with hide.");
                        }
                    }
                }
                catch (System.Exception)
                {
                    ed.WriteMessage("\nThis drawing contains no hide situation!");
                    return;
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        //Test command to clone hide:
        //[CommandMethod("TestCloneHide")]
        public void CmdTestClnHide()
        {
            Document doc = AcadAddin.CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Get selection set:
            PromptSelectionResult psr = ed.GetSelection();
            if (psr.Status != PromptStatus.OK || psr.Value.Count == 0)
            {
                ed.WriteMessage("\nYou select nothing!");
                return;
            }

            //Get COM's base interface:
            AcComBase comBase = new AcComBase();
            if (!comBase.IsCreated)
            {
                ed.WriteMessage("\n" + comBase.ErrorMsg);
                return;
            }


            //Collection for ids in selection:
            ObjectIdCollection objIds = new ObjectIdCollection();

            //Collection for ids with hide:
            ObjectIdCollection hideIds = new ObjectIdCollection();

            //Iterate SelectionSet:
            foreach (SelectedObject sObj in psr.Value)
            {
                if (sObj != null)
                {
                    //Add entity to collection:
                    objIds.Add(sObj.ObjectId);

                    //Add hide entity to hide collection:
                    try
                    {
                        if (HasHideSituation(sObj.ObjectId, comBase.StrMgrCom, comBase.DocCom))
                        {
                            hideIds.Add(sObj.ObjectId);
                        }
                    }
                    catch (System.Exception ex) 
                    {
                        ed.WriteMessage(ex.Message);
                        return;
                    }
                }
            }

            //Transform matrix:
            Matrix3d transMat = Matrix3d.Displacement(new Vector3d(100.0, 100.0, 0.0));

            //Deepclone all entities:
            IdMapping idMap = new IdMapping();
            db.DeepCloneObjects(objIds, db.CurrentSpaceId, idMap, false);
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (ObjectId id in objIds)
                {
                    if (idMap[id].IsCloned)
                    {
                        Entity ent = tr.GetObject(idMap[id].Value, OpenMode.ForWrite) as Entity;
                        ent.TransformBy(transMat);
                    }
                }

                tr.Commit();
            }

            if (hideIds.Count == 0)
            {
                return;
            }

            //Try to get RootView & Hide situations:
            McadFolderDefinition rootDef;
            try
            {
                //Get root definition:
                rootDef = comBase.StrMgrCom.RootViewDefinition[comBase.DocCom.Database];
            }
            catch (System.Exception)
            {
                ed.WriteMessage("\nCannot get root def.");
                return;
            }

            //List<keyvalue<Tupple<KeyValue>,tupple<KeyValue>>>
            //Create HideMap's structure:
            //List<KeyValuePair<List<KeyValuePair<ObjectId, ObjectId>>,
            //                  List<KeyValuePair<ObjectId, ObjectId>>>
            //    > HideMap = new List<KeyValuePair<List<KeyValuePair<ObjectId, ObjectId>>,
            //                                           List<KeyValuePair<ObjectId, ObjectId>>>
            //                        >();

            #region [Fill structure]
            //Add raw data:
            IMcadFolder fdr;
            IMcadFolders fgFdrs,bgFdrs;
            McadHideSituations tempHides;
            object referredToAs;

            //Create list to store hide entities map info:
            List<object> entsInfo = new List<object>();

            foreach (ObjectId id in hideIds)
            {
                AXDBLib.AcadEntity comEnt = comBase.DocCom.ObjectIdToObject((long)id.OldIdPtr);

                //Get folder:
                fdr = comBase.StrMgrCom.GetStructureFromEntity(comEnt);

                //Find hide situations:
                rootDef.FindHideSituations(fdr, out tempHides, out referredToAs);

                //Create list to store hidesituations:
                List<object> hidesInfo = new List<object>();

                foreach (McadHideSituation tempHide in tempHides)
                {
                    fgFdrs = tempHide.Subents[McadHideSituationSubentType.mc2DSFGEnt];
                    List<object> fgGrp = new List<object>();
                    foreach (IMcadFolder tempFdr in fgFdrs)
                    {
                        List<KeyValuePair<ObjectId, ObjectId>> fgIdPairs = new List<KeyValuePair<ObjectId, ObjectId>>();
                        
                        foreach (long tempVal in tempFdr.Entities)
                        {
                            #region [For testing]
                            //ed.WriteMessage("\nFore:");
                            //ed.WriteMessage($"\nOld id: {tempVal}.");
                            //ObjectId recoId = new ObjectId((IntPtr)tempVal);
                            //ed.WriteMessage($"\nNew id: {recoId}.");
                            //ed.WriteMessage("\n------------");
                            #endregion

                            ObjectId srcId = new ObjectId((IntPtr)tempVal);
                            ObjectId desId = idMap[srcId].Value;
                            KeyValuePair<ObjectId, ObjectId> idPair = new KeyValuePair<ObjectId, ObjectId>(srcId, desId);
                            fgIdPairs.Add(idPair);
                        }

                        fgGrp.Add(fgIdPairs);
                    }

                    bgFdrs = tempHide.Subents[McadHideSituationSubentType.mc2DSBGEnt];
                    List<object> bgGrp = new List<object>();
                    foreach (IMcadFolder tempFdr in bgFdrs)
                    {
                        List<KeyValuePair<ObjectId, ObjectId>> bgIdPairs = new List<KeyValuePair<ObjectId, ObjectId>>();

                        foreach (long tempVal in tempFdr.Entities)
                        {
                            #region [For testing]
                            //ed.WriteMessage("\nBack:");
                            //ed.WriteMessage($"\nOld id: {tempVal}.");
                            //ObjectId recoId = new ObjectId((IntPtr)tempVal);
                            //ed.WriteMessage($"\nNew id: {recoId}.");
                            //ed.WriteMessage("\n------------");
                            #endregion

                            ObjectId srcId = new ObjectId((IntPtr)tempVal);
                            ObjectId desId = idMap[srcId].Value;
                            KeyValuePair<ObjectId, ObjectId> idPair = new KeyValuePair<ObjectId, ObjectId>(srcId, desId);
                            bgIdPairs.Add(idPair);
                        }

                        bgGrp.Add(bgIdPairs);
                    }

                    KeyValuePair<object, object> hideInfo = new KeyValuePair<object, object>(fgGrp, bgGrp);

                    hidesInfo.Add(hideInfo);
                }

                entsInfo.Add(hidesInfo);
            }

            #endregion

            #region [Kill overlap]

            ed.WriteMessage($"\nRaw list's count: {entsInfo.Count}");
            
            ////Remove overlap in raw list :
            //List<object> entsInfo2 = entsInfo.Distinct().ToList();

            //ed.WriteMessage($"\nAfter overkill, count: {entsInfo2.Count}");

            #endregion


            #region [Clone hide situations]

            #endregion

            //Print infor:
            //ed.WriteMessage($"\nNumber hides {hideIds.Count}");
        }

        private  void TestGetStruct()
        {
            Document doc = AcadAddin.CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;
            
            //Check current cad is mechanical or not:
            if (!AcadAddin.IsCadMechanical.Status())
            {
                ed.WriteMessage("\nThis command cannot be used for non mechanical cad!");
                return;
            }
            
            //Main process:
            try
            {
                #region [Check drawing contain hide situation]
                //Get acad interface:
                acApp = (AcadApplication)AcAp.AcadApplication;
                
                //Get mechanical interface:
                acMApp = acApp.GetInterfaceObject("AcadmAuto.AcadmApplication");
                
                //Get document interface:
                acDoc = acApp.ActiveDocument;
                
                //Get structures:
                mgr = acMApp.ActiveDocument.StructureMgr2D;

                //Try to get RootView & Hide situations:
                try
                {
                    //Get root definition:
                    rootDef = mgr.RootViewDefinition[acDoc.Database];

                    //Get hide situations:
                    hideSituations = rootDef.HideSituations;
                    if (hideSituations.Count == 0)
                    {
                        ed.WriteMessage("\nThis drawing contains no hide situation!");
                        return;
                    }
                    else
                    {
                        ed.WriteMessage($"\nNumber of hide situation in drawing: {hideSituations.Count}");
                    }
                }
                catch (System.Exception)
                {
                    //ed.WriteMessage("\nCannot get 'RootView'!");
                    ed.WriteMessage("\nThis drawing contains no hide situation!");
                    //ed.WriteMessage(ex.Message);
                    return;
                }
                #endregion

                //Get selection set:
                PromptSelectionResult psr = ed.GetSelection();
                if (psr.Status != PromptStatus.OK)
                {
                    return;
                }

                //Start main transaction:
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Iterate selection set:
                    foreach (SelectedObject sObj in psr.Value)
                    {
                        if (sObj != null)
                        {
                            //Get .Net entity (read mode)
                            Entity ent = tr.GetObject(sObj.ObjectId, OpenMode.ForRead) as Entity;

                            //Get com entity:
                            AXDBLib.AcadEntity comEnt = (AXDBLib.AcadEntity)ent.AcadObject;

                            //Check selected entity has hide situation or not:
                            if (HasHideSituation(comEnt))
                            {
                                ed.WriteMessage($"\nEntity {ent.ObjectId} has hide situation.");
                                IMcadFolder mFolder = mgr.GetStructureFromEntity(comEnt);


                                rootDef.FindHideSituations(mFolder, out hideSituations, out object referredToAs);
                                if (hideSituations.Count > 0 )
                                {
                                    //ed.WriteMessage($"\nHide situations: {hideSituations.Count}");
                                    foreach (McadHideSituation hideSituation in hideSituations)
                                    {
                                        McadFolderDefinition fdrDef = hideSituation.Definition;
                                        ed.WriteMessage($"\nFolder name: {fdrDef.Name}");
                                        //ed.WriteMessage($"\nSelected entity's level index:{hideSituation.LevelIndex}");
                                        //ed.WriteMessage($"\nSelected entity's last level:{hideSituation.IsLastLevel}");
                                    }
                                }

                                //AXDBLib.AcadEntity comEntClone = comEnt.Copy();
                                //double[] startPnt = { 0.0, 0.0, 0.0 };
                                //double[] endPnt = { 200.0, 150.0, 0.0 };
                                //comEntClone.Move(startPnt, endPnt);
                                //IMcadFolder mFolderClone =  mFolder.Copy();

                                //McadFolderDefinition fdrDef = mFolder.Definition;
                                //ed.WriteMessage($"\nFolder name: {fdrDef.Name}");
                                //ed.WriteMessage($"\nFolder full name: {fdrDef.Name}");
                                //ed.WriteMessage($"\nChildren's count: {fdrDef.ChildrenCount}");
                                //rootDef.FindHideSituations(mFolder, out hideSituations,out object referredToAs);
                            }
                            else
                            {
                                ed.WriteMessage($"\nEntity {ent.ObjectId} doesn't have hide situation.");
                            }
                        }
                    }

                    //Commit changes:
                    tr.Commit();
                }

            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }

            #region [Old codes]
            //try
            //{
            //    ed.WriteMessage($"\nNumver of hide situation: {hideSituations.Count}");
            //    if (hideSituations.Count > 0)
            //    {
            //        foreach (McadHideSituation hideSituation in hideSituations)
            //        {

            //        }
            //    }

            //    //acDoc.Utility.GetEntity(out object ent, out object pt);
            //    //myStruct = mgr.GetStructureFromEntity((AXDBLib.AcadEntity)ent);
            //    //ed.WriteMessage(myStruct.ViewName);

            //}
            //catch (System.Exception ex)
            //{
            //    ed.WriteMessage(ex.ToString());
            //    return;
            //}

            //if (myStruct.ViewName != "")
            //{
            //    ed.WriteMessage($"\nEntity belong to structure. View name {myStruct.ViewName}");
            //}
            //else
            //{
            //    ed.WriteMessage("\nEntity is free.");
            //}
            #endregion
        }

        //Method to check entity has hide situation:
        private bool HasHideSituation(AXDBLib.AcadEntity comEnt)
        {
            //IMcadFolder mFolder = mgr.GetStructureFromEntity(comEnt);

            //rootDef.FindHideSituations(mFolder, out hideSituations,out object referredToAs);

            return !mgr.IsFreeEntity(comEnt);
        }

        private bool HasHideSituation(ObjectId objId , IMcad2DStructureMgr mgr  ,AcadDocument acDoc)
        {
            AXDBLib.AcadEntity comEnt = acDoc.ObjectIdToObject((long)objId.OldIdPtr);
            return !mgr.IsFreeEntity(comEnt);
        }
    }
}

namespace AcadAddin.OverrudeCmd
{
    //https://www.keanw.com/2009/08/a-simple-overrule-to-change-the-way-autocad-lines-are-displayed-using-net.html?fbclid=IwAR0k5TC2MKAEjcOV6wcqvs3KSoXdCh7PuL5xEYW92QbkMIof2CUWbqGRHuA
    public class MyDrawOverrule : DrawableOverrule
    {
        public override bool WorldDraw(Drawable drawable, WorldDraw wd)
        {
            // Cast Drawable to Line so we can access its methods and
            // properties
            Line ln = (Line)drawable;

            // Draw some graphics primitives
            wd.Geometry.Circle(ln.StartPoint + 0.5 * ln.Delta,
                               ln.Length / 5, ln.Normal);

            // In this case we don't want the line to draw itself, nor do
            // we want ViewportDraw called
            return true;
        }
    }

    public class Commands
    {
        // Shared member variable to store our Overrule instance
        private static MyDrawOverrule _drawOverrule;

        [CommandMethod("TestOverLine")]
        public static void ToggleOverrule()
        {
            // Initialize Overrule if first time run
            if (_drawOverrule == null)
            {
                // Turn Overruling on
                _drawOverrule = new MyDrawOverrule();
                Overrule.AddOverrule(RXObject.GetClass(typeof(Line)),
                                        _drawOverrule , false);
                Overrule.Overruling = true;
            }
            else
            {
                // Turn Overruling off
                Overrule.RemoveOverrule(RXObject.GetClass(typeof(Line)), _drawOverrule);
                _drawOverrule.Dispose();
                _drawOverrule = null;
            }

            // Regen is required to update changes on screen
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            ed.Regen();
        }
    }

    namespace SelectionHighlightOverrule
    {
        public class HighlightDrawableOverrule : DrawableOverrule
        {
            private int _foreColorIndex;
            private int _backColorIndex;
            private bool _origialOverruling = false;
            private List<ObjectId> _highlightEnts;
            private bool _started = false;

            public HighlightDrawableOverrule(int foreColor, int backColor)
            {
                _foreColorIndex = foreColor;
                _backColorIndex = backColor;
                _highlightEnts = new List<ObjectId>();
            }

            public bool Started
            {
                get { return _started; }
            }

            public ObjectId[] SelectedEntIds
            {
                get { return _highlightEnts.ToArray(); }
            }

            public HighlightDrawableOverrule(int foreColor,
                int backColor, ObjectId[] entIds) : this(foreColor, backColor)
            {
                _highlightEnts.AddRange(entIds);
            }

            public void Start()
            {
                _origialOverruling = DrawableOverrule.Overruling;

                DrawableOverrule.AddOverrule(
                    RXClass.GetClass(typeof(Entity)), this, true);
                DrawableOverrule.Overruling = true;
                _started = true;

                Regen();
            }

            public void Stop()
            {
                DrawableOverrule.RemoveOverrule(
                    RXClass.GetClass(typeof(Entity)), this);
                DrawableOverrule.Overruling = _origialOverruling;
                _started = false;

                Regen();
            }

            public void AddHightlightEntities(ObjectId[] entIds)
            {
                bool added = false;
                foreach (var id in entIds)
                {
                    if (!_highlightEnts.Contains(id))
                    {
                        _highlightEnts.Add(id);
                        if (!added) added = true;
                    }
                }

                if (_started && added) Regen();
            }

            public void RemoveHighlightEntities(ObjectId[] entIds)
            {
                bool removed = false;
                foreach (var id in entIds)
                {
                    if (!_highlightEnts.Contains(id))
                    {
                        _highlightEnts.Remove(id);
                        if (!removed) removed = true;
                    }
                }

                if (_started && removed) Regen();
            }

            public void ClearHightlightEntities()
            {
                _highlightEnts.Clear();
                if (_started) Regen();
            }

            public override bool WorldDraw(Drawable drawable, WorldDraw wd)
            {
                wd.SubEntityTraits.Color = (short)_backColorIndex;

                if (_highlightEnts.Count > 0)
                {
                    Entity ent = drawable as Entity;
                    if (ent != null)
                    {
                        if (_highlightEnts.Contains(ent.ObjectId))
                            wd.SubEntityTraits.Color = (short)_foreColorIndex;
                    }
                }

                return base.WorldDraw(drawable, wd);
            }

            private void Regen()
            {
                Application.DocumentManager.MdiActiveDocument.Editor.Regen();
            }
        }

        public class Commands
        {
            [CommandMethod("HighlightSel")]
            public static void HighlightedSelection()
            {
                Document dwg = Application.DocumentManager.MdiActiveDocument;
                Editor ed = dwg.Editor;

                int foreColor = 2;  //Yellow
                int backColor = 7;  //White

                ObjectId[] selectedIds = null;

                using (HighlightDrawableOverrule hOverrule =
                    new HighlightDrawableOverrule(foreColor, backColor))
                {
                    hOverrule.Start();
                    while (true)
                    {
                        PromptEntityOptions opt =
                            new PromptEntityOptions("\nPlease pick an entity:");
                        PromptEntityResult res = ed.GetEntity(opt);
                        if (res.Status == PromptStatus.OK)
                        {
                            hOverrule.AddHightlightEntities(
                                new ObjectId[] { res.ObjectId });
                        }
                        else
                        {
                            break;
                        }
                    }

                    hOverrule.Stop();
                    selectedIds = hOverrule.SelectedEntIds;
                }

                ed.WriteMessage("\n{0} entitit{1} selected.",
                    selectedIds.Length, selectedIds.Length > 1 ? "ies" : "y");
            }
        }
    }
}

namespace AcadAddin.PractiseCmd
{
    //https://stackoverflow.com/questions/10874481/shortest-route-between-multiple-points
    public class Commands
    {
        #region [Sample for change dimstyle's property]
        //[CommandMethod("TestC970")]
        //public void CmdTestC970()
        //{
        //    Document doc = CommonCommands.doc();
        //    Editor ed = doc.Editor;
        //    Database db = doc.Database;

        //    using(Transaction tr = db.TransactionManager.StartTransaction())
        //    {
        //        DimStyleTable dimTb = tr.GetObject(db.DimStyleTableId, OpenMode.ForRead) as DimStyleTable;

        //        string dimStyleName = "NLM_VN";

        //        if (!dimTb.Has(dimStyleName))
        //        {
        //            ed.WriteMessage($"\n'{dimStyleName}' dimstyle is not founded !");
        //            tr.Abort();
        //            return;
        //        }

        //        DimStyleTableRecord dimTbRc = tr.GetObject(dimTb[dimStyleName], OpenMode.ForRead) as DimStyleTableRecord;

        //        PromptDoubleOptions pdo = new PromptDoubleOptions("\nNew dimscale : ");
        //        pdo.AllowArbitraryInput = false;
        //        pdo.AllowNone = false;
        //        pdo.AllowNegative = false;
        //        pdo.AllowZero = false;
        //        pdo.DefaultValue = dimTbRc.Dimscale;

        //        PromptDoubleResult pdr = ed.GetDouble(pdo);
        //        if (pdr.Status != PromptStatus.OK)
        //        {
        //            ed.WriteMessage("\nCannot get new dimscale !");
        //            tr.Abort();
        //            return;
        //        }

        //        if (pdr.Value.Equals(dimTbRc.Dimscale))
        //        {
        //            //ed.WriteMessage("\nNo need to change dimscale !");
        //            tr.Abort();
        //            return;
        //        }

        //        KeyValuePair<double, double> scLtsStandard = new KeyValuePair<double, double>(1.0, 5.0);
        //        double newDimSc = pdr.Value;
        //        double newLts = newDimSc * scLtsStandard.Value / scLtsStandard.Key;

        //        dimTbRc.UpgradeOpen();
        //        dimTbRc.Dimscale = newDimSc;


        //        AcAp.SetSystemVariable("LTSCALE", newLts);

        //        tr.Commit();
        //    }
        //}
        #endregion

        [CommandMethod("PrintAllLayout")]
        public void TestPrintAllLayout()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            //Get limit points of database:
            Point3d dbMaxPnt = db.Extmax;
            Point3d dbMinPnt = db.Extmin;

            //Print out limit points:
            ed.WriteMessage($"\nDatbase's max pnt: {dbMaxPnt.X},{dbMaxPnt.Y},{dbMaxPnt.Z}.");
            ed.WriteMessage($"\nDatbase's min pnt: {dbMinPnt.X},{dbMinPnt.Y},{dbMinPnt.Z}");

            // Get the layout dictionary of the current database
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                DBDictionary lays = tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead) as DBDictionary;

                #region [Sample - 1]
                //doc.Editor.WriteMessage("\nLayouts:");

                //// Step through and list each named layout and Model
                //foreach (DBDictionaryEntry item in lays)
                //{
                //    doc.Editor.WriteMessage("\n  " + item.Key);

                //    Layout lay = tr.GetObject(item.Value, OpenMode.ForRead) as Layout;

                //    ObjectIdCollection vpIds = lay.GetViewports();
                //    int numberOfVps = vpIds.Count;
                //    doc.Editor.WriteMessage($"\nNumber of viewports: {numberOfVps}");

                //    foreach (ObjectId vpId in vpIds)
                //    {
                //        Autodesk.AutoCAD.DatabaseServices.Viewport vp =
                //            tr.GetObject(vpId, OpenMode.ForRead) as Autodesk.AutoCAD.DatabaseServices.Viewport;

                //        doc.Editor.WriteMessage($"\nLayer: {vp.Layer}");
                //    }

                //    doc.Editor.WriteMessage("\n----------------------------------");
                //}
                #endregion

                //Step through layour and print its name:
                foreach (DBDictionaryEntry item in lays)
                {
                    ed.WriteMessage($"\nLayout name: {item.Key}");

                    //Get layout object:
                    Autodesk.AutoCAD.DatabaseServices.Layout lay = tr.GetObject(item.Value, OpenMode.ForRead) as Layout;
                    
                    //Get BlockTableRecord connected to layout:
                    BlockTableRecord layBtr = tr.GetObject(lay.BlockTableRecordId,OpenMode.ForRead) as BlockTableRecord;

                    foreach (var objId in layBtr)
                    {
                        DBObject dbObj = tr.GetObject(objId, OpenMode.ForRead);
                        if (dbObj.GetType() == typeof(Autodesk.AutoCAD.DatabaseServices.Viewport))
                        {
                            //https://forums.autodesk.com/t5/net/viewport-get-entities-from-viewport/td-p/5832707
                            Autodesk.AutoCAD.DatabaseServices.Viewport vpObj = dbObj as Autodesk.AutoCAD.DatabaseServices.Viewport;
                            ed.WriteMessage("\n***");
                        }
                        else
                        {
                            ed.WriteMessage($"\nType: {dbObj.GetType()}");
                        }
                    }

                    ////Count how many items inside BlockTableRecord:
                    //ObjectIdCollection ids = new ObjectIdCollection(layBtr.Cast<ObjectId>().ToArray());
                    //ed.WriteMessage($"\nBlockTableRecord contains: {ids.Count}");
                }

                // Abort the changes to the database
                tr.Abort();
            }
        }

        private void CusTOmEditor_SelectionAdded(object sender, SelectionAddedEventArgs e)
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            //ed.WriteMessage($"\nObject: {sender}");
            //ed.WriteMessage($"\nName: {e.GetType().Name}");

            SelectionSet ss = e.Selection;

            for (int i = ss.Count - 1; i > -1; i--)
            {
                e.Remove(i);
            }

            //using (Transaction tr = db.TransactionManager.StartTransaction())
            //{
            //    for (int i = ss.Count -1 ; i >= 0; i--)
            //    {
            //        if (ss[i] != null)
            //        {
            //            Line line = tr.GetObject(ss[i].ObjectId, OpenMode.ForRead) as Line;
            //            e.Remove(i);

            //            //if (line.ColorIndex != 1)
            //            //{
            //            //    e.Remove(i);
            //            //}
            //        }
            //    }

            //    tr.Commit();
            //}
        }

        //Control selection set with event:
        [CommandMethod("Test240501")]
        public void CmdTest240501()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            ed.SelectionAdded += new SelectionAddedEventHandler(CusTOmEditor_SelectionAdded);

            try
            {
                TypedValue[] typeVals = new TypedValue[1];
                typeVals.SetValue(new TypedValue((int)DxfCode.Start, "LINE"), 0);

                SelectionFilter ssFilter = new SelectionFilter(typeVals);

                PromptSelectionResult psr = ed.GetSelection(ssFilter);
                if (psr.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nFail!");
                    return;
                }
                else
                {
                    ed.WriteMessage($"\nNumber of selected: {psr.Value.Count}");
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage($"\nError: {ex.Message}");
            }
            finally
            {
                ed.SelectionAdded -= new SelectionAddedEventHandler(CusTOmEditor_SelectionAdded);
            }

        }

        //Control autocad window state:
        [CommandMethod("Test231227")]
        public void CmdTest231227()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;

            Autodesk.AutoCAD.Windows.Window myWnd = Autodesk.AutoCAD.ApplicationServices.Application.MainWindow;

            if (myWnd.WindowState != Autodesk.AutoCAD.Windows.Window.State.Minimized)
            {
                myWnd.WindowState = Autodesk.AutoCAD.Windows.Window.State.Minimized;
            }
        }

        [CommandMethod("TestShortPath")]
        public void TestShortestPath()
        {
            Autodesk.AutoCAD.ApplicationServices.Document doc = Autodesk.AutoCAD.ApplicationServices.Application.
                                                                DocumentManager.MdiActiveDocument;

            Autodesk.AutoCAD.EditorInput.Editor ed = doc.Editor;


            PromptPointOptions ppo = new PromptPointOptions("");
            ppo.Message = "\nPick a point: ";
            ppo.AllowArbitraryInput = false;
            ppo.AllowNone = true;

            PromptPointResult ppr;
            System.Collections.Generic.List<Point3d> pointLst = new System.Collections.Generic.List<Point3d>();

            bool isDone = false;
            while (!isDone)
            {
                ppr = ed.GetPoint(ppo);
                if (ppr.Status == PromptStatus.Cancel)
                {
                    return;
                }
                else if(ppr.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get a point!");
                    return;
                }
                else if(ppr.Status == PromptStatus.None)
                {
                    isDone = true;
                }
                else if(ppr.Status == PromptStatus.OK)
                {

                    Point3d pntWcs = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);

                    if (!pointLst.Contains(pntWcs))
                    {
                        pointLst.Add(pntWcs);
                    }
                }
                else
                {
                    ed.WriteMessage("\nUnknown error. Command ended!");
                    return;
                }
            }

            ed.WriteMessage($"\nNumber of picked points: {pointLst.Count}");

            if (pointLst.Count > 1)
            {
                pointLst.Sort((a, b) => a.X.CompareTo(b.X));

                System.Collections.Generic.List<Point3d> shortPoints = new System.Collections.Generic.List<Point3d>();

                for (int i = 0 ; i < pointLst.Count-1; i++)
                {




                }
            }
        }

        [CommandMethod("Test230916_2")]
        public void CmdTest230916_2()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            PromptEntityOptions peo = new PromptEntityOptions("");

            System.Type allowedType = typeof(Autodesk.AutoCAD.DatabaseServices.Curve);
            peo.Message = "\nSelect " + allowedType.Name + ": ";
            peo.SetRejectMessage($"\nSelect {allowedType.Name} only!");
            peo.AddAllowedClass(allowedType, false);
            peo.AllowNone = false;
            peo.AllowObjectOnLockedLayer = false;
            
            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK)
            {
                ed.WriteMessage($"\nCannot get {allowedType.Name}!");
                return;
            }
            else
            {
                ed.WriteMessage($"\nC++'s class name: {per.ObjectId.ObjectClass.Name}");

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    Curve curv = tr.GetObject(per.ObjectId, OpenMode.ForWrite) as Curve;

                    BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                    List<double> offDists = new List<double>()
                        {
                            15.0 , -15.0
                        };

                    for (int i = 0; i < offDists.Count; i++)
                    {
                        using (DBObjectCollection dbObjs = curv.GetOffsetCurves(offDists[i] / 2.0))
                        {
                            foreach (Curve item in dbObjs)
                            {
                                btr.AppendEntity(item);
                                tr.AddNewlyCreatedDBObject(item, true);
                            }
                        }
                    }
                    tr.Commit();
                }
            }
        }

        [CommandMethod("Test230916_1")]
        public void CmdTest230916_1()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;

            Database db = doc.Database;

            Editor ed = doc.Editor;

            PromptEntityResult per = ed.GetEntity("\nSelect:");
            if (per.Status != PromptStatus.OK)
            {
                return;
            }

            try
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    Entity ent = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Entity;

                    if (ent is MText mTxt && mTxt.HasFields)
                    {
                        ObjectId fldsId = mTxt.GetField();

                        if (fldsId != ObjectId.Null)
                        {
                            Field flds = tr.GetObject(fldsId, OpenMode.ForWrite) as Field;
                            flds.Evaluate();
                            ed.WriteMessage("\nAll done!");
                        }

                        tr.Commit();
                    }
                    else
                    {
                        ed.WriteMessage("\nNot valid!");
                        tr.Abort();
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage($"\nError: {ex.Message}");
                return;
            }
        }

        //Test command to check 2 curves intersect?
        [CommandMethod("TestDJ")]
        public void CmdTestDisjoint()
        {
            Document doc = AcadAddin.CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptEntityOptions peo = new PromptEntityOptions("")
            {
                AllowNone = false
            };
            peo.SetRejectMessage("\nInvalid selection!");
            peo.AddAllowedClass(typeof(Curve), false);

            peo.Message = "\nSelect 1:";
            PromptEntityResult per1 = ed.GetEntity(peo);
            if (per1.Status != PromptStatus.OK)
            {
                return;
            }

            peo.Message = "\nSelect 2:";
            PromptEntityResult per2 = ed.GetEntity(peo);
            if (per2.Status != PromptStatus.OK)
            {
                return;
            }

            PromptPointResult ppr = ed.GetPoint("\nTest point");
            if (ppr.Status != PromptStatus.OK)
            {
                return;
            }

            Point3d testPnt = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                Curve curv1 = tr.GetObject(per1.ObjectId, OpenMode.ForRead) as Curve;
                Curve curv2 = tr.GetObject(per2.ObjectId, OpenMode.ForRead) as Curve;

                using (Curve3d geoCurv1 = curv1.GetGeCurve())
                using (Curve3d geoCurv2 = curv2.GetGeCurve())
                using (BoundBlock3d bndBlk1 = geoCurv1.BoundBlock)
                using (BoundBlock3d bndBlk2 = geoCurv2.BoundBlock)
                {
                    if (bndBlk1.IsDisjoint(bndBlk2))
                    {
                        ed.WriteMessage("\nCurves don't intersect!");
                    }
                    else
                    {
                        ed.WriteMessage("\nCurves intersect");
                    }

                    ed.WriteMessage($"\nPoint is on Curve 1 : {bndBlk1.IsOn(testPnt)}");
                    ed.WriteMessage($"\nPoint is on Curve 2 : {bndBlk2.IsOn(testPnt)}");

                    //ed.WriteMessage($"\nIs disjointed {bndBlk1.IsDisjoint(bndBlk2)}");
                }

                tr.Commit();
            }
        }

        //Lệnh in ra hello trên màn hình:
        [CommandMethod("Hello")]
        public void CmdHello()
        {
            AcAp.ShowAlertDialog("hello autocad from C#");
        }

        //Lệnh change color for nested entity:
        [CommandMethod("ChangeColorNestedEntity")]
        public void ChangeColorNestedEntity_Method()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            try
            {
                PromptNestedEntityOptions nestedEntOpt = new PromptNestedEntityOptions("\nPick a nested entity:");
                PromptNestedEntityResult nestedEntRes = ed.GetNestedEntity(nestedEntOpt);

                if (nestedEntRes.Status == PromptStatus.OK)
                {
                    PromptIntegerOptions promptOpt = new PromptIntegerOptions("\nInput the new color index (0-255):");
                    PromptIntegerResult promptRes = ed.GetInteger(promptOpt);
                    using (Transaction tr = db.TransactionManager.StartTransaction())
                    {
                        Entity ent = tr.GetObject(nestedEntRes.ObjectId, OpenMode.ForWrite) as Entity;
                        ent.ColorIndex = promptRes.Value;

                        tr.Commit();
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.ToString());
            }
        }

        //Sample to draw line without using transaction :
        [CommandMethod("drawline")]
        public void Cmddrawline()
        {
            Database db = CommonCommands.db();
            using (BlockTableRecord btr = (BlockTableRecord)db.CurrentSpaceId.
                GetObject(OpenMode.ForWrite))
            {
                using (Line lineObj = new Line())
                {
                    lineObj.StartPoint = new Point3d(0.0, 0.0, 0.0);
                    lineObj.EndPoint = new Point3d(100.0, 45.0, 0.0);
                    btr.AppendEntity(lineObj);
                }
            }
        }

        //Lệnh vẽ Circle:
        [CommandMethod("drawcir")]
        public void Cmddrawcir()
        {
            var doc = AcAp.DocumentManager.MdiActiveDocument;
            //var ed = doc.Editor;
            var db = doc.Database;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable blt;
                blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord bltr;
                bltr = tr.GetObject(blt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                using (Circle accir = new Circle())
                {
                    accir.Center = new Point3d(2, 3, 0);
                    accir.Radius = 25;
                    bltr.AppendEntity(accir);
                    tr.AddNewlyCreatedDBObject(accir, true);
                }
                tr.Commit();
            }
        }

        //Lệnh tạo bản vẽ mới:
        [CommandMethod("NewDrawing", CommandFlags.Session)]
        public void NewDrawing()
        {
            // Specify the template to use, if the template is not found
            // the default settings are used.
            string strTemplatePath = "BARAZU_TEMPLATE.dwt";

            DocumentCollection acDocMgr = Application.DocumentManager;
            Document acDoc = acDocMgr.Add(strTemplatePath);

            acDocMgr.MdiActiveDocument = acDoc;
        }

        //Lệnh ví dụ cho nested transaction:
        [CommandMethod("NestedTransactions")]
        public void NestedTransactions()
        {
            // Get the current document and database
            Document acDoc = Application.DocumentManager.MdiActiveDocument;
            Database acCurDb = acDoc.Database;

            // Create a reference to the Transaction Manager
            Autodesk.AutoCAD.DatabaseServices.TransactionManager acTransMgr;
            acTransMgr = acCurDb.TransactionManager;

            // Create a new transaction
            using (Transaction acTrans1 = acTransMgr.StartTransaction())
            {
                // Print the current number of active transactions
                acDoc.Editor.WriteMessage("\nNumber of transactions active: " +
                                            acTransMgr.NumberOfActiveTransactions.ToString());

                // Open the Block table for read
                BlockTable acBlkTbl;
                acBlkTbl = acTrans1.GetObject(acCurDb.BlockTableId,
                                                OpenMode.ForRead) as BlockTable;

                // Open the Block table record Model space for write
                BlockTableRecord acBlkTblRec;
                acBlkTblRec = acTrans1.GetObject(acBlkTbl[BlockTableRecord.ModelSpace],
                                                    OpenMode.ForWrite) as BlockTableRecord;

                // Create a circle with a radius of 3 at 5,5
                using (Circle acCirc = new Circle())
                {
                    acCirc.Center = new Point3d(5, 5, 0);
                    acCirc.Radius = 3;

                    // Add the new object to Model space and the transaction
                    acBlkTblRec.AppendEntity(acCirc);
                    acTrans1.AddNewlyCreatedDBObject(acCirc, true);

                    // Create the second transaction
                    using (Transaction acTrans2 = acTransMgr.StartTransaction())
                    {
                        acDoc.Editor.WriteMessage("\nNumber of transactions active: " +
                                                    acTransMgr.NumberOfActiveTransactions.ToString());

                        // Change the circle's color
                        acCirc.ColorIndex = 5;

                        // Get the object that was added to Transaction 1 and set it to the color 5
                        using (Line acLine = new Line(new Point3d(2, 5, 0), new Point3d(10, 7, 0)))
                        {
                            acLine.ColorIndex = 3;

                            // Add the new object to Model space and the transaction
                            acBlkTblRec.AppendEntity(acLine);
                            acTrans2.AddNewlyCreatedDBObject(acLine, true);
                        }

                        // Create the third transaction
                        using (Transaction acTrans3 = acTransMgr.StartTransaction())
                        {
                            acDoc.Editor.WriteMessage("\nNumber of transactions active: " +
                                                        acTransMgr.NumberOfActiveTransactions.ToString());

                            // Change the circle's color
                            acCirc.ColorIndex = 3;

                            // Update the display of the drawing
                            acDoc.Editor.WriteMessage("\n");
                            acDoc.Editor.Regen();

                            // Request to keep or discard the changes in the third transaction
                            PromptKeywordOptions pKeyOpts = new PromptKeywordOptions("")
                            {
                                Message = "\nKeep color change "
                            };
                            pKeyOpts.Keywords.Add("Yes");
                            pKeyOpts.Keywords.Add("No");
                            pKeyOpts.Keywords.Default = "No";
                            pKeyOpts.AllowNone = true;

                            PromptResult pKeyRes = acDoc.Editor.GetKeywords(pKeyOpts);

                            if (pKeyRes.StringResult == "No")
                            {
                                // Discard the changes in transaction 3
                                acTrans3.Abort();
                            }
                            else
                            {
                                // Save the changes in transaction 3
                                acTrans3.Commit();
                            }

                            // Dispose the transaction
                        }

                        acDoc.Editor.WriteMessage("\nNumber of transactions active: " +
                                                    acTransMgr.NumberOfActiveTransactions.ToString());

                        // Keep the changes to transaction 2
                        acTrans2.Commit();
                    }
                }

                acDoc.Editor.WriteMessage("\nNumber of transactions active: " +
                                            acTransMgr.NumberOfActiveTransactions.ToString());

                // Keep the changes to transaction 1
                acTrans1.Commit();
            }
        }

        //gọi test form
        [CommandMethod("testform")]
        public void Testform()
        {
            testform fr = new testform();
            Application.ShowModelessDialog(fr);
        }
    }
}

namespace AcadAddin.LayerCmd
{
    public class Commands
    {
        #region[Nhóm lệnh về Layer]
        // Đưa layer hiện hành về layer '1'
        [CommandMethod("1")]
        public void Cmd1()
        {
            //// Get the current value from a system variable
            //int nMaxSort = System.Convert.ToInt32(Application.GetSystemVariable("MAXSORT"));

            // Set system variable to new value
            SetSystemVariable("CLAYER", "1");
        }

        // Đưa layer hiện hành về layer 'HIDDEN'
        [CommandMethod("2")]
        public void CmdHIDDEN()
        {
            // Set system variable to new value
            SetSystemVariable("CLAYER", "HIDDEN");
        }

        // Đưa layer hiện hành về layer 'CENTER'
        [CommandMethod("3")]
        public void CmdCENTER()
        {
            // Set system variable to new value
            Application.SetSystemVariable("CLAYER", "CENTER");
        }

        // Đưa layer hiện hành về layer 'SCALE'
        [CommandMethod("4")]
        public void CmdSCALE()
        {
            // Set system variable to new value
            Application.SetSystemVariable("CLAYER", "SCALE");
        }

        // Đưa layer hiện hành về layer 'TEXT'
        [CommandMethod("5")]
        public void CmdTEXT()
        {
            // Set system variable to new value
            Application.SetSystemVariable("CLAYER", "TEXT");
        }
        #endregion

        //Tắt layer SCALE, TEXT
        [CommandMethod("TL")]
        public void CmdTL()
        {
            System.Collections.Generic.List<string> layNameLst = new System.Collections.Generic.List<string>();
            layNameLst.Add(KRCADLayer.LayerScale.Item1);
            layNameLst.Add(KRCADLayer.LayerText.Item1);

            for (int i = 0; i < layNameLst.Count; i++)
            {
                TurnOnOffLayer(layNameLst[i], false);
            }
        }

        //Mở layer SCALE, TEXT
        [CommandMethod("ML")]
        public void CmdML()
        {
            System.Collections.Generic.List<string> layNameLst = new System.Collections.Generic.List<string>();
            layNameLst.Add(KRCADLayer.LayerScale.Item1);
            layNameLst.Add(KRCADLayer.LayerText.Item1);

            for (int i = 0; i < layNameLst.Count; i++)
            {
                TurnOnOffLayer(layNameLst[i], true);
            }
        }

        //Tắt layer SCALE, TEXT
        [CommandMethod("TLJ")]
        public void CmdTLJ()
        {
            TurnOnOffLayer(KRCADLayer.LayerJsAno.Item1, false);
        }

        //Mở layer SCALE, TEXT
        [CommandMethod("MLJ")]
        public void CmdMLJ()
        {
            TurnOnOffLayer(KRCADLayer.LayerJsAno.Item1, true);
        }

        private void TurnOnOffLayer(string layName, bool turnOn = true)
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                LayerTable layTb = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;

                if (!layTb.Has(layName))
                {
                    tr.Commit();
                    return;
                }

                LayerTableRecord layTbRc = tr.GetObject(layTb[layName],OpenMode.ForWrite) as LayerTableRecord;
                if (turnOn)
                {
                    if (layTbRc.IsOff)
                    {
                        layTbRc.IsOff = false;
                    }
                }
                else
                {
                    if (!layTbRc.IsOff)
                    {
                        layTbRc.IsOff = true;
                    }
                }

                tr.Commit();
            }
        }

        [Obsolete("Use 'TurnOnOffLayer' instead!")]
        public void CmdTL_Old()
        {
            using (Transaction tr = CommonCommands.db().TransactionManager.StartTransaction())
            {
                LayerTable lat = tr.GetObject(CommonCommands.db().LayerTableId, OpenMode.ForRead) as LayerTable;
                string laykt = "SCALE";
                if (lat.Has(laykt) == false)
                {
                    using (LayerTableRecord latr = new LayerTableRecord())
                    {
                        latr.Name = laykt;
                        latr.IsOff = true;
                        tr.GetObject(CommonCommands.db().LayerTableId, OpenMode.ForWrite);
                        lat.Add(latr);
                        tr.AddNewlyCreatedDBObject(latr, true);
                    }
                }
                else
                {
                    LayerTableRecord latr = tr.GetObject(lat[laykt], OpenMode.ForWrite) as LayerTableRecord;
                    latr.IsOff = true;
                }
                tr.Commit();
            }

            using (Transaction tr = CommonCommands.db().TransactionManager.StartTransaction())
            {
                LayerTable lat = tr.GetObject(CommonCommands.db().LayerTableId, OpenMode.ForRead) as LayerTable;
                string laykt = "TEXT";
                if (lat.Has(laykt) == false)
                {
                    using (LayerTableRecord latr = new LayerTableRecord())
                    {
                        latr.Name = laykt;
                        latr.IsOff = true;
                        tr.GetObject(CommonCommands.db().LayerTableId, OpenMode.ForWrite);
                        lat.Add(latr);
                        tr.AddNewlyCreatedDBObject(latr, true);
                    }
                }
                else
                {
                    LayerTableRecord latr = tr.GetObject(lat[laykt], OpenMode.ForWrite) as LayerTableRecord;
                    latr.IsOff = true;
                }
                tr.Commit();
            }
        }

        [Obsolete("Use 'TurnOnOffLayer' instead!")]
        public void CmdML_Old()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                LayerTable lat = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                string laykt = "SCALE";
                if (lat.Has(laykt) == false)
                {
                    using (LayerTableRecord latr = new LayerTableRecord())
                    {
                        latr.Name = laykt;
                        latr.IsOff = false;
                        tr.GetObject(db.LayerTableId, OpenMode.ForWrite);
                        lat.Add(latr);
                        tr.AddNewlyCreatedDBObject(latr, true);
                    }
                }
                else
                {
                    LayerTableRecord latr = tr.GetObject(lat[laykt], OpenMode.ForWrite) as LayerTableRecord;
                    latr.IsOff = false;
                }

                tr.Commit();
            }

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                LayerTable lat = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                string laykt = "TEXT";
                if (lat.Has(laykt) == false)
                {
                    using (LayerTableRecord latr = new LayerTableRecord())
                    {
                        latr.Name = laykt;
                        latr.IsOff = false;
                        tr.GetObject(db.LayerTableId, OpenMode.ForWrite);
                        lat.Add(latr);
                        tr.AddNewlyCreatedDBObject(latr, true);
                    }
                }
                else
                {
                    LayerTableRecord latr = tr.GetObject(lat[laykt], OpenMode.ForWrite) as LayerTableRecord;
                    latr.IsOff = false;
                }

                tr.Commit();
            }
        }
    }
}

namespace AcadAddin.GeneralCmd
{
    public class Commands
    {
        #region [Command to convert Region to polyline]
        //https://through-the-interface.typepad.com/through_the_interface/2008/08/creating-a-seri.html
        [CommandMethod("R2P")]
        public void RegionToPolyline()
        {
            Autodesk.AutoCAD.ApplicationServices.Document doc = Autodesk.AutoCAD.ApplicationServices.
                                                                Application.DocumentManager.MdiActiveDocument;
            Autodesk.AutoCAD.DatabaseServices.Database db = doc.Database;
            Autodesk.AutoCAD.EditorInput.Editor ed = doc.Editor;

            //Prompt selection option:
            PromptSelectionOptions pso = new PromptSelectionOptions();
            pso.RejectObjectsOnLockedLayers = true;
            pso.MessageForAdding = "\nSelect regions to convert to polylines: ";
            pso.MessageForRemoval = "\nSelect regions to remove: ";

            // Create a TypedValue array to define the filter criteria
            //https://www.theswamp.org/index.php?topic=31864.0
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "REGION"), 0);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK ||
                acSSPrompt.Value == null || acSSPrompt.Value.Count == 0)
            {
                ed.WriteMessage("\nYou select nothing!");
                return;
            }

            //Main transaction:
            using (Transaction tr = doc.TransactionManager.StartTransaction())
            {
                Autodesk.AutoCAD.DatabaseServices.BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead)
                    as Autodesk.AutoCAD.DatabaseServices.BlockTable;
                Autodesk.AutoCAD.DatabaseServices.BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForRead)
                    as Autodesk.AutoCAD.DatabaseServices.BlockTableRecord;

                //Iterate SelectionSet and try to convert region to polyline:
                foreach (SelectedObject sObj in acSSPrompt.Value)
                {
                    if (sObj != null)
                    {
                        Autodesk.AutoCAD.DatabaseServices.Region reg = tr.GetObject(sObj.ObjectId, OpenMode.ForRead) 
                            as Autodesk.AutoCAD.DatabaseServices.Region;
                        if (reg != null)
                        {
                            Autodesk.AutoCAD.DatabaseServices.DBObjectCollection objs = PolylineFromRegion(reg);
                            if (objs.Count == 0)
                            {
                                continue;
                            }
                            else
                            {
                                // Append our new entities to the database
                                btr.UpgradeOpen();
                                foreach (Autodesk.AutoCAD.DatabaseServices.Entity ent in objs)
                                {
                                    btr.AppendEntity(ent);
                                    tr.AddNewlyCreatedDBObject(ent, true);
                                }
                                btr.DowngradeOpen();

                                // Finally we erase the original region
                                reg.UpgradeOpen();
                                reg.Erase();
                            }
                        }
                    }
                }

                //Commit changes:
                tr.Commit();
            }
        }

        [Obsolete("This method doesn't support selection of multiple regions.")]
        public void RegionToPolyline_Old()
        {
            Autodesk.AutoCAD.ApplicationServices.Document doc = Application.DocumentManager.MdiActiveDocument;
            Autodesk.AutoCAD.DatabaseServices.Database db = doc.Database;
            Autodesk.AutoCAD.EditorInput.Editor ed = doc.Editor;

            PromptEntityOptions peo = new PromptEntityOptions("\nSelect a region:");
            peo.SetRejectMessage("\nMust be a region.");
            peo.AddAllowedClass(typeof(Region), true);

            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK)
                return;
            using (Transaction tr = doc.TransactionManager.StartTransaction())
            {
                BlockTable bt =(BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);
                Region reg = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Region;
                if (reg != null)
                {
                    DBObjectCollection objs = PolylineFromRegion(reg);

                    // Append our new entities to the database
                    btr.UpgradeOpen();
                    foreach (Entity ent in objs)
                    {
                        btr.AppendEntity(ent);
                        tr.AddNewlyCreatedDBObject(ent, true);
                    }

                    // Finally we erase the original region
                    reg.UpgradeOpen();
                    reg.Erase();
                }

                tr.Commit();
            }
        }

        //Helper method to get polyline from region:
        private static DBObjectCollection PolylineFromRegion(Autodesk.AutoCAD.DatabaseServices.Region reg)
        {
            // We will return a collection of entities
            // which should include closed Polylines and
            // other closed curves, such as Circles.
            Autodesk.AutoCAD.DatabaseServices.DBObjectCollection res = new
                Autodesk.AutoCAD.DatabaseServices.DBObjectCollection();

            // Explode Region -> collection of Curves / Regions
            Autodesk.AutoCAD.DatabaseServices.DBObjectCollection cvs = new
                Autodesk.AutoCAD.DatabaseServices.DBObjectCollection();
            reg.Explode(cvs);

            // Create a plane to convert 3D coords
            // into Region coord system
            Autodesk.AutoCAD.Geometry.Plane pl = new 
                Autodesk.AutoCAD.Geometry.Plane(new Autodesk.AutoCAD.Geometry.Point3d(0, 0, 0), reg.Normal);

            using (pl)
            {
                bool finished = false;
                while (!finished && cvs.Count > 0)
                {
                    // Count the Curves and the non-Curves, and find
                    // the index of the first Curve in the collection
                    int cvCnt = 0, nonCvCnt = 0, fstCvIdx = -1;
                    for (int i = 0; i < cvs.Count; i++)
                    {
                        Autodesk.AutoCAD.DatabaseServices.Curve tmpCv = cvs[i] as 
                            Autodesk.AutoCAD.DatabaseServices.Curve;
                        if (tmpCv == null)
                            nonCvCnt++;
                        else
                        {
                            // Closed curves can go straight into the
                            // results collection, and aren't added
                            // to the Curve count
                            if (tmpCv.Closed)
                            {
                                res.Add(tmpCv);
                                cvs.Remove(tmpCv);

                                // Decrement, so we don't miss an item
                                i--;
                            }
                            else
                            {
                                cvCnt++;
                                if (fstCvIdx == -1)
                                    fstCvIdx = i;
                            }
                        }
                    }

                    if (fstCvIdx >= 0)
                    {
                        // For the initial segment take the first
                        // Curve in the collection
                        Autodesk.AutoCAD.DatabaseServices.Curve fstCv = 
                            (Autodesk.AutoCAD.DatabaseServices.Curve)cvs[fstCvIdx];

                        // The resulting Polyline
                        Autodesk.AutoCAD.DatabaseServices.Polyline p = new 
                            Autodesk.AutoCAD.DatabaseServices.Polyline();

                        // Set common entity properties from the Region
                        p.SetPropertiesFrom(reg);

                        // Add the first two vertices, but only set the
                        // bulge on the first (the second will be set
                        // retroactively from the second segment)
                        // We also assume the first segment is counter-
                        // clockwise (the default for arcs), as we're
                        // not swapping the order of the vertices to
                        // make them fit the Polyline's order

                        p.AddVertexAt(
                            p.NumberOfVertices,
                            fstCv.StartPoint.Convert2d(pl),
                            BulgeFromCurve(fstCv, false), 0, 0
                        );

                        p.AddVertexAt(
                            p.NumberOfVertices,
                            fstCv.EndPoint.Convert2d(pl),
                            0, 0, 0
                        );

                        cvs.Remove(fstCv);

                        // The next point to look for
                        Autodesk.AutoCAD.Geometry.Point3d nextPt = fstCv.EndPoint;

                        // We no longer need the curve
                        fstCv.Dispose();

                        // Find the line that is connected to
                        // the next point
                        // If for some reason the lines returned were not
                        // connected, we could loop endlessly.
                        // So we store the previous curve count and assume
                        // that if this count has not been decreased by
                        // looping completely through the segments once,
                        // then we should not continue to loop.
                        // Hopefully this will never happen, as the curves
                        // should form a closed loop, but anyway...
                        // Set the previous count as artificially high,
                        // so that we loop once, at least.
                        int prevCnt = cvs.Count + 1;
                        while (cvs.Count > nonCvCnt && cvs.Count < prevCnt)
                        {
                            prevCnt = cvs.Count;
                            foreach (Autodesk.AutoCAD.DatabaseServices.DBObject obj in cvs)
                            {
                                Autodesk.AutoCAD.DatabaseServices.Curve cv = obj as 
                                    Autodesk.AutoCAD.DatabaseServices.Curve;
                                if (cv != null)
                                {
                                    Autodesk.AutoCAD.Geometry.Tolerance newTor = new Autodesk.AutoCAD.Geometry.Tolerance
                                        (AcadAddin.CommonCommands.KRTolerance, AcadAddin.CommonCommands.KRTolerance);

                                    //Autodesk.AutoCAD.Geometry.Tolerance newTor = new Autodesk.AutoCAD.Geometry.Tolerance(
                                    //    0.000001, 0.000001);

                                    //Autodesk.AutoCAD.Geometry.Tolerance newTor = new Autodesk.AutoCAD.Geometry.Tolerance(
                                    //    0.00000001, 0.00000001);

                                    // If one end of the curve connects with the
                                    // point we're looking for...
                                    if (cv.StartPoint.IsEqualTo(nextPt,newTor) ||
                                        cv.EndPoint.IsEqualTo(nextPt,newTor))
                                    {
                                        // Calculate the bulge for the curve and
                                        // set it on the previous vertex
                                        double bulge = BulgeFromCurve(cv, cv.EndPoint.IsEqualTo(nextPt, newTor));
                                        if (bulge != 0.0)
                                            p.SetBulgeAt(p.NumberOfVertices - 1, bulge);

                                        // Reverse the points, if needed
                                        if (cv.StartPoint.IsEqualTo(nextPt,newTor))
                                            nextPt = cv.EndPoint;
                                        else
                                            // cv.EndPoint == nextPt
                                            nextPt = cv.StartPoint;

                                        // Add out new vertex (bulge will be set next
                                        // time through, as needed)
                                        p.AddVertexAt(
                                            p.NumberOfVertices,
                                            nextPt.Convert2d(pl),
                                            0, 0, 0
                                        );

                                        // Remove our curve from the list, which
                                        // decrements the count, of course
                                        cvs.Remove(cv);
                                        cv.Dispose();
                                        break;
                                    }
                                }
                            }
                        }

                        // Once we have added all the Polyline's vertices,
                        // transform it to the original region's plane
                        p.TransformBy(Matrix3d.PlaneToWorld(pl));
                        res.Add(p);
                        if (cvs.Count == nonCvCnt)
                            finished = true;
                    }
                    
                    // If there are any Regions in the collection,
                    // recurse to explode and add their geometry
                    if (nonCvCnt > 0 && cvs.Count > 0)
                    {
                        foreach (Autodesk.AutoCAD.DatabaseServices.DBObject obj in cvs)
                        {
                            Autodesk.AutoCAD.DatabaseServices.Region subReg = obj as Autodesk.AutoCAD.DatabaseServices.Region;
                            if (subReg != null)
                            {
                                Autodesk.AutoCAD.DatabaseServices.DBObjectCollection subRes = PolylineFromRegion(subReg);
                                foreach (Autodesk.AutoCAD.DatabaseServices.DBObject o in subRes)
                                    res.Add(o);

                                cvs.Remove(subReg);
                                subReg.Dispose();
                            }
                        }
                    }

                    if (cvs.Count == 0)
                        finished = true;
                }
            }

            return res;
        }

        //Helper method to calculate the bulge for arcs:
        private static double BulgeFromCurve(Autodesk.AutoCAD.DatabaseServices.Curve cv,bool clockwise)
        {
            double bulge = 0.0;

            Autodesk.AutoCAD.DatabaseServices.Arc a = cv as Autodesk.AutoCAD.DatabaseServices.Arc;
            if (a != null)
            {
                double newStart;

                // The start angle is usually greater than the end,
                // as arcs are all counter-clockwise.
                // (If it isn't it's because the arc crosses the
                // 0-degree line, and we can subtract 2PI from the
                // start angle.)
                if (a.StartAngle > a.EndAngle)
                    newStart = a.StartAngle - 8 * System.Math.Atan(1);
                else
                    newStart = a.StartAngle;

                // Bulge is defined as the tan of
                // one fourth of the included angle
                bulge = System.Math.Tan((a.EndAngle - newStart) / 4);

                // If the curve is clockwise, we negate the bulge
                if (clockwise)
                    bulge = -bulge;
            }

            return bulge;
        }
        #endregion

        private static AcadAddin.CommonDialog.SetLangFrm _SetLangFrm = null;

        [CommandMethod("KRLang")]
        public void CmdKRLang()
        {
            if (_SetLangFrm == null)
                _SetLangFrm = new AcadAddin.CommonDialog.SetLangFrm();
            else if (_SetLangFrm.IsDisposed == true)
            {
                //Clear old instance :
                _SetLangFrm = null;

                //Create new instance :
                _SetLangFrm = new AcadAddin.CommonDialog.SetLangFrm();
            }

            try
            {
                //Show/ activate form:
                if (_SetLangFrm.Visible == false)
                {
                    if (AcAp.ShowModalDialog(null, _SetLangFrm, false) == 
                        System.Windows.Forms.DialogResult.Cancel)
                    {
                        _SetLangFrm.Dispose();
                    }
                }
                else
                {
                    _SetLangFrm.Activate();
                }
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(CommonMessage.ERROR_MES(ex.Message),
                    CommonDeclaration.Form_Owner,
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Error);
                _SetLangFrm.Dispose();
                return;
            }
        }

        //Lệnh offset closed boundary:
        [CommandMethod("BOO")]
        public void CmdBOO()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Key words' list:
            System.Collections.Generic.List<string> kwLst = new System.Collections.Generic.List<string>();
            kwLst.Add("Single");
            kwLst.Add("Double");

            PromptKeywordOptions pko = new PromptKeywordOptions("");
            pko.Message = "\nOffset type: ";
            pko.AllowArbitraryInput = false;
            pko.AllowNone = false;
            for (int i = 0; i < kwLst.Count; i++)
            {
                pko.Keywords.Add(kwLst[i]);
            }
            pko.Keywords.Default = kwLst[0];

            //Get keywords:
            PromptResult pr = ed.GetKeywords(pko);
            if (pr.Status == PromptStatus.Error || pr.Status == PromptStatus.None)
            {
                ed.WriteMessage("\nCannot get offset type!");
                return;
            }
            else if(pr.Status == PromptStatus.Cancel)
            {
                return;
            }

            string kwRes = pr.StringResult;

            PromptDoubleOptions pdo = new PromptDoubleOptions("");
            pdo.Message = "\nOffset distance: ";
            pdo.AllowArbitraryInput = false;
            pdo.AllowNone = false;
            pdo.AllowNegative = true;
            pdo.AllowZero = true;

            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status == PromptStatus.Cancel ||
                pdr.Status == PromptStatus.None)
            {
                ed.WriteMessage("\nCannot get offset distance!");
                return;
            }
            else if (pdr.Status == PromptStatus.Cancel)
            {
                return;
            }

            double offDist = pdr.Value;

            //Prompt selection option:
            PromptSelectionOptions pso = new PromptSelectionOptions();
            pso.RejectObjectsOnLockedLayers = true;
            pso.MessageForAdding = "\nSelect closed boundary to add: ";
            pso.MessageForRemoval = "\nSelect closed boundary to remove: ";

            // Create a TypedValue array to define the filter criteria
            //https://www.theswamp.org/index.php?topic=31864.0
            TypedValue[] acTypValAr = new TypedValue[4];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "POLYLINE"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LWPOLYLINE"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK ||
                acSSPrompt.Value == null || acSSPrompt.Value.Count == 0)
            {
                ed.WriteMessage("\nYou select nothing!");
                return;
            }

            //Set color index:
            //https://www.keanw.com/2008/02/using-standard.html?cid=102138552
            short defaultColorIndex = -500;
            short colorIndex = defaultColorIndex;
            //using (Transaction tr = db.TransactionManager.StartTransaction())
            //{
            //    LayerTableRecord lyrTbRc = tr.GetObject(db.Clayer, OpenMode.ForRead) as LayerTableRecord;
            //    colorIndex = lyrTbRc.Color.ColorIndex;
            //    tr.Commit();
            //}

            //ed.WriteMessage("\nUse current layer's color index.");

            Autodesk.AutoCAD.Windows.ColorDialog clrDlg = new Autodesk.AutoCAD.Windows.ColorDialog();
            System.Windows.Forms.DialogResult dr = clrDlg.ShowDialog();
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                Autodesk.AutoCAD.Colors.Color clr = clrDlg.Color;
                if (clr.IsByAci)
                {
                    colorIndex = clr.ColorIndex;
                }
            }

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                //Build offset distance list:
                System.Collections.Generic.List<double> offDistLst = new List<double>();
                offDistLst.Add(offDist);

                if (kwRes.Equals(kwLst[1]))
                {
                    offDistLst.Add(offDist * -1.0);
                }

                //Build list of side to offset:
                System.Collections.Generic.List<short> side =
                       new System.Collections.Generic.List<short>();
                side.Add(1);
                side.Add(-1);

                foreach (SelectedObject sObj in acSSPrompt.Value)
                {
                    if (sObj != null)
                    {
                        Curve memCurv = tr.GetObject(sObj.ObjectId, OpenMode.ForWrite) as Curve;

                        if (memCurv != null && memCurv.Closed)
                        {
                            bool curveAdded;

                            for (int i = 0; i < offDistLst.Count; i++)
                            {
                                curveAdded = false;

                                for (int j = 0; j < side.Count; j++)
                                {
                                    if (curveAdded)
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        using (DBObjectCollection dbObjs = memCurv.GetOffsetCurves(offDistLst[i] * side[j]))
                                        {
                                            if (dbObjs != null)
                                            {
                                                foreach (Entity offEnt in dbObjs)
                                                {
                                                    if (offEnt != null && offEnt is Curve offCurv) 
                                                    {
                                                        if ((offCurv.Area - memCurv.Area) * offDistLst[i] >= 0.0)
                                                        {
                                                            offEnt.LayerId = db.Clayer;

                                                            if (colorIndex != defaultColorIndex)
                                                            {
                                                                offEnt.ColorIndex = colorIndex;
                                                            }
                                                            
                                                            btr.AppendEntity(offEnt);
                                                            tr.AddNewlyCreatedDBObject(offEnt, true);
                                                            curveAdded = true;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                tr.Commit();
            }
        }

        #region [Nhóm lệnh set kích thước]
        //Sub method to update DIMSCALE_LTSCALE for XML setting file:
        private bool UpdateDimScale_LtScale(Editor ed)
        {
            try
            {
                double dimScale;
                double ltScale;

                PromptDoubleOptions pdo = new PromptDoubleOptions("");
                pdo.AllowArbitraryInput = false;
                pdo.AllowNone = false;
                pdo.AllowNegative = false;
                pdo.AllowZero = false;

                PromptDoubleResult pdr;

                //Read XML:
                string xmlFullPath = CommonDeclaration.GetSettingXmlFullPath();
                
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlFullPath);

                XmlNode xmlNode = null;
                xmlNode = xmlDoc.DocumentElement.SelectSingleNode(CommonDeclaration.SysVars);
                string DimSc_Lts;

                if (xmlNode != null)
                {
                    DimSc_Lts = xmlNode["StandardScaleLts"].InnerText;

                    if (string.IsNullOrEmpty(DimSc_Lts))
                    {
                        DimSc_Lts = "1_5";
                        ed.WriteMessage($"\nCannot read XML. Use {DimSc_Lts}");
                    }
                }
                else
                {
                    DimSc_Lts = "1_5";
                    ed.WriteMessage($"\nCannot read XML. Use {DimSc_Lts}");
                }

                string[] splittedStrs = DimSc_Lts.Split('_');
                double defaultLts, defaultSc;
                if (splittedStrs != null && splittedStrs.Length == 2)
                {
                    if (!double.TryParse(splittedStrs[0], out defaultSc))
                    {
                        defaultSc = 1.0;
                        ed.WriteMessage($"\nError when read dimscale. Use {defaultSc}");
                    }
                    
                    if (!double.TryParse(splittedStrs[1], out defaultLts))
                    {
                        defaultLts = 5.0;
                        ed.WriteMessage($"\nError when read ltscale. Use {defaultLts}");
                    }
                }
                else
                {
                    defaultSc = 1.0;
                    ed.WriteMessage($"\nError when read dimscale. Use {defaultSc}");

                    defaultLts = 5.0;
                    ed.WriteMessage($"\nError when read ltscale. Use {defaultLts}");
                }

                //Get standard DIMSCALE:
                pdo.Message = "\nStandard DIMSCALE: ";
                pdo.DefaultValue = defaultSc;
                pdr = ed.GetDouble(pdo);
                if (pdr.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nCannot get standard DIMSCALE!");
                    return false;
                }
                else
                {
                    dimScale = pdr.Value;
                }

                //Get standard LTSCALE:
                pdo.Message = "\nStandard LTSCALE: ";
                pdo.DefaultValue = defaultLts;
                pdr = ed.GetDouble(pdo);
                if (pdr.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nCannot get standard LTSCALE!");
                    return false;
                }
                else
                {
                    ltScale = pdr.Value;
                }

                //Get XML's node new content:
                string xmlNodeNewContent = dimScale.ToString().Trim() + "_" + ltScale.ToString().Trim();

                xmlNode = xmlDoc.DocumentElement.SelectSingleNode(CommonDeclaration.SysVars);
                if (xmlNode != null)
                {
                    xmlNode["StandardScaleLts"].InnerText = xmlNodeNewContent;
                    xmlDoc.Save(xmlFullPath);
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage($"\nError: {ex.Message}");
                return false;
            }

            return true;
        }

        //Lệnh set size kích thước(nhập dimscale)
        [CommandMethod("C970",CommandFlags.Modal)]
        public void Cmdc970()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;

            ////Check current cad is mechanical or not:
            //if (!AcadAddin.IsCadMechanical.Status())
            //{
            //    ed.WriteMessage("\nThis command cannot be used for non mechanical cad!");
            //    return;
            //}

            PromptDoubleOptions prd = new PromptDoubleOptions("");
            //{
            //    AllowNegative = false,
            //    AllowNone = true
            //};
            prd.Message = "\nNew DIMSCALE: ";
            prd.AllowArbitraryInput = false;
            prd.AllowNone = false;
            prd.AllowNegative = false;
            prd.AllowZero = false;
            prd.Keywords.Add("Setting");

            bool isDone = false;
            PromptDoubleResult prdr = null;
            while (!isDone)
            {
                prdr = ed.GetDouble(prd);
                if (prdr.Status == PromptStatus.Cancel)
                {
                    return;
                }
                else if (prdr.Status == PromptStatus.Error ||
                         prdr.Status == PromptStatus.None)
                {
                    ed.WriteMessage("\nCannot get new DIMSCALE !");
                    return;
                }
                else if (prdr.Status == PromptStatus.Keyword)
                {
                    if (!UpdateDimScale_LtScale(ed))
                    {
                        return;
                    }
                    else
                    {
                        isDone = false;
                    }
                }
                else
                {
                    isDone = true;
                }
            }
           
            //if (prdr.Value == ToDouble(GetSystemVariable("DIMSCALE")))
            //{
            //    ed.WriteMessage("\nNo need to change DIMSCALE !");
            //    return;
            //}

            if (prdr == null)
            {
                ed.WriteMessage("\nScale value is not valid!");
                return;
            }
            else
            {
                //Change LTSCALE & DIMSCALE :
                string xmlFullPath = CommonDeclaration.GetSettingXmlFullPath();
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlFullPath);

                XmlNode xmlNode = null;
                xmlNode = xmlDoc.DocumentElement.SelectSingleNode(CommonDeclaration.SysVars);
                if (xmlNode != null)
                {
                    string innerTxt = xmlNode["StandardScaleLts"].InnerText;
                    if (string.IsNullOrEmpty(innerTxt))
                    {
                        ed.WriteMessage("\nCannot read XML setting file !");
                        return;
                    }

                    string[] splitedStrs = innerTxt.Split('_');
                    if (splitedStrs == null || splitedStrs.Length != 2)
                    {
                        ed.WriteMessage("\nXML's node text is invalid !");
                        return;
                    }

                    double stdSc = double.Parse(splitedStrs[0]);
                    if (stdSc == 0.0)
                    {
                        ed.WriteMessage("\nCannot get standard DIMSCALE !");
                        return;
                    }

                    double stdLts = double.Parse(splitedStrs[1]);
                    if (stdLts == 0.0)
                    {
                        ed.WriteMessage("\nCannot get standard LTSCALE !");
                        return;
                    }

                    KeyValuePair<double, double> stdScLts = new KeyValuePair<double, double>(stdSc, stdLts);
                    SetSystemVariable("DIMSCALE", prdr.Value);
                    SetSystemVariable("LTSCALE", prdr.Value * stdScLts.Value / stdScLts.Key);

                    //For mechanical ONLY,
                    //Set this for changing Power Dimension's DIMSCALE:
                    if (AcadAddin.IsCadMechanical.Status())
                    {
                        // build the arguments list:
                        //https://forums.autodesk.com/t5/net/resultbuffer-and-application-invoke/td-p/5212711
                        ResultBuffer args = new ResultBuffer(
                            new TypedValue((int)LispDataType.Text, "AMSYMSCALE"),
                            new TypedValue((int)LispDataType.Double, prdr.Value));

                        //Call the Lisp function:
                        try
                        {
                            //With getting return value:
                            //ResultBuffer result = Application.Invoke(args);

                            //Without getting return value:
                            AcAp.Invoke(args);
                        }
                        catch (System.Exception ex)
                        {
                            ed.WriteMessage(ex.Message);
                            return;
                        }
                    }

                    #region [Old codes]
                    //Get string to send command:
                    //string stcm = "._AMSYMSCALE " + prdr.Value.ToString() + " ";

                    //Send command:
                    //doc.SendStringToExecute(stcm, true, false, false);
                    #endregion
                }
            }
        }

        //Lệnh set size kích thước(Chọn kích thước/Text/Mtext)
        [CommandMethod("DDN",CommandFlags.Modal)]
        public void CmdDDN()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            ////Get current DIMSCALE & LTSCALE :
            //double dimsc = ToDouble(GetSystemVariable("dimscale"));
            //double ltsc = ToDouble(GetSystemVariable("ltscale"));

            #region [Select source entity]
            PromptEntityOptions peo = new PromptEntityOptions("\nSelect dimension/ MText/ Text: ");
            peo.SetRejectMessage("\nInvalid selection. Please select dimension/ MText/ Text.");
            peo.AddAllowedClass(typeof(Dimension), false);
            peo.AddAllowedClass(typeof(MText), false);
            peo.AddAllowedClass(typeof(DBText), false);
            peo.AllowNone = true;

            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK)
            {
                ed.WriteMessage("\nCannot get entity !");
                return;
            }
            #endregion

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                #region [Get new DIMSCALE
                //Get entity by its id :
                Entity ent = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Entity;

                double newdimsc;
                switch (ent.GetType().Name)
                {
                    case "MText":
                        newdimsc = ((MText)ent).TextHeight / KRCADTextStyle.KRTextHeight;
                        break;
                    case "DBText":
                        newdimsc = ((DBText)ent).Height / KRCADTextStyle.KRTextHeight;
                        break;
                    default:
                        newdimsc = ((Dimension)ent).Dimscale;
                        break;
                }

                //if (newdimsc == ToDouble( GetSystemVariable("DIMSCALE")))
                //{
                //    ed.WriteMessage("\nNo need to change DIMSCALE !");
                //    tr.Abort();
                //    return;
                //}
                if (newdimsc == 0)
                {
                    ed.WriteMessage("\nScale value is not valid!");
                    tr.Abort();
                    return;
                }
                #endregion

                //Change LTSCALE & DIMSCALE :
                string xmlFullPath = CommonDeclaration.GetSettingXmlFullPath();
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlFullPath);

                XmlNode xmlNode = null;
                xmlNode = xmlDoc.DocumentElement.SelectSingleNode("SysVars");
                if (xmlNode != null)
                {
                    string innerTxt = xmlNode["StandardScaleLts"].InnerText;
                    if (string.IsNullOrEmpty(innerTxt))
                    {
                        ed.WriteMessage("\nCannot read XML setting file !");
                        tr.Abort();
                        return;
                    }

                    string[] splitedStrs = innerTxt.Split('_');
                    if (splitedStrs == null || splitedStrs.Length != 2)
                    {
                        ed.WriteMessage("\nXML's node text is invalid !");
                        tr.Abort();
                        return;
                    }

                    double stdSc = double.Parse(splitedStrs[0]);
                    if (stdSc == 0.0)
                    {
                        ed.WriteMessage("\nCannot get standard DIMSCALE !");
                        tr.Abort();
                        return;
                    }

                    double stdLts = double.Parse(splitedStrs[1]);
                    if (stdLts == 0.0)
                    {
                        ed.WriteMessage("\nCannot get standard LTSCALE !");
                        tr.Abort();
                        return;
                    }

                    KeyValuePair<double, double> stdScLts = new KeyValuePair<double, double>(stdSc, stdLts);
                    SetSystemVariable("DIMSCALE", newdimsc);
                    SetSystemVariable("LTSCALE", newdimsc * stdScLts.Value / stdScLts.Key);

                    //For mechanical ONLY,
                    //Set this for changing Power Dimension's DIMSCALE:
                    if (AcadAddin.IsCadMechanical.Status())
                    {
                        // build the arguments list:
                        ResultBuffer args = new ResultBuffer(
                            new TypedValue((int)LispDataType.Text, "AMSYMSCALE"),
                            new TypedValue((int)LispDataType.Double, newdimsc));

                        //Call the Lisp function:
                        try
                        {
                            AcAp.Invoke(args);
                        }
                        catch (System.Exception ex)
                        {
                            ed.WriteMessage(ex.Message);
                            tr.Abort();
                            return;
                        }

                        #region [Old codes]
                        //string stcm = "._AMSYMSCALE " + newdimsc.ToString() + " ";
                        //doc.SendStringToExecute(stcm, true, false, false);
                        #endregion
                    }

                    //Commit changes:
                    tr.Commit();
                }
            }
        }

        //Set bounding frame for dimension:
        [CommandMethod("BDim")]
        public void CmdBDim()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            PromptKeywordOptions pkwo = new PromptKeywordOptions("\nHas bounding frame? : ");
            pkwo.AllowNone = false;
            pkwo.AllowArbitraryInput = false;
            pkwo.Keywords.Add("Yes");
            pkwo.Keywords.Add("No");
            pkwo.Keywords.Default = "Yes";

            PromptResult pr = ed.GetKeywords(pkwo);
            if (pr.Status == PromptStatus.Cancel ||
                pr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get type!");
                return;
            }

            PromptSelectionOptions pso = new PromptSelectionOptions();
            pso.RejectObjectsOnLockedLayers = true;
            pso.MessageForAdding = "\nSelect dimension to add: ";
            pso.MessageForRemoval = "\nSelect dimension to remove: ";

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            PromptSelectionResult psr = ed.GetSelection(pso, acSelFtr);
            if (psr.Status == PromptStatus.Cancel ||
                psr.Status == PromptStatus.Error ||
                psr.Value.Count == 0)
            {
                ed.WriteMessage("\nCannot get selection set!");
                return;
            }

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sObj in psr.Value)
                {
                    if (sObj != null)
                    {
                        //https://www.cadforum.cz/en/qaID.asp?tip=1243
                        Dimension dimObj = (Dimension)tr.GetObject(sObj.ObjectId, OpenMode.ForWrite);

                        try
                        {
                            if (pr.StringResult == "Yes")
                            {
                                dimObj.Dimgap = -1;
                            }
                            else
                            {
                                dimObj.Dimgap = KRCADDimStyle.KRDimGap;
                            }
                        }
                        catch (System.Exception ex)
                        {
                            ed.WriteMessage($"\nError: {ex.Message}");
                            tr.Abort();
                            return;
                        }
                    }
                }

                tr.Commit();
            }
        }
        #endregion

        #region[Ví dụ Switch Case]
        [CommandMethod("VERCHECK")]
        public void CmdVERCHECK()
        {
            Editor ed = Application.DocumentManager.MdiActiveDocument.Editor;

            switch (Application.DocumentManager.MdiActiveDocument.Database.LastSavedAsVersion)
            {
                case (Autodesk.AutoCAD.DatabaseServices.DwgVersion.AC1032):
                    ed.WriteMessage("\n autocad 2018");
                    break;
            }
        }
        #endregion

        #region[check bản vẽ đã save thành file chưa]
        //Lệnh xác nhận đã save thành file chưa :
        [CommandMethod("svcheck")]
        public void Cmdsvcheck()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            if (IsSavedFile() == true)
            {
                ed.WriteMessage("\n file đã save rồi");
            }
            else
            {
                ed.WriteMessage("\n file chưa save nha !");
            }
        }

        private static Boolean IsSavedFile()
        {
            int result = System.Convert.ToInt32(Application.GetSystemVariable("DWGTITLED"));
            if (result != 0)
            {
                return true;
            }
            {
                return false;
            }
        }
        #endregion

        //Lệnh lấy tọa độ 2 điểm người dùng :
        [CommandMethod("get2p")]
        public void Cmdget2p()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = Application.DocumentManager.MdiActiveDocument.Editor;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bltb = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord blrc = tr.GetObject(bltb[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                PromptPointOptions prpoint1 = new PromptPointOptions("\n 開始の点を選んで下さい。")
                {
                    AllowArbitraryInput = false,
                    AllowNone = true
                };

                PromptPointOptions prpoint2 = new PromptPointOptions("\n 最終の点を選んで下さい。")
                {
                    AllowArbitraryInput = false,
                    AllowNone = true
                };

                PromptPointResult promptPointResult1 = ed.GetPoint(prpoint1);
                if (promptPointResult1.Status != PromptStatus.OK) return;

                prpoint2.BasePoint = promptPointResult1.Value;
                prpoint2.UseBasePoint = true;

                PromptPointResult promptPointResult2 = ed.GetPoint(prpoint2);
                if (promptPointResult2.Status != PromptStatus.OK) return;

                ed.WriteMessage("\n point1 = " + promptPointResult1.Value.ToString() + " point 2 = " + promptPointResult2.Value);
            }
        }

        //Lệnh thay đổi ltscale
        [CommandMethod("ltschange")]
        public void Cmdltschange()
        {
            Database db = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Database;
            db.Ltscale = 100;
        }
        
        #region[Lệnh vẽ đường thẳng có độ dốc]
        public static Point3d PolarPoints(Point3d pPt, double dAng, double dDist)
        {
            return new Point3d(pPt.X + dDist * Math.Cos(dAng),
                               pPt.Y + dDist * Math.Sin(dAng),
                               pPt.Z);
        }

        private void DrawSlopeLine(bool isRealLeng = true)
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptPointOptions ppo = new PromptPointOptions("\nBase point: ");
            ppo.AllowArbitraryInput = false;
            ppo.AllowNone = false;
            ppo.UseBasePoint = true;
            ppo.BasePoint = Point3d.Origin;
            ppo.Keywords.Add("Origin");
            ppo.Keywords.Default = "Origin";

            Point3d basePntWcs;
            PromptPointResult ppr = ed.GetPoint(ppo);
            if (ppr.Status == PromptStatus.Cancel ||
                ppr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get base point!");
                return;
            }
            else if (ppr.Status == PromptStatus.Keyword)
            {
                basePntWcs = Point3d.Origin;
            }
            else
            {
                basePntWcs = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
            }

            PromptDoubleOptions pdo = new PromptDoubleOptions("");
            PromptDoubleResult pdr;
            while (true)
            {
                //Get real length(mm):
                pdo.UseDefaultValue = false;
                if (isRealLeng)
                {
                    pdo.Message = "\nReal length: ";
                }
                else
                {
                    pdo.Message = "\nHorizontal length: ";
                }
                
                pdo.AllowNone = true;
                pdo.AllowArbitraryInput = false;
                pdo.AllowNegative = false;
                pdo.AllowZero = false;

                double leng = 0.0;
                pdr = ed.GetDouble(pdo);
                if (pdr.Status == PromptStatus.Cancel ||
                    pdr.Status == PromptStatus.Error)
                {
                    if (isRealLeng)
                    {
                        ed.WriteMessage("\nCannot get real length!");

                    }
                    else
                    {
                        ed.WriteMessage("\nCannot get horizontal length!");
                    }
                    
                    return;
                }
                else if (pdr.Status == PromptStatus.None)
                {
                    //End process:
                    return;
                }
                else
                {
                    leng = pdr.Value;
                }

                //Get slope(%):
                pdo.UseDefaultValue = true;
                pdo.DefaultValue = 0.0;
                pdo.Message = "\nSlope(%): ";
                pdo.AllowNone = false;
                pdo.AllowArbitraryInput = false;
                pdo.AllowNegative = true;
                pdo.AllowZero = true;

                double slope;
                pdr = ed.GetDouble(pdo);
                if (pdr.Status == PromptStatus.Cancel ||
                    pdr.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get slope!");
                    return;
                }
                else
                {
                    slope = pdr.Value / 100.0;
                }

                double slopeAng = Math.Atan(slope);
                if (!isRealLeng)
                {
                    leng = Math.Abs(leng / Cos(slopeAng));
                }

                Point3d basePntUcs = basePntWcs.TransformBy(ed.CurrentUserCoordinateSystem.Inverse());
                Point3d targetPntUcs = new Point3d(basePntUcs.X + leng * Math.Cos(slopeAng), basePntUcs.Y + leng * Math.Sin(slopeAng),
                    basePntUcs.Z);

                Point3d targetPntWcs = targetPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    using (Line newLine = new Line())
                    {
                        newLine.StartPoint = basePntWcs;
                        newLine.EndPoint = targetPntWcs;
                        AppendEnt(tr, newLine);

                        basePntWcs = newLine.EndPoint;
                    }

                    tr.TransactionManager.QueueForGraphicsFlush();

                    tr.Commit();
                }
            }

            #region [Old codes]
            //PromptDoubleOptions pdo = new PromptDoubleOptions("");
            //PromptDoubleResult pdr;

            ////Get real length(mm):
            //pdo.UseDefaultValue = false;
            //pdo.Message = "\nReal length: ";
            //pdo.AllowNone = false;
            //pdo.AllowArbitraryInput = false;
            //pdo.AllowNegative = false;
            //pdo.AllowZero = false;

            //double leng = 0.0;
            //pdr = ed.GetDouble(pdo);
            //if (pdr.Status == PromptStatus.Cancel ||
            //    pdr.Status == PromptStatus.Error)
            //{
            //    ed.WriteMessage("\nCannot get real length!");
            //    return;
            //}
            //else
            //{
            //    leng = pdr.Value;
            //}

            ////Get slope(%):
            //pdo.UseDefaultValue = true;
            //pdo.DefaultValue = 0.0;
            //pdo.Message = "\nSlope(%): ";
            //pdo.AllowNone = false;
            //pdo.AllowArbitraryInput = false;
            //pdo.AllowNegative = true;
            //pdo.AllowZero = true;

            //double slope;
            //pdr = ed.GetDouble(pdo);
            //if (pdr.Status == PromptStatus.Cancel ||
            //    pdr.Status == PromptStatus.Error)
            //{
            //    ed.WriteMessage("\nCannot get slope!");
            //    return;
            //}
            //else
            //{
            //    slope = pdr.Value / 100.0;
            //}

            //double slopeAng = Math.Atan(slope);
            //Point3d basePntUcs = basePntWcs.TransformBy(ed.CurrentUserCoordinateSystem.Inverse());
            //Point3d targetPntUcs = new Point3d(basePntUcs.X + leng * Math.Cos(slopeAng), basePntUcs.Y + leng * Math.Sin(slopeAng),
            //    basePntUcs.Z);

            //Point3d targetPntWcs = targetPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);

            //using (Transaction tr = db.TransactionManager.StartTransaction())
            //{
            //    using (Line newLine = new Line())
            //    {
            //        newLine.StartPoint = basePntWcs;
            //        newLine.EndPoint = targetPntWcs;
            //        AppendEnt(tr, newLine);
            //    }

            //    tr.TransactionManager.QueueForGraphicsFlush();

            //    tr.Commit();
            //}

            #endregion
        }

        [Obsolete("This method is obsolete. Use CmdHT1 instead")]
        public void CmdHTOld()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Get base point :
            Point3d pt3d = Point3d.Origin;
            if (KRGetPoint(ed, "\n原点 : ", Point3d.Origin, ref pt3d) != PromptStatus.OK)
                return;
            else
                pt3d = Ucs2Wcs(pt3d);

            //Loop to draw :
            double leng = 0.0;
            double slope = 0.0;
            while (true)
            {
                //Get length :
                if (KRGetDouble(ed, "\n実長の記入(mm) : ", ref leng) != PromptStatus.OK)
                    return;

                //Get angle :
                if (KRGetDouble(ed, "\n勾配の記入(%) : ", ref slope) != PromptStatus.OK)
                    return;

                //Main transaction :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Create line :
                    using (Line lobj = new Line())
                    {
                        double an = Atan(slope / 100.0);
                        lobj.StartPoint = pt3d;
                        lobj.EndPoint = PolarPoints(lobj.StartPoint, an, leng);
                        pt3d = lobj.EndPoint;
                        AppendEnt(tr, lobj);
                    }

                    //Update graphic :
                    tr.TransactionManager.QueueForGraphicsFlush();

                    //Commit changes :
                    tr.Commit();
                }
            }
        }

        //Draw slope line(Real length)
        [CommandMethod("HT")]
        public void CmdHT()
        {
            #region [Old codes]
            //Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            //Database db = doc.Database;
            //Editor ed = doc.Editor;

            //PromptPointOptions ppo = new PromptPointOptions("\nBase point: ");
            //ppo.AllowArbitraryInput = false;
            //ppo.AllowNone = false;
            //ppo.UseBasePoint = true;
            //ppo.BasePoint = Point3d.Origin;
            //ppo.Keywords.Add("Origin");
            //ppo.Keywords.Default = "Origin";

            //Point3d basePntWcs;
            //PromptPointResult ppr = ed.GetPoint(ppo);
            //if (ppr.Status == PromptStatus.Cancel ||
            //    ppr.Status == PromptStatus.Error)
            //{
            //    ed.WriteMessage("\nCannot get base point!");
            //    return;
            //}
            //else if (ppr.Status == PromptStatus.Keyword)
            //{
            //    basePntWcs = Point3d.Origin;
            //}
            //else
            //{
            //    basePntWcs = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
            //}

            //PromptDoubleOptions pdo = new PromptDoubleOptions("");
            //PromptDoubleResult pdr;
            //while (true)
            //{
            //    //Get real length(mm):
            //    pdo.UseDefaultValue = false;
            //    pdo.Message = "\nReal length: ";
            //    pdo.AllowNone = false;
            //    pdo.AllowArbitraryInput = false;
            //    pdo.AllowNegative = false;
            //    pdo.AllowZero = false;

            //    double leng = 0.0;
            //    pdr = ed.GetDouble(pdo);
            //    if (pdr.Status == PromptStatus.Cancel ||
            //        pdr.Status == PromptStatus.Error)
            //    {
            //        ed.WriteMessage("\nCannot get real length!");
            //        return;
            //    }
            //    else
            //    {
            //        leng = pdr.Value;
            //    }

            //    //Get slope(%):
            //    pdo.UseDefaultValue = true;
            //    pdo.DefaultValue = 0.0;
            //    pdo.Message = "\nSlope(%): ";
            //    pdo.AllowNone = false;
            //    pdo.AllowArbitraryInput = false;
            //    pdo.AllowNegative = true;
            //    pdo.AllowZero = true;

            //    double slope;
            //    pdr = ed.GetDouble(pdo);
            //    if (pdr.Status == PromptStatus.Cancel ||
            //        pdr.Status == PromptStatus.Error)
            //    {
            //        ed.WriteMessage("\nCannot get slope!");
            //        return;
            //    }
            //    else
            //    {
            //        slope = pdr.Value / 100.0;
            //    }

            //    double slopeAng = Math.Atan(slope);
            //    Point3d basePntUcs = basePntWcs.TransformBy(ed.CurrentUserCoordinateSystem.Inverse());
            //    Point3d targetPntUcs = new Point3d(basePntUcs.X + leng * Math.Cos(slopeAng), basePntUcs.Y + leng * Math.Sin(slopeAng),
            //        basePntUcs.Z);

            //    Point3d targetPntWcs = targetPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);

            //    using (Transaction tr = db.TransactionManager.StartTransaction())
            //    {
            //        using (Line newLine = new Line())
            //        {
            //            newLine.StartPoint = basePntWcs;
            //            newLine.EndPoint = targetPntWcs;
            //            AppendEnt(tr, newLine);

            //            basePntWcs = newLine.EndPoint;
            //        }

            //        tr.TransactionManager.QueueForGraphicsFlush();

            //        tr.Commit();
            //    }
            //}


            #endregion

            DrawSlopeLine(true);
        }

        //Draw slope line(Horizontal length)
        [CommandMethod("HTS")]
        public void CmdHTH()
        {
            DrawSlopeLine(false);
        }

        #endregion

        //Lệnh vẽ đường tâm cho vòng tròn
        [CommandMethod("VT")]
        public void CmdVT()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Use try-catch to avoid crash:
            try
            {
                //Main transaction:
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    #region [Get selection set]
                    PromptSelectionOptions pso = new PromptSelectionOptions()
                    {
                        MessageForAdding = "\nSelect Circle/ Arc : ",
                        RejectObjectsOnLockedLayers = true
                    };

                    TypedValue[] acTypValAr = new TypedValue[4];
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "CIRCLE"), 1);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "ARC"), 2);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);
                    SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

                    PromptSelectionResult acSSPrompt = ed.GetSelection(pso,acSelFtr);
                    if (acSSPrompt.Status != PromptStatus.OK || 
                        acSSPrompt.Value.Count == 0)
                    {
                        ed.WriteMessage("\nYou select nothing!");
                        tr.Abort();
                        return;
                    }
                    #endregion

                    #region [Input centerline's extension]
                    PromptDoubleOptions pdo = new PromptDoubleOptions("\nCenterline's extension: ")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true,
                        AllowZero = true,
                        DefaultValue = 3.0,
                    };

                    PromptDoubleResult pdr = ed.GetDouble(pdo);
                    if (pdr.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }
                    #endregion

                    #region [Input centerline's angle]
                    PromptAngleOptions pao = new PromptAngleOptions("\nCenterline's angle: ")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true,
                        AllowZero = true,
                        DefaultValue = 0.0
                    };

                    double Angle;

                    PromptDoubleResult par = ed.GetAngle(pao);
                    if (par.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }
                    else
                    {
                        Angle = par.Value;
                    }

                    #endregion
                    //We need to iterate selection set.
                    //then define concentric circles , remove the small one.
                    ObjectId[] idsArray = acSSPrompt.Value.GetObjectIds();
                    List<Tuple<ObjectId, Point3d, double>> cirInfos = new List<Tuple<ObjectId, Point3d, double>>();
                    using (Transaction subTr = db.TransactionManager.StartTransaction())
                    {
                        foreach (ObjectId id in idsArray)
                        {
                            if (id != ObjectId.Null)
                            {
                                Point3d centerPnt;
                                double radi;

                                Entity ent = subTr.GetObject(id, OpenMode.ForRead) as Entity;
                                if (ent is Circle)
                                {
                                    centerPnt = (ent as Circle).Center;
                                    radi = (ent as Circle).Radius;
                                }
                                else
                                {
                                    centerPnt = (ent as Arc).Center;
                                    radi = (ent as Arc).Radius;
                                }

                                if (cirInfos.Count == 0)
                                {
                                    cirInfos.Add(new Tuple<ObjectId, Point3d, double>(ent.ObjectId, centerPnt, radi));
                                }
                                else
                                {
                                    if (cirInfos.Exists(x => x.Item2.Equals(centerPnt) == true))
                                    {
                                        var findMem = cirInfos.Find(x => x.Item2.Equals(centerPnt) == true);
                                        if (findMem.Item3 < radi)
                                        {
                                            cirInfos.Remove(findMem);
                                            cirInfos.Add(new Tuple<ObjectId, Point3d, double>(ent.ObjectId, centerPnt, radi));
                                        }
                                    }
                                    else
                                    {
                                        cirInfos.Add(new Tuple<ObjectId, Point3d, double>(ent.ObjectId, centerPnt, radi));
                                    }
                                }
                            }
                        }

                        //Commit changes:
                        subTr.Commit();
                    }

                    //Get layer Center:
                    string layerName;
                    if (!KRCADLayer.HasLayer(KRCADLayer.LayerCenter.Item1))
                    {
                        if (!KRCADLayer.CreateLayer(KRCADLayer.LayerCenter))
                        {
                            ed.WriteMessage("\nCannot create layer Center. Use layer '0' instead !");
                            layerName = "0";
                        }
                        else
                        {
                            layerName = KRCADLayer.LayerCenter.Item1;
                        }
                    }
                    else
                    {
                        layerName = KRCADLayer.LayerCenter.Item1;
                    }

                    //Iterate list and draw center lines:
                    foreach (var item in cirInfos)
                    {
                        Point3d CenterPoint;
                        double Radius;
                        Entity ent = tr.GetObject(item.Item1, OpenMode.ForRead) as Entity;
                        if (ent.GetType().Name.ToString() == "Circle")
                        {
                            Circle Cirobj = (Circle)ent;
                            CenterPoint = Cirobj.Center;
                            Radius = Cirobj.Radius;
                        }
                        else
                        {
                            Arc ArcObj = (Arc)ent;
                            CenterPoint = ArcObj.Center;
                            Radius = ArcObj.Radius;
                        }

                        using (Line lobj = new Line())
                        {
                            lobj.StartPoint = PolarXYonUCS(CenterPoint, Angle + PI, Radius + pdr.Value);
                            lobj.EndPoint = PolarXYonUCS(CenterPoint, Angle + 0.0, Radius + pdr.Value);
                            lobj.Layer = layerName;
                            AppendEnt(tr, lobj);
                        }

                        using (Line lobj = new Line())
                        {
                            lobj.StartPoint = PolarXYonUCS(CenterPoint, Angle - PI / 2.0, Radius + pdr.Value);
                            lobj.EndPoint = PolarXYonUCS(CenterPoint, Angle + PI / 2.0, Radius + pdr.Value);
                            lobj.Layer = layerName;
                            AppendEnt(tr, lobj);
                        }
                    }

                    //Commit changes:
                    tr.Commit();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        //Lệnh gọi form vẽ BasePost
        public BasePostFrm BasePost;
        [CommandMethod("BAS")]
        public void CmdBAS()
        {
            if (BasePost == null)
            {
                BasePost = new BasePostFrm();
                AcAp.ShowModelessDialog(BasePost);
            }
            else if (BasePost.IsDisposed == true)
            {
                //Clear old base post :
                BasePost = null;

                //Create new base post :
                BasePost = new BasePostFrm();
                AcAp.ShowModelessDialog(BasePost);
            }
            else
                AcAp.ShowModelessDialog(BasePost);
        }

        //Lệnh vẽ phân giác:
        [Obsolete("This method doesn't support nested. Use VPGN instead")]
        private void CmdVPG()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Start main transaction :
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Auto reset UCS & highlight status when process finish :
                using (KRResetUCS myResetUcs = new KRResetUCS())
                using (KRUnhighlight myUnhighlight = new KRUnhighlight())
                {
                    #region [Select curve 1]
                    //Prompt selection :
                    PromptEntityOptions peo1 = new PromptEntityOptions("\nSelect the first straight curve :");
                    peo1.SetRejectMessage("\nInvalid selection .Please select a straight curve !");
                    peo1.AddAllowedClass(typeof(Line), false);
                    peo1.AddAllowedClass(typeof(Autodesk.AutoCAD.DatabaseServices.
                        Polyline), false);//For basic autocad 2d polyline 
                    peo1.AddAllowedClass(typeof(Polyline2d), false);
                    peo1.AddAllowedClass(typeof(Xline), false);
                    peo1.AddAllowedClass(typeof(Ray), false);

                    //Prompt result :
                    PromptEntityResult per1 = ed.GetEntity(peo1);
                    if (per1.Status != PromptStatus.OK)
                        return;
                    else
                        myUnhighlight.Add(per1.ObjectId);

                    //Open curve for write :
                    Curve curvObj1 = (Curve)tr.GetObject(per1.ObjectId, OpenMode.ForWrite);

                    //Get closest point to picked point :
                    Point3d cloPnt1 = curvObj1.GetClosestPointTo(per1.PickedPoint, true);

                    //Highlight :
                    if (per1.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Polyline2d)))
                        || per1.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(
                            Autodesk.AutoCAD.DatabaseServices.Polyline)))
                        )
                    {
                        double param = curvObj1.GetParameterAtPoint(cloPnt1);
                        FullSubentityPath path = new FullSubentityPath(new ObjectId[] { curvObj1.Id },
                                             new SubentityId(SubentityType.Edge, new IntPtr((int)param + 1)));
                        curvObj1.Highlight(path, false);
                    }
                    else
                        curvObj1.Highlight();
                    #endregion

                    #region [Select curve 2]
                    //Prompt selection :
                    PromptEntityOptions peo2 = peo1;
                    peo2.Message = "\nSelect the second straight curve :";

                    //Prompt result :
                    PromptEntityResult per2 = ed.GetEntity(peo2);
                    if (per2.Status != PromptStatus.OK)
                        return;
                    else
                        myUnhighlight.Add(per2.ObjectId);

                    //Open curve for write :
                    Curve curvObj2 = (Curve)tr.GetObject(per2.ObjectId, OpenMode.ForWrite);

                    //Get closest point to picked point :
                    Point3d cloPnt2 = curvObj2.GetClosestPointTo(per2.PickedPoint, true);

                    //Highlight :
                    curvObj1.Unhighlight();
                    if (per2.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Polyline2d)))
                        || per2.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(
                                Autodesk.AutoCAD.DatabaseServices.Polyline)))
                        )
                    {
                        double param = curvObj2.GetParameterAtPoint(cloPnt2);
                        FullSubentityPath path = new FullSubentityPath(new ObjectId[] { curvObj2.Id },
                                             new SubentityId(SubentityType.Edge, new IntPtr((int)param + 1)));
                        curvObj2.Highlight(path, false);
                    }
                    else
                        curvObj2.Highlight();
                    #endregion

                    //Input number of segments :
                    PromptIntegerOptions pio = new PromptIntegerOptions("\nNumber of segments :")
                    { AllowArbitraryInput = false, AllowNegative = false, AllowNone = false, AllowZero = false };
                    pio.LowerLimit = 2;

                    PromptIntegerResult pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                        return;
                    curvObj2.Unhighlight();

                    //Get 2d plane :
                    var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                    var plane = new Plane(Point3d.Origin, normal);

                    //Get tangent vectors at closest points :
                    Vector3d vt1, vt2;
                    vt1 = curvObj1.GetFirstDerivative(cloPnt1);
                    vt2 = curvObj2.GetFirstDerivative(cloPnt2);

                    //Get angle between 2 vectors :
                    double denta = vt1.GetAngleTo(vt2);

                    //Case 1 :Parallel 
                    if (Abs(denta - 0.0) <= KRTolerance || Abs(denta - PI) <= KRTolerance)
                    {
                        Point3d pt1, pt2;
                        pt1 = cloPnt1;
                        pt2 = cloPnt2;

                        double dist = pt1.DistanceTo(pt2);
                        using (Line lobj = new Line())
                        {
                            lobj.StartPoint = pt1;
                            lobj.EndPoint = pt2;

                            double an = lobj.Angle;

                            for (int i = 0; i < pir.Value - 1; i++)
                            {
                                pt1 = PolarPoints(pt1, an, lobj.Length / (pir.Value));
                                pt2 = PolarPoints(pt1, vt1.AngleOnPlane(plane), 10.0);

                                using (Xline xl = new Xline())
                                {
                                    xl.BasePoint = pt1;
                                    xl.SecondPoint = pt2;
                                    xl.Layer = KRLayer.Center;
                                    AppendEnt(tr, xl);
                                }
                            }
                        }
                    }

                    //Case 2 :Intersect
                    else
                    {
                        Line2d consLine1 = new Line2d(cloPnt1.Convert2d(plane), vt1.Convert2d(plane));
                        Line2d consLine2 = new Line2d(cloPnt2.Convert2d(plane), vt2.Convert2d(plane));
                        Point2d[] retPnts = consLine1.IntersectWith(consLine2);
                        if (retPnts.Length > 1 || retPnts.Length == 0)
                        {
                            ed.WriteMessage("\nCannot get the intersection point. Command ended !");
                            return;
                        }
                        Point3d intPnt = new Point3d(retPnts[0].X, retPnts[0].Y, cloPnt1.Z);

                        #region [Backup codes]
                        ////Get intersect points 's collection :
                        //Point3dCollection pts3D = new Point3dCollection();
                        //curvObj1.IntersectWith(curvObj2, Intersect.ExtendBoth, pts3D, IntPtr.Zero, IntPtr.Zero);
                        //if (pts3D.Count == 0)
                        //{
                        //    ed.WriteMessage("\nCannot get intersection point. Command ended!");
                        //    return;
                        //}

                        ////Define the appropriate intersect point :
                        //Point3d intPnt = Point3d.Origin;
                        //bool pntFounded = false;
                        //foreach (Point3d pt in pts3D)
                        //{
                        //    Vector3d intVt1 = pt.GetVectorTo(cloPnt1);
                        //    Vector3d intVt2 = pt.GetVectorTo(cloPnt2);

                        //    if (intVt1.IsParallelTo(vt1) &&
                        //        intVt2.IsParallelTo(vt2))
                        //    {
                        //        intPnt = pt;
                        //        pntFounded = true;
                        //        break;
                        //    }
                        //}

                        //if (!pntFounded)
                        //{
                        //    ed.WriteMessage("\nCannot get intersection point. Command ended!");
                        //    return;
                        //}
                        #endregion

                        Point3d pt1, pt2;
                        pt1 = cloPnt1;
                        pt2 = cloPnt2;

                        //Reset tangent vector by intersect point & closest point : 
                        vt1 = intPnt.GetVectorTo(pt1);
                        vt2 = intPnt.GetVectorTo(pt2);

                        double an, an1, an2;
                        an = vt1.GetAngleTo(vt2);
                        an1 = vt1.AngleOnPlane(plane);
                        an2 = vt2.AngleOnPlane(plane);
                        denta = an / pir.Value;
                        Point3d pt3;
                        for (int i = 0; i < pir.Value - 1; i++)
                        {
                            if (an1 > an2)
                            {
                                if (an1 - an2 > PI)
                                {
                                    pt3 = PolarPoints(intPnt, an2 - denta - i * denta, 50);
                                }
                                else
                                {
                                    pt3 = PolarPoints(intPnt, an1 - denta - i * denta, 50);
                                }
                            }
                            else
                            {
                                if (an2 - an1 > PI)
                                {
                                    pt3 = PolarPoints(intPnt, an1 - denta - i * denta, 50);
                                }
                                else
                                {
                                    pt3 = PolarPoints(intPnt, an2 - denta - i * denta, 50);
                                }
                            }

                            using (Xline xl = new Xline())
                            {
                                xl.BasePoint = intPnt;
                                xl.SecondPoint = pt3;
                                xl.Layer = KRLayer.Center;
                                AppendEnt(tr, xl);
                            }
                        }
                    }
                }

                //Commit changes :
                tr.Commit();
            }
        }

        //Lệnh vẽ phân giác có hổ trợ nested entity:
        [CommandMethod("VPG")]
        public void CmdVPGN()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("")
            {
                AllowNone = false,
            };

            //Initialize variables for nested:
            bool curv1Highlighted = false;
            bool curv2Highlighted = false;
            PromptNestedEntityResult pner1 = null;
            PromptNestedEntityResult pner2 = null;
            try
            {
                //Get boundary curve 1's nested entity:
                pneo.Message = "\nSelect boundary 1: ";
                pner1 = GetNestedCurveOrLeader(ed, pneo);
                if (pner1.Status == PromptStatus.Cancel || pner1.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get boundary 1!");
                    return;
                }
                else
                {
                    //Highlight curve 1:
                    KRUnhighlight.HighlightNested(db, ed, pner1, true);
                    curv1Highlighted = true;
                }

                //Get boundary curve 2's nested entity:
                pneo.Message = "\nSelect boundary 2: ";
                pner2 = GetNestedCurveOrLeader(ed, pneo);
                if (pner2.Status == PromptStatus.Cancel || pner2.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get boundary 2!");
                    return;
                }
                else
                {
                    //Highlight curve 2:
                    KRUnhighlight.HighlightNested(db, ed, pner2, true);
                    curv2Highlighted = true;
                }

                //Input number of segments :
                PromptIntegerOptions pio = new PromptIntegerOptions("\nNumber of segments: ")
                { 
                    AllowArbitraryInput = false,
                    AllowNegative = false, 
                    AllowNone = false,
                    AllowZero = false ,
                    LowerLimit = 2,
                    DefaultValue = 2,
                };

                PromptIntegerResult pir = ed.GetInteger(pio);
                if (pir.Status != PromptStatus.OK)
                {
                    return;
                }

                //Get layer Center:
                string layerName;
                if (!KRCADLayer.HasLayer(KRCADLayer.LayerCenter.Item1))
                {
                    if (!KRCADLayer.CreateLayer(KRCADLayer.LayerCenter))
                    {
                        ed.WriteMessage("\nCannot create layer Center. Use layer '0' instead !");
                        layerName = "0";
                    }
                    else
                    {
                        layerName = KRCADLayer.LayerCenter.Item1;
                    }
                }
                else
                {
                    layerName = KRCADLayer.LayerCenter.Item1;
                }

                //Main transaction:
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Read boundary curve 1 & its closest point:
                    Curve boCurv1;
                    Point3d cloPnt1;
                    boCurv1 = GetCurveInNested(tr, ed, pner1, out cloPnt1);
                    if (boCurv1 == null)
                    {
                        ed.WriteMessage("\nCannot read boundary curve 1!");
                        tr.Abort();
                        return;
                    }

                    //Read boundary curve 2 & its closest point:
                    Curve boCurv2;
                    Point3d cloPnt2;
                    boCurv2 = GetCurveInNested(tr, ed, pner2, out cloPnt2);
                    if (boCurv2 == null)
                    {
                        ed.WriteMessage("\nCannot read boundary curve 2!");
                        tr.Abort();
                        return;
                    }

                    //Get tangent vectors in ECS:
                    Vector3d tangVt1Ecs = boCurv1.GetFirstDerivative(cloPnt1);
                    Vector3d tangVt2Ecs = boCurv2.GetFirstDerivative(cloPnt2);

                    using (Xline boXline1 = new Xline())
                    using (Xline boXline2 = new Xline())
                    {
                        //Get tangent vectors in WCS:
                        Vector3d tangVt1Wcs = tangVt1Ecs.TransformBy(pner1.Transform);
                        Vector3d tangVt2Wcs = tangVt2Ecs.TransformBy(pner2.Transform);

                        boXline1.BasePoint = cloPnt1.TransformBy(pner1.Transform);
                        boXline1.UnitDir = tangVt1Wcs;

                        boXline2.BasePoint = cloPnt2.TransformBy(pner2.Transform);
                        boXline2.UnitDir = tangVt2Wcs;

                        //Paralell:
                        if (tangVt1Wcs.IsParallelTo(tangVt2Wcs))
                        {
                            //Get PerpendicularVector (WCS):
                            Vector3d perVtWcs = tangVt1Wcs.GetPerpendicularVector();

                            //Create temp Perpendicular xline:
                            using (Xline perXline = new Xline())
                            {
                                perXline.BasePoint = boXline1.BasePoint;
                                perXline.UnitDir = perVtWcs;

                                Point3d startPnt, endPnt;
                                Point3dCollection intPnts = new Point3dCollection();
                                perXline.IntersectWith(boXline1, Intersect.OnBothOperands, intPnts, IntPtr.Zero, IntPtr.Zero);
                                if (intPnts.Count != 1)
                                {
                                    tr.Abort();
                                    return;
                                }
                                else
                                {
                                    startPnt = intPnts[0];
                                }

                                intPnts.Clear();
                                perXline.IntersectWith(boXline2, Intersect.OnBothOperands, intPnts, IntPtr.Zero, IntPtr.Zero);
                                if (intPnts.Count != 1)
                                {
                                    tr.Abort();
                                    return;
                                }
                                else
                                {
                                    endPnt = intPnts[0];
                                }

                                Vector3d transVt = startPnt.GetVectorTo(endPnt) / pir.Value;

                                

                                for (int i = 0; i < pir.Value - 1; i++)
                                {
                                    using (Xline newXline = (Xline)boXline1.Clone())
                                    {
                                        newXline.Layer = layerName;
                                        newXline.TransformBy(Matrix3d.Displacement(transVt*(i + 1)));
                                        AppendEnt(tr, newXline);
                                    }
                                }
                            }
                        }
                        //Intesection:
                        else
                        {
                            //Create new point collection for intersection:
                            Point3dCollection intPnts = new Point3dCollection();
                            boXline1.IntersectWith(boXline2, Intersect.OnBothOperands, intPnts, IntPtr.Zero, IntPtr.Zero);
                            if (intPnts.Count != 1)
                            {
                                tr.Abort();
                                return;
                            }
                            else
                            {
                                //Get intesection in WCS:
                                Point3d intPntWcs = intPnts[0];

                                Point3d cloPnt1Wcs, cloPnt2Wcs;
                                cloPnt1Wcs = cloPnt1.TransformBy(pner1.Transform);
                                cloPnt2Wcs = cloPnt2.TransformBy(pner2.Transform);

                                //Reset tangent vector by intersect point & closest point : 
                                tangVt1Wcs = intPntWcs.GetVectorTo(cloPnt1Wcs);
                                tangVt2Wcs = intPntWcs.GetVectorTo(cloPnt2Wcs);

                                //Get xyPlane in WCS:
                                Plane xyPlaneWcs = new Plane(intPntWcs, Vector3d.ZAxis.TransformBy(ed.CurrentUserCoordinateSystem));

                                //Get calculation angles (WCS):
                                double an, an1, an2;
                                an = tangVt1Wcs.GetAngleTo(tangVt2Wcs);
                                an1 = tangVt1Wcs.AngleOnPlane(xyPlaneWcs);
                                an2 = tangVt2Wcs.AngleOnPlane(xyPlaneWcs);
                                
                                //Get pitch angle:
                                double denta = an / pir.Value;
                                Point3d pt3;
                                for (int i = 0; i < pir.Value - 1; i++)
                                {
                                    if (an1 > an2)
                                    {
                                        if (an1 - an2 > PI)
                                        {
                                            pt3 = PolarPoints(intPntWcs, an2 - denta - i * denta, 50.0);
                                        }
                                        else
                                        {
                                            pt3 = PolarPoints(intPntWcs, an1 - denta - i * denta, 50.0);
                                        }
                                    }
                                    else
                                    {
                                        if (an2 - an1 > PI)
                                        {
                                            pt3 = PolarPoints(intPntWcs, an1 - denta - i * denta, 50.0);
                                        }
                                        else
                                        {
                                            pt3 = PolarPoints(intPntWcs, an2 - denta - i * denta, 50.0);
                                        }
                                    }

                                    using (Xline xl = new Xline())
                                    {
                                        xl.BasePoint = intPntWcs;
                                        xl.SecondPoint = pt3;
                                        xl.Layer = layerName;
                                        AppendEnt(tr, xl);
                                    }
                                }

                                #region [Old codes]
                                ////Get zAxis in curve1 ECS:
                                //Vector3d zAxisUcs = Vector3d.ZAxis;
                                //Vector3d zAxisWcs = zAxisUcs.TransformBy(ed.CurrentUserCoordinateSystem);
                                //Vector3d zAxisEcs = zAxisWcs.TransformBy(pner1.Transform.Inverse());

                                ////Get xyPlane in curve 1 ECS
                                //Plane xyPlaneEcs = new Plane(intPntEcs, zAxisEcs);

                                //double fullRotAngEcs = tangVt2Wcs.TransformBy(pner1.Transform.Inverse())
                                //                       .AngleOnPlane(xyPlaneEcs) -
                                //                       tangVt1Ecs.AngleOnPlane(xyPlaneEcs);

                                //double unitAngEcs = fullRotAngEcs / pir.Value;

                                ////Matrix3d rotMatEcs = Matrix3d.Rotation(unitAng, zAxisEcs, intPntEcs);

                                //for (int i = 0; i < pir.Value - 1 ; i++)
                                //{
                                //    using (Xline newXline = new Xline())
                                //    {
                                //        newXline.BasePoint = intPntWcs;
                                //        newXline.Layer = KRLayer.Center;

                                //        Matrix3d rotMatEcs = Matrix3d.Rotation(unitAngEcs * (i + 1), 
                                //                                               zAxisEcs, intPntEcs);
                                //        Vector3d tempVtEcs = tangVt1Ecs.TransformBy(rotMatEcs);

                                //        newXline.UnitDir = tempVtEcs.TransformBy(pner1.Transform);

                                //        AppendEnt(tr, newXline);
                                //    }
                                //}
                                #endregion

                            }
                        }
                    }

                    #region [Old codes]
                    //using (Xline boXline1 = new Xline())
                    //using (Xline boXline2 = new Xline())
                    //{
                    //    //Create temp xlines to find intersection (ECS):
                    //    boXline1.BasePoint = cloPnt1.TransformBy(pner1.Transform);
                    //    boXline1.UnitDir = tangVt1.TransformBy(pner1.Transform);
                    //    boXline1.TransformBy(pner1.Transform.Inverse());


                    //    boXline2.BasePoint = cloPnt2.TransformBy(pner2.Transform);
                    //    boXline2.UnitDir = tangVt2.TransformBy(pner2.Transform);
                    //    boXline2.TransformBy(pner2.Transform.Inverse());

                    //    //Iterate selection set and trim/ extend members :
                    //    foreach (SelectedObject sObj in acSSPrompt.Value)
                    //    {
                    //        if (sObj != null)
                    //        {
                    //            try
                    //            {
                    //                //Open member for read:
                    //                Curve sCurv = (Curve)tr.GetObject(sObj.ObjectId, OpenMode.ForRead);

                    //                //Create new temp line.
                    //                //if process success, then hangover the ids:
                    //                using (Line lObj = new Line())
                    //                {
                    //                    //Transform properties:
                    //                    lObj.SetPropertiesFrom(sCurv);

                    //                    //Create new point collection for intersection:
                    //                    Point3dCollection intPnts = new Point3dCollection();

                    //                    #region [Set start point]
                    //                    if (pner1.Status == PromptStatus.OK &&
                    //                        pner1.ObjectId.ObjectClass.Name != "AcDbCircle" &&
                    //                        pner1.ObjectId.ObjectClass.Name != "AcDbArc" &&
                    //                        pner1.ObjectId.ObjectClass.Name != "AcDbEllipse"
                    //                       )
                    //                    {
                    //                        using (Curve cCurv = (Curve)sCurv.Clone())
                    //                        {
                    //                            //Transform cloned curve WCS -> ECS:
                    //                            cCurv.TransformBy(pner1.Transform.Inverse());

                    //                            //Get intersection:
                    //                            cCurv.IntersectWith(boXline1, Intersect.ExtendBoth, intPnts, IntPtr.Zero, IntPtr.Zero);
                    //                            if (intPnts.Count == 0)
                    //                            {
                    //                                continue;
                    //                            }
                    //                            else
                    //                            {
                    //                                Point3d cloInPnt = intPnts[0];

                    //                                for (int i = 0; i < intPnts.Count; i++)
                    //                                {
                    //                                    Point3d tempPnt = intPnts[i];

                    //                                    #region [Old codes]
                    //                                    //double dist1 = tempPnt.DistanceTo(cloPnt1);
                    //                                    //double dist2 = cloInPnt.DistanceTo(cloPnt1);
                    //                                    //if (dist1 < dist2)
                    //                                    //{
                    //                                    //    cloInPnt = tempPnt;
                    //                                    //}
                    //                                    #endregion

                    //                                    Vector3d tempVt = cloPnt1.GetVectorTo(tempPnt);
                    //                                    if (tempVt.IsParallelTo(tangVt1))
                    //                                    {
                    //                                        cloInPnt = tempPnt;
                    //                                    }
                    //                                }

                    //                                lObj.StartPoint = cloInPnt.TransformBy(pner1.Transform);
                    //                            }
                    //                        }
                    //                    }
                    //                    else
                    //                    {
                    //                        if (pner1.ObjectId.ObjectClass.Name == "AcDbCircle")
                    //                        {
                    //                            lObj.StartPoint = sCurv.GetClosestPointTo(((Circle)boCurv1).Center, true);
                    //                        }
                    //                        else if (pner1.ObjectId.ObjectClass.Name == "AcDbArc")
                    //                        {
                    //                            lObj.StartPoint = sCurv.GetClosestPointTo(((Arc)boCurv1).Center, true);
                    //                        }
                    //                        else if (pner1.ObjectId.ObjectClass.Name == "AcDbEllipse")
                    //                        {
                    //                            lObj.StartPoint = sCurv.GetClosestPointTo(((Ellipse)boCurv1).Center, true);
                    //                        }
                    //                        else
                    //                        {
                    //                            lObj.StartPoint = sCurv.GetClosestPointTo(kwPnt1.TransformBy(ed.CurrentUserCoordinateSystem), true);
                    //                        }
                    //                    }
                    //                    #endregion

                    //                    #region [Set end point]
                    //                    //Reset intersection collection:
                    //                    intPnts.Clear();

                    //                    if (pner2.Status == PromptStatus.OK &&
                    //                        pner2.ObjectId.ObjectClass.Name != "AcDbCircle" &&
                    //                        pner2.ObjectId.ObjectClass.Name != "AcDbArc" &&
                    //                        pner2.ObjectId.ObjectClass.Name != "AcDbEllipse"
                    //                       )
                    //                    {
                    //                        using (Curve cCurv = (Curve)sCurv.Clone())
                    //                        {
                    //                            //Transform cloned form WCS -> ECS:
                    //                            cCurv.TransformBy(pner2.Transform.Inverse());

                    //                            //Find intersection:
                    //                            cCurv.IntersectWith(boXline2, Intersect.ExtendBoth, intPnts, IntPtr.Zero, IntPtr.Zero);
                    //                            if (intPnts.Count == 0)
                    //                            {
                    //                                continue;
                    //                            }
                    //                            else
                    //                            {
                    //                                Point3d cloInPnt = intPnts[0];

                    //                                for (int i = 0; i < intPnts.Count; i++)
                    //                                {
                    //                                    Point3d tempPnt = intPnts[i];
                    //                                    Vector3d tempVt = cloPnt2.GetVectorTo(tempPnt);
                    //                                    if (tempVt.IsParallelTo(tangVt2))
                    //                                    {
                    //                                        cloInPnt = tempPnt;
                    //                                    }
                    //                                }

                    //                                lObj.EndPoint = cloInPnt.TransformBy(pner2.Transform);
                    //                            }
                    //                        }
                    //                    }
                    //                    else
                    //                    {
                    //                        if (pner2.ObjectId.ObjectClass.Name == "AcDbCircle")
                    //                        {
                    //                            lObj.EndPoint = sCurv.GetClosestPointTo(((Circle)boCurv2).Center, true);
                    //                        }
                    //                        else if (pner2.ObjectId.ObjectClass.Name == "AcDbArc")
                    //                        {
                    //                            lObj.EndPoint = sCurv.GetClosestPointTo(((Arc)boCurv2).Center, true);
                    //                        }
                    //                        else if (pner2.ObjectId.ObjectClass.Name == "AcDbEllipse")
                    //                        {
                    //                            lObj.EndPoint = sCurv.GetClosestPointTo(((Ellipse)boCurv2).Center, true);
                    //                        }
                    //                        else
                    //                        {
                    //                            lObj.EndPoint = sCurv.GetClosestPointTo(kwPnt2.TransformBy(ed.CurrentUserCoordinateSystem), true);
                    //                        }
                    //                    }
                    //                    #endregion

                    //                    //Upgrate selected curve openmode -> ForWrite:
                    //                    sCurv.UpgradeOpen();

                    //                    //Exchange ids:
                    //                    sCurv.HandOverTo(lObj, true, true);
                    //                }
                    //            }
                    //            catch (System.Exception ex)
                    //            {
                    //                ed.WriteMessage(ex.Message);
                    //                return;
                    //            }
                    //        }
                    //    }
                    //}
                    #endregion

                    //Commit changes:
                    tr.Commit();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
            finally
            {
                if (curv1Highlighted == true && pner1 != null)
                {
                    KRUnhighlight.HighlightNested(db, ed, pner1, false);
                }

                if (curv2Highlighted == true && pner2 != null)
                {
                    KRUnhighlight.HighlightNested(db, ed, pner2, false);
                }
            }


        }

        //Tạo vòng tròn tự động từ giao điểm của đường tâm
        [CommandMethod("C326")]
        public void CmdC326()
        {
            //Document doc = AcAp.DocumentManager.MdiActiveDocument;
            //Base objects:
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            //Create type array:
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.LayerName, "CENTER"), 0);

            //Create selection filter:
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
            //ed.WriteMessage("\nSelect centers: ");

            //Create selection option:
            PromptSelectionOptions pso = new PromptSelectionOptions();
            pso.MessageForAdding = "\nCenters to add: ";
            pso.MessageForRemoval = "\nCenters to remove: ";
            pso.RejectObjectsOnLockedLayers = true;

            //Get selection result:
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso,acSelFtr);
            if (acSSPrompt.Status == PromptStatus.Cancel)
                return;
            else if(acSSPrompt.Status == PromptStatus.Error || 
                    acSSPrompt.Status == PromptStatus.None)
            {
                ed.WriteMessage("\nCannot get centers!");
                return;
            }

            PromptDoubleOptions pdo = new PromptDoubleOptions("\nDiameter: ")
            { 
                AllowArbitraryInput = false,
                AllowNone = true,
                AllowNegative = false, 
                AllowZero = false 
            };
            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status != PromptStatus.OK) 
                return;

            int len = acSSPrompt.Value.Count;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                for (int i = 0; i < len; i++)
                {
                    Entity ent = tr.GetObject(acSSPrompt.Value[i].ObjectId, OpenMode.ForRead) as Entity;
                    for (int j = i + 1; j < len; j++)
                    {
                        Entity ent1 = tr.GetObject(acSSPrompt.Value[j].ObjectId, OpenMode.ForRead) as Entity;
                        Point3dCollection pts3D = new Point3dCollection();
                        ent.IntersectWith(ent1, Intersect.OnBothOperands, pts3D, IntPtr.Zero, IntPtr.Zero);
                        foreach (Point3d pt in pts3D)
                        {
                            using (Circle cirobj = new Circle())
                            {
                                cirobj.Center = pt;
                                cirobj.Layer = "1";
                                cirobj.Radius = pdr.Value / 2;
                                btr.AppendEntity(cirobj);
                                tr.AddNewlyCreatedDBObject(cirobj, true);
                            }
                        }
                    }
                }
                tr.Commit();
            }
        }

        // Vẽ line vuông góc theo chiều dài xác định
        [Obsolete("Use VPT instead")]
        private void CmdC208()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Định nghĩa plane chuẩn ( TopPlain)
            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);

            //Chọn line chuẩn :
            PromptEntityOptions peo = new PromptEntityOptions("\n 基準の直線を選び: ");
            peo.SetRejectMessage("\n 選択が無効で、直線が必要です,");
            peo.AddAllowedClass(typeof(Line), false);
            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK) return;

            // chọn 1 điểm chuẩn :
            PromptPointOptions ppo = new PromptPointOptions("\n 基準点を選び:")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = new Point3d(0, 0, 0), UseBasePoint = true };
            PromptPointResult ppr = ed.GetPoint(ppo);
            if (ppr.Status != PromptStatus.OK) return;

            // Nhập khoảng cách:
            PromptDoubleOptions pdo = new PromptDoubleOptions("\n　距離を記入<0>: ")
            { AllowArbitraryInput = false, AllowNegative = true, AllowZero = true ,AllowNone =true};
            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status == PromptStatus.Cancel) return;
                
            // Nhập chiều dài:
            PromptDoubleOptions pdo1 = new PromptDoubleOptions("\n　長さを記入<100>:")
            { AllowArbitraryInput = false, AllowNegative = false, AllowZero = true,AllowNone=true };
            PromptDoubleResult pdr1 = ed.GetDouble(pdo1);
            if (pdr1.Status == PromptStatus.Cancel) return;

            Point3d pt1, pt2;
            Vector3d vt;
            double an;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                Line lobj = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Line;
                pt1 = per.PickedPoint;

                //Chuyển tọa độ điểm từ UCS sang WCS
                Matrix3d ucs = ed.CurrentUserCoordinateSystem;
                CoordinateSystem3d cs = ucs.CoordinateSystem3d;
                Matrix3d mat = Matrix3d.AlignCoordinateSystem(Point3d.Origin,
                                Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
                                cs.Origin, cs.Xaxis, cs.Yaxis, cs.Zaxis);
                pt1 = pt1.TransformBy(mat);

                pt2 = lobj.GetClosestPointTo(pt1, true);
                vt = pt2.GetVectorTo(pt1);
                an = vt.AngleOnPlane(plane);

                using (Line lobj1 = new Line())
                {
                    pt1 = ppr.Value.TransformBy(mat);

                    double an1;
                    if (lobj.EndPoint.X > lobj.StartPoint.X)
                    {
                        an1 = lobj.Angle;
                    }
                    else if (lobj.EndPoint.X<lobj.StartPoint.X)
                    {
                        an1 = lobj.Angle+Math.PI;
                    }
                    else if ((lobj.EndPoint.X==lobj.StartPoint.X) && (lobj.EndPoint.Y > lobj.StartPoint.Y))
                    {
                        an1 = lobj.Angle;
                    }
                    else
                    {
                        an1 = lobj.Angle+Math.PI;
                    }
                    if (pdr.Status == PromptStatus.None)
                    {
                        pt2 = PolarPoints(pt1, an1, 0);
                    }
                    else
                    {
                        pt2 = PolarPoints(pt1, an1, pdr.Value);
                    }
                    lobj1.StartPoint = pt2;
                    if (pdr1.Status == PromptStatus.None)
                    {
                        lobj1.EndPoint = PolarPoints(pt2, an, 100);
                    }
                    else
                    {
                        lobj1.EndPoint = PolarPoints(pt2, an, pdr1.Value);
                    }
                    btr.AppendEntity(lobj1);
                    tr.AddNewlyCreatedDBObject(lobj1, true);
                }
                tr.Commit();
            }
        }

        //Vẽ đường pháp tuyến với curve (Gộp 2 lệnh C208 & TV) :
        [CommandMethod("VPT")]
        public void cmdVPT()
        {
            //Document doc = CommonCommands.doc();
            Editor ed = CommonCommands.ed();
            Database db = CommonCommands.db();

            //Using KRResetUcs object to auto reset UCS when main process go out of its scope : 
            using (KRResetUCS myResetUCS = new KRResetUCS())
            {
                //Ask user to select curve :
                PromptEntityOptions peo = new PromptEntityOptions("\nSelect curve : ");
                peo.SetRejectMessage("\nInvalid selection. Please try again!");
                peo.AddAllowedClass(typeof(Curve), false);
                PromptEntityResult per = ed.GetEntity(peo);
                if (per.Status != PromptStatus.OK)
                    return;

                //Start main transaction :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Open curve object for read :
                    Curve curvObj = (Curve)tr.GetObject(per.ObjectId, OpenMode.ForRead);

                    //Get closest point to picked point :
                    Point3d cloPnt = curvObj.GetClosestPointTo(per.PickedPoint, true);

                    //Get tangent vector at closest point :
                    Vector3d tangVec = curvObj.GetFirstDerivative(cloPnt);

                    //Define plane to get vector angle ( Top Plain)
                    var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                    var plane = new Plane(Point3d.Origin, normal);

                    //Get vector angle :
                    double ang = tangVec.AngleOnPlane(plane);

                    ////Write angle :
                    //ed.WriteMessage("\nAngle:{0}", ang * 180.0 / PI);

                    //Get base point :
                    Point3d BasePt = cloPnt;
                    if (KRGetPoint(ed, "\nBase point <Picked point> : ",
                        Point3d.Origin, ref BasePt) == PromptStatus.Cancel)
                        return;

                    //Get distance :
                    double distance = 0.0;
                    if (KRGetDouble(ed, "\nDistance <0> : ",ref distance) 
                            == PromptStatus.Cancel )
                        return;

                    //Get length :
                    double leng = 100.0;
                    if (KRGetDouble(ed, "\nLength <100> : ", ref leng,
                        false,false) == PromptStatus.Cancel)
                        return;

                    //Get type of line (2 side / 1 side)
                    string drType = "";
                    if (KRGetKWords(ed, "\nSelect option : ", new List<string> { "Twoside", "Oneside" },ref drType)
                        == PromptStatus.Cancel)
                        return;

                    ////Write keyword :
                    //ed.WriteMessage("\nKeywords:{0}", drType);

                    //Draw line :
                    using (Line lineObj = new Line())
                    {
                        //Define angle to draw (left to right angle) :
                        double calAng = ang;
                        if (ang <= PI / 2.0 && ang >= 0)
                            calAng = ang;
                        else if (ang > 3.0* PI / 2.0 && ang <= 2.0 * PI)
                            calAng = ang;
                        else
                            calAng = ang + PI;

                        //Define points to draw :
                        Point3d midPnt, startPnt, endPnt;
                        midPnt = PolarPoints(BasePt, calAng, distance);

                        if (drType == "Twoside")
                        {
                            startPnt = PolarPoints(midPnt, calAng - PI / 2.0, leng / 2.0);
                            endPnt = PolarPoints(midPnt, calAng + PI / 2.0, leng / 2.0);
                        }
                        else
                        {
                            double pickAng;
                            double drAng;
                            //Vector3d secondDeri = curvObj.GetSecondDerivative(cloPnt);
                            Vector3d perVec = cloPnt.GetVectorTo(per.PickedPoint);
                            pickAng = perVec.AngleOnPlane(plane);

                            if (pickAng > 0 && pickAng <= PI)
                                drAng = PI / 2.0;
                            else
                                drAng = -PI / 2.0;

                            ////Write angle :
                            //ed.WriteMessage("\nAngle : {0}", drAng);

                            startPnt = midPnt;
                            endPnt = PolarPoints(startPnt, calAng + drAng, leng);
                        }
                        
                        lineObj.StartPoint = startPnt;
                        lineObj.EndPoint = endPnt;

                        //Add line to database :
                        AppendEnt(tr, lineObj);
                    }

                    //Commit changes :
                    tr.Commit();
                }
            }
        }

        //Lệnh vẽ Corner Scallop(KO trim biên dạng)
        [CommandMethod("C314")]
        public void CmdC314()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Định nghĩa plane chuẩn ( TopPlain)
            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);

            //Nhập bán kính Scallop:
            PromptDoubleOptions pdo = new PromptDoubleOptions("\n スカラップの半径: ")
            { AllowArbitraryInput = false, AllowNegative = false, AllowZero = false };
            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status != PromptStatus.OK) return;

            bool cont = true;
            while (cont == true)
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                    BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                    //Chọn line Chuẩn thứ nhất
                    PromptEntityOptions peo1 = new PromptEntityOptions("\n 基準直線<1>を選び:");
                    peo1.SetRejectMessage("\n 選択が無効で、直線が必要です,");
                    peo1.AddAllowedClass(typeof(Line), false);
                    PromptEntityResult per1 = ed.GetEntity(peo1);
                    if (per1.Status != PromptStatus.OK) return;
                    Line lobj1 = tr.GetObject(per1.ObjectId, OpenMode.ForRead) as Line;
                    lobj1.Highlight();

                    //Chọn line Chuẩn thứ hai
                    PromptEntityOptions peo2 = new PromptEntityOptions("\n 基準直線<2>を選び:");
                    peo2.SetRejectMessage("\n 選択が無効で、直線が必要です,");
                    peo2.AddAllowedClass(typeof(Line), false);
                    PromptEntityResult per2 = ed.GetEntity(peo2);
                    if (per2.Status != PromptStatus.OK) return;
                    Line lobj2 = tr.GetObject(per2.ObjectId, OpenMode.ForRead) as Line;
                    lobj2.Highlight();

                    Point3dCollection pts3D = new Point3dCollection();
                    lobj1.IntersectWith(lobj2, Intersect.ExtendBoth, pts3D, IntPtr.Zero, IntPtr.Zero);

                    if (pts3D.Count != 0)
                    {
                        foreach (Point3d pt in pts3D)
                        {
                            Point3d pt1, pt2;
                            pt1 = lobj1.GetClosestPointTo(per1.PickedPoint, true);
                            pt2 = lobj2.GetClosestPointTo(per2.PickedPoint, true);
                            Vector3d vt1, vt2;
                            vt1 = pt.GetVectorTo(pt1);
                            vt2 = pt.GetVectorTo(pt2);
                            double an1, an2;
                            an1 = vt1.AngleOnPlane(plane);
                            an2 = vt2.AngleOnPlane(plane);
                            //ed.WriteMessage("\n an1 value :{0}", an1);
                            //ed.WriteMessage("\n an2 value :{0}", an2);
                            //Định nghĩa plane bổ trợ
                            var plane1 = new Plane(pt, vt1, vt1.GetPerpendicularVector());

                            double DentaAngle = vt2.AngleOnPlane(plane1);
                            //ed.WriteMessage("\n DentaAngle value :{0}", DentaAngle);

                            if (DentaAngle > Math.PI)
                            {
                                DentaAngle = an1;
                                an1 = an2;
                                an2 = DentaAngle;
                            }
                            //ed.WriteMessage("\n an1 value :{0}", an1);
                            //ed.WriteMessage("\n an2 value :{0}", an2);
                            using (Arc arx1 = new Arc())
                            {
                                arx1.Center = pt;
                                arx1.Radius = pdr.Value;
                                arx1.StartAngle = an1;
                                arx1.EndAngle = an2;
                                btr.AppendEntity(arx1);
                                tr.AddNewlyCreatedDBObject(arx1, true);
                            }
                        }
                    }
                    lobj1.Unhighlight();
                    lobj2.Unhighlight();
                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }
            }
        }

        //Lệnh vẽ Corner Scallop(CÓ trim biên dạng)
        [CommandMethod("C317")]
        public void CmdC317()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            Application.SetSystemVariable("CMDECHO", 0);
            //Lưu lại giá trị fillet radius hiện hành:
            double fillrad = System.Convert.ToDouble(Application.GetSystemVariable("filletrad"));

            //Định nghĩa plane chuẩn ( TopPlain)
            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);

            //Nhập bán kính Scallop:
            PromptDoubleOptions pdo = new PromptDoubleOptions("\n スカラップの半径: ")
            { AllowArbitraryInput = false, AllowNegative = false, AllowZero = false };
            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status != PromptStatus.OK) return;

            bool cont = true;
            while (cont == true)
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                    BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                    //Chọn line Chuẩn thứ nhất
                    PromptEntityOptions peo1 = new PromptEntityOptions("\n 基準直線<1>を選び:");
                    peo1.SetRejectMessage("\n 選択が無効で、直線が必要です,");
                    peo1.AddAllowedClass(typeof(Line), false);
                    PromptEntityResult per1 = ed.GetEntity(peo1);
                    if (per1.Status != PromptStatus.OK) return;
                    Line lobj1 = tr.GetObject(per1.ObjectId, OpenMode.ForRead) as Line;
                    lobj1.Highlight();

                    //Chọn line Chuẩn thứ hai
                    PromptEntityOptions peo2 = new PromptEntityOptions("\n 基準直線<2>を選び:");
                    peo2.SetRejectMessage("\n 選択が無効で、直線が必要です,");
                    peo2.AddAllowedClass(typeof(Line), false);
                    PromptEntityResult per2 = ed.GetEntity(peo2);
                    if (per2.Status != PromptStatus.OK) return;
                    Line lobj2 = tr.GetObject(per2.ObjectId, OpenMode.ForRead) as Line;
                    lobj2.Highlight();

                    Point3dCollection pts3D = new Point3dCollection();
                    lobj1.IntersectWith(lobj2, Intersect.ExtendBoth, pts3D, IntPtr.Zero, IntPtr.Zero);

                    if (pts3D.Count != 0)
                    {
                        foreach (Point3d pt in pts3D)
                        {
                            Point3d pt1, pt2;
                            pt1 = lobj1.GetClosestPointTo(per1.PickedPoint, true);
                            pt2 = lobj2.GetClosestPointTo(per2.PickedPoint, true);
                            Vector3d vt1, vt2;
                            vt1 = pt.GetVectorTo(pt1);
                            vt2 = pt.GetVectorTo(pt2);
                            double an1, an2;
                            an1 = vt1.AngleOnPlane(plane);
                            an2 = vt2.AngleOnPlane(plane);
                            //Định nghĩa plane bổ trợ
                            var plane1 = new Plane(pt, vt1, vt1.GetPerpendicularVector());

                            double DentaAngle = vt2.AngleOnPlane(plane1);

                            if (DentaAngle > Math.PI)
                            {
                                DentaAngle = an1;
                                an1 = an2;
                                an2 = DentaAngle;
                            }
                            Arc arx1 = new Arc()
                            {
                                Center = pt,
                                Radius = pdr.Value,
                                StartAngle = an1,
                                EndAngle = an2
                            };
                            btr.AppendEntity(arx1);
                            tr.AddNewlyCreatedDBObject(arx1, true);

                            Application.SetSystemVariable("filletrad", 0);
                            ed.Command("_.fillet", pt1, pt2);
                            Application.SetSystemVariable("filletrad", fillrad);

                            Point3dCollection pts3D1 = new Point3dCollection();
                            arx1.IntersectWith(lobj1, Intersect.ExtendArgument, pts3D1, IntPtr.Zero, IntPtr.Zero);
                            if (pts3D1.Count != 0)
                            {
                                foreach (Point3d pt3 in pts3D1)
                                {
                                    if (lobj1.StartPoint == pt)
                                    {
                                        lobj1.StartPoint = pt3;
                                    }
                                    else
                                    {
                                        lobj1.EndPoint = pt3;
                                    }
                                }
                            }
                            Point3dCollection pts3D2 = new Point3dCollection();
                            arx1.IntersectWith(lobj2, Intersect.ExtendArgument, pts3D2, IntPtr.Zero, IntPtr.Zero);
                            if (pts3D2.Count != 0)
                            {
                                foreach (Point3d pt4 in pts3D2)
                                {
                                    if (lobj2.StartPoint == pt)
                                    {
                                        lobj2.StartPoint = pt4;
                                    }
                                    else
                                    {
                                        lobj2.EndPoint = pt4;
                                    }
                                }
                            }
                        }
                    }
                    lobj1.Unhighlight();
                    lobj2.Unhighlight();
                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }
            }
        }

        /// <summary>
        /// ----LỆNH DIM,ĐO ĐẠT,KIỂM TRA----
        /// </summary>
        #region[Lệnh đo độ dốc]
        [CommandMethod("D1")]
        public void CmdD1()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;

            PromptPointOptions prp1 = new PromptPointOptions("\n 開始の点を選んで下さい。")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = new Point3d(0, 0, 0),
                UseBasePoint = true
            };

            PromptPointResult prpr1 = ed.GetPoint(prp1);
            if (prpr1.Status != PromptStatus.OK) return;

            PromptPointOptions prp2 = new PromptPointOptions("\n 修了の点を選んで下さい。")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = prpr1.Value,
                UseBasePoint = true
            };

            PromptPointResult prpr2 = ed.GetPoint(prp2);
            if (prpr2.Status != PromptStatus.OK) return;

            double Dodoc;
            Dodoc = (Math.Abs(prpr2.Value.Y - prpr1.Value.Y) / Math.Abs(prpr2.Value.X - prpr1.Value.X)) * 100;
            ed.WriteMessage("\n 勾配: " + Dodoc.ToString() + "%");
        }
        #endregion

        #region[Lệnh đo độ dốc_ghi ra text]
        [CommandMethod("D11")]
        public void CmdD11()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptPointOptions ppo = new PromptPointOptions("");
            PromptPointResult ppr;

            //Get start point:
            Point3d startPntUcs, startPntWcs;
            ppo.Message = "\nStart point: ";
            ppo.AllowArbitraryInput = false;
            ppo.AllowNone = false;
            ppo.UseBasePoint = true;
            ppo.BasePoint = Point3d.Origin;

            ppr = ed.GetPoint(ppo);
            if (ppr.Status == PromptStatus.Cancel || 
                ppr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get start point!");
                return;
            }
            else
            {
                startPntUcs = ppr.Value;
                startPntWcs = startPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);
            }

            //Get end point:
            Point3d endPntUcs, endPntWcs;
            ppo.Message = "\nEnd point: ";
            ppo.BasePoint = startPntUcs;
            ppr = ed.GetPoint(ppo);
            if (ppr.Status == PromptStatus.Cancel ||    
                ppr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get end point!");
                return;
            }
            else
            {
                endPntUcs = ppr.Value;
                endPntWcs = endPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);
            }

            //Get slope angle:
            Vector3d dirVecWcs;
            dirVecWcs = startPntWcs.GetVectorTo(endPntWcs);

            CoordinateSystem3d CoorSysUcs = ed.CurrentUserCoordinateSystem.CoordinateSystem3d;
            Vector3d curUcsYAxis = CoorSysUcs.Yaxis;
            Vector3d curUcsZAxis = CoorSysUcs.Zaxis;

            Plane xyPlane = new Plane(Point3d.Origin, curUcsZAxis);
            double slopeAng = dirVecWcs.AngleOnPlane(xyPlane);

            //Get text content:
            string textcontent;
            if (dirVecWcs.IsCodirectionalTo(curUcsYAxis))
            {
                textcontent = "Infinity";
            }
            else
            {
                double slope;
                slope = Tan(slopeAng) * 100.0;
                if (slope > 0.0 && Abs(slope - 0.0) > KRTolerance)
                {
                    textcontent = Round(Abs(slope), 2) + "%" + "右上り";
                }
                else if (slope < 0.0 && Abs(slope - 0.0) > KRTolerance)
                {
                    textcontent = Round(Abs(slope), 2) + "%" + "左上り";
                }
                else
                {
                    textcontent = "レベル";
                }
            }

            //Check layer defpoints :
            string layerName;
            if (!KRCADLayer.HasLayer(KRCADLayer.LayerDefpoints.Item1))
            {
                if (!KRCADLayer.CreateLayer(KRCADLayer.LayerDefpoints))
                {
                    ed.WriteMessage("\nCannot create layer Defpoints. Use layer '0' instead !");
                    layerName = "0";
                }
                else
                {
                    layerName = KRCADLayer.LayerDefpoints.Item1;
                }
            }
            else
            {
                layerName = KRCADLayer.LayerDefpoints.Item1;
            }

            //Start main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Check text style :
                TextStyleTable txtStyleTb = tr.GetObject(db.TextStyleTableId, OpenMode.ForRead) as TextStyleTable;
                if (!txtStyleTb.Has(KRCADTextStyle.KRTextStyleName))
                {
                    //Import text style :
                    if (!KRCADTextStyle.ImportTextStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADTextStyle.KRTextStyleName))
                    {
                        ed.WriteMessage($"\nCannot import '{KRCADTextStyle.KRTextStyleName}' textstyle !");
                        tr.Abort();
                        return;
                    }
                }

                //Set textstyle to current :
                TextStyleTableRecord txtStyleTbRc = tr.GetObject(txtStyleTb[KRCADTextStyle.KRTextStyleName], OpenMode.ForRead) 
                                                        as TextStyleTableRecord;
                if (txtStyleTbRc.ObjectId != db.Textstyle)
                {
                    db.Textstyle = txtStyleTbRc.ObjectId;
                }

                //Add text:
                using (DBText actext = new DBText())
                {
                    actext.Normal = curUcsZAxis;

                    actext.Layer = layerName;

                    actext.Justify = AttachmentPoint.BaseCenter;

                    double van_num = ToDouble(GetSystemVariable("DIMSCALE"));
                    actext.Height = KRCADTextStyle.KRTextHeight * van_num;

                    actext.TextString = textcontent;

                    Point3d basePnt;
                    if (slopeAng > PI / 2.0 && slopeAng <= 3.0 * PI / 2.0)
                    {
                        basePnt = endPntWcs;
                        actext.Rotation = slopeAng + PI;
                    }
                    else
                    {
                        basePnt = startPntWcs;
                        actext.Rotation = slopeAng;
                    }

                    actext.AlignmentPoint = startPntWcs.TransformBy(Matrix3d.Displacement(
                                                    startPntWcs.GetVectorTo(endPntWcs) / 2.0));

                    AppendEnt(tr, actext);
                }

                //Commit changes:
                tr.Commit();
            }
        }

        [Obsolete("This method is obsolete. Use CmdD11 instead!")]
        public void CmdD11Old()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            #region [Get start point]
            Point3d startPnt;
            PromptPointOptions prp1 = new PromptPointOptions("\nStart point: ")
            {
                AllowArbitraryInput = false,
                AllowNone = false,
                BasePoint = Point3d.Origin,
                UseBasePoint = true
            };

            PromptPointResult prpr1 = ed.GetPoint(prp1);
            if (prpr1.Status != PromptStatus.OK)
                return;
            else
            {
                //Get start point in WCS:
                startPnt = prpr1.Value.TransformBy(ed.CurrentUserCoordinateSystem);
            }
            #endregion

            #region [Get end point]
            Point3d endPnt;
            PromptPointOptions prp2 = new PromptPointOptions("\nEnd point: ")
            {
                AllowArbitraryInput = false,
                AllowNone = false,
                BasePoint = prpr1.Value,
                UseBasePoint = true
            };

            PromptPointResult prpr2 = ed.GetPoint(prp2);
            if (prpr2.Status != PromptStatus.OK) 
                return;
            else
            {
                //Get end point in WCS:
                endPnt = prpr2.Value.TransformBy(ed.CurrentUserCoordinateSystem);
            }
            #endregion

            #region [Get text content]
            //Vector3d zAxisUcs = Vector3d.ZAxis;
            Vector3d dirVecUcs = prpr1.Value.GetVectorTo(prpr2.Value);

            //Vector3d xAxisUcs = Vector3d.XAxis;
            //Plane xyPlaneUcs = new Plane(Point3d.Origin, Vector3d.XAxis, Vector3d.YAxis);
            Vector3d xAxisUcs = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Xaxis;
            Vector3d yAxisUcs = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Yaxis;
            Plane xyPlaneUcs = new Plane(ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Origin ,
                                         xAxisUcs , yAxisUcs);

            double slopeAngUcs = dirVecUcs.AngleOnPlane(xyPlaneUcs) - xAxisUcs.AngleOnPlane(xyPlaneUcs);
            double slopeUcs = Tan(slopeAngUcs) * 100.0;

            //Get angle between UCS & WCS :
            double ucsWcsAng = UcsWcsAngle();

            //Get slope angle in WCS:
            double slopeAngWcs = slopeAngUcs + ucsWcsAng;

            //Get content:
            string textcontent;
            if (dirVecUcs.IsParallelTo(Vector3d.YAxis))
            {
                textcontent = "Infinity";
            }
            else
            {
                if (slopeUcs > 0.0 && Abs(slopeUcs - 0.0) > KRTolerance)
                {
                    textcontent = Round(Abs(slopeUcs), 2) + "%" + "右上り";
                }
                else if (slopeUcs < 0.0 && Abs(slopeUcs - 0.0) > KRTolerance)
                {
                    textcontent = Round(Abs(slopeUcs), 2) + "%" + "左上り";
                }
                else
                {
                    textcontent = "レベル";
                }
            }
            #endregion

            //Check layer defpoints :
            string layerName;
            if (!KRCADLayer.HasLayer(KRCADLayer.LayerDefpoints.Item1))
            {
                if (!KRCADLayer.CreateLayer(KRCADLayer.LayerDefpoints))
                {
                    ed.WriteMessage("\nCannot create layer Defpoints. Use layer '0' instead !");
                    layerName = "0";
                }
                else
                {
                    layerName = KRCADLayer.LayerDefpoints.Item1;
                }
            }
            else
            {
                layerName = KRCADLayer.LayerDefpoints.Item1;
            }

            //Start main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Check text style :
                TextStyleTable txtStyleTb = tr.GetObject(db.TextStyleTableId, OpenMode.ForRead) as TextStyleTable;
                if (!txtStyleTb.Has(KRCADTextStyle.KRTextStyleName))
                {
                    //Import text style :
                    if (!KRCADTextStyle.ImportTextStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADTextStyle.KRTextStyleName))
                    {
                        ed.WriteMessage($"\nCannot import '{KRCADTextStyle.KRTextStyleName}' textstyle !");
                        tr.Abort();
                        return;
                    }
                }

                //Set textstyle to current :
                TextStyleTableRecord txtStyleTbRc = tr.GetObject(txtStyleTb[KRCADTextStyle.KRTextStyleName], OpenMode.ForRead) as TextStyleTableRecord;
                if (txtStyleTbRc.ObjectId != db.Textstyle)
                {
                    db.Textstyle = txtStyleTbRc.ObjectId;
                }

                using (DBText actext = new DBText())
                {
                    double lent = startPnt.DistanceTo(endPnt) / 2.0;

                    double van_num = ToDouble(GetSystemVariable("DIMSCALE"));

                    actext.Justify = AttachmentPoint.BaseCenter;

                    actext.Height = KRCADTextStyle.KRTextHeight * van_num;
                    actext.TextString = textcontent;

                    Point3d basePnt;
                    if (slopeAngWcs > PI / 2.0 && slopeAngWcs <= 3.0 * PI / 2.0)
                    {
                        slopeAngWcs += PI;
                        basePnt = endPnt;
                    }
                    else
                    {
                        basePnt = startPnt;
                    }

                    actext.Rotation = slopeAngWcs;

                    actext.AlignmentPoint = PolarPoints(basePnt, actext.Rotation, lent);

                    actext.Layer = layerName;

                    //Set normal :
                    actext.Normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;

                    AppendEnt(tr, actext);
                }

                //Commit changes:
                tr.Commit();
            }
        }
        #endregion

        #region[Đo góc Xuất ra text]
        [CommandMethod("D3")]
        public void CmdD3()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptPointOptions ppo1 = new PromptPointOptions("\n 角度の原点をお選び : ")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = new Point3d(0, 0, 0), UseBasePoint = true };
            PromptPointResult ppr1 = ed.GetPoint(ppo1);
            if (ppr1.Status != PromptStatus.OK) return;

            PromptPointOptions ppo2 = new PromptPointOptions("\n 角度のVertexをお選び :")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = ppr1.Value, UseBasePoint = true };

            PromptPointResult ppr2a = ed.GetPoint(ppo2);
            if (ppr2a.Status != PromptStatus.OK) return;

            PromptPointResult ppr2b = ed.GetPoint(ppo2);
            if (ppr2b.Status != PromptStatus.OK) return;

            Vector3d vt12a, vt12b;

            vt12a = ppr1.Value.GetVectorTo(ppr2a.Value);
            vt12b = ppr1.Value.GetVectorTo(ppr2b.Value);
            double an = vt12a.GetAngleTo(vt12b);
            double deg, minu;
            deg = Math.Truncate(an * 180 / Math.PI);
            minu = an * 180 / Math.PI - deg;
            minu = Math.Round((minu * 60), 0);
            string txtcont = "θ=" + deg.ToString() + "%%d" + minu.ToString() + "'";
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Check layer :
                string layerName = "0";
                if (!KRCADLayer.HasLayer(KRCADLayer.LayerText.Item1))
                {
                    if (!KRCADLayer.CreateLayer(KRCADLayer.LayerText))
                    {
                        ed.WriteMessage($"\nCannot create '{KRCADLayer.LayerText.Item1}' layer. Use '0' layer instead !");
                        layerName = "0";
                    }
                    else
                    {
                        layerName = KRCADLayer.LayerText.Item1;
                    }
                }
                else
                {
                    layerName = KRCADLayer.LayerText.Item1;
                }

                //Check text style :
                TextStyleTable txtStyleTb = tr.GetObject(db.TextStyleTableId, OpenMode.ForRead) as TextStyleTable;
                if (!txtStyleTb.Has(KRCADTextStyle.KRTextStyleName))
                {
                    //Import text style :
                    if (!KRCADTextStyle.ImportTextStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADTextStyle.KRTextStyleName))
                    {
                        ed.WriteMessage($"\nCannot import '{KRCADTextStyle.KRTextStyleName}' textstyle!");
                        tr.Abort();
                        return;
                    }
                }

                //Set textstyle to current :
                TextStyleTableRecord txtStyleTbRc = tr.GetObject(txtStyleTb[KRCADTextStyle.KRTextStyleName], OpenMode.ForRead) as TextStyleTableRecord;
                if (txtStyleTbRc.ObjectId != db.Textstyle)
                {
                    db.Textstyle = txtStyleTbRc.ObjectId;
                }

                //BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                //BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;
                
                using (DBText txt = new DBText())
                {
                    double van_num = System.Convert.ToDouble(Application.GetSystemVariable("DIMSCALE"));
                    txt.TextString = txtcont;
                    txt.Height = KRCADTextStyle.KRTextHeight * van_num;
                    PromptPointOptions ppo3 = new PromptPointOptions("\nText location : ")
                    { AllowArbitraryInput = false, AllowNone = true, BasePoint = new Point3d(0, 0, 0), UseBasePoint = true };
                    PromptPointResult ppr30 = ed.GetPoint(ppo3);
                    if (ppr30.Status != PromptStatus.OK) return;

                    //Chuyển tọa độ điểm từ UCS sang WCS
                    Matrix3d ucs = ed.CurrentUserCoordinateSystem;
                    CoordinateSystem3d cs = ucs.CoordinateSystem3d;
                    Matrix3d mat = Matrix3d.AlignCoordinateSystem(Point3d.Origin,
                                    Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
                                    cs.Origin, cs.Xaxis, cs.Yaxis, cs.Zaxis);
                    Point3d ppr3 = ppr30.Value.TransformBy(mat);

                    txt.Position = ppr3;
                    txt.Layer = layerName;
                    btr.AppendEntity(txt);
                    tr.AddNewlyCreatedDBObject(txt, true);
                }
                tr.Commit();
            }
        }
        #endregion

        #region[Xuất text khoảng cách giữa 2 điểm kèm đường tâm]
        [CommandMethod("C320")]
        public void CmdC320()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);
            double van_num = System.Convert.ToDouble(Application.GetSystemVariable("dimscale"));
            PromptPointOptions prp1 = new PromptPointOptions("\n 開始の点を選んで下さい。")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = new Point3d(0, 0, 0),
                UseBasePoint = true
            };

            PromptPointResult prpr1 = ed.GetPoint(prp1);
            if (prpr1.Status != PromptStatus.OK) return;

            PromptPointOptions prp2 = new PromptPointOptions("\n 修了の点を選んで下さい。")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = prpr1.Value,
                UseBasePoint = true
            };

            PromptPointResult prpr2 = ed.GetPoint(prp2);
            if (prpr2.Status != PromptStatus.OK) return;

            Point3d pt0 = prpr1.Value;
            Point3d pt1 = prpr2.Value;
            double dis = prpr1.Value.DistanceTo(prpr2.Value);
            if (pt0.X > pt1.X)
            {
                pt0 = prpr2.Value;
                pt1 = prpr1.Value;
            }
            double an = pt0.GetVectorTo(pt1).AngleOnPlane(plane);
            Point3d pt = PolarPoints(pt0, an, dis / 2);
            pt = PolarPoints(pt, an + Math.PI / 2, van_num * 1.5);

            
            //Chuyển tọa độ điểm từ UCS sang WCS
            Matrix3d ucs = ed.CurrentUserCoordinateSystem;
            CoordinateSystem3d cs = ucs.CoordinateSystem3d;
            Matrix3d mat = Matrix3d.AlignCoordinateSystem(Point3d.Origin,
                            Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
                            cs.Origin, cs.Xaxis, cs.Yaxis, cs.Zaxis);
            pt = pt.TransformBy(mat);

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord bltr = tr.GetObject(blt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                using (Line acline = new Line())
                {
                    acline.StartPoint = prpr1.Value.TransformBy(mat);
                    acline.EndPoint = prpr2.Value.TransformBy(mat);
                    acline.Layer = "CENTER";
                    bltr.AppendEntity(acline);
                    tr.AddNewlyCreatedDBObject(acline, true);
                }

                using (DBText actext = new DBText())
                {
                    actext.Justify = AttachmentPoint.BaseCenter;
                    actext.AlignmentPoint = pt;
                    //actext.Position = pt;
                    actext.Height = 3.2 * van_num;
                    actext.TextString = Math.Round(dis, 1).ToString();
                    actext.Rotation = an;
                    actext.Layer = "Defpoints";
                    bltr.AppendEntity(actext);
                    tr.AddNewlyCreatedDBObject(actext, true);
                }
                tr.Commit();
            }
        }
        #endregion

        #region[Xuất text khoảng cách giữa 2 điểm]

        [CommandMethod("C322")]
        public void CmdC322()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);
            double van_num = System.Convert.ToDouble(Application.GetSystemVariable("dimscale"));
            PromptPointOptions prp1 = new PromptPointOptions("\n 開始の点を選んで下さい。")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = new Point3d(0, 0, 0),
                UseBasePoint = true
            };

            PromptPointResult prpr1 = ed.GetPoint(prp1);
            if (prpr1.Status != PromptStatus.OK) return;

            PromptPointOptions prp2 = new PromptPointOptions("\n 修了の点を選んで下さい。")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = prpr1.Value,
                UseBasePoint = true
            };

            PromptPointResult prpr2 = ed.GetPoint(prp2);
            if (prpr2.Status != PromptStatus.OK) return;

            Point3d pt0 = prpr1.Value;
            Point3d pt1 = prpr2.Value;
            double dis = prpr1.Value.DistanceTo(prpr2.Value);
            if (pt0.X > pt1.X)
            {
                pt0 = prpr2.Value;
                pt1 = prpr1.Value;
            }
            double an = pt0.GetVectorTo(pt1).AngleOnPlane(plane);
            Point3d pt = PolarPoints(pt0, an, dis / 2);
            pt = PolarPoints(pt, an + Math.PI / 2, van_num * 1.5);

            //Chuyển tọa độ điểm từ UCS sang WCS
            Matrix3d ucs = ed.CurrentUserCoordinateSystem;
            CoordinateSystem3d cs = ucs.CoordinateSystem3d;
            Matrix3d mat = Matrix3d.AlignCoordinateSystem(Point3d.Origin,
                            Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
                            cs.Origin, cs.Xaxis, cs.Yaxis, cs.Zaxis);
            pt = pt.TransformBy(mat);

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord bltr = tr.GetObject(blt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                using (DBText actext = new DBText())
                {
                    actext.Justify = AttachmentPoint.BaseCenter;
                    actext.AlignmentPoint = pt;
                    //actext.Position = pt;
                    actext.Height = 3.2 * van_num;
                    actext.TextString = Math.Round(dis, 1).ToString();
                    actext.Rotation = an;
                    actext.Layer = "Defpoints";
                    bltr.AppendEntity(actext);
                    tr.AddNewlyCreatedDBObject(actext, true);
                }
                tr.Commit();
            }
        }

        #endregion

        #region[Nhóm lệnh kéo leader lỗ]
        [CommandMethod("C328")]
        public void CmdC328()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptEntityOptions peo = new PromptEntityOptions("\n 基準の円を選び: ");
            peo.SetRejectMessage("\n 選択が無効で、円が必要です,");
            peo.AddAllowedClass(typeof(Circle), false);
            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK) return;
            Circle cirobj;
            double radi;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                cirobj = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Circle;
                cirobj.Highlight();
                radi = cirobj.Radius;
            }

            TypedValue[] acTypValAr = new TypedValue[3];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "CIRCLE"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "="), 1);
            acTypValAr.SetValue(new TypedValue(40, radi), 2);

            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;
            int n = 0;
            foreach (SelectedObject sobj in acSSPrompt.Value)
            {
                if (sobj != null)
                {
                    n++;
                }
            }
            PromptPointOptions ppo = new PromptPointOptions("\n Leaderの開始点 :")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = new Point3d(0, 0, 0),
                UseBasePoint = true
            };
            PromptPointResult ppr = ed.GetPoint(ppo);
            if (ppr.Status != PromptStatus.OK) return;

            PromptPointOptions ppo1 = new PromptPointOptions("\n Leaderの修了点 :")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = ppr.Value,
                UseBasePoint = true
            };

            PromptIntegerOptions pri = new PromptIntegerOptions("\n 加工面数　:")
            {
                AllowArbitraryInput = false,
                AllowNegative = false,
                AllowNone = true
            };

            PromptPointResult ppr1 = ed.GetPoint(ppo1);
            if (ppr1.Status != PromptStatus.OK) return;

            PromptIntegerResult prir = ed.GetInteger(pri);
            if (prir.Status != PromptStatus.OK) return;

            //Chuyển đổi tọa độ điểm leader sang WCS
            Point3d Point1 = ppr.Value;
            Point3d Point2 = ppr1.Value;
            CommonCommands.Ucs2Wcs(ref Point1);
            CommonCommands.Ucs2Wcs(ref Point2);

            double van_num = System.Convert.ToDouble(Application.GetSystemVariable("DIMSCALE"));
            string textcontent = prir.Value.ToString() + "x" + n.ToString() + "-%%c" + Math.Round((radi * 2), 1).ToString() + "孔";

            ObjectId LeaderId = ObjectId.Null;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord bltr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;

                //Tạo Mtext :
                MText mtxt = new MText();
                mtxt.TextHeight = 3.2 * van_num;
                mtxt.Location = PolarPoints(Point2, Math.PI / 2, 1.5 * van_num);
                mtxt.Contents = textcontent;
                mtxt.Width = textcontent.Length * 3.2 * van_num;
                mtxt.Layer = "TEXT";
                if (Point2.X >= Point1.X)
                {
                    mtxt.Attachment = AttachmentPoint.BottomLeft;
                }
                else
                {
                    mtxt.Attachment = AttachmentPoint.BottomRight;
                }
                bltr.AppendEntity(mtxt);
                tr.AddNewlyCreatedDBObject(mtxt, true);

                //Tạo Leader:
                Leader acLdr = new Leader();
                acLdr.AppendVertex(Point1);
                acLdr.AppendVertex(Point2);
                acLdr.HasArrowHead = true;
                bltr.AppendEntity(acLdr);
                tr.AddNewlyCreatedDBObject(acLdr,true);
                LeaderId = acLdr.ObjectId;

                //Gắn Mtext vào Leader:
                acLdr.Annotation = mtxt.ObjectId;
                acLdr.EvaluateLeader();
                cirobj.Unhighlight();
                tr.Commit();
            }

            //Leader acLdr;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                Leader LeaderObj = tr.GetObject(LeaderId, OpenMode.ForWrite) as Leader;
                LeaderObj.Dimscale = van_num;
                LeaderObj.Layer = "SCALE";
                tr.Commit();
            }
        }
        #endregion

        #region[Kéo leader hay dùng cho Top rail,Bottom rail]
        [CommandMethod("D6")]
        public void CmdD6()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Import layer,Dimstyle...vv:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Check layers :
                LayerTable lyrTb = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                System.Collections.Generic.List<Tuple<string, string, short, LineWeight>> layersInfo =
                    new System.Collections.Generic.List<Tuple<string, string, short, LineWeight>>();
                //layersInfo.Add(KRCADLayer.Layer1);
                //layersInfo.Add(KRCADLayer.LayerCenter);
                //layersInfo.Add(KRCADLayer.LayerHidden);
                layersInfo.Add(KRCADLayer.LayerScale);
                layersInfo.Add(KRCADLayer.LayerText);

                foreach (var member in layersInfo)
                {
                    if (!lyrTb.Has(member.Item1))
                    {
                        if (!KRCADLayer.CreateLayer(member))
                        {
                            ed.WriteMessage($"\nCannot create layer '{member.Item1}' !");
                            tr.Abort();
                            return;
                        }
                    }
                }

                //Check dimstyle :
                DimStyleTable dimStyleTb = tr.GetObject(db.DimStyleTableId, OpenMode.ForRead) as DimStyleTable;
                if (!dimStyleTb.Has(KRCADDimStyle.KRDimStyleName))
                {
                    //Import dim style :
                    if (!KRCADDimStyle.ImportDimStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADDimStyle.KRDimStyleName))
                    {
                        ed.WriteMessage($"\nCannot import '{KRCADDimStyle.KRDimStyleName}' dimstyle !");
                        tr.Abort();
                        return;
                    }
                }

                //Set dimstyle to current :
                //https://adndevblog.typepad.com/autocad/2012/04/creating-a-new-dimension-style-and-make-it-as-current.html
                DimStyleTableRecord dimStyleTbRc = tr.GetObject(dimStyleTb[KRCADDimStyle.KRDimStyleName], OpenMode.ForRead) as DimStyleTableRecord;
                if (dimStyleTbRc.ObjectId != db.Dimstyle)
                {
                    db.Dimstyle = dimStyleTbRc.ObjectId;
                    db.SetDimstyleData(dimStyleTbRc);
                }

                //Check text style :
                TextStyleTable txtStyleTb = tr.GetObject(db.TextStyleTableId, OpenMode.ForRead) as TextStyleTable;
                if (!txtStyleTb.Has(KRCADTextStyle.KRTextStyleName))
                {
                    //Import text style :
                    if (!KRCADTextStyle.ImportTextStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADTextStyle.KRTextStyleName))
                    {
                        ed.WriteMessage($"\nCannot import '{KRCADTextStyle.KRTextStyleName}' textstyle !");
                        tr.Abort();
                        return;
                    }
                }

                //Set textstyle to current :
                TextStyleTableRecord txtStyleTbRc = tr.GetObject(txtStyleTb[KRCADTextStyle.KRTextStyleName], OpenMode.ForRead) as TextStyleTableRecord;
                if (txtStyleTbRc.ObjectId != db.Textstyle)
                {
                    db.Textstyle = txtStyleTbRc.ObjectId;
                }

                tr.Commit();
            }

            //Get current DIMSCALE :
            double van_num = ToDouble(GetSystemVariable("DIMSCALE"));

            PromptKeywordOptions prk = new PromptKeywordOptions("")
            {
                Message = "\n ※パターンのお選び : " +
                      "\n 1)中間トップ用(TC)" + " || 端部トップ用(TT)" +
                      "\n 2)中間ボトム用(BC)" + " || 端部ボトム用(BT)" +
                      "\n 3)スリーブ用(S)" +
                      "\n 4)その他(TA)" +
                      "\n ______***Designed by Le Thuong Tri***_______ \n",
            };
            prk.Keywords.Add("TC");
            prk.Keywords.Add("TT");
            prk.Keywords.Add("BC");
            prk.Keywords.Add("BT");
            prk.Keywords.Add("S");
            prk.Keywords.Add("TA");
            PromptResult pr = ed.GetKeywords(prk);
            if (pr.Status != PromptStatus.OK) 
                return;

            bool cont = true;
            while (cont == true)
            {
                ObjectId LeaderId = ObjectId.Null;
                using (Transaction tr = doc.TransactionManager.StartTransaction())
                {
                    //Get current space :
                    BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, 
                        OpenMode.ForWrite) as BlockTableRecord;

                    //Create prompt point option for start point :
                    PromptPointOptions ppo = new PromptPointOptions("\nLeader's start point: ")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true,
                        BasePoint = new Point3d(0, 0, 0),
                        UseBasePoint = true
                    };

                    //Ask user to pick start point :
                    PromptPointResult ppr = ed.GetPoint(ppo);
                    if (ppr.Status != PromptStatus.OK) 
                        return;

                    //Get start point (WCS) :
                    Point3d startPnt = Ucs2Wcs(ppr.Value);

                    //Create prompt point option for end point :
                    PromptPointOptions ppo1 = new PromptPointOptions("\nLeader's end point: ")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true,
                        BasePoint = ppr.Value,
                        UseBasePoint = true
                    };

                    //Ask user to pick end point :
                    PromptPointResult ppr1 = ed.GetPoint(ppo1);
                    if (ppr1.Status != PromptStatus.OK) 
                        return;

                    //Get end point (WCS):
                    Point3d endPnt = Ucs2Wcs(ppr1.Value);

                    //Set text content :
                    string textcontent1 = "1x2-16x26長孔";
                    string textcontent2 = "(センター孔)";

                    //Create new instance of MText :
                    MText mtxt1 = new MText()
                    {
                        TextHeight = KRCADTextStyle.KRTextHeight * van_num,
                        //Location = PolarPoints(ppr1.Value, Math.PI / 2, 1.5 * van_num),
                        Location = PolarXYonUCS(endPnt, Math.PI / 2, 1.5 * van_num),
                        Rotation = 0.0, //<- angle on UCS 
                        Contents = textcontent1,
                        Width = textcontent1.Length * KRCADTextStyle.KRTextHeight * van_num,
                        //Layer = "TEXT"
                        Layer = KRCADLayer.LayerText.Item1

                    };

                    //if (ppr1.Value.X >= ppr.Value.X)
                    if (endPnt.X >= startPnt.X)
                        mtxt1.Attachment = AttachmentPoint.BottomLeft;
                    else
                        mtxt1.Attachment = AttachmentPoint.BottomRight;
                    btr.AppendEntity(mtxt1);
                    tr.AddNewlyCreatedDBObject(mtxt1, true);

                    //Create lower row ' text :
                    MText mtxt2 = (MText)mtxt1.Clone();
                    mtxt2.Contents = textcontent2;
                    btr.AppendEntity(mtxt2);
                    tr.AddNewlyCreatedDBObject(mtxt2, true);

                    //Point3d pt3d = new Point3d(0, 0, 0);
                    //Vector3d vt3dg = pt3d.GetVectorTo(new Point3d(0, -1 * (3.2 + 1.5 * 3) * van_num, 0));
                    //mtxt2.TransformBy(Matrix3d.Displacement(vt3dg));

                    Point3d pt3d = PolarXYonUCS(mtxt2.Location, -1.0 * Math.PI / 2, 
                        (KRCADTextStyle.KRTextHeight + KRCADTextStyle.KRTextGap * 3) * van_num);
                    mtxt2.Location = pt3d;

                    //Create new leader :
                    Leader acLdr = new Leader();
                    acLdr.AppendVertex(startPnt);
                    acLdr.AppendVertex(endPnt);
                    acLdr.HasArrowHead = true;
                    btr.AppendEntity(acLdr);
                    tr.AddNewlyCreatedDBObject(acLdr, true);
                    LeaderId = acLdr.ObjectId;
                    acLdr.Annotation = mtxt1.ObjectId;

                    if (pr.StringResult == "TT")
                        mtxt1.Contents = "1x1-16x26長孔";
                    else if (pr.StringResult == "BC")
                        mtxt1.Contents = "1x2-6x12長孔";
                    else if (pr.StringResult == "BT")
                        mtxt1.Contents = "1x1-6x12長孔";
                    else if (pr.StringResult == "S")
                    {
                        PromptDoubleOptions pdo = 
                            new PromptDoubleOptions("\n スリーブの長さ : ")
                            { 
                                AllowArbitraryInput = false, 
                                AllowNegative = false, 
                                AllowZero = false, 
                                AllowNone = false 
                            };

                        PromptDoubleResult pdr = ed.GetDouble(pdo);
                        if (pdr.Status != PromptStatus.OK) 
                            return;
                        mtxt1.Contents = "スリーブ取付";
                        mtxt2.Contents = "(L=" + pdr.Value.ToString() + ")";
                    }
                    else if (pr.StringResult == "TA")
                    {
                        //Xác định kiểu lỗ : lỗ dài / tròn.
                        PromptKeywordOptions prk1 = new PromptKeywordOptions("\n Select : ")
                        {
                            Message = "\n ※孔のタイプ : " +
                                      "\n 円の孔(E)" + " || 長孔(N)\n",
                        };
                        prk1.Keywords.Add("E");
                        prk1.Keywords.Add("N");
                        PromptResult pr1 = ed.GetKeywords(prk1);
                        if (pr1.Status != PromptStatus.OK) 
                            return;

                        //Xác định số mặt gia công ( gia công thông / ko thông)
                        PromptKeywordOptions prk2 = new PromptKeywordOptions("\n Select : ")
                        {
                            Message = "\n ※加工面数 : " +
                                      "\n 加工面数 = 1(1)" + " || 加工面数 = 2(2)\n",
                        };
                        prk2.Keywords.Add("1");
                        prk2.Keywords.Add("2");
                        PromptResult pr2 = ed.GetKeywords(prk2);
                        if (pr2.Status != PromptStatus.OK) 
                            return;

                        //Xác định số lỗ gia công trên 1 mặt
                        PromptDoubleOptions pdo1 = new PromptDoubleOptions("\n　片面上孔の数 : ")
                        { 
                            AllowArbitraryInput = false,
                            AllowNegative = false,
                            AllowNone = false, 
                            AllowZero = false 
                        };
                        PromptDoubleResult pdr1 = ed.GetDouble(pdo1);
                        if (pdr1.Status != PromptStatus.OK) 
                            return;

                        //Xác định kiểu phân bố của lỗ(kiểu center / kiểu Pitch)
                        PromptKeywordOptions prk3 = new PromptKeywordOptions("\n Select : ")
                        {
                            Message = "\n ※孔の配置 : " +
                                          "\n センター孔(C)" + " || ピッチ孔(P)\n",
                        };
                        prk3.Keywords.Add("C");
                        prk3.Keywords.Add("P");
                        PromptResult pr3 = ed.GetKeywords(prk3);
                        if (pr3.Status != PromptStatus.OK) 
                            return;

                        //Bắt đầu gắn giá trị cho text theo các thông số bên trên:
                        if (pr1.StringResult == "E")
                        {
                            //Xác định đường kính lỗ tròn:
                            PromptDoubleOptions pdoe = new PromptDoubleOptions("\n 穴径 : ")
                            { 
                                AllowArbitraryInput = false, 
                                AllowNegative = false, 
                                AllowNone = false, 
                                AllowZero = false 
                            };
                            PromptDoubleResult pdre = ed.GetDouble(pdoe);
                            if (pdre.Status != PromptStatus.OK) 
                                return;

                            mtxt1.Contents = pr2.StringResult + "x" + pdr1.Value.ToString() 
                                            + "-%%c" + pdre.Value.ToString();

                            if (pr2.StringResult == "1")
                                mtxt1.Contents += "孔";
                            else
                                mtxt1.Contents += "貫通孔";

                            if (pr3.StringResult == "C")
                                mtxt2.Contents = "(センター孔)";
                            else
                            {
                                //Xác định bước lỗ cho trường hợp lỗ phân bố theo pitch:
                                PromptDoubleOptions pdoe1 = new PromptDoubleOptions("\n 孔のピッチ : ")
                                { AllowArbitraryInput = false, AllowNegative = false, AllowNone = false, AllowZero = false };
                                PromptDoubleResult pdre1 = ed.GetDouble(pdoe1);
                                if (pdre1.Status != PromptStatus.OK) return;
                                mtxt2.Contents = "(P=" + pdre1.Value.ToString() + ")";
                            }
                        }
                        else
                        {
                            //Xác định bề rộng lỗ dài:
                            PromptDoubleOptions pdon = new PromptDoubleOptions("\n 孔の幅 : ")
                            { AllowArbitraryInput = false, AllowNegative = false, AllowNone = false, AllowZero = false };
                            PromptDoubleResult pdrn = ed.GetDouble(pdon);
                            if (pdrn.Status != PromptStatus.OK) return;

                            //Xác định chiều dài lỗ dài:
                            PromptDoubleOptions pdon1 = new PromptDoubleOptions("\n 孔の長さ : ")
                            { AllowArbitraryInput = false, AllowNegative = false, AllowNone = false, AllowZero = false };
                            PromptDoubleResult pdrn1 = ed.GetDouble(pdon1);
                            if (pdrn1.Status != PromptStatus.OK) return;

                            mtxt1.Contents = pr2.StringResult + "x" + pdr1.Value.ToString() + "-" + pdrn.Value.ToString() + "x" + pdrn1.Value.ToString();

                            if (pr2.StringResult == "1")
                            {
                                mtxt1.Contents += "長孔";
                            }
                            else
                            {
                                mtxt1.Contents += "貫通長孔";
                            }

                            if (pr3.StringResult == "C")
                            {
                                mtxt2.Contents = "(センター孔)";
                            }
                            else
                            {
                                //Xác định bước lỗ cho trường hợp lỗ phân bố theo pitch:
                                PromptDoubleOptions pdon2 = new PromptDoubleOptions("\n 孔のピッチ : ")
                                { AllowArbitraryInput = false, AllowNegative = false, AllowNone = false, AllowZero = false };
                                PromptDoubleResult pdrn2 = ed.GetDouble(pdon2);
                                if (pdrn2.Status != PromptStatus.OK) return;
                                mtxt2.Contents = "(P=" + pdrn2.Value.ToString() + ")";
                            }
                        }

                    }

                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    Leader LeaderObj = tr.GetObject(LeaderId, OpenMode.ForWrite) as Leader;
                    LeaderObj.Dimscale = van_num;
                    //LeaderObj.Layer = "SCALE";
                    LeaderObj.Layer = KRCADLayer.LayerScale.Item1;
                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }

            }
        }
        #endregion

        //Chọn đối tượng , hiện ra thuộc tính cơ bản
        [CommandMethod("STY")]
        public void CmdShowtype()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;
            PromptEntityOptions pr = new PromptEntityOptions("\n オブジェクトを選択:")
            { AllowNone = true };
            PromptEntityResult prr = ed.GetEntity(pr);
            if (prr.Status != PromptStatus.OK) return;
            using (Transaction tr = db.TransactionManager.StartTransaction())

            {
                Entity ent = tr.GetObject(prr.ObjectId, OpenMode.ForRead) as Entity;
                //var nam = ent.GetType().Name;
                ed.WriteMessage("\n オブジェクトの情報 :" +
                                "\n _____________________________________" +
                                "\n オブジェクト名: " + ent.GetType().Name +
                                "\n LAYER: " + ent.Layer +
                                "\n COLOR: " + ent.Color +
                                "\n ___***Designed by Le Thuong Tri***___");
                tr.Commit();
            }
        }

        //Ghi Text theo 1 line
        [CommandMethod("C321")]
        public void CmdC321()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Định nghĩa plane chuẩn ( TopPlain)
            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);

            //Lấy Giá trị Dimscale hiện hành:
            double van_num = System.Convert.ToDouble(Application.GetSystemVariable("DIMSCALE"));

            //Chọn line chuẩn :
            PromptEntityOptions peo = new PromptEntityOptions("\n 基準の直線を選び: ");
            peo.SetRejectMessage("\n 選択が無効で、直線が必要です,");
            peo.AddAllowedClass(typeof(Line), false);
            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK) return;

            PromptStringOptions pso = new PromptStringOptions("\n 中身を記載: ")
            { AllowSpaces = true };
            PromptResult pr = ed.GetString(pso);
            if (pr.Status != PromptStatus.OK) return;

            Point3d pt1, pt2;
            Vector3d vt;
            double an;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                pt1 = per.PickedPoint;
                Line lobj = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Line;
                pt2 = lobj.GetClosestPointTo(pt1, true);
                vt = pt2.GetVectorTo(pt1);
                an = vt.AngleOnPlane(plane);
               
                double an1;
                if (lobj.EndPoint.X > lobj.StartPoint.X)
                {
                    an1 = lobj.Angle;
                }
                else if (lobj.EndPoint.X < lobj.StartPoint.X)
                {
                    an1 = lobj.Angle + Math.PI;
                }
                else if ((lobj.EndPoint.X == lobj.StartPoint.X) && (lobj.EndPoint.Y > lobj.StartPoint.Y))
                {
                    an1 = lobj.Angle;
                }
                else
                {
                    an1 = lobj.Angle + Math.PI;
                }
                double denta;
                if (pt1.Y > pt2.Y)
                {
                    denta = 1.5 * van_num;
                }
                else if(pt1.Y < pt2.Y)
                {
                    denta = (1.5 + 3.2) * van_num;
                }
                else if ((pt1.Y == pt2.Y) && (pt1.X>pt2.X))
                {
                    denta = (1.5 + 3.2) * van_num;
                }
                else
                {
                    denta = 1.5 * van_num;
                }

                using (DBText txt = new DBText())
                {
                    txt.Height = 3.2 * van_num;
                    txt.Position = PolarPoints(pt2, an, denta);
                    txt.TextString = pr.StringResult;
                    txt.Rotation = an1;
                    txt.Layer = "TEXT";
                    btr.AppendEntity(txt);
                    tr.AddNewlyCreatedDBObject(txt, true);
                }
                tr.Commit();
            }
        }

        //Dim kích thước kèm bước/ Dim liên tục
        [CommandMethod("CDI5")]
        public void CmdCDI5()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Định nghĩa plane chuẩn ( TopPlain)
            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);

            //Thiết lập không hiện kết quả trung gian lên cửa sổ lệnh:
            Application.SetSystemVariable("CMDECHO", 0);
            //lưu lại giá trị của Dimscale
            double van_num = (double)AcAp.GetSystemVariable("Dimscale");

            //Định điểm 1 của vector chỉ phương:
            PromptPointOptions ppo1 = new PromptPointOptions("\n 方向ベクトルの第 1 ポイント(原点):")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = new Point3d(0, 0, 0), UseBasePoint = true };
            PromptPointResult ppr1 = ed.GetPoint(ppo1);
            if (ppr1.Status != PromptStatus.OK) return;
            //Định điểm 2 của vector chỉ phương:
            PromptPointOptions ppo2 = new PromptPointOptions("\n 方向ベクトルの第 2 ポイント:")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = ppr1.Value, UseBasePoint = true };
            PromptPointResult ppr2 = ed.GetPoint(ppo2);
            if (ppr2.Status != PromptStatus.OK) return;
            PromptDoubleOptions pdo = new PromptDoubleOptions("\n 丸めの単位<0.1>:")
            { AllowArbitraryInput = false, AllowNegative = false, AllowNone = true, AllowZero = true };
            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status == PromptStatus.Cancel) return;

            Vector3d vt = ppr1.Value.GetVectorTo(ppr2.Value);
            Double an = vt.AngleOnPlane(plane);
            
            //Định điểm bắt đầu đim kích thước:
            PromptPointOptions ppo3 = new PromptPointOptions("\n 寸法チェーンの開始点:")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = ppr1.Value, UseBasePoint = true };
            PromptPointResult ppr3 = ed.GetPoint(ppo3);
            if (ppr3.Status != PromptStatus.OK) return;

            PromptPointResult ppr4 = ppr3;
            Point3dCollection p3dc = new Point3dCollection
            {
                ppr3.Value
            };
            //Point3d pt1 = ppr3.Value;
            while (ppr4 != null)
            {
                PromptPointOptions ppo4 = new PromptPointOptions("\n 寸法チェーンの次の点:")
                { AllowArbitraryInput = false, AllowNone = true, BasePoint = ppr3.Value, UseBasePoint = true };
                ppr4 = ed.GetPoint(ppo4);
                if (ppr4.Status != PromptStatus.OK) break;
                p3dc.Add(ppr4.Value);
                ppr3 = ppr4;
            }
            double[] arr = new double[p3dc.Count-1];
            for (int i = 0; i < p3dc.Count-1; i++)
            {
                arr[i] = Math.Round(p3dc[i].DistanceTo(p3dc[i + 1]) * Math.Cos(an),1);
            }

            //Định điểm đặt kích thước dự phòng(Nếu không nhập bấm enter thì lấy điểm genten làm điểm đặt):
            PromptPointOptions ppo1b = new PromptPointOptions("\n 寸法の位置<原点>:")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = ppr1.Value, UseBasePoint = true };
            PromptPointResult ppr1b = ed.GetPoint(ppo1b);
            if (ppr1b.Status == PromptStatus.Cancel) return;
          
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                //Định nghĩa 1 mảng chứa tất cả các kích thước 
                List<RotatedDimension> ListDim = new List<RotatedDimension>();
                //Dim ra từng kích thước và lưu vào mảng ListDim
                for (int i = 0; i < p3dc.Count - 1; i++)
                {

                    RotatedDimension acRotDim = new RotatedDimension
                    {
                        XLine1Point = p3dc[i],
                        XLine2Point = p3dc[i + 1],
                        Rotation = an,
                        //DimLinePoint = ppr1.Value,
                        DimensionStyle = db.Dimstyle,
                        Dimscale = van_num,
                        Layer = "SCALE"
                    };
                    if (ppr1b.Status == PromptStatus.None)
                    {
                        acRotDim.DimLinePoint = ppr1.Value;
                    }
                    else
                    {
                        acRotDim.DimLinePoint = ppr1b.Value;
                    }
                    btr.AppendEntity(acRotDim);
                    tr.AddNewlyCreatedDBObject(acRotDim, true);
                    ListDim.Add(acRotDim);
                }
                int n = ListDim.Count;
                double val;
                int count = 1;
                for (int i = 1; i < n - 1; i++)
                {
                    if (Math.Abs(ListDim[i].Measurement - ListDim[i - 1].Measurement) > 0.1) continue;
                    else
                    {
                        val = ListDim[i].Measurement;
                        //làm tròn giá trị bước

                        if (pdr.Status == PromptStatus.None)
                        {
                            val = Math.Round(val * 1 / 0.1, MidpointRounding.AwayFromZero) * 0.1;
                        }
                        else if(pdr.Value == 0)
                        {
                            val = Math.Round(val, 0);
                        }
                        else
                        {
                            val = Math.Round(val * 1 / pdr.Value, MidpointRounding.AwayFromZero) * pdr.Value;
                        }
                        do
                        {
                            ListDim[i].XLine1Point = ListDim[i - 1].XLine1Point;
                            ListDim[i - 1].Erase();
                            count += 1;
                            ListDim[i].DimensionText = count.ToString() + "@" + Math.Round(val,1).ToString() + "=<>";
                            i += 1;
                            if (i == n) break;
                        } while (Math.Abs(ListDim[i].Measurement - val) < 0.1);
                        count = 1;
                    }
                }
                tr.Commit();
            }
        }

        //Quét chọn Nhiều Text/Mtext, Tạo Table thống kê chủng loại + số lượng
        #region [Command ABTK]
        [CommandMethod("ABTK", CommandFlags.UsePickSet)]
        public void CmdABTK()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Create a TypedValue array to define the filter criteria :
            TypedValue[] acTypValAr = new TypedValue[5];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 3);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);

            //Create new selection filter from above TypedValue 's array :
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
     
            //Ask user to select on screen with above selection filter :
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            //Check prompt return value :
            if (acSSPrompt.Status != PromptStatus.OK ||
                acSSPrompt.Value.Count == 0)
            {
                ed.WriteMessage("\nYou selected nothing !");
                return;
            }

            //Create list to contain raw data :
            List<string> lst = new List<string>();

            //Create list to contain not overlapping text :
            List<string> lst1;

            //Create list to contain quantity for each text :
            List<int> lst2 = new List<int>();

            //Ask user to pick a point :
            PromptPointOptions ppo = new PromptPointOptions("\n原点の選択 : ")
            {
                AllowArbitraryInput = false,
                AllowNone = false,
                BasePoint = new Point3d(0, 0, 0),
                UseBasePoint = true
            };
            PromptPointResult ppr;

            //Turn off ortho mode & get pick point:
            using (KRResetSystemVar myResetORTHO = new KRResetSystemVar("ORTHOMODE",0))
            {
                ppr = ed.GetPoint(ppo);
                if (ppr.Status != PromptStatus.OK)
                    return;
            }

            //Start transaction for iterate selection set then
            //Get mark & mark 's count : 
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Iterate selection set :
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    //Just get object not NULL :
                    if (sobj != null)
                    {
                        //Get entity :
                        Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForRead);

                        //Get content :
                        string content;
                        if (ent.GetType().Name.ToString() == "MText")
                            content = ((MText)ent).Text; //<- get text with format removed 
                        else if (ent.GetType().Name.ToString() == "DBText")
                            content = ((DBText)ent).TextString;
                        else
                        {
                            //Get dimension 's text override :
                            content = ((Dimension)ent).DimensionText;

                            //Create Mtext 's temp object then 
                            // - Set its content = dimension text .
                            // - Remove format
                            // - Get removed format text 's string .
                            MText tempObj = new MText();
                            tempObj.Contents = content;
                            content = tempObj.Text;

                            //If dimension 's text hasn't been overrided then
                            //for simple , put its text = "Dimension"
                            if (content.Trim() == "" || content.Trim() == "<>")
                            {
                                //NumberFormatInfo setPrecision = new NumberFormatInfo();
                                //setPrecision.NumberDecimalDigits = 2; //<set precision to 2
                                //content = (((Dimension)ent).Measurement).
                                //    ToString("N",setPrecision);
                                content = "Dimension";
                            }
                        }

                        //Check whether content contains '@' :
                        if (content.Contains('@'))
                        {
                            int textNums;
                            string[] result = content.Split('@');

                            if (result.Length == 2 &&
                                int.TryParse(result[0], out textNums) == true)
                            {
                                for (int i = 0; i < textNums; i++)
                                {
                                    lst.Add(result[1].Trim());
                                }
                            }
                        }
                        else
                        {
                            lst.Add(content.Trim());
                        }
                    }
                }
            }

            //Remove overlap text in raw list :
            lst1 = lst.Distinct().ToList();

            //Sort text in lst1 in alphabet order :
            //lst1.Sort((x, y) => string.Compare(x, y));

            try
            {
                lst1.Sort(new CustomStringComparer());
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage("\nCannot sort <Key,value>. Error: " + ex.ToString());
                return;
            }
            //To sort decending
            //input.Reverse();

            //Get item numbers :
            int n = 0;
            foreach (string element1 in lst1)
            {
                foreach (string element in lst)
                {
                    if (element == element1)
                    {
                        n += 1;
                    }
                }
                lst2.Add(n);
                n = 0;
            }

            //Point3d basePnt = ppr.Value;
            Point3d basePnt = Ucs2Wcs(ppr.Value);

            if (lst1.Count == 1)
            {
                if (!K230_AddTable(lst1, lst2, ref basePnt))
                {
                    ed.WriteMessage("\nCannot create table !");
                    return;
                }
            }
            else
            {
                //We divide origin list of mark into small lists , then
                //add table for each small list .
                //For example :
                // {S1, S2 , S3 , S4 } {Q1 , Q2 , Q3} {P1 , P2 , P3}
                List<string> keys = new List<string>();
                List<int> values = new List<int>();
                bool checkBool;

                for (int i = 0; i < lst1.Count - 1; i++)
                {
                    //Add items to keys & values :
                    keys.Add(lst1[i]);
                    values.Add(lst2[i]);

                    if ((lst1[i])[0] != (lst1[i + 1])[0])
                    {
                        //Add table :
                        checkBool = K230_AddTable(keys, values, ref basePnt);
                        if (!checkBool)
                            return;

                        //Allocate new list of keys & values :
                        keys = new List<string>();
                        values = new List<int>();
                    }
                }

                if ((lst1[lst1.Count - 1])[0] != (lst1[lst1.Count - 2])[0])
                {
                    //Allocate new list of keys & values :
                    keys = new List<string>();
                    values = new List<int>();
                }

                //Add items to keys & values :
                keys.Add(lst1[lst1.Count - 1]);
                values.Add(lst2[lst1.Count - 1]);

                //Add table :
                checkBool = K230_AddTable(keys, values, ref basePnt);
                if (!checkBool)
                {
                    ed.WriteMessage("\nCannot create table !");
                    return;
                }

                #region [Try-Catch]
                /*
                Below code using try -catch but it have error which
                I'm finding now !

                for (int i = 0; i < lst1.Count; i++)
                {
                    keys.Add(lst1[i]);
                    values.Add(lst2[i]);
                    try
                    {
                        if ((lst1[i])[0] != (lst1[i + 1])[0])
                        {
                            K230_AddTable(keys, values, ref basePnt);
                            keys = new List<string>();
                            values = new List<int>();
                        }
                    }

                    catch (System.Exception)
                    {
                        if ((lst1[lst1.Count - 1])[0] != (lst1[lst1.Count - 2])[0])
                        {
                            keys = new List<string>();
                            values = new List<int>();
                        }
                        keys.Add(lst1[lst1.Count - 1]);
                        values.Add(lst2[lst1.Count - 1]);
                        K230_AddTable(keys, values, ref basePnt);
                    }
                }
                */
                #endregion
            }
        }

        //Function to return prefix of string :
        string GetSuffix(string strWithNum) //<- save for next time 
                                            //This function receive string with format like
                                            // KA01 , KA02 , KA11 ...vv then return prefix :
                                            // KA ...vv
        {
            int strLen = strWithNum.Length;
            string suffix = "";

            for (int i = 0; i < strLen; i++)
            {
                if (!Char.IsDigit(strWithNum[i]))
                    suffix += strWithNum[i];
                else
                    break;
            }

            return suffix;
        }

        //Sub function for command [ABTK] : 
        bool K230_AddTable(List<string> keys, List<int> values, ref Point3d basePnt)
        {
            //Declare return value :
            bool retVal = false;

            //Get list length ;
            int len = keys.Count;

            //Variable for table id :
            ObjectId tableId;

            //Variables for common use :
            double dimSc;       // current dimscale 
            double textHeight;  // text height
            double rowHeight;   // row height
            double colWidth;    // column width 

            Document doc = CommonCommands.doc();
            Database db = doc.Database;

            //Try to create table :
            try
            {
                //Transaction for creating table :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Check text style :
                    TextStyleTable txtTb = tr.GetObject(db.TextStyleTableId, OpenMode.ForRead) as TextStyleTable;
                    if (!txtTb.Has(KRCADTextStyle.KRTextStyleName))
                    {
                        if (!KRCADTextStyle.ImportTextStyleFromFile(CommonDeclaration.GetCommonBlkPath(),KRCADTextStyle.KRTextStyleName))
                        {
                            tr.Abort();
                            return false;
                        }
                    }

                    //Set text style to current :
                    if (db.Textstyle != txtTb[KRCADTextStyle.KRTextStyleName])
                    {
                        db.Textstyle = txtTb[KRCADTextStyle.KRTextStyleName];
                    }

                    //Check table style :
                    DBDictionary dbDic = tr.GetObject(db.TableStyleDictionaryId, OpenMode.ForRead) as DBDictionary;
                    ObjectId tbStyleId = ObjectId.Null;
                    if (!dbDic.Contains(KRCADTableStyle.KRTableStyleName))
                    {
                        if (!KRCADTableStyle.ImportTableStyleFromFile(CommonDeclaration.GetCommonBlkPath(),KRCADTableStyle.KRTableStyleName))
                        {
                            tr.Abort();
                            return false;
                        }
                    }

                    tbStyleId = dbDic.GetAt(KRCADTableStyle.KRTableStyleName);
                    if (tbStyleId == ObjectId.Null)
                    {
                        tr.Abort();
                        return false;
                    }

                    //Activate table style :
                    if (db.Tablestyle != tbStyleId)
                    {
                        db.Tablestyle = tbStyleId;
                    }

                    //Check layer :
                    LayerTable lyrTb = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                    if (!lyrTb.Has(KRCADLayer.LayerScale.Item1))
                    {
                        if (!KRCADLayer.CreateLayer(KRCADLayer.LayerScale))
                        {
                            tr.Abort();
                            return false;
                        }
                    }

                    BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                    BlockTableRecord btr = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId,
                        OpenMode.ForWrite);

                    //Define a variable for autocad table :
                    Table tb = new Table();
                    tableId = tb.ObjectId;

                    //Get dimscale :
                    if (db.CurrentSpaceId == bt[BlockTableRecord.ModelSpace])
                        dimSc = ToDouble(GetSystemVariable("DIMSCALE"));
                    else
                        dimSc = 1.0;

                    //Define table row height :
                    textHeight = KRCADTextStyle.KRTextHeight * dimSc;
                    rowHeight = textHeight * 4.0;
                    colWidth = textHeight * 6.0;

                    //Set attribute for table :
                    tb.Layer = KRCADLayer.LayerScale.Item1;
                    tb.TableStyle = db.Tablestyle;
                    tb.SetSize(len + 3, 2);    //<- Set rows & column numbers 
                    tb.SetRowHeight(rowHeight);
                    tb.SetColumnWidth(colWidth);
                    tb.Position = basePnt;

                    //Make Header :
                    tb.Cells[0, 0].TextString = "マーク表";
                    tb.Cells[1, 0].TextString = "合番";
                    tb.Cells[1, 1].TextString = "数量";

                    //Add data to table :
                    for (int i = 2; i < len + 2; i++)
                    {
                        //Add data from keys :
                        tb.Cells[i, 0].TextString = keys[i - 2];

                        //Add data from values : 
                        tb.Cells[i, 1].TextString = values[i - 2].ToString();
                    }

                    //Add Sum of all mark 's count :
                    tb.Cells[tb.Rows.Count - 1, 0].TextString = "全数量";
                    tb.Cells[tb.Rows.Count - 1, 1].TextString = (values.Sum()).ToString();

                    //Get table space :
                    double tableSpace = textHeight * 6.0 + tb.Width;

                    //Get next base point :
                    basePnt = PolarXYonUCS(basePnt, 0.0, tableSpace);

                    //Rotate table :
                    RotateEntXYonWcs(tb, basePnt, 0.0);

                    //Add table to database :
                    tableId = btr.AppendEntity(tb);

                    //And to the transaction, which we then commit
                    tr.AddNewlyCreatedDBObject(tb, true);
                    tr.Commit();
                }

                //Transaction for updating table with valid text height , alignment :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    Table tb = (Table)tr.GetObject(tableId, OpenMode.ForWrite);
                    for (int i = 0; i < tb.Rows.Count; i++)
                    {
                        for (int j = 0; j < tb.Columns.Count; j++)
                        {
                            tb.Cells[i, j].TextHeight = textHeight;
                            tb.Cells[i, j].Alignment = CellAlignment.MiddleCenter;
                        }
                    }

                    //Commit changes :
                    tr.Commit();
                }
            }
            //On error go below :
            catch (System.Exception ex)
            {
                ed().WriteMessage("\nError : " + ex.Message);
                return retVal;
            }

            retVal = true;
            return retVal;
        }
        #endregion

        //Clear Mtext & Dimension formated contents :
        [CommandMethod("ClearFormat")]
        public void CmdClearFormat()
        {
            //Declare variables for editor & database :
            Editor ed = CommonCommands.ed();
            Database db = CommonCommands.db();

            //Create a TypedValue array to define the filter criteria :
            TypedValue[] typValArr = new TypedValue[4];
            typValArr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            typValArr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 1);
            typValArr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 2);
            typValArr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);

            //Create new selection filter from above TypedValue 's array :
            SelectionFilter ssFilter = new SelectionFilter(typValArr);

            //Ask user to select on screen with above selection filter :
            PromptSelectionResult ssRet = ed.GetSelection(ssFilter);

            //Check prompt return value :
            if (ssRet.Status != PromptStatus.OK ||
                ssRet.Value.Count == 0)
            {
                ed.WriteMessage("\nYou selected nothing !");
                return;
            }

            //Start transaction for iterate selection set then
            //Get mark & mark 's count : 
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {

                //Iterate selection set :
                foreach (SelectedObject sobj in ssRet.Value)
                {
                    //Just handle not null object :
                    if (sobj != null)
                    {
                        using (Entity ent = (Entity)tr.GetObject(sobj.ObjectId, 
                            OpenMode.ForRead))
                        {
                            //Get content :
                            if (ent.GetType().Name.ToString() == "MText")
                            {
                                if (! (((MText)ent).Contents).Equals(((MText)ent).Text))
                                {
                                    ent.UpgradeOpen();
                                    ((MText)ent).Contents = ((MText)ent).Text;
                                }
                            }
                            else
                            {
                                //Create temp MText object to remove formated text :
                                MText tempObj = new MText();
                                tempObj.Contents = ((Dimension)ent).DimensionText;

                                if (! (((Dimension)ent).DimensionText).Equals(tempObj.Text))
                                {
                                    ent.UpgradeOpen();
                                    ((Dimension)ent).DimensionText = tempObj.Text;
                                }
                            }
                        }
                    }
                }

                //Commit changes :
                tr.Commit();
            }
        }

        /// <summary>
        /// ----LỆNH HIỆU CHỈNH ĐỐI TƯỢNG----
        /// </summary>

        #region[Nhóm lệnh xoay theo độ nghiêng %]
        //Sub method, called by CmdROPN:
        private void RotateByNestCurve(double slopeAng, Document doc = null, 
                                       Database db = null, Editor ed = null)

        {
            //Check input document :
            if (doc == null)
            {
                doc = CommonCommands.doc();
                db = doc.Database;
                ed = doc.Editor;
            }

            //Ask user to select entities :
            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                RejectObjectsOnLockedLayers = true,
            };

            PromptSelectionResult psr = ed.GetSelection(pso);
            if (psr.Status != PromptStatus.OK ||
                psr.Value.Count == 0)
            {
                ed.WriteMessage("\nYou select nothing!");
                return;
            }

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                #region [Get nested entity]
                PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("\nSelect curve/ Mleader: ")
                {
                    AllowNone = true,
                };
                pneo.Keywords.Add("Input");

                PromptNestedEntityResult pner = ed.GetNestedEntity(pneo);
                if (pner.Status == PromptStatus.Cancel || 
                    pner.Status == PromptStatus.Error)
                {
                    tr.Abort();
                    return;
                }

                bool isValidInput = pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Curve))) ||
                                    pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(MLeader)))||
                                    pner.Status == PromptStatus.Keyword;
                if (isValidInput == false && pner.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                    isValidInput = true;

                while (!isValidInput)
                {
                    ed.WriteMessage("\nInvalid selection!");
                    pner = ed.GetNestedEntity(pneo);
                    if (pner.Status == PromptStatus.Cancel || 
                        pner.Status == PromptStatus.Error)
                    {
                        tr.Abort();
                        return;
                    }
                    else
                    {
                        isValidInput = pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Curve))) ||
                                       pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(MLeader))) ||
                                       pner.Status == PromptStatus.Keyword;
                        if (isValidInput == false && pner.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                            isValidInput = true;
                    }
                }
                #endregion
              
                #region [Get slope vector]
                //Get UCS's Z Axis(WCS):
                Vector3d zAxisUcs = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;

                //Get UCS's X Axis(WCS):
                Vector3d xAxisUcs = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Xaxis;

                //Get slope vector (WCS):
                Vector3d slopeVec;
                slopeVec = xAxisUcs.RotateBy(slopeAng, zAxisUcs);
                #endregion

                //Get point in UCS:
                Point3d pickPntUcs = pner.PickedPoint;

                //Get point in WCS:
                Point3d pickPntWcs = pickPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);

                //Base point WCS:
                Point3d basePnt = pickPntWcs;

                //Get point in ECS:
                Point3d pickPntEcs = pickPntWcs.TransformBy(pner.Transform.Inverse());

                //Get direction vector & base point in UCS:
                Vector3d dirVec;
                if (pner.Status == PromptStatus.Keyword)
                {
                    //Prompt for base point:
                    PromptPointOptions ppo = new PromptPointOptions("")
                    {
                        Message = "\nBase point: ",
                        AllowArbitraryInput = false,
                        AllowNone = false,
                        UseBasePoint = true,
                        BasePoint = new Point3d(0.0, 0.0, 0.0)
                    };

                    PromptPointResult ppr = ed.GetPoint(ppo);
                    if (ppr.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }

                    //Get base point in WCS:
                    basePnt = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);

                    //Prompt angle:
                    PromptAngleOptions pao = new PromptAngleOptions("")
                    {
                        Message = "\nInput angle: ",
                        UseBasePoint = true,
                        BasePoint = ppr.Value,
                        AllowArbitraryInput = false,
                        AllowZero = true,
                        DefaultValue = 0.0
                    };

                    PromptDoubleResult pdr = ed.GetAngle(pao);
                    if (pdr.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }

                    //Direction vector (WCS):
                    dirVec = xAxisUcs.RotateBy(pdr.Value, zAxisUcs);
                }
                else
                {
                    //Open entity for read:
                    Entity ent = (Entity)tr.GetObject(pner.ObjectId, OpenMode.ForRead);
                    if (ent == null)
                    {
                        ed.WriteMessage("\nCannot read source entity!");
                        tr.Abort();
                        return;
                    }
                    else
                    {
                        Curve boCurv;
                        if (ent is Vertex2d vert)
                        {
                            boCurv = (Curve)tr.GetObject(vert.OwnerId, OpenMode.ForRead);
                        }
                        else if (ent is Leader || ent is MLeader)
                        {
                            //Make the clone of Leader/ MLeader.
                            //Explode cloned enitity, iterate members and get closest curve to picked point.
                            using (Entity ldr = (Entity)ent.Clone())
                            using (DBObjectCollection leaderSegs = new DBObjectCollection())
                            using (DBObjectCollection polyCol = new DBObjectCollection())
                            {
                                //var leaderSegs = new DBObjectCollection();
                                ldr.Explode(leaderSegs);

                                //var polyCol = new DBObjectCollection();
                                foreach (DBObject dbObj in leaderSegs)
                                {//Autodesk.AutoCAD.DatabaseServices.Polyline
                                    if (dbObj is Curve)
                                    {
                                        polyCol.Add(dbObj);
                                    }
                                }

                                if (polyCol.Count == 0)
                                {
                                    tr.Abort();
                                    return;
                                }
                                else
                                {
                                    //Get curve closest to picked point:
                                    int closestIndex = 0;

                                    for (int i = 0; i < polyCol.Count; i++)
                                    {
                                        Point3d thisClosest, stdClosest;
                                        thisClosest = ((Curve)polyCol[i]).GetClosestPointTo(pickPntEcs, true);
                                        stdClosest = ((Curve)polyCol[closestIndex]).GetClosestPointTo(pickPntEcs, true);

                                        double dist1 = thisClosest.DistanceTo(pickPntEcs);
                                        double dist2 = stdClosest.DistanceTo(pickPntEcs);

                                        if (dist1 < dist2)
                                        {
                                            closestIndex = i;
                                        }
                                    }

                                    boCurv = (Curve)polyCol[closestIndex];
                                }
                            }
                        }
                        else
                        {
                            boCurv = (Curve)ent;
                        }

                        //Get closest point to picked point:
                        Point3d cloPnt = boCurv.GetClosestPointTo(pickPntEcs, true);

                        try
                        {
                            //Get tangent vector at closest point(ECS):
                            dirVec = boCurv.GetFirstDerivative(cloPnt);
                        }
                        catch (System.Exception ex)
                        {
                            ed.WriteMessage($"\nError: {ex.Message}");
                            ed.WriteMessage("\nDo you forget to set XY-Plane to contain selection set?");
                            tr.Abort();
                            return;
                        }

                        //Transform ECS -> WCS:
                        dirVec = dirVec.TransformBy(pner.Transform);
                    }
                    #region [On hold]
                    //else if(ent is MLeader mldr)
                    //{
                    //    //Direction vector (WCS):
                    //    dirVec = xAxisUcs.RotateBy(mldr.MText.Rotation, zAxisUcs);

                    //    //Base point(WCS):
                    //    basePnt = mldr.MText.Location;
                    //}
                    #endregion
                }

                //Get XY plane in UCS :
                Plane plane = new Plane(basePnt, zAxisUcs);

                //Get direction angle (UCS):
                double dirAng = dirVec.AngleOnPlane(plane);
                double dirAng1;

                //Get calculation angle (UCS):
                if (dirAng <= PI / 2.0 && dirAng >= 0.0)
                    dirAng1 = dirAng;
                else if (dirAng > 3.0 * PI / 2.0 && dirAng <= 2.0 * PI)
                    dirAng1 = dirAng;
                else
                    dirAng1 = dirAng + PI;

                //Get rotation angle:
                double rotAng = slopeVec.AngleOnPlane(plane) - dirAng1;

                //Create rotation matrix:
                Matrix3d rotMat = Matrix3d.Rotation(rotAng, zAxisUcs, basePnt);

                //Iterate selection set and rotated entities :
                foreach (SelectedObject sobj in psr.Value)
                {
                    if (sobj != null)
                    {
                        //Open entities for write :
                        Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);
                        if (ent != null)
                        {
                            try
                            {
                                ent.TransformBy(rotMat);
                            }
                            catch (System.Exception ex)
                            {
                                ed.WriteMessage(ex.Message);
                                tr.Abort();
                                return;
                            }
                        }
                    }
                }

                //Commit changes :
                tr.Commit();
            }
        }

        //Chọn đối tượng xoay về độ nghiêng % bất kỳ :
        [CommandMethod("ROP")]
        public void CmdROPN()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Variable for slope angle :
            double slopeAng;

            PromptDoubleOptions pdo = new PromptDoubleOptions("")
            {
                Message = "\nNew slope(%):",
                DefaultValue = 0.0,
                AllowArbitraryInput = false,
                AllowNegative = true,
                AllowZero = true
            };

            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status != PromptStatus.OK)
            {
                return;
            }
            else
            {
                slopeAng = Atan(pdr.Value / 100.0);
            }

            //Call subfuntion :
            RotateByNestCurve(slopeAng, doc, db, ed);
        }

        [Obsolete("Use RotateByNestCurve instead!")]
        private void CmdD22()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                PromptSelectionResult prsr = ed.GetSelection();
                if (prsr.Status == PromptStatus.OK)
                {
                    PromptDoubleOptions prd = new PromptDoubleOptions("\n 勾配の記入(%) : ")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true
                    };
                    PromptPointOptions prp = new PromptPointOptions("\n 原点の選び : ")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true
                    };
                    PromptDoubleResult prdr = ed.GetDouble(prd);
                    if (prdr.Status != PromptStatus.OK) return;

                    PromptPointResult prpr = ed.GetPoint(prp);
                    if (prpr.Status != PromptStatus.OK) return;

                    Matrix3d CurUCSMatrix = ed.CurrentUserCoordinateSystem;
                    CoordinateSystem3d curUCS = CurUCSMatrix.CoordinateSystem3d;
                    SelectionSet ss = prsr.Value;
                    foreach (SelectedObject sobj in ss)
                    {
                        if (sobj != null)
                        {
                            Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;

                            if (ent != null)
                            {
                                double an = Math.Atan(prdr.Value / 100);
                                ent.TransformBy(Matrix3d.Rotation(an, curUCS.Zaxis, prpr.Value));
                            }
                        }
                    }
                }
                tr.Commit();
            }
        }
        
        [Obsolete("Use RotateByNestCurve instead!")]
        private void CmdC211() 
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Request for objects to be selected in the drawing area
            PromptSelectionResult psr = ed.GetSelection();
            if (psr.Status != PromptStatus.OK) return;

            PromptKeywordOptions prk = new PromptKeywordOptions("")
            {
                Message = "\n ※パターンのお選び : " +
                      "\n 直線のお選び (C)" + " || 2点の選び(2)" +
                      "\n ______***Designed by Le Thuong Tri***_______ \n",
                AllowNone = true,
                AllowArbitraryInput = false,
            };
            prk.Keywords.Add("C");
            prk.Keywords.Add("2");
            PromptResult pr = ed.GetKeywords(prk);
            if (pr.Status != PromptStatus.OK) return;

            //Start main transaction :
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                var plane = new Plane(Point3d.Origin, normal);
                if (pr.StringResult == "C")
                {
                    //ed.WriteMessage("\n da chon dt");
                    PromptEntityOptions peo = new PromptEntityOptions("\n 基準直線を選び: ");
                    peo.SetRejectMessage("\n 選択が無効で、直線が必要です,");
                    peo.AddAllowedClass(typeof(Line), false);
                    PromptEntityResult per = ed.GetEntity(peo);
                    if (per.Status != PromptStatus.OK) return;
                    Line lobj = (Line)(tr.GetObject(per.ObjectId, OpenMode.ForRead) as Entity);
                    lobj.Highlight();

                    Point3d pt0 = lobj.StartPoint;
                    Point3d pt1 = lobj.EndPoint;
                    double an;
                    if (pt1.X >= pt0.X)
                    {
                        an = (pt0.GetVectorTo(pt1).AngleOnPlane(plane)) * -1;
                    }
                    else
                    {
                        pt0 = lobj.EndPoint;
                        pt1 = lobj.StartPoint;
                        an = (pt0.GetVectorTo(pt1).AngleOnPlane(plane)) * -1;
                    }

                    Matrix3d CurUCSMatrix = ed.CurrentUserCoordinateSystem;
                    CoordinateSystem3d curUCS = CurUCSMatrix.CoordinateSystem3d;
                    foreach (SelectedObject sobj in psr.Value)
                    {
                        if (sobj != null)
                        {
                            Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                            if (ent != null)
                            {
                                ent.TransformBy(Matrix3d.Rotation(an, curUCS.Zaxis, pt0));
                            }
                        }
                    }
                }
                else
                {
                    //ed.WriteMessage("\n da chon diem");
                    PromptPointOptions prp1 = new PromptPointOptions("\n 開始の点を選んで下さい。")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true,
                        BasePoint = new Point3d(0, 0, 0),
                        UseBasePoint = true
                    };

                    PromptPointResult prpr1 = ed.GetPoint(prp1);
                    if (prpr1.Status != PromptStatus.OK) return;

                    PromptPointOptions prp2 = new PromptPointOptions("\n 修了の点を選んで下さい。")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true,
                        BasePoint = prpr1.Value,
                        UseBasePoint = true
                    };
                    PromptPointResult prpr2 = ed.GetPoint(prp2);
                    if (prpr2.Status != PromptStatus.OK) return;

                    Point3d pt0 = prpr1.Value;
                    Point3d pt1 = prpr2.Value;
                    double an;
                    if (pt1.X >= pt0.X)
                    {
                        an = (pt0.GetVectorTo(pt1).AngleOnPlane(plane)) * -1;
                    }
                    else
                    {
                        pt0 = prpr2.Value;
                        pt1 = prpr1.Value;
                        an = (pt0.GetVectorTo(pt1).AngleOnPlane(plane)) * -1;
                    }
                    Matrix3d CurUCSMatrix = ed.CurrentUserCoordinateSystem;
                    CoordinateSystem3d curUCS = CurUCSMatrix.CoordinateSystem3d;
                    foreach (SelectedObject sobj in psr.Value)
                    {
                        if (sobj != null)
                        {
                            Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                            if (ent != null)
                            {
                                ent.TransformBy(Matrix3d.Rotation(an, curUCS.Zaxis, prpr1.Value));
                            }
                        }
                    }
                }
                tr.Commit();
            }
        }

        [Obsolete("Use RotateByNestCurve instead!")]
        private void RotateByCurveSlope(double slopeAng, double ucsWcsAng,
                            Document doc = null, Database db = null, Editor ed = null)

        {
            //Check input document :
            if (doc == null)
            {
                doc = CommonCommands.doc();
                db = doc.Database;
                ed = doc.Editor;
            }

            //Auto reset highlight & UCS when process finish :
            using (KRUnhighlight myUnHighlight = new KRUnhighlight())
            using (KRResetUCS myResetUcs = new KRResetUCS())
            {
                //Ask user to select entities :
                PromptSelectionResult psr = ed.GetSelection();
                if (psr.Status != PromptStatus.OK || psr.Value.Count == 0)
                    return;

                //Start main transaction :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Create plane 2d :
                    var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                    var plane = new Plane(Point3d.Origin, normal);

                    #region [Get curve]
                    //Prompt option :
                    PromptEntityOptions peo = new PromptEntityOptions("")
                    {
                        Message = "\nSelect a Curve/ MLeader for an old angle or :",
                    };

                    #region [Old codes]
                    //if (slopeAng != 0.0)
                    //{
                    //    peo.Message = "\nSelect a curve for an old angle or :";
                    //    peo.Keywords.Add("Input");
                    //}
                    //else
                    //    peo.Message = "\nSelect a curve for an old angle :";
                    #endregion

                    peo.Keywords.Add("Input");
                    peo.AllowNone = false;
                    peo.SetRejectMessage("\nInvalid selection. Please select Curve/ MLeader!");
                    peo.AddAllowedClass(typeof(Curve), false);
                    peo.AddAllowedClass(typeof(MLeader), false);

                    double calAng = 0.0;
                    Point3d cloPnt = Point3d.Origin;

                    //Prompt result :
                    PromptEntityResult per = ed.GetEntity(peo);
                    if (per.Status != PromptStatus.OK && per.Status != PromptStatus.Keyword)
                        return;
                    else if (per.Status == PromptStatus.Keyword)
                    {
                        //Get base point :
                        if (KRGetPoint(ed,"\nPick a base point: ",Point3d.Origin,ref cloPnt) != PromptStatus.OK)
                        {
                            return;
                        }

                        #region [Get Angle]

                        PromptAngleOptions pao = new PromptAngleOptions("\nInput old angle/ pick 1 point: ");
                        pao.UseBasePoint = true;
                        pao.BasePoint = cloPnt;
                        pao.AllowArbitraryInput = false;
                        pao.AllowNone = true;
                        pao.AllowZero = true;

                        PromptDoubleResult pdr = ed.GetAngle(pao);
                        if (pdr.Status == PromptStatus.None)
                        {
                            calAng = 0.0;
                        }
                        else if(pdr.Status == PromptStatus.Cancel || pdr.Status == PromptStatus.Error)
                        {
                            return;
                        }
                        else
                        {
                            calAng = pdr.Value;
                        }
                        #endregion
                    }
                    else
                    {
                        //Add a selected curve to 'Reset unhighlight object' :
                        myUnHighlight.Add(per.ObjectId);
                     
                        Vector3d tangVt; //Variable for tangent vector
                        double vtAng;    //Variable for tangent angle

                        //Highlight selected Curve/ MLeader then
                        //get vector angle by type(Curve/ MLeader):
                        if (per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Curve))))
                        {
                            //Open curve for write :
                            Curve boCurv = (Curve)tr.GetObject(per.ObjectId, OpenMode.ForWrite);
                            if (boCurv == null)
                            {
                                ed.WriteMessage("\nCannot get a curve for angle. Command ended!");
                                return;
                            }
                            else
                            {
                                try
                                {
                                    //Get closest point to curve :
                                    cloPnt = boCurv.GetClosestPointTo(per.PickedPoint, true);

                                    #region [Curve's highlight]

                                    //Variable for make a flag that a curve have subentity or not:
                                    bool hasSubEnt = false;

                                    //Get sub entity that is nearest to picked point :
                                    FullSubentityPath path = FullSubentityPath.Null;

                                    //Check curve type :
                                    if (per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Polyline2d)))
                                        || per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(
                                            Autodesk.AutoCAD.DatabaseServices.Polyline)))
                                        )
                                    {
                                        //Get curve param & Sub Ent path :
                                        double param;
                                        param = boCurv.GetParameterAtPoint(cloPnt);
                                        path = new FullSubentityPath(new ObjectId[] { boCurv.Id },
                                                new SubentityId(SubentityType.Edge, new IntPtr((int)param + 1)));
                                        hasSubEnt = true;
                                    }
                                    else
                                        hasSubEnt = false;

                                    //Highlight curve / its subentity :
                                    if (hasSubEnt)
                                        boCurv.Highlight(path, false);
                                    else
                                        boCurv.Highlight();

                                    #endregion

                                    #region [Get vector's angle]
                                    if (per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Leader))))
                                    {
                                        //Cast curve -> leader:
                                        Leader leObj = (Leader)boCurv;

                                        //Get tangent vector & angle:
                                        if (leObj.Annotation == ObjectId.Null)
                                        {
                                            tangVt = leObj.VertexAt(leObj.NumVertices - 2).GetVectorTo(leObj.LastVertex);
                                            vtAng = tangVt.AngleOnPlane(plane);
                                        }
                                        else
                                        {
                                            tangVt = leObj.LastVertex.GetVectorTo(cloPnt);
                                            MText mtextObj = (MText)tr.GetObject(leObj.Annotation, OpenMode.ForRead);
                                            vtAng = mtextObj.Rotation;
                                        }
                                    }
                                    else
                                    {
                                        tangVt = boCurv.GetFirstDerivative(cloPnt);
                                        vtAng = tangVt.AngleOnPlane(plane);
                                    }
                                    #endregion
                                }
                                catch (System.Exception ex)
                                {
                                    ed.WriteMessage(ex.ToString());
                                    return;
                                }
                            }
                        }
                        else
                        {
                            //Open curve for write :
                            MLeader mlObj = (MLeader)tr.GetObject(per.ObjectId, OpenMode.ForWrite);
                            if (mlObj == null)
                            {
                                ed.WriteMessage("\nCannot get mleader for angle. Command ended!");
                                return;
                            }
                            else
                            {
                                try
                                {
                                    mlObj.Highlight();
                                    vtAng = mlObj.MText.Rotation;
                                    cloPnt = mlObj.MText.Location;
                                }
                                catch (System.Exception ex)
                                {
                                    ed.WriteMessage(ex.ToString());
                                    return;
                                }
                            }
                        }

                        //Get calculation angle :
                        if (vtAng <= PI / 2.0 && vtAng >= 0)
                            calAng = vtAng;
                        else if (vtAng > 3.0 * PI / 2.0 && vtAng <= 2.0 * PI)
                            calAng = vtAng;
                        else
                            calAng = vtAng + PI;
                    }
                    #endregion

                    //Get rotated angle 
                    double rotAng;
                    if (slopeAng == 0.0)
                    {
                        rotAng = (calAng - ucsWcsAng) * -1.0;
                    }
                    else
                    {
                        rotAng = (calAng - ucsWcsAng) * -1.0 + slopeAng;
                    }

                    //Iterate selection set and rotated entities :
                    foreach (SelectedObject sobj in psr.Value)
                    {
                        if (sobj != null)
                        {
                            //Open entities for write :
                            Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);
                            if (ent != null)
                            {
                                try
                                {
                                    ent.TransformBy(Matrix3d.Rotation(rotAng,
                                            ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis, cloPnt));
                                }
                                catch (System.Exception ex)
                                {
                                    ed.WriteMessage(ex.ToString());
                                    return;
                                }
                            }
                        }
                    }

                    //Commit changes :
                    tr.Commit();
                }
            }
        }

        [Obsolete("Use CmdROPN instead!")]
        private void CmdROP()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Get angle between UCS & WCS :
            double ucsWcsAng = UcsWcsAngle();

            //Variable for slope angle :
            double slopeAng;

            //Get slope :
            double slope = 0.0;
            PromptStatus retStatus = KRGetDouble(ed, "\nThe new slope(%) <0.0>: ", ref slope);
            if (retStatus == PromptStatus.None)
            {
                slopeAng = 0.0;
            }
            else if (retStatus != PromptStatus.OK)
                return;
            else
                slopeAng = Atan(slope / 100.0);

            //Call subfuntion :
            RotateByCurveSlope(slopeAng, ucsWcsAng, doc, db, ed);
        }

        //[CommandMethod("ROPML")]
        private void CmdROPML()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Get angle between UCS & WCS :
            double ucsWcsAng = UcsWcsAngle();

            //Auto reset highlight & UCS when process finish :
            using (KRUnhighlight myUnHighlight = new KRUnhighlight())
            using (KRResetUCS myResetUcs = new KRResetUCS())
            {
                //Ask user to select entities :
                PromptSelectionResult psr = ed.GetSelection();
                if (psr.Status != PromptStatus.OK || psr.Value.Count == 0)
                    return;

                //Start main transaction :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Create plane 2d :
                    var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                    var plane = new Plane(Point3d.Origin, normal);

                    #region [Get curve]
                    //Prompt option :
                    PromptEntityOptions peo = new PromptEntityOptions("");
                    peo.Message = "\nSelect a curve for an old angle or :";
                    peo.Keywords.Add("Input");
                    peo.AllowNone = false;
                    peo.SetRejectMessage("\nInvalid selection. Please select curve !");
                    peo.AddAllowedClass(typeof(MLeader), false);

                    double calAng = 0.0;
                    Point3d cloPnt = Point3d.Origin;

                    //Prompt result :
                    PromptEntityResult per = ed.GetEntity(peo);
                    if (per.Status != PromptStatus.OK && per.Status != PromptStatus.Keyword)
                        return;
                    else if (per.Status == PromptStatus.Keyword)
                    {
                        //Get base point :
                        if (KRGetPoint(ed, "\nPick a base point: ", Point3d.Origin, ref cloPnt) != PromptStatus.OK)
                        {
                            return;
                        }

                        #region [Get Angle]
                        PromptAngleOptions pao = new PromptAngleOptions("\nInput old angle/ pick 1 point: ");
                        pao.UseBasePoint = true;
                        pao.BasePoint = cloPnt;
                        pao.AllowArbitraryInput = false;
                        pao.AllowNone = true;
                        pao.AllowZero = true;

                        PromptDoubleResult pdr = ed.GetAngle(pao);
                        if (pdr.Status == PromptStatus.None)
                        {
                            calAng = 0.0;
                        }
                        else if (pdr.Status == PromptStatus.Cancel || pdr.Status == PromptStatus.Error)
                        {
                            return;
                        }
                        else
                        {
                            calAng = pdr.Value;
                        }
                        #endregion
                    }
                    else
                    {
                        //Add a selected curve to 'Reset unhighlight object' :
                        myUnHighlight.Add(per.ObjectId);

                        //Open ML:
                        MLeader mlObj = (MLeader)tr.GetObject(per.ObjectId, OpenMode.ForWrite);
                        ed.WriteMessage($"\nAngle : {mlObj.MText.Rotation * 180.0 / Math.PI}");
                    }
                    #endregion

                    //Commit changes :
                    tr.Commit();
                }
            }

        }

        #endregion

        //Chọn nhiều kích thước , đổi mũi tên thành dotsmall
        [CommandMethod("TD")]
        public void Cmdtd()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[1];

            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status == PromptStatus.Cancel)
            {
                return;
            }
            else if(acSSPrompt.Status == PromptStatus.None || 
                    acSSPrompt.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get selection set!");
                return;
            }
            //if (acSSPrompt.Status != PromptStatus.OK) return;

            PromptKeywordOptions prk = new PromptKeywordOptions("");
            //{
            //    Message = "\n ※Select head location: " +
            //              "\n First head = 1" + " || Second head = 2" +
            //              "\n First & second head = 12" + " || Reset = 0" +
            //              "\n ______***Designed by Le Thuong Tri***_______ \n",
            //};
            prk.AllowNone = false;
            prk.AllowArbitraryInput = false;
            prk.Message = "\nSelect arrow position (0->reset): ";
            prk.Keywords.Add("1");
            prk.Keywords.Add("2");
            prk.Keywords.Add("12");
            prk.Keywords.Add("0");
            prk.Keywords.Add("Chains");
            prk.Keywords.Default = "Chains";

            PromptResult pr = ed.GetKeywords(prk);
            if (pr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get arrow position!");
                return;
            }
            else if (pr.Status == PromptStatus.Cancel)
            {
                return;
            }

            string newArrName = "_DotSmall";
            string sysVarName = "DIMBLK";

            //Store old arrow:
            string prevArrowName = (string)AcAp.GetSystemVariable(sysVarName);

            //Main processing:
            try
            {
                //https://forums.autodesk.com/t5/net/how-to-change-the-arrow-to-little-point-in-a-dimension/td-p/7662718
                //Load the new Arrow:
                AcAp.SetSystemVariable(sysVarName, newArrName);
                if (!string.IsNullOrWhiteSpace(prevArrowName))
                {
                    AcAp.SetSystemVariable(sysVarName, prevArrowName);
                }

                //Main transaction:
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Open block table for read:
                    BlockTable blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                    //Check new arrow head is loaded ?
                    if (!blt.Has(newArrName))
                    {
                        //throw new System.Exception($"Not found: {"_DotSmall"}");
                        ed.WriteMessage($"\nCannot get '{newArrName}' block!");
                        tr.Abort();
                        return;
                    }

                    ObjectId newArrId = blt[newArrName];

                    if (pr.StringResult != "Chains")
                    {
                        foreach (SelectedObject sobj in acSSPrompt.Value)
                        {
                            Dimension dimobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Dimension;
                            //ed.WriteMessage("\n"+dimobj.GetType().Name.ToString());
                            //dimobj.UpgradeOpen();
                            dimobj.Dimsah = true;

                            if (pr.StringResult == "1")
                            {
                                dimobj.Dimblk1 = newArrId;
                            }
                            else if (pr.StringResult == "2")
                            {
                                dimobj.Dimblk2 = newArrId;
                            }
                            else if (pr.StringResult == "12")
                            {
                                dimobj.Dimblk1 = newArrId;
                                dimobj.Dimblk2 = newArrId;
                            }
                            else if (pr.StringResult == "0")
                            {
                                dimobj.Dimblk1 = ObjectId.Null;
                                dimobj.Dimblk2 = ObjectId.Null;
                            }

                            //Force dimension to update:
                            dimobj.RecomputeDimensionBlock(true);
                        }
                    }
                    else
                    {
                        Dictionary<ObjectId, KeyValuePair<Point3d, Point3d>> pointsLst =
                            new Dictionary<ObjectId, KeyValuePair<Point3d, Point3d>>();

                        Autodesk.AutoCAD.Geometry.Tolerance newTor = new Autodesk.AutoCAD.Geometry.Tolerance(
                            AcadAddin.CommonCommands.KRTolerance, AcadAddin.CommonCommands.KRTolerance);

                        //Get dictionary of object id and headarrow points:
                        using (Transaction subTr = db.TransactionManager.StartTransaction())
                        {
                            foreach (SelectedObject sObj in acSSPrompt.Value)
                            {
                                if (sObj.ObjectId != ObjectId.Null)
                                {
                                    Entity ent = subTr.GetObject(sObj.ObjectId, OpenMode.ForRead) as Entity;

                                    if (ent is AlignedDimension alDim)
                                    {
                                        CommonCommands.GetAlignedDimArrowHeadPoints(alDim,
                                            out Point3d arrowHead1, out Point3d arrowHead2);

                                        if (arrowHead1.IsEqualTo(Point3d.Origin,newTor) && 
                                            arrowHead2.IsEqualTo(Point3d.Origin,newTor))
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            pointsLst.Add(ent.ObjectId, new KeyValuePair<Point3d, Point3d>(arrowHead1, arrowHead2));
                                        }
                                    }
                                    else if (ent is RotatedDimension rotDim)
                                    {
                                        CommonCommands.GetRotatedDimArrowHeadPoints(rotDim,
                                            out Point3d arrowHead1, out Point3d arrowHead2);

                                        if (arrowHead1.IsEqualTo(Point3d.Origin,newTor) && 
                                            arrowHead2.IsEqualTo(Point3d.Origin,newTor))
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            pointsLst.Add(ent.ObjectId, new KeyValuePair<Point3d, Point3d>(arrowHead1, arrowHead2));
                                        }
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                            }

                            subTr.Commit();
                        }

                        if (pointsLst.Count > 0)
                        {
                            #region [Test method]
                            //for (int i = 0; i < pointsLst.Count; i++)
                            //{
                            //    Point3d thisHead1Pnt = pointsLst.ElementAt(i).Value.Key;
                            //    Point3d thisHead2Pnt = pointsLst.ElementAt(i).Value.Value;

                            //    using (Circle temCir1 = new Circle())
                            //    using (Circle temCir2 = new Circle())
                            //    {
                            //        temCir1.Radius = 5;
                            //        temCir1.Center = thisHead1Pnt;

                            //        temCir2.Radius = 10;
                            //        temCir2.Center = thisHead2Pnt;

                            //        AppendEnt(tr, temCir1);
                            //        AppendEnt(tr, temCir2);
                            //    }
                            //}
                            #endregion

                            Dictionary<ObjectId, int> arrHeadsToChange = new Dictionary<ObjectId, int>();

                            for (int i = 0; i < pointsLst.Count; i++)
                            {
                                ObjectId thisObjId = pointsLst.ElementAt(i).Key;
                                Point3d thisHead1Pnt = pointsLst.ElementAt(i).Value.Key;
                                Point3d thisHead2Pnt = pointsLst.ElementAt(i).Value.Value;
                                int headIndex = 0;

                                for (int j = 0 ; j < pointsLst.Count; j++)
                                {
                                    ObjectId nextObjId = pointsLst.ElementAt(j).Key;
                                    if (nextObjId != thisObjId)
                                    {
                                        Point3d nextHead1Pnt = pointsLst.ElementAt(j).Value.Key;
                                        Point3d nextHead2Pnt = pointsLst.ElementAt(j).Value.Value;

                                        if (thisHead1Pnt.IsEqualTo(nextHead1Pnt,newTor) ||
                                            thisHead1Pnt.IsEqualTo(nextHead2Pnt,newTor))
                                        {
                                            if (headIndex == 0)
                                            {
                                                headIndex = 1;
                                            }
                                            else if (headIndex == 2)
                                            {
                                                headIndex = 12;
                                            }
                                        }

                                        if (thisHead2Pnt.IsEqualTo(nextHead1Pnt,newTor) ||
                                            thisHead2Pnt.IsEqualTo(nextHead2Pnt,newTor))
                                        {
                                            if (headIndex == 0)
                                            {
                                                headIndex = 2;
                                            }
                                            else if (headIndex == 1)
                                            {
                                                headIndex = 12;
                                            }
                                        }
                                    }
                                }

                                if (headIndex != 0)
                                {
                                    arrHeadsToChange.Add(thisObjId, headIndex);
                                }
                            }

                            if (arrHeadsToChange.Count > 0)
                            {
                                for (int i = 0; i < arrHeadsToChange.Count; i++)
                                {
                                    Dimension dimobj = tr.GetObject(arrHeadsToChange.ElementAt(i).Key, OpenMode.ForWrite) as Dimension;
                                    dimobj.Dimsah = true;

                                    int headIndex = arrHeadsToChange.ElementAt(i).Value;

                                    if (headIndex == 1)
                                    {
                                        dimobj.Dimblk1 = newArrId;
                                    }
                                    else if (headIndex == 2)
                                    {
                                        dimobj.Dimblk2 = newArrId;
                                    }
                                    else if (headIndex == 12)
                                    {
                                        dimobj.Dimblk1 = newArrId;
                                        dimobj.Dimblk2 = newArrId;
                                    }
                                    else if (headIndex == 0)
                                    {
                                        dimobj.Dimblk1 = ObjectId.Null;
                                        dimobj.Dimblk2 = ObjectId.Null;
                                    }

                                    //Force dimension to update:
                                    dimobj.RecomputeDimensionBlock(true);
                                }
                            }
                        }
                    }

                    tr.Commit();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage($"\nError: {ex.Message}");
                return;
            }
            finally
            {
                //Reset:
                if (!prevArrowName.Equals(newArrName))
                {
                    if (prevArrowName.Equals(""))
                    {
                        AcAp.SetSystemVariable(sysVarName, ".");
                    }
                    else
                    {
                        AcAp.SetSystemVariable(sysVarName, prevArrowName);
                    }
                }
            }
        }

        //Chọn nhiều kích thước , Thay đổi độ chính xác
        [CommandMethod("CX")]
        public void CmCX()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;
            PromptKeywordOptions prk = new PromptKeywordOptions("")
            {
                Message = "\n ※Select the precision for dimensions : " +
                      //"\n 矢印1の変化 = 1" + " || 矢印2の変化 = 2" +
                      //"\n 矢印1及び2の変化 = 12" + " || 元々へ戻り = 0" +
                      "\n ______***Designed by Le Thuong Tri***_______ \n",
                AllowNone = true,
            };
            prk.Keywords.Add("1");
            prk.Keywords.Add("2");
            prk.Keywords.Add("3");
            prk.Keywords.Add("4");
            prk.Keywords.Add("5");
            prk.Keywords.Add("6");
            prk.Keywords.Add("7");
            prk.Keywords.Add("8");
            PromptResult pr = ed.GetKeywords(prk);
            if (pr.Status != PromptStatus.OK) return;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Dimension dimobj = (Dimension)(tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity);
                        dimobj.Dimdec = Int32.Parse(pr.StringResult);
                        dimobj.Dimadec = dimobj.Dimdec;
                        dimobj.Dimrnd = 1 / Math.Pow(10, dimobj.Dimdec);
                        //try
                        //{
                        //    dimobj.Dimdec = Int32.Parse(pr.StringResult);
                        //    dimobj.Dimrnd = 1 / Math.Pow(10, dimobj.Dimdec);
                        //}
                        //catch
                        //{
                        //    dimobj.Dimadec = Int32.Parse(pr.StringResult);
                        //    dimobj.Dimrnd = 1 / Math.Pow(10, dimobj.Dimadec);
                        //}
                        Point3d pt3d = new Point3d(0, 0, 0);
                        Vector3d vt3dg = pt3d.GetVectorTo(new Point3d(1, 0, 0));
                        Vector3d vt3db = pt3d.GetVectorTo(new Point3d(-1, 0, 0));
                        dimobj.TransformBy(Matrix3d.Displacement(vt3dg));
                        dimobj.TransformBy(Matrix3d.Displacement(vt3db));
                    }
                }
                tr.Commit();
            }
        }

        //Chọn nhiều TEXT/MTEXT/DIMENSION, Sửa nội dung
        private AcadAddin.Command.EDSViewForm _EDSViewForm;

        [CommandMethod("EDS")]
        public void CmdEDS()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                RejectObjectsOnLockedLayers = true
            };

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[5];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 3);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);
            
            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
            
            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso,acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK ||
                acSSPrompt.Value.Count == 0)
            {
                ed.WriteMessage("\nYou select nothing!");        
                return;
            }

            //Get sort type:
            System.Collections.Generic.List<string> kwLst = new System.Collections.Generic.List<string>();
            kwLst.Add("Random");
            kwLst.Add("X");
            kwLst.Add("Y");
            kwLst.Add("View");

            PromptKeywordOptions pko = new PromptKeywordOptions("");
            pko.Message = "\nSort type: ";
            pko.AllowArbitraryInput = false;
            pko.AllowNone = false;
            
            for (int i = 0; i < kwLst.Count; i++)
            {
                pko.Keywords.Add(kwLst[i]);
            }
            pko.Keywords.Default = kwLst[0];

            PromptResult prr;

            prr = ed.GetKeywords(pko);
            if (prr.Status == PromptStatus.Cancel)
            {
                return;
            }
            else if(prr.Status == PromptStatus.Error || 
                    prr.Status == PromptStatus.None)
            {
                ed.WriteMessage("\nCannot get sort type!");
                return;
            }

            string sortType = prr.StringResult;

            //ObjectIdCollection ids = new ObjectIdCollection();
            ObjectId[] ids =   acSSPrompt.Value.GetObjectIds();
            if (ids.Length == 0)
            {
                ed.WriteMessage("\nCannot read selection set!");
                return;
            }

            //List contain id + entity position(for sort):
            // - In case of random, position = origin.
            System.Collections.Generic.List<KeyValuePair<ObjectId, Point3d>> idsPos =
                new System.Collections.Generic.List<KeyValuePair<ObjectId, Point3d>>();

            //Sort object ids:
            if(sortType == kwLst[0])
            {
                for (int i = 0; i < ids.Length; i++)
                {
                    if (ids[i] != ObjectId.Null)
                    {
                        idsPos.Add(new KeyValuePair<ObjectId, Point3d>(ids[i], Point3d.Origin));
                    }
                }
            }
            else if (sortType == kwLst[1] || 
                     sortType == kwLst[2])
            {
                System.Collections.Generic.List<string> sortDirKws = 
                                    new System.Collections.Generic.List<string>();
                sortDirKws.Add("+");
                sortDirKws.Add("-");

                pko.Message = "\nSort direction: ";
                pko.Keywords.Clear();

                for (int i = 0; i < sortDirKws.Count; i++)
                {
                    pko.Keywords.Add(sortDirKws[i]);
                }
                pko.Keywords.Default = sortDirKws[0];

                prr = ed.GetKeywords(pko);
                if (prr.Status == PromptStatus.Cancel)
                {
                    return;
                }
                else if(prr.Status == PromptStatus.Error || 
                        prr.Status == PromptStatus.None)
                {
                    ed.WriteMessage("\nCannot get sort direction!");
                    return;
                }

                string sortDir = prr.StringResult;

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Build list of id + position:
                    for (int i = 0; i < ids.Length; i++)
                    {
                        if (ids[i] != ObjectId.Null)
                        {
                            Entity tempEnt = tr.GetObject(ids[i], OpenMode.ForRead) as Entity;
                            Extents3d? ext3d = tempEnt.Bounds;
                            if (ext3d != null)
                            {
                                Point3d maxPnt = ext3d.Value.MaxPoint;
                                Point3d minPnt = ext3d.Value.MinPoint;
                                Point3d midPnt = new Point3d((maxPnt.X + minPnt.X) / 2.0,
                                                             (maxPnt.Y + minPnt.Y) / 2.0,
                                                             (maxPnt.Z + minPnt.Z) / 2.0
                                                            );

                                //WCS -> UCS:
                                Point3d midPntUcs = midPnt.TransformBy(ed.CurrentUserCoordinateSystem.Inverse());

                                //Add member to list:
                                //idsPos.Add(new KeyValuePair<ObjectId, Point3d>(ids[i], midPnt));
                                idsPos.Add(new KeyValuePair<ObjectId, Point3d>(ids[i], midPntUcs));
                            }
                        }
                    }

                    //Check list length:
                    if (ids.Length == 0)
                    {
                        ed.WriteMessage("\nCannot sort seleted objects!");
                        return;
                    }

                    //Start to sort list:
                    if (sortType == kwLst[1])
                    {
                        if (sortDir == sortDirKws[0])
                        {
                            idsPos.Sort((a, b) => a.Value.X.CompareTo(b.Value.X));
                        }
                        else
                        {
                            idsPos.Sort((b, a) => a.Value.X.CompareTo(b.Value.X));
                        }
                    }
                    else if (sortType == kwLst[2])
                    {
                        if (sortDir == sortDirKws[0])
                        {
                            idsPos.Sort((a, b) => a.Value.Y.CompareTo(b.Value.Y));
                        }
                        else
                        {
                            idsPos.Sort((b, a) => a.Value.Y.CompareTo(b.Value.Y));
                        }
                    }

                    tr.Commit();
                }
            }
            else
            {
                //Do something to call datagridview form:
                if (_EDSViewForm == null)
                    _EDSViewForm = new AcadAddin.Command.EDSViewForm();
                else if (_EDSViewForm.IsDisposed == true || _EDSViewForm != null)
                {
                    //Clear old instance :
                    _EDSViewForm = null;

                    //Create new instance :
                    _EDSViewForm = new AcadAddin.Command.EDSViewForm();
                }

                if (_EDSViewForm.PopulateData(ids) != true)
                {
                    _EDSViewForm.Dispose();
                    ed.WriteMessage("\nFail to populate data!");
                    return;
                }

                //Show/ activate form:
                if (_EDSViewForm.Visible == false)
                {
                    AcAp.ShowModalDialog(null, _EDSViewForm, false);
                }
                else
                {
                    _EDSViewForm.Activate();
                }

                //End command here:
                return;
            }

            if (idsPos.Count == 0)
            {
                ed.WriteMessage("\nFail to get object ids!");
                return;
            }

            PromptStringOptions prs;
            string promptMsg = "\nNew content: ";
            
            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //ObjectId[] ids = new ObjectId[0];
                for (int i = 0; i < idsPos.Count; i++)
                {
                    Entity ent = tr.GetObject(idsPos[i].Key , OpenMode.ForWrite) as Entity;

                    if (ent.GetType().Name.ToString() == "MText")
                    {
                        MText mtxt = (MText)ent;
                        mtxt.Highlight();

                        prs = new PromptStringOptions(promptMsg)
                        {
                            AllowSpaces = true,
                            DefaultValue = mtxt.Contents
                        };

                        prr = ed.GetString(prs);
                        if (prr.Status != PromptStatus.OK)
                        {
                            mtxt.Unhighlight();
                            tr.Abort();
                            return;
                        }
                        else
                        {
                            mtxt.Contents = prr.StringResult;
                            mtxt.Unhighlight();
                        }
                    }
                    else if (ent.GetType().Name.ToString() == "DBText")
                    {
                        DBText txt = (DBText)ent;
                        txt.Highlight();

                        prs = new PromptStringOptions(promptMsg)
                        {
                            AllowSpaces = true,
                            DefaultValue = txt.TextString
                        };

                        prr = ed.GetString(prs);
                        if (prr.Status != PromptStatus.OK)
                        {
                            txt.Unhighlight();
                            tr.Abort();
                            return;
                        }
                        else
                        {
                            txt.TextString = prr.StringResult;
                            txt.Unhighlight();
                        }
                    }
                    else
                    {
                        Dimension dimobj = (Dimension)ent;
                        dimobj.Highlight();

                        prs = new PromptStringOptions(promptMsg)
                        {
                            AllowSpaces = true,
                            DefaultValue = dimobj.DimensionText
                        };

                        prr = ed.GetString(prs);
                        if (prr.Status != PromptStatus.OK)
                        {
                            dimobj.Unhighlight();
                            tr.Abort();
                            return;
                        }
                        else
                        {
                            dimobj.DimensionText = prr.StringResult;
                            dimobj.Unhighlight();
                        }

                    }

                    //Update graphics:
                    tr.TransactionManager.QueueForGraphicsFlush();
                }

                #region [Old codes]
                //foreach (SelectedObject sobj in acSSPrompt.Value)
                //{
                //    Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                //    if (ent.GetType().Name.ToString() == "MText")
                //    {
                //        MText mtxt = (MText)ent;
                //        mtxt.Highlight();

                //        prs = new PromptStringOptions(promptMsg)
                //        {
                //            AllowSpaces = true,
                //            DefaultValue = mtxt.Contents
                //        };

                //        prr = ed.GetString(prs);
                //        if (prr.Status != PromptStatus.OK)
                //        {
                //            mtxt.Unhighlight();
                //            tr.Abort();
                //            return;
                //        }
                //        else
                //        {
                //            mtxt.Contents = prr.StringResult;
                //            mtxt.Unhighlight();
                //        }
                //    }
                //    else if (ent.GetType().Name.ToString() == "DBText")
                //    {
                //        DBText txt = (DBText)ent;
                //        txt.Highlight();

                //        prs = new PromptStringOptions(promptMsg)
                //        {
                //            AllowSpaces = true,
                //            DefaultValue = txt.TextString
                //        };

                //        prr = ed.GetString(prs);
                //        if (prr.Status != PromptStatus.OK)
                //        {
                //            txt.Unhighlight();
                //            tr.Abort();
                //            return;
                //        }
                //        else
                //        {
                //            txt.TextString = prr.StringResult;
                //            txt.Unhighlight();
                //        }
                //    }
                //    else
                //    {
                //        Dimension dimobj = (Dimension)ent;
                //        dimobj.Highlight();

                //        prs = new PromptStringOptions(promptMsg)
                //        {
                //            AllowSpaces = true,
                //            DefaultValue = dimobj.DimensionText
                //        };

                //        prr = ed.GetString(prs);
                //        if (prr.Status != PromptStatus.OK)
                //        {
                //            dimobj.Unhighlight();
                //            tr.Abort();
                //            return;
                //        }
                //        else
                //        {
                //            dimobj.DimensionText = prr.StringResult;
                //            dimobj.Unhighlight();
                //        }

                //    }

                //    //Update graphics:
                //    tr.TransactionManager.QueueForGraphicsFlush();
                //}

                #endregion

                //Commit changes:
                tr.Commit();
            }

            //Silently send command to check fake dim:            
            using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
            {
                try
                {
                    //Send command to change color of fake dim :
                    ed.Command("_.FDS", "P", "");
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage(ex.Message);
                }
            }
        }

        //[CommandMethod("EDSI")]
        public void CmdEDSI()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                RejectObjectsOnLockedLayers = true
            };

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[5];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 3);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK ||
                acSSPrompt.Value.Count == 0)
            {
                ed.WriteMessage("\nYou select nothing!");
                return;
            }

            PromptStringOptions prs;
            PromptResult prr;
            string promptMsg = "\nNew content: ";

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //ObjectId[] ids = new ObjectId[0];
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                    if (ent.GetType().Name.ToString() == "MText")
                    {
                        MText mtxt = (MText)ent;
                        mtxt.Highlight();

                        prs = new PromptStringOptions(promptMsg)
                        {
                            AllowSpaces = true,
                            DefaultValue = mtxt.Contents
                        };

                        prr = ed.GetString(prs);
                        if (prr.Status != PromptStatus.OK)
                        {
                            mtxt.Unhighlight();
                            tr.Abort();
                            return;
                        }
                        else
                        {
                            mtxt.Contents = prr.StringResult;
                            mtxt.Unhighlight();
                        }
                    }
                    else if (ent.GetType().Name.ToString() == "DBText")
                    {
                        DBText txt = (DBText)ent;
                        txt.Highlight();

                        ObjectId[] ids = new ObjectId[0];
                        InplaceTextEditor.Invoke(txt, ref ids);

                        //prs = new PromptStringOptions(promptMsg)
                        //{
                        //    AllowSpaces = true,
                        //    DefaultValue = txt.TextString
                        //};

                        //prr = ed.GetString(prs);
                        //if (prr.Status != PromptStatus.OK)
                        //{
                        //    txt.Unhighlight();
                        //    tr.Abort();
                        //    return;
                        //}
                        //else
                        //{
                        //    txt.TextString = prr.StringResult;
                        //    txt.Unhighlight();
                        //}
                    }
                    else
                    {
                        Dimension dimobj = (Dimension)ent;
                        dimobj.Highlight();

                        prs = new PromptStringOptions(promptMsg)
                        {
                            AllowSpaces = true,
                            DefaultValue = dimobj.DimensionText
                        };

                        prr = ed.GetString(prs);
                        if (prr.Status != PromptStatus.OK)
                        {
                            dimobj.Unhighlight();
                            tr.Abort();
                            return;
                        }
                        else
                        {
                            dimobj.DimensionText = prr.StringResult;
                            dimobj.Unhighlight();
                        }

                    }

                    //Update graphics:
                    tr.TransactionManager.QueueForGraphicsFlush();
                }

                //Commit changes:
                tr.Commit();
            }

            //Silently send command to check fake dim:            
            using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
            {
                try
                {
                    //Send command to change color of fake dim :
                    ed.Command("_.FDS", "P", "");
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage(ex.Message);
                }
            }
        }

        //Chọn nhiều TEXT/MTEXT/DIMENSION, Cho nội dung vào trong dấu ()
        [CommandMethod("TK")]
        public void CmdTK()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[5];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 3);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                        if (ent.GetType().Name == "MText")
                        {
                            MText mtxt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as MText;
                            mtxt.Contents = "(" + mtxt.Contents + ")";
                        }
                        else if (ent.GetType().Name == "DBText")
                        {
                            DBText txt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as DBText;
                            txt.TextString = "(" + txt.TextString + ")";
                        }
                        else
                        {
                            Dimension dimobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Dimension;
                            if (dimobj.DimensionText != "")
                            {
                                dimobj.DimensionText = "(" + dimobj.DimensionText + ")";
                            }
                            else
                            {
                                dimobj.DimensionText = "(<>)";
                            }
                        }
                    }
                }
                tr.Commit();
            }
        }

        #region[Nhóm lệnh fake dim]
        //Chọn nhiều DIMENSION, đưa về dạng fake dim
        [CommandMethod("FD")]
        public void CmdFD()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) 
                return;

            //Start transaction for making fake dimension :
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Iterate selection set :
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    //Only get object which NOT null :
                    if (sobj != null)
                    {
                        //Open dimension for write :
                        Dimension dimobj = (Dimension)tr.GetObject(sobj.ObjectId, 
                            OpenMode.ForWrite);

                        //Declare entity to check type of dimension :
                        Entity ent;

                        //Get dimension 's measurement :
                        double Measure = dimobj.Measurement;

                        //Get dimension round off :
                        double Rnd = dimobj.Dimrnd;

                        //Get dimension text :
                        string dimtext = dimobj.DimensionText;

                        //Compare text string :
                        if (dimtext == "" || dimtext == "<>")
                        {//This case : dimension 's text hasn't been overrided :
                            ent = dimobj;
                            if (ent.GetType().Name.ToString() == "Point3AngularDimension" ||
                                ent.GetType().Name.ToString() == "LineAngularDimension2")
                            {//Angular dimensions :
                                //Get mesure in degree :
                                Measure = ((dimobj.Measurement) * 180.0 / Math.PI);

                                if (dimobj.Dimadec <= 2)
                                    dimtext = AngInDegree(Measure.ToString(), AngleFormat.DegMi);
                                else
                                    dimtext = AngInDegree(Measure.ToString(),AngleFormat.DegMiSe);
                            }
                            else
                            {//Other dimensions :
                                //Get dimension text :
                                if (Rnd == 0)
                                {
                                    Rnd = 1 / Math.Pow(10, dimobj.Dimdec);
                                }
                                dimtext = (Math.Round(Measure * 1 / Rnd,
                                                        MidpointRounding.AwayFromZero) * Rnd
                                                        ).ToString();
                            }

                            //Put dimension text :
                            if (dimobj is RadialDimension)
                            {
                                dimobj.DimensionText = "R" + dimtext;
                            }
                            else if(dimobj is DiametricDimension)
                            {
                                dimobj.DimensionText = "%%c" + dimtext;
                            }
                            else
                            {
                                dimobj.DimensionText = dimtext;
                            }
                        }
                        else
                        {//Dimension has been overrided :
                            ent = dimobj;
                            if (ent.GetType().Name.ToString() == "Point3AngularDimension" ||
                                ent.GetType().Name.ToString() == "LineAngularDimension2")
                            {//Angular dimensions :
                                //Get mesure in degree :
                                Measure = ((dimobj.Measurement) * 180.0 / Math.PI);

                                if (dimobj.Dimadec <= 2)
                                    dimtext = dimtext.Replace("<>", 
                                        AngInDegree(Measure.ToString(), AngleFormat.DegMi));
                                        
                                else
                                    dimtext = dimtext.Replace("<>",
                                        AngInDegree(Measure.ToString(), AngleFormat.DegMiSe));
                            }
                            else
                            {//Other dimensions :

                                //Get dimension text :
                                dimtext = dimtext.Replace("<>",
                                    (Math.Round(dimobj.Measurement * 1 / dimobj.Dimrnd,
                                    MidpointRounding.AwayFromZero)
                                    * dimobj.Dimrnd).ToString());
                            }

                            //Put dimension text :
                            dimobj.DimensionText = dimtext;
                        }
                    }
                }

                //Commit changes :
                tr.Commit();

            }//End transaction 

            //Silently send command to check fake dim:            
            using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
            {
                try
                {
                    //Send command to change color of fake dim :
                    ed.Command("_.FDS", "P", "");
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage(ex.Message);
                }
            }
        }

        //Chọn nhiều DIMENSION, đưa về dạng ko fake dim
        [CommandMethod("NFD")]
        public void CmdNFD()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Dimension dimobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Dimension;
                        dimobj.DimensionText = "<>";
                    }
                }
                tr.Commit();
            }

            //Silently send command to check fake dim:            
            using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
            {
                try
                {
                    //Send command to change color of fake dim :
                    ed.Command("_.FDS", "P", "");
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage(ex.Message);
                }
            }
        }

        //Chọn nhiều DIMENSION, Kiểm tra có phải là fake dim không]
        [CommandMethod("FDCHECK")]
        public void CmdFdCheck()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Dimension dimobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Dimension;

                        if (dimobj.DimensionText != "" && dimobj.DimensionText != "<>")
                        {
                            dimobj.Dimtfill = 2;
                            Point3d pt3d = new Point3d(0, 0, 0);
                            Vector3d vt3dg = pt3d.GetVectorTo(new Point3d(1, 0, 0));
                            Vector3d vt3db = pt3d.GetVectorTo(new Point3d(-1, 0, 0));
                            dimobj.TransformBy(Matrix3d.Displacement(vt3dg));
                            dimobj.TransformBy(Matrix3d.Displacement(vt3db));
                        }
                    }
                }
                tr.Commit();
            }
        }
        #endregion

        //Chọn nhiều TEXT/MTEXT , Xoay theo 2 điểm
        [CommandMethod("RT")]
        public void CmdRT()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[4];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;

            PromptPointOptions ppo1 = new PromptPointOptions("\nFirst point: ")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = Point3d.Origin, UseBasePoint = true };

            PromptPointResult ppr1 = ed.GetPoint(ppo1);
            if (ppr1.Status != PromptStatus.OK) 
                return;

            PromptPointOptions ppo2 = new PromptPointOptions("\nSecond point: ")
            { AllowArbitraryInput = false, AllowNone = true, BasePoint = ppr1.Value, UseBasePoint = true };

            PromptPointResult ppr2 = ed.GetPoint(ppo2);
            if (ppr2.Status != PromptStatus.OK) 
                return;

            var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
            var plane = new Plane(Point3d.Origin, normal);

            Point3d pt1,pt2;
            pt1 = ppr1.Value.TransformBy(ed.CurrentUserCoordinateSystem);
            pt2 = ppr2.Value.TransformBy(ed.CurrentUserCoordinateSystem);
            double an = pt1.GetVectorTo(pt2).AngleOnPlane(plane) - UcsWcsAngle();

            try
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    foreach (SelectedObject sobj in acSSPrompt.Value)
                    {
                        Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);
                        if (ent != null)
                        {
                            if (ent.GetType().Name.ToString() == "MText")
                                (tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as MText).Rotation = an;
                            else
                                (tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as DBText).Rotation = an;
                        }
                    }

                    //Commit changes:
                    tr.Commit();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.ToString());
                return;
            }
        }

        //Biến Line/ Ray -> XLine
        [CommandMethod("NN")]
        public void CmNN()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Create a TypedValue array to define the filter criteria :
            TypedValue[] acTypValAr = new TypedValue[4];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LINE"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "RAY"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);

            //Create new selection filter from above TypedValue 's array :
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            //Prompt option :
            PromptSelectionOptions pso = new PromptSelectionOptions
            {
                MessageForAdding = "\nSelect Line/ Ray:",
                RejectObjectsOnLockedLayers = true
            };

            //Prompt result :
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);

            //Selection set :
            SelectionSet ss;
            //Check prompt return value :
            if (acSSPrompt.Status != PromptStatus.OK ||
                acSSPrompt.Value.Count == 0)
            {
                ed.WriteMessage("\nYou selected nothing!");
                return;
            }
            else
                ss = acSSPrompt.Value;

            try
            {
                //Start main transaction:
                //***Use 'StartOpenCloseTransaction' for HangOverTo.
                using (Transaction tr = db.TransactionManager.StartOpenCloseTransaction())
                {
                    //Iterate selection set:
                    foreach (SelectedObject sObj in ss)
                    {
                        //Check whether selected object is null:
                        if (sObj != null)
                        {
                            //Open entity for write:
                            Entity sEnt = (Entity)tr.GetObject(sObj.ObjectId, OpenMode.ForWrite);

                            //Create new Xline to replace old entity:
                            using (Xline newXline = new Xline())
                            {
                                //Transfer properties:
                                //newXline.Layer = sEnt.Layer;
                                //newXline.Color = sEnt.Color;
                                //newXline.Linetype = sEnt.Linetype;
                                //newXline.LineWeight = sEnt.LineWeight;
                                newXline.SetPropertiesFrom(sEnt);

                                //Set Xline's points:
                                if (sObj.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Line))))
                                {

                                    newXline.BasePoint = ((Line)sEnt).StartPoint;
                                    newXline.SecondPoint = ((Line)sEnt).EndPoint;
                                }
                                else
                                {
                                    newXline.BasePoint = ((Ray)sEnt).BasePoint;
                                    newXline.SecondPoint = ((Ray)sEnt).SecondPoint;
                                }

                                //Exchange Xline's objectId with old entity's objectId:
                                sEnt.HandOverTo(newXline, true, true);
                            }
                        }
                    }

                    //Commit changes:
                    tr.Commit();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        //Lệnh extend 2 đầu:
        [CommandMethod("LL")]
        public void CmdLL()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            #region [Get SelectionSet]
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LINE"), 0);
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                RejectObjectsOnLockedLayers = true
            };

            PromptSelectionResult acSSPrompt = ed.GetSelection(pso,acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) 
                return;
            #endregion

            //Read line extend from XML file:
            string xmlFullPath = CommonDeclaration.GetSettingXmlFullPath();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlFullPath);

            XmlNode xmlNode = null;
            string lineExtStr = "";
            double lineExtVal;
            xmlNode = xmlDoc.DocumentElement.SelectSingleNode(CommonDeclaration.SysVars);
            if (xmlNode != null)
            {
                lineExtStr = xmlNode["LineExtend"].InnerText;

                if (!double.TryParse(lineExtStr, out lineExtVal))
                {
                    ed.WriteMessage("\nError when read system variable. Use 3mm as extend.");
                    lineExtVal = 3.0;
                }
            }
            else
            {
                ed.WriteMessage("\nCannot read XML file. Use 3mm as extend.");
                lineExtVal = 3.0;
            }

            #region [Get line's extension]
            PromptDoubleOptions pdo = new PromptDoubleOptions("\nLine's extension: ")
            { 
                AllowArbitraryInput = false,
                AllowNone = true,
                AllowZero = false ,
                DefaultValue = lineExtVal
            };

            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status != PromptStatus.OK)
                return;
            else
            {
                //Write value to XML file:
                xmlNode["LineExtend"].InnerText = pdr.Value.ToString();
                xmlDoc.Save(xmlFullPath);
            }
            #endregion
            
            double an;

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Line lobj = (Line)(tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity);
                        an = lobj.Angle;
                        lobj.StartPoint = PolarPoints(lobj.StartPoint, an + Math.PI, pdr.Value);
                        lobj.EndPoint = PolarPoints(lobj.EndPoint, an, pdr.Value);
                    }
                }

                //Commit changes:
                tr.Commit();
            }
        }

        #region [Nhóm lệnh copy nhanh đối tượng]
        //Copy nhanh đối tượng(Từ đối tượng vừa tạo)]
        [CommandMethod("Q1")]
        public void CmdQ1()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            //ed.WriteMessage("\n コピーしたいエンティティを選択 :");
            PromptSelectionResult prs = ed.SelectLast();
            if (prs.Status != PromptStatus.OK) return;

            Boolean cont = true;

            while (cont == true)
            {
                using (Transaction tr = doc.TransactionManager.StartTransaction())
                {
                    BlockTable blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                    BlockTableRecord bltr = tr.GetObject(blt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                    PromptStringOptions prst = new PromptStringOptions("\n 相対座標を入力 :");
                    PromptResult prr = ed.GetString(prst);
                    if (prr.Status != PromptStatus.OK) return;
                    if (prr.StringResult == "") return;

                    string[] arrlist = prr.StringResult.Split(',');

                    Point3d pt3d = new Point3d(0, 0, 0);
                    Vector3d vt3d = pt3d.GetVectorTo(new Point3d(double.Parse(arrlist[0]),
                                                                 double.Parse(arrlist[1]), 0));

                    foreach (SelectedObject sobj in prs.Value)
                    {
                        tr.TransactionManager.QueueForGraphicsFlush();
                        if (sobj != null)
                        {
                            Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                            Entity entcopy = (Entity)ent.Clone();
                            ent.TransformBy(Matrix3d.Displacement(vt3d));
                            bltr.AppendEntity(entcopy);
                            tr.AddNewlyCreatedDBObject(entcopy, true);
                        }
                    }
                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }
            }
        }

        //Copy nhanh đối tượng(chọn đối tượng)]
        [CommandMethod("Q2")]
        public void CmdQ2()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            ed.WriteMessage("\n コピーしたいエンティティを選択 :");
            PromptSelectionResult prs = ed.GetSelection();
            if (prs.Status != PromptStatus.OK) return;

            Boolean cont = true;

            while (cont == true)
            {
                using (Transaction tr = doc.TransactionManager.StartTransaction())
                {
                    BlockTable blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                    BlockTableRecord bltr = tr.GetObject(blt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                    PromptStringOptions prst = new PromptStringOptions("\n 相対座標を入力 :");
                    PromptResult prr = ed.GetString(prst);
                    if (prr.Status != PromptStatus.OK) return;
                    if (prr.StringResult == "") return;

                    string[] arrlist = prr.StringResult.Split(',');

                    Point3d pt3d = new Point3d(0, 0, 0);
                    Vector3d vt3d = pt3d.GetVectorTo(new Point3d(double.Parse(arrlist[0]),
                                                                 double.Parse(arrlist[1]), 0));

                    foreach (SelectedObject sobj in prs.Value)
                    {
                        tr.TransactionManager.QueueForGraphicsFlush();
                        if (sobj != null)
                        {
                            Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                            Entity entcopy = (Entity)ent.Clone();
                            ent.TransformBy(Matrix3d.Displacement(vt3d));
                            bltr.AppendEntity(entcopy);
                            tr.AddNewlyCreatedDBObject(entcopy, true);
                        }
                    }
                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }
            }
        }
        #endregion

        #region [Trim / extend curve]
        private void CmdTE()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Auto unhighlight entities when process finish .
            using (KRUnhighlight myUnHighlight = new KRUnhighlight())
            using (KRResetSystemVar myResetOrtho = new KRResetSystemVar("ORTHOMODE",0))
            using (KRResetUCS myResetUcs = new KRResetUCS())
            {
                //Start main transaction :
                using (Transaction tr = db.TransactionManager.StartOpenCloseTransaction())
                {
                    #region [Get boundary curve]
                    //Prompt option :
                    PromptEntityOptions peo = new PromptEntityOptions("\nSelect the boundary curve :");
                    peo.SetRejectMessage("\nInvalid selection. Please select curve !");
                    peo.AddAllowedClass(typeof(Curve), false);

                    //Prompt result :
                    PromptEntityResult per = ed.GetEntity(peo);
                    if (per.Status != PromptStatus.OK)
                        return;
                    else
                        myUnHighlight.Add(per.ObjectId);

                    //Open curve for write :
                    Curve boCurv = (Curve)tr.GetObject(per.ObjectId, OpenMode.ForWrite);

                    //Get sub entity that is nearest to picked point :
                    Entity subBoCurv;
                    FullSubentityPath path = FullSubentityPath.Null;
                    if (per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Polyline2d)))
                        || per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(
                            Autodesk.AutoCAD.DatabaseServices.Polyline)))
                        )
                    {
                        Point3d cloPnt;
                        double param;
                        try
                        {
                            cloPnt = boCurv.GetClosestPointTo(per.PickedPoint, true);
                            param = boCurv.GetParameterAtPoint(cloPnt);
                            path = new FullSubentityPath(new ObjectId[] { boCurv.Id },
                                        new SubentityId(SubentityType.Edge, new IntPtr((int)param + 1)));
                            subBoCurv = boCurv.GetSubentity(path);
                        }
                        catch (System.Exception ex)
                        {
                            ed.WriteMessage(ex.ToString());
                            return;
                        }
                    }
                    else
                    {
                        subBoCurv = null;
                    }

                    //Highlight curve :
                    try
                    {
                        if (subBoCurv != null)
                            boCurv.Highlight(path, false);
                        else
                            boCurv.Highlight();
                    }
                    catch (System.Exception ex)
                    {
                        ed.WriteMessage(ex.ToString());
                        return;
                    }
                    #endregion

                    #region [Select curves to trim /extend]
                    //Create a TypedValue array to define the filter criteria :
                    TypedValue[] acTypValAr = new TypedValue[9];
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LINE"), 1);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "ARC"), 2);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LWPOLYLINE"), 3);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "POLYLINE"), 4);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "XLINE"), 5);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "RAY"), 6);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "SPLINE"), 7);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 8);

                    //Create new selection filter from above TypedValue 's array :
                    SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

                    //Prompt option :
                    PromptSelectionOptions pso = new PromptSelectionOptions
                    {
                        MessageForAdding = "\nSelect curves to trim/ extend :"
                    };

                    //Prompt result :
                    PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);

                    //Selection set :
                    SelectionSet ss;
                    //Check prompt return value :
                    if (acSSPrompt.Status != PromptStatus.OK ||
                        acSSPrompt.Value.Count == 0)
                    {
                        ed.WriteMessage("\nYou selected nothing !");
                        return;
                    }
                    else
                        ss = acSSPrompt.Value;

                    //Unhighlight boudnary curve :
                    try
                    {
                        boCurv.Unhighlight();
                    }
                    catch (System.Exception ex)
                    {
                        //throw;
                        ed.WriteMessage(ex.ToString());
                        return;
                    }
                    #endregion

                    //Pick the standard point :
                    Point3d stdPnt = per.PickedPoint;
                    if (KRGetPoint(ed, "\nPick the standard point :", Point3d.Origin, ref stdPnt,
                        false) != PromptStatus.OK)
                        return;

                    //Boundary curve for extend or trim :
                    Curve boCurveSeg;
                    if (subBoCurv != null)
                        boCurveSeg = (Curve)subBoCurv;
                    else
                        boCurveSeg = boCurv;

                    //Iterate selection set and trim/ extend members :
                    foreach (SelectedObject sObj in ss)
                    {
                        //Get selected point sample :
                        //https://forums.autodesk.com/t5/net/any-way-to-get-points-used-in-getselection/td-p/5706564
                        
                        //if (sObj != null && sObj.ObjectId != boCurv.ObjectId)
                        if (sObj != null)
                        {
                            //Allocate new points collection for intersection : 
                            Point3dCollection intPnts = new Point3dCollection();

                            //Open member curve for read :
                            Curve memCurv = (Curve)tr.GetObject(sObj.ObjectId, OpenMode.ForRead);

                            //Check intersection without extending member curve :
                            memCurv.IntersectWith(boCurveSeg, Intersect.ExtendArgument,
                                                    intPnts, IntPtr.Zero, IntPtr.Zero);
                            if (intPnts.Count > 0)
                                //Call trim sub SubFunction :
                                CmdTE_TrimCurves(ed, tr, boCurveSeg , memCurv, intPnts, stdPnt);
                            else
                            {
                                if (memCurv.ObjectId.ObjectClass.
                                    IsDerivedFrom(RXClass.GetClass(typeof(Spline))))
                                {
                                    //Cast curve to spline :
                                    Spline splObj = (Spline)memCurv;

                                    //Update curve to open :
                                    splObj.UpgradeOpen();

                                    //Define point to extend :
                                    Point3d extPnt;
                                    
                                    if (splObj.StartPoint.DistanceTo(per.PickedPoint) <
                                        splObj.EndPoint.DistanceTo(per.PickedPoint))
                                        extPnt = splObj.StartPoint;
                                    else
                                        extPnt = splObj.EndPoint;

                                    Vector3d extVt = splObj.GetFirstDerivative(extPnt);

                                    //Create temp line then join it into spline :
                                    using (Line tempLine = new Line())
                                    {
                                        //Create plane 2d to convert 3d geometry -> 2d geometry :
                                        var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                                        var plane = new Plane(Point3d.Origin, normal);

                                        //Find the intersection point to boundary curve :
                                        tempLine.StartPoint = extPnt;
                                        tempLine.EndPoint = PolarXYonUCS(extPnt, extVt.AngleOnPlane(plane), extVt.Length);
                                        tempLine.Layer = splObj.Layer;
                                        intPnts.Clear();//Reset intersection points
                                        tempLine.IntersectWith(boCurveSeg, Intersect.ExtendBoth, intPnts, IntPtr.Zero, IntPtr.Zero);
                                        if (intPnts.Count == 0 || intPnts.Count > 1)
                                        {
                                            return;
                                        }
                                        else
                                            tempLine.EndPoint = intPnts[0];

                                        //Extend spline to intersection point:
                                        try
                                        {
                                            if (extPnt == splObj.StartPoint)
                                            {
                                                splObj.Extend(true, intPnts[0]);
                                            }
                                            else
                                            {
                                                splObj.Extend(false, intPnts[0]);
                                            }
                                        }
                                        catch (System.Exception ex)
                                        {
                                            ed.WriteMessage($"\nError : {ex.Message}. Using join line instead !");
                                            splObj.JoinEntity(tempLine);
                                        }
                                    }
                                }
                                else
                                {
                                    //Check intersection with extending member curve :
                                    memCurv.IntersectWith(boCurveSeg, Intersect.ExtendBoth,
                                            intPnts, IntPtr.Zero, IntPtr.Zero);
                                    if (intPnts.Count == 0)
                                        continue;//Skip to next entity
                                    else
                                        CmdTE_ExtendCurves(ed, tr, boCurveSeg ,
                                                memCurv, intPnts, stdPnt);
                                }
                            }
                        }
                    }

                    //Commit changes :
                    tr.Commit();
                }
            }
        }

        private void CmdTE_TrimCurves(Editor baseEd, Transaction baseTr,
                              Curve boCurv, Curve memCurv,
                              Point3dCollection intPnts, Point3d stdPnt)
        {
            //Variable for trim point :
            Point3d trimPnt;

            //Upgrate member curve to 'OpenForWrite'
            memCurv.UpgradeOpen();

            trimPnt = intPnts[0];

            //Find point to trim :
            if (intPnts.Count > 1)
            {
                for (int i = 1; i < intPnts.Count; i++)
                {
                    if (stdPnt.DistanceTo(intPnts[i]) <
                        stdPnt.DistanceTo(trimPnt))
                        trimPnt = intPnts[i];
                }
            }

            #region [Trim curve]
            try
            {
                Point3dCollection splitPnts = new Point3dCollection() { trimPnt };

                using (DBObjectCollection splitCurvs = memCurv.GetSplitCurves(splitPnts))
                {
                    //Find closet points  :
                    Point3d cloPnt = ((Curve)splitCurvs[0]).GetClosestPointTo(stdPnt, false);

                    #region [Back codes]
                    ////Trim curve :
                    //if (cloPnt.DistanceTo(trimPnt) <= KRTolerance)
                    //    memCurv.HandOverTo(splitCurvs[1], true, true);
                    //else
                    //    memCurv.HandOverTo(splitCurvs[0], true, true);
                    #endregion

                    Curve retCurv;
                    if (cloPnt.DistanceTo(trimPnt) <= KRTolerance)
                        retCurv = (Curve)splitCurvs[1];
                    else
                        retCurv = (Curve)splitCurvs[0];

                    ObjectId retId;
                    using (Transaction tr = db().TransactionManager.StartTransaction())
                    {
                        retId = AppendEnt(tr, retCurv);
                        tr.Commit();
                    }

                    memCurv.SwapIdWith(retId, true, true);
                    memCurv.Erase();
                }
            }

            catch (System.Exception ex)
            {
                baseEd.WriteMessage(ex.ToString());
                return;
            }
            #endregion
        }

        private void CmdTE_ExtendCurves(Editor baseEd, Transaction baseTr,
                                Curve boCurv, Curve memCurv, 
                                Point3dCollection intPnts , Point3d stdPnt)
        {
            //Variable for extend point :
            Point3d extPnt = intPnts[0];

            //Upgrate member curve to 'OpenForWrite'
            memCurv.UpgradeOpen();

            if (memCurv.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Ray))))
            {
                //Cast curve to ray :
                Ray rayObj = (Ray)memCurv;

                //Find point to extend :
                if (intPnts.Count > 1)
                {
                    for (int i = 1; i < intPnts.Count; i++)
                    {
                        if (rayObj.BasePoint.DistanceTo(intPnts[i]) < 
                            rayObj.BasePoint.DistanceTo(extPnt))
                            extPnt = intPnts[i];
                    }
                }
                
                //Extend ray 's base point to extend point :
                rayObj.BasePoint = extPnt;
            }
            else
            {
                //Find point to extend :
                if (intPnts.Count > 1)
                {
                    for (int i = 1; i < intPnts.Count; i++)
                    {
                        if (stdPnt.DistanceTo(intPnts[i]) <
                            stdPnt.DistanceTo(extPnt))
                            extPnt = intPnts[i];
                    }
                }

                //Get distance from extend point to member curve 's start & end :
                double startDist, endDist;
                startDist = memCurv.StartPoint.DistanceTo(extPnt);
                endDist = memCurv.EndPoint.DistanceTo(extPnt);
                
                //Extend member curve :
                if (startDist < endDist)
                    memCurv.Extend(true, extPnt);
                else
                    memCurv.Extend(false, extPnt);
            }
        }

        //Version 2:
        [CommandMethod("TE")]
        public void CmdTENE()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Initialize variables for nested:
            bool curv1Highlighted = false;
            PromptNestedEntityResult pner1 = null;

            try
            {
                #region [Get & highlight boundary curve]
                PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("")
                {
                    AllowNone = true,
                };
                pneo.Keywords.Add("Partial");
                pneo.Keywords.Default = "Partial";
                //pneo.Keywords.Add("Points");
                bool isCurvByPnt = false;

                //Set defaut values to avoid compile error:
                //Point3d kwPnt1 = new Point3d();

                //Get boundary curve 1's nested entity:
                pneo.Message = "\nSelect boundary: ";
                pner1 = GetNestedCurveOrLeader(ed, pneo);
                if (pner1.Status == PromptStatus.Cancel || pner1.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get boundary!");
                    return;
                }
                else if (pner1.Status == PromptStatus.Keyword || pner1.Status == PromptStatus.None)
                {
                    #region [Solution 1 - on hold]
                    //if (KRGetPoint(ed, "\nPoint for boundary: ", Point3d.Origin, ref kwPnt1) !=
                    //    PromptStatus.OK)
                    //{
                    //    return;
                    //}
                    //else
                    //{
                    //    isCurvByPnt = true;
                    //}
                    #endregion

                    #region [Solution 2 - on running]
                    CmdTE();

                    return;
                    #endregion
                }
                else
                {
                    //Highlight curve 1:
                    KRUnhighlight.HighlightNested(db, ed, pner1, true,true);
                    curv1Highlighted = true;
                }
                #endregion

                #region [Select members]
                //Prompt option :
                PromptSelectionOptions pso = new PromptSelectionOptions
                {
                    MessageForAdding = "\nSelect curve to trim: ",
                    RejectObjectsOnLockedLayers = true
                };

                //Create a TypedValue array to define the filter criteria :
                List<string> typesList = new List<string>()
                {
                    "LINE","RAY","XLINE",
                    "CIRCLE","ARC","ELLIPSE",
                    "POLYLINE","LWPOLYLINE",
                    "SPLINE"
                };

                int acTypValArLen = typesList.Count + 2;
                TypedValue[] acTypValAr = new TypedValue[acTypValArLen];
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), acTypValArLen -1);
                for (int i = 1 ; i < acTypValArLen - 1; i++)
                {
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, typesList[i - 1]), i);
                }

                //Create new selection filter from above TypedValue 's array :
                SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

                //Prompt result :
                PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);

                //Check prompt return value :
                if (acSSPrompt.Status != PromptStatus.OK ||
                    acSSPrompt.Value.Count == 0)
                {
                    ed.WriteMessage("\nYou selected nothing!");
                    return;
                }
                #endregion

                #region [Get side to keep]
                PromptPointOptions ppo = new PromptPointOptions("")
                {
                    Message = "\nPick side to keep: ",
                    AllowArbitraryInput = false,
                    AllowNone = false,
                    BasePoint = Point3d.Origin,
                    UseBasePoint = true
                };

                PromptPointResult ppr = ed.GetPoint(ppo);
                if (ppr.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nCannot get side point!");
                    return;
                }

                //Get side point in WCS:
                Point3d sidePntWcs = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
                #endregion
                
                //Main transaction:
                using (Transaction tr = db.TransactionManager.StartOpenCloseTransaction())
                {
                    //Split by curve:
                    if (!isCurvByPnt)
                    {
                        //Open boundary curve for read:
                        Curve boCurv;
                        if (pner1.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                        {
                            Vertex2d vert2d = tr.GetObject(pner1.ObjectId, OpenMode.ForRead) as Vertex2d;
                            boCurv = tr.GetObject(vert2d.OwnerId, OpenMode.ForRead) as Curve;
                        }
                        else
                        {
                            boCurv = tr.GetObject(pner1.ObjectId, OpenMode.ForRead) as Curve;
                        }

                        //Get outer most:
                        ObjectId boOuterId = GetBounded(pner1);

                        #region [Old codes]
                        ////Get boundary curve's geometry:
                        //Curve3d boGeoCurv = boCurv.GetGeCurve();    //Geo in ECS
                        //boGeoCurv.TransformBy(pner1.Transform);     //Transform ECS -> WCS

                        ////Extend boundary curve to get intersection as much as possible:
                        //if (boGeoCurv is LineSegment3d geoLine)
                        //{
                        //    Vector3d lineSegVec = geoLine.Direction;
                        //    Point3d basePnt = new Point3d((geoLine.StartPoint.X + geoLine.EndPoint.X) / 2.0,
                        //                                (geoLine.StartPoint.Y + geoLine.EndPoint.Y) / 2.0,
                        //                                geoLine.StartPoint.Z);

                        //    boGeoCurv.Dispose();
                        //    boGeoCurv = new Line3d(basePnt, lineSegVec);
                        //}
                        //else if (boGeoCurv is Ray3d geoRay)
                        //{
                        //    Vector3d lineSegVec = geoRay.Direction;
                        //    Point3d basePnt = geoRay.StartPoint;

                        //    boGeoCurv.Dispose();
                        //    boGeoCurv = new Line3d(basePnt, lineSegVec);
                        //}
                        //else if (boGeoCurv is CircularArc3d geoCir)
                        //{
                        //    if (!geoCir.IsClosed())
                        //    {
                        //        Point3d centerPnt = geoCir.Center;
                        //        double radius = geoCir.Radius;

                        //        boGeoCurv.Dispose();
                        //        boGeoCurv = new CircularArc3d(centerPnt, Vector3d.ZAxis,radius);
                        //    }
                        //}
                        
                        //myDisposeLst.Add(boGeoCurv);
                        #endregion

                        //Get boundary curve's geometry:
                        using (Curve3d boGeoCurv = boCurv.GetGeCurve())
                        {
                            //ECS -> WCS:
                            boGeoCurv.TransformBy(pner1.Transform);

                            using (Curve cloneBoCurv = Curve.CreateFromGeCurve(boGeoCurv))
                            {
                                Vector3d boCrossVt = CurveCrossProduct(cloneBoCurv, sidePntWcs);

                                //Iterate selection set:
                                foreach (SelectedObject sObj in acSSPrompt.Value)
                                {
                                    if (sObj != null && sObj.ObjectId != boOuterId)
                                    {
                                        //Open member curve for read:
                                        Curve memCurv = tr.GetObject(sObj.ObjectId, OpenMode.ForRead) as Curve;

                                        using (Point3dCollection intPnts = new Point3dCollection())
                                        {
                                            cloneBoCurv.IntersectWith(memCurv, Intersect.ExtendBoth, intPnts, 
                                                                                    IntPtr.Zero, IntPtr.Zero);
                                            if (intPnts.Count > 0)
                                            {
                                                //Extend member:
                                                using (Point3dCollection extPnts = new Point3dCollection())
                                                {
                                                    //Use list to sort intersection points:
                                                    List<Point3d> intPntList = new List<Point3d>();

                                                    using (Curve3d memGeoCurv = memCurv.GetGeCurve())
                                                    {
                                                        if (!memGeoCurv.IsClosed())
                                                        {
                                                            foreach (Point3d intPnt in intPnts)
                                                            {
                                                                if (!memGeoCurv.IsOn(intPnt))
                                                                {
                                                                    extPnts.Add(intPnt);
                                                                }

                                                                intPntList.Add(intPnt);
                                                            }
                                                        }
                                                    }

                                                    if (extPnts.Count > 0)
                                                    {
                                                        memCurv.UpgradeOpen();
                                                        
                                                        using (Curve3d memGeoCurv = memCurv.GetGeCurve())
                                                        {
                                                            if (extPnts.Count == 1 && memGeoCurv is CircularArc3d geoCir)
                                                            {
                                                                using (Transaction subTr = db.TransactionManager.StartTransaction())
                                                                {
                                                                    ObjectId newId;

                                                                    //Create new full circle:
                                                                    using (Circle newCir = new Circle(geoCir.Center, Vector3d.ZAxis, geoCir.Radius))
                                                                    {
                                                                        newCir.SetPropertiesFrom(memCurv);
                                                                        newId = AppendEnt(subTr, newCir);
                                                                    }

                                                                    subTr.Commit();

                                                                    //Exchange with the old one:
                                                                    memCurv.SwapIdWith(newId, true, true);
                                                                    memCurv.Erase();

                                                                    continue;
                                                                }
                                                            }
                                                            else if (extPnts.Count == 1 && memGeoCurv is EllipticalArc3d geoEl)
                                                            {
                                                                using (Transaction subTr = db.TransactionManager.StartTransaction())
                                                                {
                                                                    ObjectId newId;

                                                                    //Create new full circle:
                                                                    using (EllipticalArc3d geoFullEl = new EllipticalArc3d(geoEl.Center, geoEl.MajorAxis, geoEl.MinorAxis,
                                                                        geoEl.MajorRadius, geoEl.MinorRadius))
                                                                    using(Curve newEl = Curve.CreateFromGeCurve(geoFullEl))
                                                                    {
                                                                        newEl.SetPropertiesFrom(memCurv);
                                                                        newId = AppendEnt(subTr, newEl);
                                                                    }

                                                                    subTr.Commit();

                                                                    //Exchange with the old one:
                                                                    memCurv.SwapIdWith(newId, true, true);
                                                                    memCurv.Erase();

                                                                    continue;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                foreach (Point3d extPnt in extPnts)
                                                                {
                                                                    //Check side to extend:
                                                                    if (memGeoCurv.HasEndPoint)
                                                                    {
                                                                        if (extPnt.DistanceTo(memGeoCurv.StartPoint) <
                                                                            extPnt.DistanceTo(memGeoCurv.EndPoint))
                                                                        {
                                                                            memCurv.Extend(true, extPnt);
                                                                        }
                                                                        else
                                                                        {
                                                                            memCurv.Extend(false, extPnt);
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        //Always insert at start:
                                                                        memCurv.Extend(true, extPnt);
                                                                    }
                                                                }

                                                                #region [For learning NOT DELETE]
                                                                //https://forums.autodesk.com/t5/net/sort-point3dcollection-by-x/td-p/5221137
                                                                //List<Point3d> extPntList = new List<Point3d>();

                                                                //if (memGeoCurv.HasStartPoint)
                                                                //{
                                                                //    //ed.WriteMessage($"\nStart Param : {memGeoCurv.GetParameterOf(memGeoCurv.StartPoint)}");
                                                                //    extPntList.Add(memGeoCurv.StartPoint);
                                                                //}

                                                                //if (memGeoCurv.HasEndPoint)
                                                                //{
                                                                //    //ed.WriteMessage($"\nEnd Param : {memGeoCurv.GetParameterOf(memGeoCurv.EndPoint)}");
                                                                //    extPntList.Add(memGeoCurv.EndPoint);
                                                                //}

                                                                //foreach (Point3d extPnt in extPnts)
                                                                //{
                                                                //    extPntList.Add(extPnt);
                                                                //}

                                                                //extPntList.Sort((a, b) => memGeoCurv.GetParameterOf(a).CompareTo(memGeoCurv.GetParameterOf(b)));

                                                                ////Extend start:
                                                                //Point3d newStartPnt = extPntList[0];
                                                                //if (!newStartPnt.Equals(memGeoCurv.StartPoint))
                                                                //{
                                                                //    memCurv.Extend(true, extPntList[0]);
                                                                //}

                                                                ////Extend end:
                                                                //if (memGeoCurv.HasEndPoint)
                                                                //{
                                                                //    Point3d newEndPnt = extPntList[extPntList.Count - 1];
                                                                //    if (!newEndPnt.Equals(memGeoCurv.StartPoint) &&
                                                                //        !newEndPnt.Equals(memGeoCurv.EndPoint))
                                                                //    {
                                                                //        memCurv.Extend(false, newEndPnt);
                                                                //    }
                                                                //}
                                                                #endregion
                                                            }
                                                        }

                                                        memCurv.DowngradeOpen();
                                                    }
                                                }

                                                //Sort intersection:
                                                intPnts.Clear();
                                                cloneBoCurv.IntersectWith(memCurv, Intersect.ExtendThis, intPnts,
                                                                                    IntPtr.Zero, IntPtr.Zero);
                                                using (Curve3d memGeoCurv = memCurv.GetGeCurve())
                                                {
                                                    if (intPnts.Count == 0)
                                                    {
                                                        ed.WriteMessage("\nCannot get intersects for trimming!");
                                                        tr.Abort();
                                                        return;
                                                    }

                                                    if (intPnts.Count > 1)
                                                    {
                                                        for (int i = 0; i < intPnts.Count - 1; i++)
                                                        {
                                                            for (int j = i + 1; j < intPnts.Count; j++)
                                                            {
                                                                if (memGeoCurv.GetParameterOf(intPnts[j]) <
                                                                    memGeoCurv.GetParameterOf(intPnts[i]))
                                                                {
                                                                    Point3d tempPnt = intPnts[i];
                                                                    intPnts[i] = intPnts[j];
                                                                    intPnts[j] = tempPnt;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    #region [Old codes]
                                                    //intPnts.Clear();
                                                    //List<Point3d> startEndPnts = new List<Point3d>();
                                                    //startEndPnts.Add(memGeoCurv.StartPoint);
                                                    //if (memGeoCurv.HasEndPoint)
                                                    //{
                                                    //    startEndPnts.Add(memGeoCurv.EndPoint);
                                                    //}

                                                    //for (int i = 0; i < intPntList.Count; i++)
                                                    //{
                                                    //    if (!startEndPnts.Contains(intPntList[i]))
                                                    //    {
                                                    //        intPnts.Add(intPntList[i]);
                                                    //    }
                                                    //}
                                                    #endregion
                                                }

                                                //Trim member:
                                                bool noNeedToTrim = intPnts.Count == 1 && (memCurv is Circle || memCurv is Ellipse);
                                                if (!noNeedToTrim)
                                                {
                                                    using (DBObjectCollection splitObjs = memCurv.GetSplitCurves(intPnts))
                                                    using (ObjectIdCollection addIds = new ObjectIdCollection())
                                                    {
                                                        //Iterate split objects to add:
                                                        foreach (var splitObj in splitObjs)
                                                        {
                                                            if (splitObj is Curve splitCurv)
                                                            {
                                                                using (Curve3d splitGeoCurv = splitCurv.GetGeCurve())
                                                                {
                                                                    Point3d checkPnt = splitGeoCurv.EvaluatePoint(splitCurv.StartParam + KRTolerance);

                                                                    bool needToAdd = false;

                                                                    if (boGeoCurv is CircularArc3d boGeoCir)
                                                                    {
                                                                        if (boGeoCir.IsInside(checkPnt) == boGeoCir.IsInside(sidePntWcs))
                                                                        {
                                                                            needToAdd = true;
                                                                        }
                                                                    }
                                                                    else if (boGeoCurv is EllipticalArc3d boGeoEl)
                                                                    {
                                                                        if (boGeoEl.IsInside(checkPnt) == boGeoEl.IsInside(sidePntWcs))
                                                                        {
                                                                            needToAdd = true;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        Vector3d memCrossVt = CurveCrossProduct(cloneBoCurv, checkPnt);

                                                                        //Add and close:
                                                                        if (memCrossVt.IsCodirectionalTo(boCrossVt))
                                                                        {
                                                                            needToAdd = true;
                                                                        }
                                                                    }

                                                                    if (needToAdd)
                                                                    {
                                                                        using (Transaction subTr = db.TransactionManager.StartTransaction())
                                                                        {
                                                                            addIds.Add(AppendEnt(subTr, splitCurv));
                                                                            subTr.Commit();
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        //Erase source:
                                                        if (addIds.Count > 0)
                                                        {
                                                            memCurv.UpgradeOpen();
                                                            memCurv.SwapIdWith(addIds[0], true, true);
                                                            memCurv.Erase();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        //Iterate selection set:
                        #region [Solution 1 - on hold]
                        //foreach (SelectedObject sObj in acSSPrompt.Value)
                        //{
                        //    if (sObj != null && sObj.ObjectId != boOuterId)
                        //    {
                        //        Curve memCurv = tr.GetObject(sObj.ObjectId, OpenMode.ForRead) as Curve;

                        //        using (Curve3d boGeoCurv = boCurv.GetGeCurve())
                        //        using (Curve3d memGeoCurv = memCurv.GetGeCurve())
                        //        {
                        //            boGeoCurv.TransformBy(pner1.Transform);     //ECS -> WCS

                        //            //Extend to fit boundary & member:
                        //            #region [Solution 1 - on holding]
                        //            //using (Curve3d tempGeoCurv = memCurv.GetGeCurve())
                        //            //using (CurveCurveIntersector3d tempInterSector = new CurveCurveIntersector3d(boGeoCurv,
                        //            //                                                            tempGeoCurv, Vector3d.ZAxis))
                        //            //{
                        //            //    if (!tempGeoCurv.IsClosed())
                        //            //    {
                        //            //        if (ExtendCurve(boGeoCurv, memCurv) != true)
                        //            //        {
                        //            //            ed.WriteMessage("\nCannot extend curve!");
                        //            //        }
                        //            //    }

                        //            //    #region [old codes]
                        //            //    //if ((tempInterSector == null || tempInterSector.NumberOfIntersectionPoints == 0) &&
                        //            //    //    !tempGeoCurv.IsClosed()
                        //            //    //    )
                        //            //    //{
                        //            //    //    ExtendCurve(boGeoCurv, memCurv);

                        //            //    //    #region [Old codes]
                        //            //    //    //if (tempGeoCurv.HasStartPoint)
                        //            //    //    //{
                        //            //    //    //    if (ExtendCurve(boGeoCurv, pickPntWcs, memCurv, memCurv.StartPoint) != true)
                        //            //    //    //    {
                        //            //    //    //        ed.WriteMessage("\nCannot extend curve's start!");
                        //            //    //    //        tr.Abort();
                        //            //    //    //        return;
                        //            //    //    //    }
                        //            //    //    //}

                        //            //    //    //if (tempGeoCurv.HasEndPoint)
                        //            //    //    //{
                        //            //    //    //    if (ExtendCurve(boGeoCurv, pickPntWcs, memCurv, memCurv.EndPoint) != true)
                        //            //    //    //    {
                        //            //    //    //        ed.WriteMessage("\nCannot extend curve's end!");
                        //            //    //    //        tr.Abort();
                        //            //    //    //        return;
                        //            //    //    //    }
                        //            //    //    //}
                        //            //    //    #endregion
                        //            //    //}
                        //            //    #endregion
                        //            //}
                        //            #endregion
                        //            //ExtendToFit(boGeoCurv, memGeoCurv, tr, memCurv);    //<- on buidling
                        //            //ed.WriteMessage($"\nDistance : {boGeoCurv.GetDistanceTo(memGeoCurv)}");

                        //            #region [Test codes 1]
                        //            //using (Curve tempBoCurv = Curve.CreateFromGeCurve(boGeoCurv))
                        //            //using (Point3dCollection tempIntPnts = new Point3dCollection())
                        //            //using (Point3dCollection extPnts = new Point3dCollection())
                        //            //{
                        //            //    tempBoCurv.IntersectWith(memCurv, Intersect.ExtendBoth, tempIntPnts, IntPtr.Zero, IntPtr.Zero);
                        //            //    if (tempIntPnts.Count > 0)
                        //            //    {
                        //            //        //ed.WriteMessage($"\nNumber of intersect(Extend both) : {tempIntPnts.Count}");

                        //            //        foreach (Point3d intPnt in tempIntPnts)
                        //            //        {
                        //            //            if (!memGeoCurv.IsOn(intPnt))
                        //            //            {
                        //            //                extPnts.Add(intPnt);
                        //            //            }
                        //            //        }


                        //            //        if (extPnts.Count == 1)
                        //            //        {
                        //            //            memCurv.UpgradeOpen();

                        //            //            if (extPnts[0].DistanceTo(memCurv.StartPoint) <
                        //            //                extPnts[0].DistanceTo(memCurv.EndPoint))
                        //            //            {
                        //            //                memCurv.StartPoint = extPnts[0];
                        //            //            }
                        //            //            else
                        //            //            {
                        //            //                memCurv.EndPoint = extPnts[0];
                        //            //            }

                        //            //            memCurv.DowngradeOpen();
                        //            //        }
                        //            //        else if (extPnts.Count > 1)
                        //            //        {
                        //            //            List<Point3d> extPntLst = new List<Point3d>();
                        //            //            foreach (Point3d extPnt in extPnts)
                        //            //            {
                        //            //                extPntLst.Add(extPnt);
                        //            //            }

                        //            //            Point3d newStartPnt;
                        //            //            extPntLst.Sort((a, b) => a.DistanceTo(memCurv.StartPoint).CompareTo(
                        //            //                                     b.DistanceTo(memCurv.StartPoint)));
                        //            //            newStartPnt = extPntLst[0];
                        //            //            extPntLst.RemoveAt(0);

                        //            //            Point3d newEndPnt;
                        //            //            extPntLst.Sort((a, b) => a.DistanceTo(memCurv.EndPoint).CompareTo(
                        //            //                                     b.DistanceTo(memCurv.EndPoint)));
                        //            //            newEndPnt = extPntLst[0];

                        //            //            memCurv.UpgradeOpen();
                        //            //            memCurv.StartPoint = newStartPnt;
                        //            //            memCurv.EndPoint = newEndPnt;
                        //            //            memCurv.DowngradeOpen();
                        //            //        }
                        //            //    }


                        //            //}
                        //            #endregion

                        //            //Trim:
                        //            using (CurveCurveIntersector3d interSector = new CurveCurveIntersector3d(boGeoCurv,
                        //                                                             memGeoCurv, Vector3d.ZAxis))
                        //            {
                        //                //myDisposeLst.Add(interSector);
                        //                if (interSector != null && interSector.NumberOfIntersectionPoints > 0)
                        //                {
                        //                    //ed.WriteMessage($"\nNumber of intersection : {interSector.NumberOfIntersectionPoints}");

                        //                    //Get intersection points:
                        //                    Point3d intPnt;
                        //                    for (int i = 0; i < interSector.NumberOfIntersectionPoints; i++)
                        //                    {
                        //                        intPnt = interSector.GetIntersectionPoint(i);
                        //                        intPnts.Add(intPnt);
                        //                    }

                        //                    //Sort intersection points (using bubble sort):
                        //                    if (intPnts.Count > 1)
                        //                    {
                        //                        for (int i = 0; i < intPnts.Count - 1; i++)
                        //                        {
                        //                            for (int j = i + 1; j < intPnts.Count; j++)
                        //                            {
                        //                                double thisParam = memGeoCurv.GetParameterOf(intPnts[i]);
                        //                                double nextParam = memGeoCurv.GetParameterOf(intPnts[j]);

                        //                                if (nextParam < thisParam)
                        //                                {
                        //                                    Point3d tempIntPnt = intPnts[i];
                        //                                    intPnts[i] = intPnts[j];
                        //                                    intPnts[j] = tempIntPnt;
                        //                                }
                        //                            }
                        //                        }
                        //                    }

                        //                    #region [Sample sort]
                        //                    //Use LINQ to sort intersection points:
                        //                    //intPnts.Cast<Point3d>().OrderBy(point => point.X);
                        //                    #endregion

                        //                    //Split member curve
                        //                    using (DBObjectCollection dbObjs = memCurv.GetSplitCurves(intPnts))
                        //                    using (ObjectIdCollection objIds = new ObjectIdCollection())
                        //                    {
                        //                        if (dbObjs != null && dbObjs.Count > 1)
                        //                        {
                        //                            using (Transaction subTr = db.TransactionManager.StartTransaction())
                        //                            {
                        //                                foreach (DBObject item in dbObjs)
                        //                                {
                        //                                    if (item is Curve splitCurv)
                        //                                    {
                        //                                        splitCurv.SetPropertiesFrom(memCurv);

                        //                                        //Check side & add
                        //                                        using (DisposeList subDispose = new DisposeList())
                        //                                        {
                        //                                            bool memIsOutside = true;

                        //                                            Curve3d tempSpitCurv = splitCurv.GetGeCurve();
                        //                                            subDispose.Add(tempSpitCurv);

                        //                                            int sampleLen = 4;
                        //                                            PointOnCurve3d[] tempPntOnCurv = tempSpitCurv.GetSamplePoints(sampleLen);
                        //                                            foreach (PointOnCurve3d pnt in tempPntOnCurv)
                        //                                            {
                        //                                                subDispose.Add(pnt);
                        //                                            }

                        //                                            Point3d midPnt = tempPntOnCurv[sampleLen / 2 - 1].Point;

                        //                                            memIsOutside = IsOutSideCurve(boGeoCurv, midPnt);
                        //                                            if (memIsOutside == isOutSide)
                        //                                            {
                        //                                                objIds.Add(AppendEnt(subTr, splitCurv));
                        //                                            }
                        //                                        }
                        //                                    }
                        //                                }

                        //                                //Commit changes:
                        //                                subTr.Commit();
                        //                            }

                        //                            //Swap id with the first splitted:
                        //                            if (objIds.Count > 0)
                        //                            {
                        //                                memCurv.UpgradeOpen();
                        //                                memCurv.SwapIdWith(objIds[0], true, true);
                        //                                memCurv.Erase();
                        //                            }
                        //                        }
                        //                    }

                        //                    //Clear intersection points:
                        //                    intPnts.Clear();
                        //                }
                        //            }
                        //        }
                        //    }
                        //}
                        #endregion
                    }

                    //Split by point:
                    else
                    {
                        ed.WriteMessage("\nOn building!");
                        
                        #region [On building]
                        //foreach (SelectedObject sObj in acSSPrompt.Value)
                        //{
                        //    if (sObj != null)
                        //    {
                        //        //Open member curve for read:
                        //        Curve memCurv = tr.GetObject(sObj.ObjectId, OpenMode.ForRead) as Curve;

                        //        //Get boundary curve by point:
                        //        using (Xline boXline = new Xline())
                        //        {
                        //            //Get pick point in WCS:
                        //            Point3d pickPntUcs = kwPnt1;
                        //            Point3d pickPntWcs = pickPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);

                        //            //Get closest point in WCS:
                        //            Point3d cloPntWcs;
                        //            try
                        //            {
                        //                cloPntWcs = memCurv.GetClosestPointTo(pickPntWcs, true);
                        //            }
                        //            catch (System.Exception ex)
                        //            {
                        //                ed.WriteMessage(ex.Message);
                        //                continue;
                        //            }

                        //            //Get direction vector in WCS:
                        //            Vector3d dirVecWcs = cloPntWcs.GetVectorTo(pickPntWcs);
                        //            boXline.BasePoint = cloPntWcs;
                        //            boXline.UnitDir = dirVecWcs;

                        //            //Find intersection:
                        //            memCurv.IntersectWith(boXline, Intersect.OnBothOperands, intPnts, IntPtr.Zero, IntPtr.Zero);
                        //            if (intPnts.Count == 0)
                        //            {
                        //                continue;
                        //            }
                        //            else
                        //            {
                        //                //Do something:
                        //                ed.WriteMessage($"\nCut by temp Xline. Number of intersections: {intPnts.Count}");


                        //            }
                        //        }

                        //        //Reset intersection collection:
                        //        intPnts.Clear();
                        //    }
                        //}
                        #endregion
                    }

                    //Commit changes:
                    tr.Commit();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage("\n" + ex.Message);
                return;
            }
            finally
            {
                if (curv1Highlighted == true && pner1 != null)
                {
                    KRUnhighlight.HighlightNested(db, ed, pner1, false,true);
                }
            }
        }
        
        //Lệnh trim Line/ Xline/ Ray bằng 2 boundary, có hổ trợ nested:
        [CommandMethod("TLT")]
        public void CmdTLTN()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("")
            {
                AllowNone = false,
            };
            pneo.Keywords.Add("Points");

            //Set defaut values to avoid compile error:
            Point3d kwPnt1 = new Point3d();
            Point3d kwPnt2 = new Point3d();

            //Initialize variables for nested:
            bool curv1Highlighted = false;
            bool curv2Highlighted = false;
            PromptNestedEntityResult pner1 = null;
            PromptNestedEntityResult pner2 = null;
            //string promptMsg;
            try
            {
                //Get boundary curve 1's nested entity:
                pneo.Message = "\nSelect boundary 1: ";
                pner1 = GetNestedCurveOrLeader(ed,pneo);
                if (pner1.Status == PromptStatus.Cancel || pner1.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get boundary 1!");
                    return;
                }
                else if (pner1.Status == PromptStatus.Keyword)
                {
                    if (KRGetPoint(ed, "\nPoint for boundary 1: ", Point3d.Origin, ref kwPnt1) !=
                        PromptStatus.OK)
                    {
                        return;
                    }
                }
                else
                {
                    //Highlight curve 1:
                    KRUnhighlight.HighlightNested(db, ed, pner1, true);
                    curv1Highlighted = true;
                }

                //Get boundary curve 2's nested entity:
                pneo.Message = "\nSelect boundary 2: ";
                pner2 = GetNestedCurveOrLeader(ed, pneo);
                if (pner2.Status == PromptStatus.Cancel || pner2.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get boundary 2!");
                    return;
                }
                else if (pner2.Status == PromptStatus.Keyword)
                {
                    if (KRGetPoint(ed, "\nPoint for boundary 2: ", Point3d.Origin, ref kwPnt2) !=
                        PromptStatus.OK)
                    {
                        return;
                    }
                }
                else
                {
                    //Highlight curve 2:
                    KRUnhighlight.HighlightNested(db, ed, pner2, true);
                    curv2Highlighted = true;
                }

                #region [Select members]
                //Prompt option :
                PromptSelectionOptions pso = new PromptSelectionOptions
                {
                    MessageForAdding = "\nSelect Line/ Ray/ XLine:",
                    RejectObjectsOnLockedLayers = true
                };

                //Create a TypedValue array to define the filter criteria :
                TypedValue[] acTypValAr = new TypedValue[5];
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LINE"), 1);
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "RAY"), 2);
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "XLINE"), 3);
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);

                //Create new selection filter from above TypedValue 's array :
                SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
               
                //Prompt result :
                PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);

                //Check prompt return value :
                if (acSSPrompt.Status != PromptStatus.OK ||
                    acSSPrompt.Value.Count == 0)
                {
                    ed.WriteMessage("\nYou selected nothing!");
                    return;
                }
                #endregion

                //Main transaction (using open & close)
                using (Transaction tr = db.TransactionManager.StartOpenCloseTransaction())
                {
                    Curve boCurv1;
                    Point3d cloPnt1;
                    if (pner1.Status == PromptStatus.OK)
                    {
                        //Read boundary curve 1 & its closest point:
                        boCurv1 = GetCurveInNested(tr, ed, pner1, out cloPnt1);
                        if (boCurv1 == null)
                        {
                            ed.WriteMessage("\nCannot read boundary curve 1!");
                            tr.Abort();
                            return;
                        }
                    }
                    else
                    {
                        //Set default values to avoid compile error:
                        cloPnt1 = new Point3d();
                        boCurv1 = null;
                    }

                    Curve boCurv2;
                    Point3d cloPnt2;
                    if (pner2.Status == PromptStatus.OK)
                    {
                        //Read boundary curve 2 & its closest point:
                        boCurv2 = GetCurveInNested(tr, ed, pner2, out cloPnt2);
                        if (boCurv2 == null)
                        {
                            ed.WriteMessage("\nCannot read boundary curve 2!");
                            tr.Abort();
                            return;
                        }
                    }
                    else
                    {
                        //Set default values to avoid compile error:
                        cloPnt2 = new Point3d();
                        boCurv2 = null;
                    }

                    using (Xline boXline1 = new Xline())
                    using (Xline boXline2 = new Xline())
                    {
                        //Get tangent vectors in ECS:
                        Vector3d tangVt1;
                        Vector3d tangVt2;

                        if (boCurv1 != null)
                        {
                            tangVt1 = boCurv1.GetFirstDerivative(cloPnt1);

                            //Create temp xlines to find intersection (ECS):
                            boXline1.BasePoint = cloPnt1.TransformBy(pner1.Transform);
                            boXline1.UnitDir = tangVt1.TransformBy(pner1.Transform);
                            boXline1.TransformBy(pner1.Transform.Inverse());
                        }
                        else
                        {
                            //Avoid compile error:
                            tangVt1 = new Vector3d();
                        }

                        if (boCurv2 != null)
                        {
                            tangVt2 = boCurv2.GetFirstDerivative(cloPnt2);

                            //Create temp xlines to find intersection (ECS):
                            boXline2.BasePoint = cloPnt2.TransformBy(pner2.Transform);
                            boXline2.UnitDir = tangVt2.TransformBy(pner2.Transform);
                            boXline2.TransformBy(pner2.Transform.Inverse());
                        }
                        else
                        {
                            //Avoid compile error:
                            tangVt2 = new Vector3d();
                        }

                        #region [Get outer most]
                        //Get outer most for nested 1 & nested 2:
                        ObjectId outerId1, outerId2;
                        if (boCurv1 != null)
                        {
                            outerId1 = GetBounded(pner1);
                        }
                        else
                        {
                            outerId1 = ObjectId.Null;
                        }

                        if (boCurv2 != null)
                        {
                            outerId2 = GetBounded(pner2);
                        }
                        else
                        {
                            outerId2 = ObjectId.Null;
                        }
                        #endregion

                        //Variable for counting processed entities:
                        int processCount = 0;

                        //Iterate selection set and trim/ extend members :
                        foreach (SelectedObject sObj in acSSPrompt.Value)
                        {
                            if (sObj != null)
                            {
                                //Check selected id is not outer most of nested entity 1 & nested entity 2:
                                if (boCurv1 != null && sObj.ObjectId == outerId1)
                                {
                                    continue;
                                }

                                if (boCurv2 != null && sObj.ObjectId == outerId2)
                                {
                                    continue;
                                }

                                try
                                {
                                    //Open member for read:
                                    Curve sCurv = (Curve)tr.GetObject(sObj.ObjectId, OpenMode.ForRead);

                                    //Create new temp line.
                                    //if process success, then hangover the ids:
                                    using (Line lObj = new Line())
                                    {
                                        //Transform properties:
                                        //lObj.Layer = sCurv.Layer;
                                        //lObj.Color = sCurv.Color;
                                        //lObj.Linetype = sCurv.Linetype;
                                        //lObj.LineWeight = sCurv.LineWeight;

                                        //Transform properties:
                                        lObj.SetPropertiesFrom(sCurv);

                                        //Create new point collection for intersection:
                                        Point3dCollection intPnts = new Point3dCollection();

                                        #region [Set start point]
                                        if (pner1.Status == PromptStatus.OK &&
                                            pner1.ObjectId.ObjectClass.Name != "AcDbCircle" &&
                                            pner1.ObjectId.ObjectClass.Name != "AcDbArc" &&
                                            pner1.ObjectId.ObjectClass.Name != "AcDbEllipse"
                                           )
                                        {
                                            using (Xline cCurv = new Xline())
                                            {
                                                if (sObj.ObjectId.ObjectClass.Name == "AcDbLine")
                                                {
                                                    cCurv.BasePoint = (sCurv as Line).StartPoint;
                                                    cCurv.SecondPoint = (sCurv as Line).EndPoint;
                                                }
                                                else if (sObj.ObjectId.ObjectClass.Name == "AcDbXline")
                                                {
                                                    cCurv.BasePoint = (sCurv as Xline).BasePoint;
                                                    cCurv.SecondPoint = (sCurv as Xline).SecondPoint;
                                                }
                                                else
                                                {
                                                    cCurv.BasePoint = (sCurv as Ray).BasePoint;
                                                    cCurv.SecondPoint = (sCurv as Ray).SecondPoint;
                                                }

                                                //Transform cloned curve WCS -> ECS:
                                                cCurv.TransformBy(pner1.Transform.Inverse());
                                                
                                                //Get intersection:
                                                cCurv.IntersectWith(boXline1, Intersect.ExtendBoth, intPnts, IntPtr.Zero, IntPtr.Zero);
                                                if (intPnts.Count == 0)
                                                {
                                                    continue;
                                                }
                                                else
                                                {
                                                    Point3d cloInPnt = intPnts[0];

                                                    for (int i = 0; i < intPnts.Count; i++)
                                                    {
                                                        Point3d tempPnt = intPnts[i];

                                                        #region [Old codes]
                                                        //double dist1 = tempPnt.DistanceTo(cloPnt1);
                                                        //double dist2 = cloInPnt.DistanceTo(cloPnt1);
                                                        //if (dist1 < dist2)
                                                        //{
                                                        //    cloInPnt = tempPnt;
                                                        //}
                                                        #endregion

                                                        Vector3d tempVt = cloPnt1.GetVectorTo(tempPnt);
                                                        if (tempVt.IsParallelTo(tangVt1))
                                                        {
                                                            cloInPnt = tempPnt;
                                                        }
                                                    }

                                                    lObj.StartPoint = cloInPnt.TransformBy(pner1.Transform);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (pner1.ObjectId.ObjectClass.Name == "AcDbCircle")
                                            {
                                                lObj.StartPoint = sCurv.GetClosestPointTo(((Circle)boCurv1).Center, true);
                                            }
                                            else if (pner1.ObjectId.ObjectClass.Name == "AcDbArc")
                                            {
                                                lObj.StartPoint = sCurv.GetClosestPointTo(((Arc)boCurv1).Center, true);
                                            }
                                            else if (pner1.ObjectId.ObjectClass.Name == "AcDbEllipse")
                                            {
                                                lObj.StartPoint = sCurv.GetClosestPointTo(((Ellipse)boCurv1).Center, true);
                                            }
                                            else
                                            {
                                                lObj.StartPoint = sCurv.GetClosestPointTo(kwPnt1.TransformBy(ed.CurrentUserCoordinateSystem), true);
                                            }
                                        }
                                        #endregion

                                        #region [Set end point]
                                        //Reset intersection collection:
                                        intPnts.Clear();

                                        if (pner2.Status == PromptStatus.OK &&
                                            pner2.ObjectId.ObjectClass.Name != "AcDbCircle" &&
                                            pner2.ObjectId.ObjectClass.Name != "AcDbArc" &&
                                            pner2.ObjectId.ObjectClass.Name != "AcDbEllipse"
                                           )
                                        {
                                            //using (Curve cCurv = (Curve)sCurv.Clone())
                                            using (Xline cCurv = new Xline())
                                            {
                                                if (sObj.ObjectId.ObjectClass.Name == "AcDbLine")
                                                {
                                                    cCurv.BasePoint = (sCurv as Line).StartPoint;
                                                    cCurv.SecondPoint = (sCurv as Line).EndPoint;
                                                }
                                                else if (sObj.ObjectId.ObjectClass.Name == "AcDbXline")
                                                {
                                                    cCurv.BasePoint = (sCurv as Xline).BasePoint;
                                                    cCurv.SecondPoint = (sCurv as Xline).SecondPoint;
                                                }
                                                else
                                                {
                                                    cCurv.BasePoint = (sCurv as Ray).BasePoint;
                                                    cCurv.SecondPoint = (sCurv as Ray).SecondPoint;
                                                }

                                                //Transform cloned form WCS -> ECS:
                                                cCurv.TransformBy(pner2.Transform.Inverse());

                                                //Find intersection:
                                                cCurv.IntersectWith(boXline2, Intersect.ExtendBoth, intPnts, IntPtr.Zero, IntPtr.Zero);
                                                if (intPnts.Count == 0)
                                                {
                                                    continue;
                                                }
                                                else
                                                {
                                                    Point3d cloInPnt = intPnts[0];

                                                    for (int i = 0; i < intPnts.Count; i++)
                                                    {
                                                        Point3d tempPnt = intPnts[i];
                                                        Vector3d tempVt = cloPnt2.GetVectorTo(tempPnt);
                                                        if (tempVt.IsParallelTo(tangVt2))
                                                        {
                                                            cloInPnt = tempPnt;
                                                        }
                                                    }

                                                    lObj.EndPoint = cloInPnt.TransformBy(pner2.Transform);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (pner2.ObjectId.ObjectClass.Name == "AcDbCircle")
                                            {
                                                lObj.EndPoint = sCurv.GetClosestPointTo(((Circle)boCurv2).Center, true);
                                            }
                                            else if (pner2.ObjectId.ObjectClass.Name == "AcDbArc")
                                            {
                                                lObj.EndPoint = sCurv.GetClosestPointTo(((Arc)boCurv2).Center, true);
                                            }
                                            else if (pner2.ObjectId.ObjectClass.Name == "AcDbEllipse")
                                            {
                                                lObj.EndPoint = sCurv.GetClosestPointTo(((Ellipse)boCurv2).Center, true);
                                            }
                                            else
                                            {
                                                lObj.EndPoint = sCurv.GetClosestPointTo(kwPnt2.TransformBy(ed.CurrentUserCoordinateSystem), true);
                                            }
                                        }
                                        #endregion

                                        //Upgrate selected curve openmode -> ForWrite:
                                        sCurv.UpgradeOpen();

                                        //Exchange ids:
                                        sCurv.HandOverTo(lObj, true, true);
                                    }


                                    processCount += 1;
                                }
                                catch (System.Exception ex)
                                {
                                    ed.WriteMessage(ex.Message);
                                    return;
                                }
                            }
                        }

                        //Print out number of processed entties:
                        ed.WriteMessage($"\nNumber of processed entities: {processCount}");
                    }

                    //Commit changes:
                    tr.Commit();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
            finally
            {
                if (curv1Highlighted == true && pner1 != null)
                {
                    KRUnhighlight.HighlightNested(db, ed, pner1, false);
                }

                if (curv2Highlighted == true && pner2 != null)
                {
                    KRUnhighlight.HighlightNested(db, ed, pner2, false);
                }
            }
        }

        [Obsolete("This method doesn't support nested curve/ leader/ mleader. Use CmdTLTN instead!")]
        private void CmdTLT()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Auto unhighlight entities when process finish .
            using (KRUnhighlight myUnHighlight = new KRUnhighlight())
            using (KRResetUCS myResetUcs = new KRResetUCS())
            {
                //Start main transaction:
                using (Transaction tr = db.TransactionManager.StartOpenCloseTransaction())
                {
                    //Variable for check prompt status:
                    PromptStatus checkStatus;

                    #region [Select boundary curves]
                    Curve boCurv1 = CmdTLT_GetCurve(tr, ed, "\nFirst boundary curve:",
                                                    myUnHighlight, out Point3d cloPnt1,out checkStatus);
                    if (checkStatus != PromptStatus.OK)
                        return;

                    Curve boCurv2 = CmdTLT_GetCurve(tr, ed, "\nSecond boundary curve:",
                                                    myUnHighlight, out Point3d cloPnt2,out checkStatus);
                    if (checkStatus != PromptStatus.OK)
                        return;
                    #endregion

                    #region [Select curves to trim/ extend]
                    //Create a TypedValue array to define the filter criteria :
                    TypedValue[] acTypValAr = new TypedValue[5];
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LINE"), 1);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "RAY"), 2);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "XLINE"), 3);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);

                    //Create new selection filter from above TypedValue 's array :
                    SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

                    //Prompt option :
                    PromptSelectionOptions pso = new PromptSelectionOptions
                    {
                        MessageForAdding = "\nSelect Line/ Ray/ XLine:"
                    };

                    //Prompt result :
                    PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);

                    //Selection set :
                    SelectionSet ss;
                    //Check prompt return value :
                    if (acSSPrompt.Status != PromptStatus.OK ||
                        acSSPrompt.Value.Count == 0)
                    {
                        ed.WriteMessage("\nYou selected nothing!");
                        return;
                    }
                    else
                        ss = acSSPrompt.Value;
                    #endregion

                    //Iterate selection set and trim/ extend members :
                    foreach (SelectedObject sObj in ss)
                    {
                        if (sObj != null)
                        {
                            try
                            {
                                //Open entity for read:
                                Curve sCurv = (Curve)tr.GetObject(sObj.ObjectId, OpenMode.ForRead);

                                //Create new line:
                                using (Line lObj = new Line())
                                {
                                    //Transform properties:
                                    lObj.Layer = sCurv.Layer;
                                    lObj.Color = sCurv.Color;
                                    lObj.Linetype = sCurv.Linetype;
                                    lObj.LineWeight = sCurv.LineWeight;

                                    //Create new point collection for intersection:
                                    Point3dCollection intPnts = new Point3dCollection();

                                    #region [Set start point]
                                    if (boCurv1 != null)
                                    {
                                        sCurv.IntersectWith(boCurv1, Intersect.ExtendBoth, intPnts ,IntPtr.Zero, IntPtr.Zero);
                                        if (intPnts.Count != 1)
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            lObj.StartPoint = intPnts[0];
                                        }
                                    }
                                    else
                                    {
                                        lObj.StartPoint = sCurv.GetClosestPointTo(cloPnt1, true);
                                    }
                                    #endregion

                                    #region [Set end point]
                                    intPnts.Clear();//Reset intersection points's collection.
                                    if (boCurv2 != null)
                                    {
                                        sCurv.IntersectWith(boCurv2, Intersect.ExtendBoth, intPnts, IntPtr.Zero, IntPtr.Zero);
                                        if (intPnts.Count != 1)
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            lObj.EndPoint = intPnts[0];
                                        }
                                    }
                                    else
                                    {
                                        lObj.EndPoint = sCurv.GetClosestPointTo(cloPnt2, true);
                                    }
                                    #endregion

                                    //Upgrate selected curve openmode -> ForWrite:
                                    sCurv.UpgradeOpen();

                                    //Exchange ids:
                                    sCurv.HandOverTo(lObj, true, true);
                                }

                            }
                            catch (System.Exception ex)
                            {
                                ed.WriteMessage(ex.Message);
                                return;
                            }
                        }
                    }

                    //Commit changes:
                    tr.Commit();
                }
            }
        }

        private Curve CmdTLT_GetCurve(Transaction tr, Editor ed, string msg,
                                      KRUnhighlight myUnHighlight, 
                                      out Point3d cloPnt,out PromptStatus retStatus)
        {
            //Initialize default value for closest point,
            //promptstatus. Use prompt status as flag to check return value.
            cloPnt = Point3d.Origin;
            retStatus = PromptStatus.Error;

            //Prompt option :
            //This function only permit user to select POLYLINE(2D)/ STRAIGHT CURVE only:
            PromptEntityOptions peo = new PromptEntityOptions(msg);
            peo.Keywords.Add("Point");
            peo.SetRejectMessage("\nInvalid selection. Please select Polyline/ Line/ Ray/ Xline!");
            peo.AddAllowedClass(typeof(Autodesk.AutoCAD.DatabaseServices.Polyline), false);
            peo.AddAllowedClass(typeof(Polyline2d), false);
            peo.AddAllowedClass(typeof(Line), false);
            peo.AddAllowedClass(typeof(Ray), false);
            peo.AddAllowedClass(typeof(Xline), false);

            //Prompt result :
            PromptEntityResult per;
            try
            {
                per = ed.GetEntity(peo);
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.ToString());
                return null;
            }

            //Check prompt status:
            if (per.Status == PromptStatus.Keyword)
            {
                retStatus = KRGetPoint(ed, "\nPick a point:", Point3d.Origin, ref cloPnt);
                return null;
            }
            else if (per.Status == PromptStatus.OK)
            {
                try
                {
                    //Acquire prompt status:
                    retStatus = per.Status;

                    //Add boundary curve to CleanUp object:
                    myUnHighlight.Add(per.ObjectId);

                    //Open curve for read:
                    Curve boCurv = (Curve)tr.GetObject(per.ObjectId, OpenMode.ForRead);

                    //Get closest point to curve:
                    cloPnt = boCurv.GetClosestPointTo(per.PickedPoint, true);

                    //Path for SubEntity:
                    FullSubentityPath path = FullSubentityPath.Null;

                    //Check curve type:
                    if (per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Polyline2d)))
                        || per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(
                            Autodesk.AutoCAD.DatabaseServices.Polyline)))
                        )
                    {
                        //Get 'path' for highlight subentity:
                        double param;
                        param = boCurv.GetParameterAtPoint(cloPnt);
                        path = new FullSubentityPath(new ObjectId[] { boCurv.Id },
                                    new SubentityId(SubentityType.Edge, new IntPtr((int)param + 1)));
                        boCurv.Highlight(path, false);

                        //Get subentity & return its value:
                        Entity subBoCurv = boCurv.GetSubentity(path);
                        return (Curve)subBoCurv;
                    }
                    else
                    {
                        //Highlight full curve & return its value:
                        boCurv.Highlight();
                        return boCurv;
                    }
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage(ex.ToString());
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        [Obsolete("This method doesn't support nested curve/ leader/ mleader. Use CmdTLTN instead!")]
        private void CmdTE2()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Chọn line Chuẩn thứ nhất
                PromptEntityOptions peo1 = new PromptEntityOptions("\n 基準直線<1>を選び:");
                peo1.SetRejectMessage("\n 選択が無効で、直線が必要です,");
                peo1.AddAllowedClass(typeof(Line), false);
                PromptEntityResult per1 = ed.GetEntity(peo1);
                if (per1.Status != PromptStatus.OK) return;
                Line lobj1 = tr.GetObject(per1.ObjectId, OpenMode.ForRead) as Line;
                lobj1.Highlight();

                //Chọn line Chuẩn thứ hai
                PromptEntityOptions peo2 = new PromptEntityOptions("\n 基準直線<2>を選び:");
                peo2.SetRejectMessage("\n 選択が無効で、直線が必要です,");
                peo2.AddAllowedClass(typeof(Line), false);
                PromptEntityResult per2 = ed.GetEntity(peo2);
                if (per2.Status != PromptStatus.OK) return;
                Line lobj2 = tr.GetObject(per2.ObjectId, OpenMode.ForRead) as Line;
                lobj2.Highlight();

                //Chọn nhiều đối tượng Line để trim / extend
                TypedValue[] acTypValAr = new TypedValue[1];
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "LINE"), 0);
                SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
                ed.WriteMessage("\n 多数の直線を選び:");
                PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
                if (acSSPrompt.Status != PromptStatus.OK) return;

                //Duyệt qua tập Line được chọn 
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    Line lobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Line;
                    Point3dCollection pts3D1 = new Point3dCollection();
                    lobj1.IntersectWith(lobj, Intersect.ExtendBoth, pts3D1, IntPtr.Zero, IntPtr.Zero);
                    if (pts3D1.Count != 0)
                    {
                        foreach (Point3d pt in pts3D1)
                        {
                            lobj.StartPoint = pt;
                        }
                    }
                    Point3dCollection pts3D2 = new Point3dCollection();
                    lobj2.IntersectWith(lobj, Intersect.ExtendBoth, pts3D2, IntPtr.Zero, IntPtr.Zero);
                    if (pts3D2.Count != 0)
                    {
                        foreach (Point3d pt in pts3D2)
                        {
                            lobj.EndPoint = pt;
                        }
                    }
                }
                lobj1.Unhighlight();
                lobj2.Unhighlight();
                tr.Commit();
            }
        }

        #endregion

        #region[Lệnh chuyển Xline thành Line (độ dài 5000)]
        [CommandMethod("X2L")]
        public void CmdX2L()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "XLINE"), 0);


            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;

            PromptPointOptions ppo = new PromptPointOptions("\n 基準点を選び :")
            { AllowArbitraryInput = false, AllowNone = true, UseBasePoint = true, BasePoint = new Point3d(0, 0, 0) };

            PromptPointResult ppr = ed.GetPoint(ppo);
            if (ppr.Status != PromptStatus.OK) return;

            using (Transaction tr=db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;

                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                        var plane = new Plane(Point3d.Origin, normal);
                        Xline xobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Xline;
                        Point3d pt = xobj.GetClosestPointTo(ppr.Value, false);
                        Point3d pt1, pt2;
                        pt1 = xobj.BasePoint;
                        pt2 = xobj.SecondPoint;
                        Vector3d vt = pt1.GetVectorTo(pt2);
                        double an = vt.AngleOnPlane(plane);

                        using (Line lobj = new Line())
                        {
                            lobj.StartPoint = PolarPoints(pt, an, 2500);
                            lobj.EndPoint = PolarPoints(pt, an + Math.PI, 2500);
                            lobj.Layer = xobj.Layer;
                            btr.AppendEntity(lobj);
                            tr.AddNewlyCreatedDBObject(lobj, true);
                        }
                        xobj.Erase();
                    }
                }
                tr.Commit();
            }
        }
        #endregion

        [CommandMethod("UPFN")]
        public void CmdUPFN()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Ask user to select 2 curve :
            PromptEntityOptions peo = new PromptEntityOptions("\nSelect curve: ")
            { AllowNone = false };
            peo.SetRejectMessage("\nInvalid selection.Please try again !");
            peo.AddAllowedClass(typeof(MText), false);

            //Select curve 1 :
            PromptEntityResult per1 = ed.GetEntity(peo);
            if (per1.Status != PromptStatus.OK)
                return;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                MText mtxtObj = (MText)tr.GetObject(per1.ObjectId, OpenMode.ForWrite);
                tr.Commit();
            }
        }

        //On building :
        #region[Lệnh Fillet liên tục From A - > Z ]
        //[CommandMethod("FCO")]
        private void CmdFCO()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;
            Database db = doc.Database;

            //Ask user to select 2 curve :
            PromptEntityOptions peo = new PromptEntityOptions("\nSelect curve: ")
            { AllowNone = false };
            peo.SetRejectMessage("\nInvalid selection.Please try again !");
            peo.AddAllowedClass(typeof(Curve), false);

            //Select curve 1 :
            PromptEntityResult per1 = ed.GetEntity(peo);
            if (per1.Status != PromptStatus.OK)
                return;

            ObjectId curv1Id = per1.ObjectId;

            HighLightById(curv1Id);

            while (true)
            {

                HighLightById(curv1Id, false);

                //Select curve 2:
                PromptEntityResult per2 = ed.GetEntity(peo);
                if (per2.Status != PromptStatus.OK)
                    return;

                ObjectId curv2Id = per2.ObjectId;

                HighLightById(curv2Id);

                //Get curve 1 's picked point :
                Point3d pickPnt1 = per1.PickedPoint;

                //Get curve 2 's picked point :
                Point3d pickPnt2 = per2.PickedPoint;

                //Start transaction to fillet curves :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Get entity 1 :
                    Curve curve1 = (Curve)tr.GetObject(curv1Id, OpenMode.ForWrite);

                    //Get entity 2 :
                    Curve curve2 = (Curve)tr.GetObject(curv2Id, OpenMode.ForWrite);

                    //Get closest point on curves to picked point :
                    Point3d cloPnt1 = curve1.GetClosestPointTo(pickPnt1, true);
                    Point3d cloPnt2 = curve2.GetClosestPointTo(pickPnt2, true);

                    //Allocate new point collection :
                    Point3dCollection pntCol = new Point3dCollection();

                    //Find intersection points :
                    curve1.IntersectWith(curve2, Intersect.ExtendBoth, pntCol,
                        IntPtr.Zero, IntPtr.Zero);

                    //In case curves don't intersect :
                    if (pntCol.Count == 0)
                    {
                        ed.WriteMessage("\nCurves don't intersect .");
                        return;
                    }

                    //In case curves intersect :
                    else
                    {
                        int position;

                        //In case curve intersect at one point only :
                        if (pntCol.Count == 1)
                        {
                            position = 0;

                            //-------Curve1--------//
                            curv1Id = FCO_CurveFillet(db, curve1, cloPnt1, pntCol[position]);

                            //-------Curve2--------//
                            curv2Id = FCO_CurveFillet(db, curve2, cloPnt2, pntCol[position]);
                        }

                        //In case curve intersect at multiple points :
                        else
                        {
                            //position = 0;
                            //pnt1 = pntCol[position];

                            //for (int i = 0; i < pntCol.Count; i++)
                            //{
                            //    pnt2 = pntCol[i];
                            //    if (pnt2.DistanceTo(pickPnt1) < pnt1.DistanceTo(pickPnt1))
                            //    {
                            //        position = i;
                            //        pnt1 = pnt2;
                            //    }
                            //}
                        }
                    }

                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }

                curv1Id = curv2Id;
            }
        }

        private void HighLightById(ObjectId objId,bool isHighlight = true)
        {
            //Get document & database :
            Document doc = CommonCommands.doc();
            Database db = doc.Database;

            //Start transaction :
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                Entity ent = (Entity)tr.GetObject(objId, OpenMode.ForWrite);

                if (isHighlight)
                    ent.Unhighlight();
                else
                    ent.Highlight();

                //Commit changes :
                tr.Commit();
            }
        }

        private ObjectId FCO_CurveFillet (Database db,Curve curvObj,Point3d cloPnt,
            Point3d intPnt)
        {
            //Declare return object id :
            ObjectId retId;

            //Start transaction :
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, 
                    OpenMode.ForWrite);

                //In case curve is a Xline :
                if (curvObj.GetType().Name == "Xline")
                {
                    //Create new Ray :
                    Ray rayObj = new Ray()
                    {
                        BasePoint = intPnt,
                        Layer = curvObj.Layer,
                        Linetype = curvObj.Linetype,
                        LineWeight = curvObj.LineWeight,
                        SecondPoint = cloPnt
                    };

                    curvObj.Erase();
                    retId = btr.AppendEntity(rayObj);
                    tr.AddNewlyCreatedDBObject(rayObj, true);
                }

                //In case curve is a ray :
                else if (curvObj.GetType().Name == "Ray")
                {
                    //Cast curve to ray :
                    Ray rayObj = (Ray)curvObj;

                    //Sympol naming :
                    // Intersection point : i
                    // Ray 's base point : s
                    // Ray 's second point : e
                    // closest point : c

                    //Define vectors :
                    Vector3d isVt, icVt, ieVt;
                    isVt = intPnt.GetVectorTo(rayObj.BasePoint);
                    icVt = intPnt.GetVectorTo(cloPnt);
                    ieVt = intPnt.GetVectorTo(rayObj.SecondPoint);

                    //Define distance to compare :
                    double isDist, ieDist;
                    isDist = intPnt.DistanceTo(rayObj.BasePoint);
                    ieDist = intPnt.DistanceTo(rayObj.SecondPoint);

                    //Intersect --- start , end :
                    if ((icVt.IsCodirectionalTo(isVt) &&
                            icVt.IsCodirectionalTo(ieVt)
                        )
                        ||
                        (!icVt.IsCodirectionalTo(isVt) &&
                             !icVt.IsCodirectionalTo(ieVt)
                        )
                       )
                    {
                        if (isDist < ieDist)
                        {
                            rayObj.BasePoint = intPnt;
                            retId = rayObj.ObjectId;
                        }
                        else
                           retId = FCO_Ray2Line(db, rayObj, intPnt);
                    }

                    //Start --- intesect --- closest --- end :
                    else if (!icVt.IsCodirectionalTo(isVt) &&
                              icVt.IsCodirectionalTo(ieVt)
                            )
                    {
                        rayObj.BasePoint = intPnt;
                        retId = rayObj.ObjectId;
                    }

                    //end --- intesect --- closest --- start : 
                    else
                        retId = FCO_Ray2Line(db, rayObj, intPnt);
                }

                //The others :
                else
                {
                    //Sympol naming :
                    // Intersection point : i
                    // Curve 's start point : s
                    // Curve 's end point : e
                    // closest point : c

                    //Define vectors :
                    Vector3d isVt, icVt, ieVt;
                    isVt = intPnt.GetVectorTo(curvObj.StartPoint);
                    icVt = intPnt.GetVectorTo(cloPnt);
                    ieVt = intPnt.GetVectorTo(curvObj.EndPoint);

                    //Define distance to compare :
                    double isDist, ieDist;
                    isDist = intPnt.DistanceTo(curvObj.StartPoint);
                    ieDist = intPnt.DistanceTo(curvObj.EndPoint);

                    //Intersect --- start , end :
                    if (
                        (icVt.IsCodirectionalTo(isVt) &&
                            icVt.IsCodirectionalTo(ieVt)
                        ) 
                        ||
                        (!icVt.IsCodirectionalTo(isVt) &&
                             !icVt.IsCodirectionalTo(ieVt)
                        )
                       )
                    {
                        if (isDist < ieDist)
                        {
                            curvObj.StartPoint = intPnt;
                            retId = curvObj.ObjectId;
                        }
                        else
                        {
                            curvObj.EndPoint = intPnt;
                            retId = curvObj.ObjectId;
                        }
                    }

                    //start --- intesect --- closest --- end :
                    else if (!icVt.IsCodirectionalTo(isVt) &&
                              icVt.IsCodirectionalTo(ieVt)
                            )
                    {
                        curvObj.StartPoint = intPnt;
                        retId = curvObj.ObjectId;
                    }

                    //end --- intesect --- closest --- start : 
                    else
                    {
                        curvObj.EndPoint = intPnt;
                        retId = curvObj.ObjectId;
                    }
                }

                //Commit changes :
                tr.Commit();
            }//End transaction 

            //Return object id :
            return retId;
        }

        private ObjectId FCO_Ray2Line(Database db ,Ray rayObj , Point3d endPnt)
        {
            ObjectId retId;

            //Start transaction :
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, 
                    OpenMode.ForWrite);

                Line lineObj = new Line()
                {
                    StartPoint = rayObj.BasePoint,
                    EndPoint = endPnt,
                    Layer = rayObj.Layer,
                    Linetype = rayObj.Linetype,
                    LineWeight = rayObj.LineWeight,
                };

                rayObj.Erase();
                retId = btr.AppendEntity(lineObj);
                tr.AddNewlyCreatedDBObject(lineObj, true);

                //Commit changes :
                tr.Commit();
            }//End transaction

            return retId;
        }
        #endregion

        //Lệnh thêm tiếp đầu ngữ / vị ngữ / cả hai cho Text/Mtext
        [CommandMethod("PSA")]
        public void CmdPSA()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Define add postion index:
            // 0 => prefix
            // 1 => suffix
            System.Collections.Generic.List<KeyValuePair<int, string>> kws =
                new System.Collections.Generic.List<KeyValuePair<int, string>>();
            kws.Add(new KeyValuePair<int, string>(0, "Prefix"));
            kws.Add(new KeyValuePair<int, string>(1, "Suffix"));

            PromptKeywordOptions pko = new PromptKeywordOptions("");
            pko.Message = "\nLocation to add string:";
            pko.AllowArbitraryInput = false;
            pko.AllowNone = false;
            for (int i = 0; i < kws.Count; i++)
            {
                pko.Keywords.Add(kws[i].Value);
            }

            PromptResult pr = ed.GetKeywords(pko);
            if (pr.Status == PromptStatus.Error || pr.Status == PromptStatus.None)
            {
                ed.WriteMessage("\nCannot get location to add!");
                return;
            }
            else if(pr.Status == PromptStatus.Cancel)
            {
                return;
            }

            //Get add position index:
            int addPosition = -1;
            try
            {
                var foundItem = kws.Find(a => a.Value == pr.StringResult);
                addPosition = foundItem.Key;
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage($"\nError: {ex.Message}");
                return;
            }

            if (addPosition == -1)
            {
                ed.WriteMessage("\nCannot get location to add!");
                return;
            }

            //Get string to add:
            PromptStringOptions pso = new PromptStringOptions("");
            pso.Message = "\nString to add: ";
            pso.AllowSpaces = true;

            pr = ed.GetString(pso);
            if (pr.Status == PromptStatus.Error || pr.Status == PromptStatus.None)
            {
                ed.WriteMessage("\nCannot get string to add!");
                return;
            }
            else if(pr.Status == PromptStatus.Cancel)
            {
                return;
            }

            string contentToAdd = pr.StringResult;
            if (string.IsNullOrEmpty(contentToAdd) || string.IsNullOrWhiteSpace(contentToAdd))
            {
                ed.WriteMessage("\nString to add is not valid!");
                return;
            }

            //Create typed value array:
            TypedValue[] acTypValAr = new TypedValue[5];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 3);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);

            //Create filter based on typed value array:
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            //Selection option:
            PromptSelectionOptions pseo = new PromptSelectionOptions();
            pseo.RejectObjectsOnLockedLayers = true;
            pseo.MessageForAdding = "\nSelect Text/ Mtext/ Dimension to add: ";
            pseo.MessageForRemoval = "\nSelect Text/ Mtext/ Dimension to remove: ";

            //Get selection set:
            PromptSelectionResult pser = ed.GetSelection(pseo, acSelFtr);
            if (pser.Status == PromptStatus.Error || pser.Status == PromptStatus.None || 
                pser.Value == null || pser.Value.Count == 0)
            {
                ed.WriteMessage("\nCannot get selection set!");
                return;
            }
            else if(pser.Status == PromptStatus.Cancel)
            {
                return;
            }

            //Main process:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sObj in pser.Value)
                {
                    if (sObj != null)
                    {
                        Entity ent = tr.GetObject(sObj.ObjectId, OpenMode.ForWrite) as Entity;

                        if (ent is MText)
                        {
                            MText mText = (MText)ent;

                            if (addPosition == 0)
                            {
                                mText.Contents = contentToAdd + mText.Contents;

                            }
                            else
                            {
                                mText.Contents = mText.Contents + contentToAdd;
                            }
                        }
                        else if (ent is DBText)
                        {
                            DBText dbTxt = (DBText)ent;

                            if (addPosition == 0)
                            {
                                dbTxt.TextString = contentToAdd + dbTxt.TextString;

                            }
                            else
                            {
                                dbTxt.TextString = dbTxt.TextString + contentToAdd;
                            }
                        }
                        else
                        {
                            Dimension dim = (Dimension)ent;

                            if (addPosition == 0)
                            {
                                if (dim.DimensionText == "" || dim.DimensionText == "<>")
                                {
                                    if (dim is RadialDimension)
                                    {
                                        dim.Prefix = contentToAdd + "R";
                                    }
                                    else if(dim is DiametricDimension)
                                    {
                                        dim.Prefix = contentToAdd + "%%c";
                                    }
                                    else
                                    {
                                        dim.Prefix = contentToAdd;
                                    }
                                }
                                else
                                {
                                    dim.DimensionText = contentToAdd + dim.DimensionText;
                                }
                            }
                            else
                            {
                                if (dim.DimensionText == "" || dim.DimensionText == "<>")
                                {
                                    dim.Suffix = contentToAdd;
                                }
                                else
                                {
                                    dim.DimensionText = dim.DimensionText + contentToAdd;
                                }
                            }

                            //Force dimension to update:
                            dim.RecomputeDimensionBlock(true);
                        }
                    }
                }

                tr.Commit();
            }
        }

        [Obsolete("This method is obsolete. Use CmdPSA instead!")]
        public void CmdPTAS()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            Application.SetSystemVariable("CMDECHO", 0);
            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[4];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;

            //Option :
            PromptKeywordOptions pko = new PromptKeywordOptions("")
            {
                Message = "\n ※パターンのお選び : " +
                      "\n Prefix(1)" + " || Suffix(2)" + " || Both(12)",
            };
            pko.Keywords.Add("1");
            pko.Keywords.Add("2");
            pko.Keywords.Add("12");
            PromptResult pr = ed.GetKeywords(pko);
            if (pr.Status != PromptStatus.OK) return;


            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                if (pr.StringResult == "1")
                {
                    PromptStringOptions pso1 = new PromptStringOptions("\n Prefix中身 : ")
                    { AllowSpaces = true };
                    PromptResult pr1 = ed.GetString(pso1);
                    if (pr1.Status != PromptStatus.OK) return;

                    foreach (SelectedObject sobj in acSSPrompt.Value)
                    {
                        Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                        if (ent.GetType().Name.ToString() == "MText")
                        {
                            MText mtxt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as MText;
                            mtxt.Contents = pr1.StringResult+mtxt.Contents;
                        }
                        else
                        {
                            DBText txt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as DBText;
                            txt.TextString = pr1.StringResult+txt.TextString;
                        }
                    }
                }
                else if (pr.StringResult == "2")
                {
                    PromptStringOptions pso2 = new PromptStringOptions("\n Suffix中身 : ")
                    { AllowSpaces = true };
                    PromptResult pr2 = ed.GetString(pso2);
                    if (pr2.Status != PromptStatus.OK) return;
                    foreach (SelectedObject sobj in acSSPrompt.Value)
                    {
                        Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                        if (ent.GetType().Name.ToString() == "MText")
                        {
                            MText mtxt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as MText;
                            mtxt.Contents += pr2.StringResult;
                        }
                        else
                        {
                            DBText txt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as DBText;
                            txt.TextString += pr2.StringResult;
                        }
                    }
                }
                else
                {
                    PromptStringOptions pso1 = new PromptStringOptions("\n Prefix中身 : ")
                    { AllowSpaces = true };
                    PromptResult pr1 = ed.GetString(pso1);
                    if (pr1.Status != PromptStatus.OK) return;

                    PromptStringOptions pso2 = new PromptStringOptions("\n Suffix中身 : ")
                    { AllowSpaces = true };
                    PromptResult pr2 = ed.GetString(pso2);
                    if (pr2.Status != PromptStatus.OK) return;
                    foreach (SelectedObject sobj in acSSPrompt.Value)
                    {
                        Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                        if (ent.GetType().Name.ToString() == "MText")
                        {
                            MText mtxt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as MText;
                            mtxt.Contents = pr1.StringResult + mtxt.Contents+pr2.StringResult;
                        }
                        else
                        {
                            DBText txt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as DBText;
                            txt.TextString = pr1.StringResult + txt.TextString + pr2.StringResult;
                        }
                    }
                }
                tr.Commit();
            }
        }

        //Duyệt qua tập kích thước đã chọn, Đổi màu vàng các kích thước ảo
        [CommandMethod("FDS")]
        public void CmdFDS()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Dimension dimobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Dimension;
                        //ed.WriteMessage("\n" + dimobj.DimensionText);
                        //if ((dimobj.DimensionText != "<>") || (dimobj.DimensionText != " "))
                        //https://forums.autodesk.com/t5/net/how-does-the-color-fromcolorindex-work/td-p/8938082
                        if ((dimobj.DimensionText == "<>") || (dimobj.DimensionText == ""))
                        {
                            //dimobj.Dimclrt = Autodesk.AutoCAD.Colors.Color.FromRgb(255, 0, 255);
                            dimobj.Dimclrt = Autodesk.AutoCAD.Colors.Color.FromColorIndex(Autodesk.AutoCAD.Colors.ColorMethod.ByAci,
                                (short)CommonDeclaration.KRColorIndex.Magenta);
                            //continue;
                        }
                        else
                        {
                            //dimobj.Dimclrt = Autodesk.AutoCAD.Colors.Color.FromRgb(255, 255, 0);
                            dimobj.Dimclrt = Autodesk.AutoCAD.Colors.Color.FromColorIndex(Autodesk.AutoCAD.Colors.ColorMethod.ByAci,
                                (short)CommonDeclaration.KRColorIndex.Yellow);
                        }

                        #region [Old codes]

                        //Vector3d vt = new Vector3d(1, 0, 0);
                        //Vector3d vt1 = new Vector3d(-1, 0, 0);
                        //dimobj.TransformBy(Matrix3d.Displacement(vt));
                        //dimobj.TransformBy(Matrix3d.Displacement(vt1));

                        #endregion

                        //Force dimension to update:
                        dimobj.RecomputeDimensionBlock(true);
                    }
                }
                tr.Commit();
            }
        }

        //Duyệt qua tập kích thước đã chọn, đưa lên front và set fill là background
        [CommandMethod("FID")]
        public void CmdFID()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[4];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);

            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                RejectObjectsOnLockedLayers = true
            };

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso,acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK || 
                acSSPrompt.Value.Count == 0)
            {
                ed.WriteMessage("\nYou select nothing!");
                return;
            }

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Get BlockTableRecord:
                BlockTableRecord btr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForRead) as BlockTableRecord;

                //Get DrawOrderTable:
                DrawOrderTable dot = tr.GetObject(btr.DrawOrderTableId, OpenMode.ForWrite) as DrawOrderTable;

                //Iterate SelectionSet:
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForRead) as Entity;
                        ObjectIdCollection oic = new ObjectIdCollection();
                        if (ent is Dimension dimobj)
                        {
                            dimobj.UpgradeOpen();
                            dimobj.Dimtfill = 1;

                            //Force dimension to update:
                            dimobj.RecomputeDimensionBlock(true);
                        }
                        else if (ent is MText mtext)
                        {
                            mtext.UpgradeOpen();

                            //https://forums.autodesk.com/t5/net/background-mask-mtext-in-vb-net/td-p/8291048

                            mtext.BackgroundFill = true;

                            mtext.BackgroundFillColor = 
                                Autodesk.AutoCAD.Colors.Color.FromColorIndex(
                                    Autodesk.AutoCAD.Colors.ColorMethod.ByAci , 1);
                            
                            mtext.UseBackgroundColor = true;

                            mtext.BackgroundScaleFactor = 1.0;
                        }
                        else
                        {
                            ed.WriteMessage("\nCannot get entity's type!");
                            tr.Abort();
                            return;
                        }

                        //Create collection:
                        oic.Add(sobj.ObjectId);
                        dot.MoveToTop(oic);
                    }
                }

                //Commit changes:
                tr.Commit();
            }
        }

        //Chọn nhiều TEXT/MTEXT , Tính toán + - * / với 1 đối số
        [CommandMethod("EDC")]
        public void CmdEDC()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[4];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 3);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;

            PromptKeywordOptions prk = new PromptKeywordOptions("")
            {
                Message = "\n ※演算子の選択 : ",
            };
            prk.Keywords.Add("+");
            prk.Keywords.Add("-");
            prk.Keywords.Add("*");
            prk.Keywords.Add("d");
            PromptResult pr = ed.GetKeywords(prk);
            if (pr.Status != PromptStatus.OK) return;

            PromptDoubleOptions pdo = new PromptDoubleOptions("\n 引数値 : ")
            { AllowArbitraryInput = false, AllowNegative = false, AllowZero = false };
            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status != PromptStatus.OK) return;

            string content;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForRead) as Entity;
                        if (ent.GetType().Name.ToString() == "MText")
                        {
                            MText mtxt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as MText;
                            content = mtxt.Contents;
                            double n;
                            bool isNumeric = double.TryParse(content, out n);
                            if (n != 0)
                            {
                                if (pr.StringResult == "+")
                                {
                                    mtxt.Contents = (n + pdr.Value).ToString();
                                }
                                if (pr.StringResult == "-")
                                {
                                    mtxt.Contents = (n - pdr.Value).ToString();
                                }
                                if (pr.StringResult == "*")
                                {
                                    mtxt.Contents = (n * pdr.Value).ToString();
                                }
                                if (pr.StringResult == "d")
                                {
                                    mtxt.Contents = (n / pdr.Value).ToString();
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            DBText txt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as DBText;
                            content = txt.TextString;
                            double n;
                            bool isNumeric = double.TryParse(content, out n);
                            if (n != 0)
                            {
                                if (pr.StringResult == "+")
                                {
                                    txt.TextString = (n + pdr.Value).ToString();
                                }
                                if (pr.StringResult == "-")
                                {
                                    txt.TextString = (n - pdr.Value).ToString();
                                }
                                if (pr.StringResult == "*")
                                {
                                    txt.TextString = (n * pdr.Value).ToString();
                                }
                                if (pr.StringResult == "d")
                                {
                                    txt.TextString = (n / pdr.Value).ToString();
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                   
                }
                tr.Commit();
            }
        }

        #region [Làm tròn Text,Mtext,Dimension đa năng ]
        //Sử dụng khi muốn làm tròn Text , Mtext chứa nội dung là số .
        //Với kích thước sử dụng khi không thể dùng các lệnh làm tròn thông thường .
        //Có thể làm tròn kiểu bình thường ,làm tròn lên / xuống 1 đơn vị (1,10 ..vv)
        [CommandMethod("RD")]
        public void CmdRDT()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            List<string> typeName = new List<string>()
            {
                "TEXT","MTEXT","DIMENSION"
            };
            
            TypedValue[] acTypValAr = new TypedValue[typeName.Count + 2];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), acTypValAr.Length - 1);
            for (int i = 1; i < acTypValAr.Length - 1; i++)
            {
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, typeName[i-1]), i);
            }

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            //Prompt selection option:
            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                RejectObjectsOnLockedLayers = true,
            };

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso,acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) 
                return;

            //Ask user to select option :
            PromptKeywordOptions prk = new PromptKeywordOptions("")
            {
                //Message = "\n ______***Designed by Le Thuong Tri***_______\n",
                Message = "\nSelect round option :",
                AllowNone = true
            };
            prk.Keywords.Add("Off");
            prk.Keywords.Add("Up");
            prk.Keywords.Add("Down");
            prk.Keywords.Default = "Off";

            PromptResult pr = ed.GetKeywords(prk);
            if (pr.Status == PromptStatus.Cancel || pr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get round option!");
                return;
            }

            //Ask user to input round 's unit :
            PromptDoubleOptions pdo = new PromptDoubleOptions("\nRound 's unit: ")
            { 
                AllowArbitraryInput = false, 
                AllowNegative = false, 
                AllowZero = true, 
                AllowNone = true,
                DefaultValue = 0.5
            };

            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pr.Status == PromptStatus.Cancel || pr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get round unit!");
                return;
            }

            //Declare variable for content :
            string content;

            //Declare variable for value of content :
            double n;

            //Variable to check string is numeric :
            bool isNumeric;

            Autodesk.AutoCAD.Colors.Color colorForRndUp_Down = Autodesk.AutoCAD.Colors.Color.FromRgb(255, 127, 0);

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                #region [Old codes]
                ////In case user press enter or select round off(1):
                //if (pr.Status == PromptStatus.None || pr.StringResult == "1")
                //{
                //    //Iterate through selection set :
                //    foreach (SelectedObject sobj in acSSPrompt.Value)
                //    {
                //        //Just handle object that NOT null :
                //        if (sobj != null)
                //        {
                //            //Open entity for write :
                //            Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                //            //In case MText :
                //            if (ent.GetType().Name.ToString() == "MText")
                //            {
                //                //Get text string :
                //                content = ((MText)ent).Contents;

                //                //Check whether it is numeric :
                //                isNumeric = double.TryParse(content, out n);
                //                if (isNumeric)
                //                {
                //                    n = RoundOff(n, pdr.Value);
                //                    content = n.ToString();
                //                    ((MText)ent).Contents = content;
                //                }
                //                else
                //                    continue;
                //            }

                //            //In case Text :
                //            else if (ent.GetType().Name.ToString() == "DBText")
                //            {
                //                //Get text string :
                //                content = ((DBText)ent).TextString;

                //                //Check whether it is numeric :
                //                isNumeric = double.TryParse(content, out n);
                //                if (isNumeric)
                //                {
                //                    n = RoundOff(n, pdr.Value);
                //                    content = n.ToString();
                //                    ((DBText)ent).TextString = content;
                //                }
                //                else
                //                    continue;
                //            }
                //            else
                //            {
                //                //Get dimension object :
                //                Dimension dimobj = (Dimension)ent;

                //                //Get dimension 's text :
                //                content = dimobj.DimensionText;

                //                //In case text is NOT overrided :
                //                if (content == "" || content == "<>")
                //                    dimobj.Dimrnd = pdr.Value;

                //                //In case text is overrided :
                //                else
                //                {
                //                    //Check whether it is numeric :
                //                    isNumeric = double.TryParse(content, out n);
                //                    if (isNumeric)
                //                    {
                //                        n = RoundOff(n, pdr.Value);
                //                        content = n.ToString();
                //                        dimobj.DimensionText = content;
                //                    }
                //                    else
                //                        continue;
                //                }

                //            }
                //        }
                //    }
                //}
                #endregion

                //In case user select round up(2) or round down(3) :
                switch (pr.StringResult)
                {
                    //Round off:
                    case "Off":
                        foreach (SelectedObject sobj in acSSPrompt.Value)
                        {
                            //Just handle object that NOT null :
                            if (sobj != null)
                            {
                                //Open entity for write :
                                Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                                //In case MText :
                                if (ent.GetType().Name.ToString() == "MText")
                                {
                                    //Get text string :
                                    content = ((MText)ent).Contents;

                                    //Check whether it is numeric :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = RoundOff(n, pdr.Value);
                                        content = n.ToString();
                                        ((MText)ent).Contents = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case Text :
                                else if (ent.GetType().Name.ToString() == "DBText")
                                {
                                    //Get text string :
                                    content = ((DBText)ent).TextString;

                                    //Check whether it is numeric :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = RoundOff(n, pdr.Value);
                                        content = n.ToString();
                                        ((DBText)ent).TextString = content;
                                    }
                                    else
                                        continue;
                                }

                                else
                                {
                                    //Get dimension object :
                                    Dimension dimobj = (Dimension)ent;

                                    //Get dimension 's text :
                                    content = dimobj.DimensionText;

                                    //In case text is NOT overrided :
                                    if (content == "" || content == "<>")
                                    {
                                        dimobj.Dimrnd = pdr.Value;

                                        //Force dimension to update:
                                        dimobj.RecomputeDimensionBlock(true);
                                    }

                                    //In case text is overrided :
                                    else
                                    {
                                        //Check whether it is numeric :
                                        isNumeric = double.TryParse(content, out n);
                                        if (isNumeric)
                                        {
                                            n = RoundOff(n, pdr.Value);
                                            content = n.ToString();
                                            dimobj.DimensionText = content;
                                        }
                                        else
                                            continue;
                                    }

                                }
                            }
                        }
                        break;

                    //Round up:
                    case "Up":
                        foreach (SelectedObject sobj in acSSPrompt.Value)
                        {
                            //Only handle object that NOT null :
                            if (sobj != null)
                            {
                                //Open entity for write :
                                Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                                //In case MText :
                                if (ent.GetType().Name.ToString() == "MText")
                                {
                                    //Get MText 's content :
                                    content = ((MText)ent).Contents;
                                    
                                    //Check whether it is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        //n = Ceiling(n / pdr.Value) * pdr.Value;
                                        n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);
                                        n += pdr.Value;

                                        content = n.ToString();
                                        
                                        ((MText)ent).Contents= content;
                                    }
                                    else
                                        continue;
                                }

                                //In case Text :
                                else if (ent.GetType().Name.ToString() == "DBText")
                                {
                                    //Get Text 's content :
                                    content = ((DBText)ent).TextString;

                                    //Check whether it is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        //n = Ceiling(n / pdr.Value) * pdr.Value;
                                        n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);
                                        n += pdr.Value;

                                        content = n.ToString();
                                        ((DBText)ent).TextString = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case dimension :
                                else
                                {
                                    //Get dimension object :
                                    Dimension dimobj = (Dimension)ent;

                                    //Get dimension 's text :
                                    content = dimobj.DimensionText;

                                    //In case text is NOT overrided :
                                    if (content == "" || content == "<>")
                                    {
                                        //Get mesurement 's value :
                                        n = dimobj.Measurement;

                                        n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);

                                        n += pdr.Value;

                                        dimobj.Dimrnd = n;

                                        dimobj.Dimclrt = colorForRndUp_Down;

                                        //Force dimension to update:
                                        dimobj.RecomputeDimensionBlock(true);
                                    }
                                    else //In case text is overrided:
                                    {
                                        //Check whether it is a number or not :
                                        isNumeric = double.TryParse(content, out n);
                                        if (isNumeric)
                                        {
                                            //n = Ceiling(n / pdr.Value) * pdr.Value;
                                            n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);
                                            n += pdr.Value;

                                            content = n.ToString();
                                            dimobj.DimensionText = content;
                                        }
                                        else
                                            continue;
                                    }
                                }
                            }
                        }
                        break;

                    //Round down:
                    case "Down":
                        foreach (SelectedObject sobj in acSSPrompt.Value)
                        {
                            //Only handle object that NOT null :
                            if (sobj != null)
                            {
                                //Open entity for write :
                                Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                                //In case MText :
                                if (ent.GetType().Name.ToString() == "MText")
                                {
                                    //Get text string :
                                    content = ((MText)ent).Contents;

                                    //Check whether text is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        //n = Floor(n / pdr.Value) * pdr.Value;
                                        n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);
                                        n -= pdr.Value;

                                        content = n.ToString();
                                        ((MText)ent).Contents = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case Text :
                                else if (ent.GetType().Name.ToString() == "DBText")
                                {
                                    //Get text string :
                                    content = ((DBText)ent).TextString;

                                    //Check whether text is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        //n = Floor(n / pdr.Value) * pdr.Value;
                                        n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);
                                        n -= pdr.Value;

                                        content = n.ToString();
                                        ((DBText)ent).TextString = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case dimension :
                                else
                                {
                                    //Get dimension object :
                                    Dimension dimobj = (Dimension)ent;

                                    //Get dimension 's text :
                                    content = dimobj.DimensionText;

                                    //In case text is NOT overrided :
                                    if (content == "" || content == "<>")
                                    {
                                        //Get mesurement 's value :
                                        n = dimobj.Measurement;

                                        n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);

                                        n -= pdr.Value;

                                        dimobj.Dimrnd = n;

                                        dimobj.Dimclrt = colorForRndUp_Down;

                                        //Force dimension to update:
                                        dimobj.RecomputeDimensionBlock(true);
                                    }
                                    //In case text is overrided :
                                    else
                                    {
                                        //Check whether it is a number or not :
                                        isNumeric = double.TryParse(content, out n);
                                        if (isNumeric)
                                        {
                                            //n = Floor(n / pdr.Value) * pdr.Value;
                                            n = AcadAddin.CommonCommands.RoundOff(n, pdr.Value);
                                            n -= pdr.Value;

                                            content = n.ToString();
                                            dimobj.DimensionText = content;
                                        }
                                        else
                                            continue;
                                    }
                                }
                            }
                        }
                        break;
                }
                
                //Commit changes :
                tr.Commit();
            }

            ////Silently send command to check fake dim:            
            //using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
            //{
            //    try
            //    {
            //        //Send command to change color of fake dim :
            //        ed.Command("_.FDS", "P", "");
            //    }
            //    catch (System.Exception ex)
            //    {
            //        ed.WriteMessage(ex.Message);
            //    }
            //}
        }

        public void CmdRDT_Old()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Create a TypedValue array to define the filter criteria
            List<string> typeName = new List<string>()
            {
                "TEXT","MTEXT","DIMENSION"
            };

            TypedValue[] acTypValAr = new TypedValue[typeName.Count + 2];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), acTypValAr.Length - 1);
            for (int i = 1; i < acTypValAr.Length - 1; i++)
            {
                acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, typeName[i - 1]), i);
            }

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            //Prompt selection option:
            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                RejectObjectsOnLockedLayers = true,
            };

            // Request for objects to be selected in the drawing area
            PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK)
                return;

            //Ask user to select option :
            PromptKeywordOptions prk = new PromptKeywordOptions("")
            {
                //Message = "\n ______***Designed by Le Thuong Tri***_______\n",
                Message = "\nSelect round option :",
                AllowNone = true
            };
            prk.Keywords.Add("Off");
            prk.Keywords.Add("Up");
            prk.Keywords.Add("Down");
            prk.Keywords.Default = "Off";

            PromptResult pr = ed.GetKeywords(prk);
            if (pr.Status == PromptStatus.Cancel || pr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get round option!");
                return;
            }

            //Ask user to input round 's unit :
            PromptDoubleOptions pdo = new PromptDoubleOptions("\nRound 's unit: ")
            {
                AllowArbitraryInput = false,
                AllowNegative = false,
                AllowZero = true,
                AllowNone = true,
                DefaultValue = 0.5
            };

            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pr.Status == PromptStatus.Cancel || pr.Status == PromptStatus.Error)
            {
                ed.WriteMessage("\nCannot get round unit!");
                return;
            }

            //Declare variable for content :
            string content;

            //Declare variable for value of content :
            double n;

            //Variable to check string is numeric :
            bool isNumeric;

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                #region [Old codes]
                ////In case user press enter or select round off(1):
                //if (pr.Status == PromptStatus.None || pr.StringResult == "1")
                //{
                //    //Iterate through selection set :
                //    foreach (SelectedObject sobj in acSSPrompt.Value)
                //    {
                //        //Just handle object that NOT null :
                //        if (sobj != null)
                //        {
                //            //Open entity for write :
                //            Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                //            //In case MText :
                //            if (ent.GetType().Name.ToString() == "MText")
                //            {
                //                //Get text string :
                //                content = ((MText)ent).Contents;

                //                //Check whether it is numeric :
                //                isNumeric = double.TryParse(content, out n);
                //                if (isNumeric)
                //                {
                //                    n = RoundOff(n, pdr.Value);
                //                    content = n.ToString();
                //                    ((MText)ent).Contents = content;
                //                }
                //                else
                //                    continue;
                //            }

                //            //In case Text :
                //            else if (ent.GetType().Name.ToString() == "DBText")
                //            {
                //                //Get text string :
                //                content = ((DBText)ent).TextString;

                //                //Check whether it is numeric :
                //                isNumeric = double.TryParse(content, out n);
                //                if (isNumeric)
                //                {
                //                    n = RoundOff(n, pdr.Value);
                //                    content = n.ToString();
                //                    ((DBText)ent).TextString = content;
                //                }
                //                else
                //                    continue;
                //            }
                //            else
                //            {
                //                //Get dimension object :
                //                Dimension dimobj = (Dimension)ent;

                //                //Get dimension 's text :
                //                content = dimobj.DimensionText;

                //                //In case text is NOT overrided :
                //                if (content == "" || content == "<>")
                //                    dimobj.Dimrnd = pdr.Value;

                //                //In case text is overrided :
                //                else
                //                {
                //                    //Check whether it is numeric :
                //                    isNumeric = double.TryParse(content, out n);
                //                    if (isNumeric)
                //                    {
                //                        n = RoundOff(n, pdr.Value);
                //                        content = n.ToString();
                //                        dimobj.DimensionText = content;
                //                    }
                //                    else
                //                        continue;
                //                }

                //            }
                //        }
                //    }
                //}
                #endregion

                //In case user select round up(2) or round down(3) :
                switch (pr.StringResult)
                {
                    //Round off:
                    case "Off":
                        foreach (SelectedObject sobj in acSSPrompt.Value)
                        {
                            //Just handle object that NOT null :
                            if (sobj != null)
                            {
                                //Open entity for write :
                                Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                                //In case MText :
                                if (ent.GetType().Name.ToString() == "MText")
                                {
                                    //Get text string :
                                    content = ((MText)ent).Contents;

                                    //Check whether it is numeric :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = RoundOff(n, pdr.Value);
                                        content = n.ToString();
                                        ((MText)ent).Contents = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case Text :
                                else if (ent.GetType().Name.ToString() == "DBText")
                                {
                                    //Get text string :
                                    content = ((DBText)ent).TextString;

                                    //Check whether it is numeric :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = RoundOff(n, pdr.Value);
                                        content = n.ToString();
                                        ((DBText)ent).TextString = content;
                                    }
                                    else
                                        continue;
                                }

                                else
                                {
                                    //Get dimension object :
                                    Dimension dimobj = (Dimension)ent;

                                    //Get dimension 's text :
                                    content = dimobj.DimensionText;

                                    //In case text is NOT overrided :
                                    if (content == "" || content == "<>")
                                        dimobj.Dimrnd = pdr.Value;

                                    //In case text is overrided :
                                    else
                                    {
                                        //Check whether it is numeric :
                                        isNumeric = double.TryParse(content, out n);
                                        if (isNumeric)
                                        {
                                            n = RoundOff(n, pdr.Value);
                                            content = n.ToString();
                                            dimobj.DimensionText = content;
                                        }
                                        else
                                            continue;
                                    }

                                }
                            }
                        }
                        break;

                    //Round up:
                    case "Up":
                        foreach (SelectedObject sobj in acSSPrompt.Value)
                        {
                            //Only handle object that NOT null :
                            if (sobj != null)
                            {
                                //Open entity for write :
                                Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                                //In case MText :
                                if (ent.GetType().Name.ToString() == "MText")
                                {
                                    //Get MText 's content :
                                    content = ((MText)ent).Contents;

                                    //Check whether it is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = Ceiling(n / pdr.Value) * pdr.Value;
                                        content = n.ToString();
                                        ((MText)ent).Contents = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case Text :
                                else if (ent.GetType().Name.ToString() == "DBText")
                                {
                                    //Get Text 's content :
                                    content = ((DBText)ent).TextString;

                                    //Check whether it is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = Ceiling(n / pdr.Value) * pdr.Value;
                                        content = n.ToString();
                                        ((DBText)ent).TextString = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case dimension :
                                else
                                {
                                    //Get dimension object :
                                    Dimension dimobj = (Dimension)ent;

                                    //Get dimension 's text :
                                    content = dimobj.DimensionText;

                                    //In case text is NOT overrided :
                                    if (content == "" || content == "<>")
                                    {
                                        //Get mesurement 's value :
                                        n = dimobj.Measurement;

                                        //Get max roundable value:
                                        double maxRound = n * 2.0;

                                        //Target value:
                                        double tarVal;
                                        if (n % 1 != 0)
                                        {
                                            tarVal = Ceiling(n / pdr.Value) * pdr.Value;
                                        }
                                        else
                                        {
                                            tarVal = n + pdr.Value;
                                        }

                                        //Round up:
                                        if (tarVal >= maxRound)
                                        {
                                            dimobj.DimensionText = tarVal.ToString();
                                        }
                                        else
                                        {
                                            dimobj.Dimrnd = tarVal;
                                        }

                                        #region [Old codes
                                        ////Get new DIMROUND :
                                        //double newDimRnd = GetDimRound(n,
                                        //     Ceiling(n / pdr.Value) * pdr.Value, pdr.Value);

                                        ////Check new DIMROUND :
                                        //if (newDimRnd == 0.0)
                                        //{
                                        //    n = Ceiling(n / pdr.Value) * pdr.Value;
                                        //    content = n.ToString();
                                        //    dimobj.DimensionText = content;
                                        //}
                                        //else
                                        //    dimobj.Dimrnd = newDimRnd;
                                        #endregion
                                    }
                                    else //In case text is overrided:
                                    {
                                        //Check whether it is a number or not :
                                        isNumeric = double.TryParse(content, out n);
                                        if (isNumeric)
                                        {
                                            n = Ceiling(n / pdr.Value) * pdr.Value;
                                            content = n.ToString();
                                            dimobj.DimensionText = content;
                                        }
                                        else
                                            continue;
                                    }
                                }
                            }
                        }
                        break;

                    //Round down:
                    case "Down":
                        foreach (SelectedObject sobj in acSSPrompt.Value)
                        {
                            //Only handle object that NOT null :
                            if (sobj != null)
                            {
                                //Open entity for write :
                                Entity ent = (Entity)tr.GetObject(sobj.ObjectId, OpenMode.ForWrite);

                                //In case MText :
                                if (ent.GetType().Name.ToString() == "MText")
                                {
                                    //Get text string :
                                    content = ((MText)ent).Contents;

                                    //Check whether text is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = Floor(n / pdr.Value) * pdr.Value;
                                        content = n.ToString();
                                        ((MText)ent).Contents = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case Text :
                                else if (ent.GetType().Name.ToString() == "DBText")
                                {
                                    //Get text string :
                                    content = ((DBText)ent).TextString;

                                    //Check whether text is a number :
                                    isNumeric = double.TryParse(content, out n);
                                    if (isNumeric)
                                    {
                                        n = Floor(n / pdr.Value) * pdr.Value;
                                        content = n.ToString();
                                        ((DBText)ent).TextString = content;
                                    }
                                    else
                                        continue;
                                }

                                //In case dimension :
                                else
                                {
                                    //Get dimension object :
                                    Dimension dimobj = (Dimension)ent;

                                    //Get dimension 's text :
                                    content = dimobj.DimensionText;

                                    //In case text is NOT overrided :
                                    if (content == "" || content == "<>")
                                    {
                                        //Get mesurement 's value :
                                        n = dimobj.Measurement;

                                        #region [Old codes
                                        ////Get new DIMROUND :
                                        //double newDimRnd = GetDimRound(n,
                                        //     Floor(n / pdr.Value) * pdr.Value, pdr.Value);

                                        ////Check new DIMROUND :
                                        //if (newDimRnd == 0.0)
                                        //{
                                        //    n = Floor(n / pdr.Value) * pdr.Value;
                                        //    content = n.ToString();
                                        //    dimobj.DimensionText = content;
                                        //}
                                        //else
                                        //    dimobj.Dimrnd = newDimRnd;
                                        #endregion

                                        //Target value:
                                        double tarVal;
                                        tarVal = n - pdr.Value;
                                        tarVal = RoundOff(tarVal, pdr.Value);

                                        //Round down:
                                        if (tarVal > 0.0)
                                        {
                                            dimobj.Dimrnd = tarVal;
                                        }
                                    }

                                    //In case text is overrided :
                                    else
                                    {
                                        //Check whether it is a number or not :
                                        isNumeric = double.TryParse(content, out n);
                                        if (isNumeric)
                                        {
                                            n = Floor(n / pdr.Value) * pdr.Value;
                                            content = n.ToString();
                                            dimobj.DimensionText = content;
                                        }
                                        else
                                            continue;
                                    }
                                }
                            }
                        }
                        break;
                }

                //Commit changes :
                tr.Commit();
            }

            //Silently send command to check fake dim:            
            using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
            {
                try
                {
                    //Send command to change color of fake dim :
                    ed.Command("_.FDS", "P", "");
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage(ex.Message);
                }
            }
        }

        [Obsolete("This method hasn't been supported.")]
        private double GetDimRound (double currValue, double targetValue , 
            double roundUnit)
        {
            double retVal;

            try
            {
                //Define increment :
                double incre;  //Variable for increment 
                char probablyDot = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator[0];
                string[] numbers = roundUnit.ToString().Split(probablyDot); //Get splited string .
                if (numbers.Length == 2)
                    incre = 1.0 / Pow(10, numbers[1].Length + 1);
                else
                    incre = 0.1;

                double tempRound = roundUnit;
                double limit = roundUnit + 100.0 * incre; //<- out of process if go to here :

                while (Abs(RoundOff(currValue, tempRound) - targetValue ) > KRTolerance &&
                    tempRound <= limit)
                {
                    tempRound += incre;
                }

                retVal = tempRound;
            }
            catch (System.Exception)
            {
                retVal = 0.0;
            }

            //Return value :
            return retVal;
        }

        [Obsolete("This method hasn't been supported.")]
        private void CmRd()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            TypedValue[] acTypValAr = new TypedValue[1];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 0);
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);
            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;

            PromptDoubleOptions pdo = new PromptDoubleOptions("\n 丸めのユニットをお記入 : ")
            { AllowArbitraryInput = false, AllowNone = true, AllowNegative = false };

            PromptDoubleResult pdr = ed.GetDouble(pdo);
            if (pdr.Status != PromptStatus.OK) return;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    if (sobj != null)
                    {
                        Dimension dimobj = (Dimension)(tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity);
                        dimobj.Dimrnd = pdr.Value;
                        Point3d pt3d = new Point3d(0, 0, 0);
                        Vector3d vt3dg = pt3d.GetVectorTo(new Point3d(1, 0, 0));
                        Vector3d vt3db = pt3d.GetVectorTo(new Point3d(-1, 0, 0));
                        dimobj.TransformBy(Matrix3d.Displacement(vt3dg));
                        dimobj.TransformBy(Matrix3d.Displacement(vt3db));
                    }
                }
                tr.Commit();
            }
        }
        #endregion

        //Chuyển đối tượng kích thước chứa @ thành nhiều text-> Dùng kết hợp K230 //<- deprecated 
        //[CommandMethod("D2T")]
        [Obsolete("Use 'K230' instead!")]
        public void CmdD2T()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Lưu lại giá trị của biến dimscale
            double van_num = System.Convert.ToDouble(Application.GetSystemVariable("dimscale"));

            TypedValue[] acTypValAr = new TypedValue[5];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "TEXT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "MTEXT"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "DIMENSION"), 3);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 4);

            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            PromptSelectionResult acSSPrompt = ed.GetSelection(acSelFtr);
            if (acSSPrompt.Status != PromptStatus.OK) return;

            //PromptStringOptions prs;
            //PromptResult prr;
            using (Transaction tr = doc.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                BlockTableRecord btr = tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                foreach (SelectedObject sobj in acSSPrompt.Value)
                {
                    Entity ent = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Entity;
                    if (ent.GetType().Name.ToString() == "MText")
                    {
                        MText mtxt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as MText;
                        string oldcontent = mtxt.Contents;
                        string[] words;
                        if (oldcontent.Contains('@'))
                        {
                            words = oldcontent.Split('@');
                            int n = int.Parse(words[0].Trim());
                            string content = words[1].Trim();
                            for (int i = 0; i < n; i++)
                            {
                                using (DBText actext = new DBText())
                                {
                                    actext.Position = PolarPoints(mtxt.Location, -1 * Math.PI / 2, (3.2 + 1.5) * van_num * i);
                                    actext.Height = 3.2 * van_num;
                                    actext.TextString = content;
                                    actext.Rotation = 0;
                                    actext.Layer = "TEXT";
                                    btr.AppendEntity(actext);
                                    tr.AddNewlyCreatedDBObject(actext, true);
                                }
                            }
                            mtxt.Erase();
                        }
                    }
                    else if (ent.GetType().Name.ToString() == "DBText")
                    {
                        DBText txt = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as DBText;
                        string oldcontent = txt.TextString;
                        string[] words;
                        if (oldcontent.Contains('@'))
                        {
                            words = oldcontent.Split('@');
                            int n = int.Parse(words[0].Trim());
                            string content = words[1].Trim();
                            for (int i = 0; i < n; i++)
                            {
                                using (DBText actext = new DBText())
                                {
                                    actext.Position = PolarPoints(txt.Position, -1 * Math.PI / 2, (3.2 + 1.5) * van_num * i);
                                    actext.Height = 3.2 * van_num;
                                    actext.TextString = content;
                                    actext.Rotation = 0;
                                    actext.Layer = "TEXT";
                                    btr.AppendEntity(actext);
                                    tr.AddNewlyCreatedDBObject(actext, true);
                                }
                            }
                            txt.Erase();
                        }
                    }
                    else
                    {
                        Dimension dimobj = tr.GetObject(sobj.ObjectId, OpenMode.ForWrite) as Dimension;
                        string oldcontent = dimobj.DimensionText;
                        string[] words;
                        if (oldcontent.Contains('@'))
                        {
                            words = oldcontent.Split('@');
                            int n = int.Parse(words[0].Trim());
                            string content = words[1].Trim();
                            for (int i = 0; i < n; i++)
                            {
                                using (DBText actext = new DBText())
                                {
                                    actext.Position = PolarPoints(dimobj.TextPosition, -1 * Math.PI / 2, (3.2 + 1.5) * van_num * i);
                                    actext.Height = 3.2 * van_num;
                                    actext.TextString = content;
                                    actext.Rotation = 0;
                                    actext.Layer = "TEXT";
                                    btr.AppendEntity(actext);
                                    tr.AddNewlyCreatedDBObject(actext, true);
                                }
                            }
                            dimobj.Erase();
                        }
                    }
                }
                tr.Commit();
            }
        }

        public void CmdSendcom()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;
            double rad = System.Convert.ToDouble(Application.GetSystemVariable("filletrad"));
            Application.SetSystemVariable("filletrad", 0);

            PromptEntityOptions peo1 = new PromptEntityOptions("\n エンティティの選択 :")
            { AllowNone = true };
            PromptEntityOptions peo2 = new PromptEntityOptions("\n 次のエンティティの選択 :")
            { AllowNone = true };

            PromptEntityResult per1 = ed.GetEntity(peo1);
            if (per1.Status != PromptStatus.OK) return;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                Curve cuv1 = tr.GetObject(per1.ObjectId, OpenMode.ForRead) as Curve;
                cuv1.Highlight();
                tr.Commit();
            }

            PromptEntityResult per2 = ed.GetEntity(peo2);
            if (per2.Status != PromptStatus.OK) return;
            using(Transaction tr = db.TransactionManager.StartTransaction())
            {
                Curve cuv1 = tr.GetObject(per1.ObjectId, OpenMode.ForRead) as Curve;
                cuv1.Unhighlight();
                Curve cuv2 = tr.GetObject(per1.ObjectId, OpenMode.ForRead) as Curve;
                cuv1.Highlight();
                Point3d pt1 = cuv1.GetClosestPointTo(per1.PickedPoint, true);
                Point3d pt2 = cuv2.GetClosestPointTo(per2.PickedPoint, true);
                ed.Command("_.fillet", pt1, pt2);
                tr.Commit();
            }
            bool cont = true;
            while (cont == true)
            {
                using (Transaction tr = doc.TransactionManager.StartTransaction())
                {
                    per1 = per2;
                    Curve cuv1 = tr.GetObject(per1.ObjectId, OpenMode.ForWrite) as Curve;
                    cuv1.Unhighlight();
                    per2 = ed.GetEntity(peo2);
                    if (per2.Status != PromptStatus.OK) return;
                    Curve cuv2 = tr.GetObject(per2.ObjectId, OpenMode.ForWrite) as Curve;
                    cuv2.Highlight();
                    Point3d pt1 = cuv1.GetClosestPointTo(per1.PickedPoint, true);
                    Point3d pt2 = cuv2.GetClosestPointTo(per2.PickedPoint, true);
                    ed.Command("_.fillet", pt1, pt2);
                    tr.Commit();
                }
            }
            Application.SetSystemVariable("filletrad", rad);
        }
    }
}

namespace AcadAddin.JigCmd
{
    public class Commands
    {
        #region [Nhóm lệnh tạo Xline dùng Jig]
        //This method used to draw Xline by vector:
        private void XlineByJig(Vector3d oDirVec, Document doc = null, Database db = null, Editor ed = null)
        {
            if (doc == null)
            {
                doc = CommonCommands.doc();
                db = doc.Database;
                ed = doc.Editor;
            }

            //Main loop :
            while (true)
            {
                try
                {
                    //Reset information:
                    List<KeyValuePair<string, object>> resetInfo = new List<KeyValuePair<string, object>>
                    {
                        new KeyValuePair<string, object>("ORTHOMODE", 0),
                        new KeyValuePair<string, object>("CURSORSIZE", 3),
                    };

                    using (KRResetSystemVar myResetCurSize = new KRResetSystemVar(resetInfo))
                    using (Xline xlObj = new Xline())
                    {
                        xlObj.UnitDir = oDirVec.TransformBy(ed.CurrentUserCoordinateSystem.Inverse());
                        xlObj.TransformBy(ed.CurrentUserCoordinateSystem);
                        XlineJig xlJigObj = new XlineJig(xlObj, "\nBase point: ");

                        PromptResult pr = ed.Drag(xlJigObj);
                        if (pr.Status == PromptStatus.OK)
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                //Add Xline to database:
                                AppendEnt(tr, xlJigObj.JigEntity);

                                //Update graphic:
                                tr.TransactionManager.QueueForGraphicsFlush();

                                //Commit changes:
                                tr.Commit();
                            }
                        }
                        else
                        {
                            //ed.WriteMessage("\nCannot create xline!");
                            return;
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage("\n" + ex.Message);
                    return;
                }
            }
        }

        private void XlineByJig(Point3d basePnt, Vector3d oDirVec, Document doc = null, Database db = null, Editor ed = null)
        {
            if (doc == null)
            {
                doc = CommonCommands.doc();
                db = doc.Database;
                ed = doc.Editor;
            }

            //Main loop :
            while (true)
            {
                try
                {
                    //Reset information:
                    List<KeyValuePair<string, object>> resetInfo = new List<KeyValuePair<string, object>>
                    {
                        new KeyValuePair<string, object>("ORTHOMODE", 0),
                        new KeyValuePair<string, object>("CURSORSIZE", 3),
                        new KeyValuePair<string, object>("DYNMODE", 3)
                    };

                    using (KRResetSystemVar myResetCurSize = new KRResetSystemVar(resetInfo))
                    using (Xline xlObj = new Xline())
                    {
                        xlObj.UnitDir = oDirVec.TransformBy(ed.CurrentUserCoordinateSystem.Inverse());
                        xlObj.TransformBy(ed.CurrentUserCoordinateSystem);

                        XlineJigDydim xlJigObj = new XlineJigDydim(xlObj, "\nBase point: ", basePnt);

                        PromptResult pr = ed.Drag(xlJigObj);
                        if (pr.Status == PromptStatus.OK || pr.Status == PromptStatus.Other)
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                //Add Xline to database:
                                AppendEnt(tr, xlJigObj.JigEntity);

                                //Update graphic:
                                tr.TransactionManager.QueueForGraphicsFlush();

                                //Commit changes:
                                tr.Commit();
                            }
                        }
                        else if (pr.Status == PromptStatus.Keyword)
                        {
                            PromptStringOptions pso = new PromptStringOptions("")
                            {
                                Message = "\nContinuous distances(20,30,40...): ",
                                AllowSpaces = false
                            };

                            //ed.WriteMessage("\nUsed keyword mode");
                            PromptResult pr2 = ed.GetString(pso);
                            if (pr2.Status == PromptStatus.OK)
                            {
                                string[] splitStrs = pr2.StringResult.Split(',');
                                if (splitStrs == null || splitStrs.Length == 0)
                                {
                                    ed.WriteMessage("\nInput is not valid!");
                                    continue;
                                }
                                else
                                {
                                    //List for offset distances:
                                    List<double> offDists = new List<double>();
                                    foreach (string splitStr in splitStrs)
                                    {
                                        if (System.Double.TryParse(splitStr, out double tempReal))
                                        {
                                            offDists.Add(tempReal);
                                        }
                                    }

                                    if (offDists.Count == 0 || xlJigObj.OffsetVector == Vector3d.ZAxis)
                                    {
                                        ed.WriteMessage("\nOffset distances are not valid!");
                                        continue;
                                    }
                                    else
                                    {
                                        using (Transaction tr = db.TransactionManager.StartTransaction())
                                        {
                                            Vector3d xlUnitDir = (xlJigObj.JigEntity as Xline).UnitDir;

                                            double calOffDist = 0.0;
                                            for (int i = 0; i < offDists.Count; i++)
                                            {
                                                calOffDist += offDists[i];

                                                using (Xline tempXline = new Xline())
                                                {
                                                    tempXline.SetPropertiesFrom(xlJigObj.JigEntity);

                                                    tempXline.BasePoint = basePnt.TransformBy
                                                        (Matrix3d.Displacement(xlJigObj.OffsetVector * calOffDist / xlJigObj.OffsetVector.Length));

                                                    tempXline.UnitDir = xlUnitDir;

                                                    AppendEnt(tr, tempXline);
                                                }
                                            }

                                            //Update graphics:
                                            tr.TransactionManager.QueueForGraphicsFlush();

                                            //Commit changes:
                                            tr.Commit();
                                        }
                                    }
                                }
                            }
                            else
                            {
                                ed.WriteMessage("\nInput is not valid!");
                                continue;
                            }
                        }
                        else
                        {
                            //ed.WriteMessage("\nCannot create xline!");
                            return;
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage("\n" + ex.Message);
                    return;
                }
            }
        }

        private void XlineByJig(Curve3d boGeoCurv, bool isTangent, Document doc = null, Database db = null, Editor ed = null)
        {
            if (doc == null)
            {
                doc = CommonCommands.doc();
                db = doc.Database;
                ed = doc.Editor;
            }

            //Main loop :
            while (true)
            {
                try
                {
                    //Reset information:
                    List<KeyValuePair<string, object>> resetInfo = new List<KeyValuePair<string, object>>
                    {
                        new KeyValuePair<string, object>("ORTHOMODE", 0),
                        new KeyValuePair<string, object>("CURSORSIZE", 3),
                    };

                    using (KRResetSystemVar myResetCurSize = new KRResetSystemVar(resetInfo))
                    using (Xline xlObj = new Xline())
                    {
                        xlObj.TransformBy(ed.CurrentUserCoordinateSystem);

                        XlineJigWithGeo xlJigObj = new XlineJigWithGeo(xlObj, "\nBase point: ", boGeoCurv, isTangent);

                        PromptResult pr = ed.Drag(xlJigObj);
                        if (pr.Status == PromptStatus.OK)
                        {
                            using (Transaction tr = db.TransactionManager.StartTransaction())
                            {
                                //Add Xline to database:
                                AppendEnt(tr, xlJigObj.JigEntity);

                                //Update graphic:
                                tr.TransactionManager.QueueForGraphicsFlush();

                                //Commit changes:
                                tr.Commit();
                            }
                        }
                        else
                        {
                            //ed.WriteMessage("\nCannot create xline!");
                            return;
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage("\n" + ex.Message);
                    return;
                }
            }
        }

        //Lệnh vẽ Horizontal line
        [CommandMethod("LH")]
        public void CmdLH()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            #region [For understand]
            //Cach lay truc X,Y,Z trong UCS:
            //Vector3d.XAxis;
            //Vector3d.YAxis;
            //Vector3d.ZAxis;
            #endregion

            Vector3d dirVec = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Xaxis;

            //Draw by Jig:
            XlineByJig(dirVec, doc, db, ed);
        }

        //Lệnh vẽ Vertical line
        [CommandMethod("LV")]
        public void CmdLV()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            #region [For understand]
            //Cach lay truc X,Y,Z trong UCS:
            //Vector3d.XAxis;
            //Vector3d.YAxis;
            //Vector3d.ZAxis;
            #endregion

            Vector3d dirVec = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Yaxis;

            //Draw by Jig:
            XlineByJig(dirVec, doc, db, ed);
        }

        //This method called by CmdLAN & CmdLPEN:
        private void CmdXlineByCurve(bool isPer = false)
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Start main transaction :
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                try
                {
                    #region [Get nested entity]
                    PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("\nSelect curve: ")
                    {
                        AllowNone = true,
                    };

                    PromptNestedEntityResult pner = ed.GetNestedEntity(pneo);
                    if (pner.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }

                    bool isCurve = pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Curve))) ||
                                   pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(MLeader)));
                    if (isCurve == false && pner.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                        isCurve = true;

                    while (!isCurve)
                    {
                        ed.WriteMessage("\nInvalid selection!");
                        pner = ed.GetNestedEntity(pneo);
                        if (pner.Status != PromptStatus.OK)
                        {
                            tr.Abort();
                            return;
                        }
                        else
                        {
                            isCurve = pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Curve))) ||
                                      pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(MLeader)));
                            if (isCurve == false && pner.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                                isCurve = true;
                        }
                    }
                    #endregion

                    #region [Old codes]
                    ////Get nested containers:
                    //ObjectId[] objIds = pner.GetContainers();
                    //ObjectId ensel = pner.ObjectId;
                    //int len = objIds.Length;

                    //// Reverse the "containers" list
                    //ObjectId[] revIds = new ObjectId[len + 1];
                    //for (int i = 0; i < len; i++)
                    //{
                    //    ObjectId id = (ObjectId)objIds.GetValue(len - i - 1);
                    //    revIds.SetValue(id, i);
                    //}

                    ////Now add the selected entity to the end
                    //revIds.SetValue(ensel, len);

                    ////Retrieve the sub-entity path for this entity
                    //SubentityId subEnt = new SubentityId(SubentityType.Null, IntPtr.Zero);

                    ////Get full path to highlight:
                    //FullSubentityPath stdPath = new FullSubentityPath(revIds, subEnt);

                    ////Highlight standard entity:
                    //KRUnhighlight.HighlightNested(db, ed,pner,true,true);
                    #endregion

                    #region [For understand]
                    //Get point in UCS:
                    Point3d pickPntUcs = pner.PickedPoint;
                    //ed.WriteMessage($"\nCoor in UCS : {pickPntUcs.X} , {pickPntUcs.Y}");

                    //Get point in UCS:
                    Point3d pickPntWcs = pickPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);
                    //ed.WriteMessage($"\nCoor in WCS : {pickPntWcs.X} , {pickPntWcs.Y}");

                    //Get point in ECS:
                    Point3d pickPntEcs = pickPntWcs.TransformBy(pner.Transform.Inverse());
                    //ed.WriteMessage($"\nCoor in ECS : {pickPntEcs.X} , {pickPntEcs.Y}");
                    #endregion

                    bool isHighlightAll = true;

                    try
                    {
                        //Open curve for read:
                        Curve boCurv;
                        if (pner.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                        {
                            Vertex2d vert = (Vertex2d)tr.GetObject(pner.ObjectId, OpenMode.ForRead);
                            boCurv = (Curve)tr.GetObject(vert.OwnerId, OpenMode.ForRead);
                        }
                        else if (pner.ObjectId.ObjectClass.Name == "AcDbLeader" ||
                                 pner.ObjectId.ObjectClass.Name == "AcDbMLeader")
                        {
                            //Open entity for read:
                            Entity srcldr = (Entity)tr.GetObject(pner.ObjectId, OpenMode.ForRead);

                            //Make the clone of Leader/ MLeader.
                            //Explode cloned enitity, iterate members and get closest curve to picked point.
                            using (Entity ldr = (Entity)srcldr.Clone())
                            using (DBObjectCollection leaderSegs = new DBObjectCollection())
                            using (DBObjectCollection polyCol = new DBObjectCollection())
                            {
                                //var leaderSegs = new DBObjectCollection();
                                ldr.Explode(leaderSegs);

                                //var polyCol = new DBObjectCollection();
                                foreach (DBObject dbObj in leaderSegs)
                                {//Autodesk.AutoCAD.DatabaseServices.Polyline
                                    if (dbObj is Curve)
                                    {
                                        polyCol.Add(dbObj);
                                    }
                                }

                                if (polyCol.Count == 0)
                                {
                                    tr.Abort();
                                    return;
                                }
                                else
                                {
                                    //Get curve closest to picked point:
                                    int closestIndex = 0;

                                    for (int i = 0; i < polyCol.Count; i++)
                                    {
                                        Point3d thisClosest, stdClosest;
                                        thisClosest = ((Curve)polyCol[i]).GetClosestPointTo(pickPntEcs, true);
                                        stdClosest = ((Curve)polyCol[closestIndex]).GetClosestPointTo(pickPntEcs, true);

                                        double dist1 = thisClosest.DistanceTo(pickPntEcs);
                                        double dist2 = stdClosest.DistanceTo(pickPntEcs);

                                        if (dist1 < dist2)
                                        {
                                            closestIndex = i;
                                        }
                                    }

                                    boCurv = (Curve)polyCol[closestIndex];
                                }
                            }
                        }
                        else
                        {
                            boCurv = (Curve)tr.GetObject(pner.ObjectId, OpenMode.ForRead);
                        }

                        ////Get closest point to picked point (ECS):
                        Point3d cloPnt = boCurv.GetClosestPointTo(pickPntEcs, true);
                        //ed.WriteMessage($"\nClosest Coor in ECS : {cloPnt.X} , {cloPnt.Y}");

                        //Get tangent vector at closest point (ECS):
                        Vector3d tangVt = boCurv.GetFirstDerivative(cloPnt);

                        //Get perdendicular vector (ECS):
                        Vector3d perVec = tangVt.GetPerpendicularVector();

                        //Transform vector from ECS -> WCS:
                        tangVt = tangVt.TransformBy(pner.Transform);
                        perVec = perVec.TransformBy(pner.Transform);

                        //Draw by Jig:
                        using (Curve3d boGeoCurv = boCurv.GetGeCurve())
                        {
                            boGeoCurv.TransformBy(pner.Transform);    //ECS -> WCS

                            if (isPer)
                            {
                                KRUnhighlight.HighlightNested(db, ed, pner, true, isHighlightAll);
                                XlineByJig(boGeoCurv, false, doc, db, ed);
                            }
                            else
                            {
                                if (boGeoCurv is LinearEntity3d || boGeoCurv is CompositeCurve3d)
                                {
                                    isHighlightAll = false;
                                    KRUnhighlight.HighlightNested(db, ed, pner, true, isHighlightAll);
                                    XlineByJig(cloPnt.TransformBy(pner.Transform), tangVt, doc, db, ed);
                                }
                                else
                                {
                                    KRUnhighlight.HighlightNested(db, ed, pner, true, isHighlightAll);
                                    XlineByJig(boGeoCurv, true, doc, db, ed);
                                }
                            }
                        }

                        //Commit changes :
                        tr.Commit();
                    }
                    catch (System.Exception ex)
                    {
                        ed.WriteMessage("\n" + ex.Message);
                        tr.Abort();
                        return;
                    }
                    finally
                    {
                        //Unhighlight:
                        KRUnhighlight.HighlightNested(db, ed, pner, false, isHighlightAll);
                    }
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage("\n" + ex.Message);
                    tr.Abort();
                    return;
                }
            }
        }

        //Draw paralel Xline:
        [CommandMethod("LA")]
        public void CmdLAN()
        {
            CmdXlineByCurve(false);
        }

        //Draw perpendicular Xline:
        [CommandMethod("LPE")]
        public void CmdLPEN()
        {
            CmdXlineByCurve(true);
        }

        [Obsolete("Use XlineByJig instead.")]
        private void XlineByVec(Vector3d dirVec, Document doc = null, Database db = null, Editor ed = null)
        {
            if (doc == null)
            {
                doc = CommonCommands.doc();
                db = doc.Database;
                ed = doc.Editor;
            }

            //Declare variable for the base point :
            Point3d basePnt = Point3d.Origin;

            //Main loop :
            while (true)
            {
                //Get base point :
                if (KRGetPoint(ed, "\nBase point: ", Point3d.Origin, ref basePnt) != PromptStatus.OK)
                    break;
                else
                    basePnt = Ucs2Wcs(basePnt);

                //Start main transaction :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    using (Xline xlObj = new Xline())
                    {
                        xlObj.BasePoint = basePnt;
                        xlObj.UnitDir = dirVec;
                        AppendEnt(tr, xlObj);
                    }

                    //Update graphic :
                    tr.TransactionManager.QueueForGraphicsFlush();

                    //Commit changes :
                    tr.Commit();
                }
            }
        }

        [Obsolete("Use CmdLV instead.")]
        private void CmdLVOld()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            bool cont = true;
            while (cont == true)
            {
                PromptPointOptions prp = new PromptPointOptions("\n 原点を選んで下さい。")
                {
                    AllowArbitraryInput = false,
                    AllowNone = true,
                    BasePoint = new Point3d(0, 0, 0),
                    UseBasePoint = true
                };

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    BlockTableRecord bltr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;
                    PromptPointResult prpr0 = ed.GetPoint(prp);
                    if (prpr0.Status != PromptStatus.OK) return;

                    //Chuyển tọa độ điểm từ UCS sang WCS
                    Matrix3d ucs = ed.CurrentUserCoordinateSystem;
                    CoordinateSystem3d cs = ucs.CoordinateSystem3d;
                    Matrix3d mat = Matrix3d.AlignCoordinateSystem(Point3d.Origin,
                                    Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
                                    cs.Origin, cs.Xaxis, cs.Yaxis, cs.Zaxis);
                    Point3d prpr = prpr0.Value.TransformBy(mat);

                    double DimSc = System.Convert.ToDouble(Application.GetSystemVariable("DIMSCALE"));
                    double Len = DimSc * 1000000;
                    using (Line xl = new Line())
                    {
                        xl.StartPoint = PolarPoints(prpr, -1 * Math.PI / 2, Len / 2);
                        xl.EndPoint = PolarPoints(prpr, Math.PI / 2, Len / 2);
                        bltr.AppendEntity(xl);
                        tr.AddNewlyCreatedDBObject(xl, true);
                    }
                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }
            }
        }

        [Obsolete("This method doesn't support nested entity. Use CmdLAN instead!")]
        private void CmdLA()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Auto unhighlight entities when process finish .
            using (KRUnhighlight myUnHighlight = new KRUnhighlight())
            using (KRResetUCS myResetUcs = new KRResetUCS())
            {
                //Start main transaction :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    ////Create plane 2d to convert 3d geometry -> 2d geometry :
                    //var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                    //var plane = new Plane(Point3d.Origin, normal);
                    try
                    {
                        #region [Get curve for angle]
                        //Prompt option :
                        PromptEntityOptions peo = new PromptEntityOptions("\nSelect curve for angle :");
                        peo.SetRejectMessage("\nInvalid selection. Please select curve !");
                        peo.AddAllowedClass(typeof(Curve), false);

                        //Prompt result :
                        PromptEntityResult per = ed.GetEntity(peo);
                        if (per.Status != PromptStatus.OK)
                            return;
                        else
                            myUnHighlight.Add(per.ObjectId);

                        //Open curve for read:
                        Curve boCurv = (Curve)tr.GetObject(per.ObjectId, OpenMode.ForRead);

                        //Get closest point to picked point:
                        Point3d cloPnt = boCurv.GetClosestPointTo(per.PickedPoint, true);

                        //Get tangent vector at closest point:
                        Vector3d tangVt = boCurv.GetFirstDerivative(cloPnt);

                        //Check curve's type & highlight:
                        if (per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Polyline2d)))
                            || per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(
                                Autodesk.AutoCAD.DatabaseServices.Polyline)))
                            )
                        {
                            double param = boCurv.GetParameterAtPoint(cloPnt);
                            FullSubentityPath path = new FullSubentityPath(new ObjectId[] { boCurv.Id },
                                        new SubentityId(SubentityType.Edge, new IntPtr((int)param + 1)));
                            boCurv.Highlight(path, false);
                        }
                        else
                        {
                            boCurv.Highlight();
                        }
                        #endregion

                        //Call sub function to draw Xline :
                        //XlineByVec(tangVt, doc, db, ed);

                        //Draw by Jig:
                        XlineByJig(tangVt, doc, db, ed);

                        //Commit changes :
                        tr.Commit();
                    }
                    catch (System.Exception ex)
                    {
                        ed.WriteMessage(ex.ToString());
                        return;
                    }
                }
            }
        }

        [Obsolete("Use CmdLPEN instead!")]
        private void CmdXL()//Deprecated 
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptPointOptions prp = new PromptPointOptions("\n原点:")
            {
                AllowArbitraryInput = false,
                AllowNone = true,
                BasePoint = new Point3d(0, 0, 0),
                UseBasePoint = true
            };
            PromptPointResult prpr0 = ed.GetPoint(prp);

            bool cont = true;
            while (cont == true)
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //BlockTable blt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                    //BlockTableRecord bltr = tr.GetObject(blt[BlockTableRecord.ModelSpace], OpenMode.ForWrite) as BlockTableRecord;
                    BlockTableRecord bltr = tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite) as BlockTableRecord;
                    if (prpr0.Status != PromptStatus.OK) return;

                    PromptPointOptions prp1 = new PromptPointOptions("\nVertex点:")
                    {
                        AllowArbitraryInput = false,
                        AllowNone = true,
                        BasePoint = prpr0.Value,
                        UseBasePoint = true
                    };

                    PromptPointResult prpr1 = ed.GetPoint(prp1);
                    if (prpr1.Status != PromptStatus.OK) return;

                    //Chuyển tọa độ điểm từ UCS sang WCS
                    Matrix3d ucs = ed.CurrentUserCoordinateSystem;
                    CoordinateSystem3d cs = ucs.CoordinateSystem3d;
                    Matrix3d mat = Matrix3d.AlignCoordinateSystem(Point3d.Origin,
                                    Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis,
                                    cs.Origin, cs.Xaxis, cs.Yaxis, cs.Zaxis);
                    Point3d prpr = prpr0.Value.TransformBy(mat);
                    Point3d prpr2 = prpr1.Value.TransformBy(mat);
                    Vector3d Vt1 = prpr2 - prpr;

                    var normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis;
                    var plane = new Plane(Point3d.Origin, normal);
                    double angle = Vt1.AngleOnPlane(plane);

                    double DimSc = System.Convert.ToDouble(Application.GetSystemVariable("DIMSCALE"));
                    double Len = DimSc * 1000000;
                    using (Line xl = new Line())
                    {
                        xl.StartPoint = PolarPoints(prpr, angle + Math.PI, Len / 2);
                        xl.EndPoint = PolarPoints(prpr, angle, Len / 2);
                        bltr.AppendEntity(xl);
                        tr.AddNewlyCreatedDBObject(xl, true);
                    }

                    tr.TransactionManager.QueueForGraphicsFlush();
                    tr.Commit();
                }
            }
        }

        [Obsolete("This method doesn't support nested entity. Use CmdLPEN instead!")]
        private void CmdLPE()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Auto unhighlight entities when process finish .
            using (KRUnhighlight myUnHighlight = new KRUnhighlight())
            using (KRResetUCS myResetUcs = new KRResetUCS())
            {
                //Start main transaction :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    try
                    {
                        #region [Get curve for angle]
                        //Prompt option :
                        PromptEntityOptions peo = new PromptEntityOptions("\nSelect curve for angle :");
                        peo.SetRejectMessage("\nInvalid selection. Please select curve !");
                        peo.AddAllowedClass(typeof(Curve), false);

                        //Prompt result :
                        PromptEntityResult per = ed.GetEntity(peo);
                        if (per.Status != PromptStatus.OK)
                            return;
                        else
                            myUnHighlight.Add(per.ObjectId);

                        //Open curve for read:
                        Curve boCurv = (Curve)tr.GetObject(per.ObjectId, OpenMode.ForRead);

                        //Get closest point to picked point:
                        Point3d cloPnt = boCurv.GetClosestPointTo(per.PickedPoint, true);

                        //Get tangent vector at closest point:
                        Vector3d tangVt = boCurv.GetFirstDerivative(cloPnt);

                        //Get perdendicular vector:
                        Vector3d perVec = tangVt.GetPerpendicularVector();

                        //Check curve's type & highlight:
                        if (per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Polyline2d)))
                            || per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(
                                Autodesk.AutoCAD.DatabaseServices.Polyline)))
                            )
                        {
                            double param = boCurv.GetParameterAtPoint(cloPnt);
                            FullSubentityPath path = new FullSubentityPath(new ObjectId[] { boCurv.Id },
                                        new SubentityId(SubentityType.Edge, new IntPtr((int)param + 1)));
                            boCurv.Highlight(path, false);
                        }
                        else
                        {
                            boCurv.Highlight();
                        }
                        #endregion

                        //Draw by Jig:
                        XlineByJig(perVec, doc, db, ed);

                        //Commit changes :
                        tr.Commit();
                    }
                    catch (System.Exception ex)
                    {
                        ed.WriteMessage(ex.ToString());
                        return;
                    }
                }
            }
        }

        #endregion

        #region [Nhóm lệnh move dùng Jig]
        //Test method to change entity transparency:
        private void TestChangeTrans()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;
            Database db = doc.Database;

            PromptSelectionResult pr = ed.GetSelection();
            if (pr.Status != PromptStatus.OK || pr.Value.Count == 0)
            {
                return;
            }

            List<KeyValuePair<ObjectId, Autodesk.AutoCAD.Colors.Transparency>> objsTrans =
                new List<KeyValuePair<ObjectId, Autodesk.AutoCAD.Colors.Transparency>>();
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {

                foreach (SelectedObject sObj in pr.Value)
                {
                    if (sObj != null)
                    {
                        Entity ent = tr.GetObject(sObj.ObjectId, OpenMode.ForWrite) as Entity;
                        Autodesk.AutoCAD.Colors.Transparency oldTrans = ent.Transparency;
                        double percent = oldTrans.Alpha * 100.0 / 255.0;
                        objsTrans.Add(new KeyValuePair<ObjectId, Autodesk.AutoCAD.Colors.Transparency>
                            (ent.ObjectId, ent.Transparency));

                        Byte newTransByte = (Byte)((percent / 2.0) * 255.0 / 100.0);
                        Autodesk.AutoCAD.Colors.Transparency newTrans = new Autodesk.AutoCAD.Colors.Transparency(newTransByte);
                        ent.Transparency = newTrans;
                    }

                    db.TransactionManager.QueueForGraphicsFlush();
                }

                //Commit changes:
                tr.Commit();
            }

            PromptPointResult ppr = ed.GetPoint("\nPick point: ");
            if (ppr.Status == PromptStatus.OK)
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    foreach (var item in objsTrans)
                    {
                        Entity ent = tr.GetObject(item.Key, OpenMode.ForWrite) as Entity;
                        ent.Transparency = item.Value;
                    }

                    tr.Commit();
                }

                ed.WriteMessage("\nTrans back to 100%.");
            }
            else
            {
                ed.WriteMessage("\nTrans become 50%.");
            }
        }

        //Test method to send command using Async + Await:
        private async void TestSendCmd()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;

            PromptSelectionOptions pso = new PromptSelectionOptions()
            {
                MessageForAdding = "\nSelect entities to add: ",
                MessageForRemoval = "\nSelect entities to remove: ",
            };

            //Ask user to get select on screen:
            PromptSelectionResult selRes = ed.GetSelection(pso);
            if (selRes.Status != PromptStatus.OK ||
                selRes.Value.Count == 0)
            {
                ed.WriteMessage("\nYou selected nothing!");
                return;
            }

            //https://stackoverflow.com/questions/32491746/autocad-net-send-string-to-execute-synchronously
            //https://adndevblog.typepad.com/autocad/2012/05/why-does-sendcommand-run-asynchronously.html#:~:text=If%20SendCommand%20is%20synchronous%20or%20not%20also%20depends,this%2C%20just%20add%20CommandFlags.Session%20to%20the%20CommandMethod%20attribute.
            //http://www.theswamp.org/index.php?topic=49124.0

            ////This can keep the hide situation but process is asynchronous:
            //string cmd = "Copy " + "P " + " " + "0,0,0 " + "1500,1500,0 " + " ";
            //doc.SendStringToExecute(cmd, true, false, false);

            ////This will lose hide situation but process is synchronous:
            //ed.Command("Copy", "P", "", "0,0,0", "1500,1500,0");

            await ed.CommandAsync("_.Copy");
            await ed.CommandAsync("_P");
            await ed.CommandAsync("");
            await ed.CommandAsync("0,0,0");
            await ed.CommandAsync("150,150,0");

            ed.WriteMessage("\nDone");

            #region [Old codes
            //string cmdStr = "(Command " + "\"Copy\" " + "\"P\" \"\" " + "\"0,0,0\" " + "\"25,25,0\"" + ")";

            //ed.WriteMessage("\nString :" + cmdStr);
            //ed.Command(cmdStr);

            //(defun foo(l)(reverse l)) (vl - acad - defun "foo")

            // build the arguments list
            //ResultBuffer args = new ResultBuffer(
            //    new TypedValue((int)LispDataType.Text, cmdStr)
            //    );


            // call the LISP fuction anf get the return value
            //ResultBuffer result = Application.Invoke(args);

            // print the return value
            //ed.WriteMessage(result.ToString());
            //ed.Command(cmdStr);
            #endregion
        }

        //Method to check entity has hide situation:
        private bool HasHideSituation(IMcad2DStructureMgr mgr, Entity ent)
        {
            AXDBLib.AcadEntity comEnt = (AXDBLib.AcadEntity)ent.AcadObject;
            return !mgr.IsFreeEntity(comEnt);
        }

        //Method to search for hide situation:
        private McadHideSituation SearchForHide(AcadDocument acDoc,
                    IMcad2DStructureMgr mgr, McadFolderDefinition rootDef, IMcadUtility acmUti,
                    KeyValuePair<ObjectId, ObjectId> idMap, out string errMsg)
        {
            errMsg = "";
            McadHideSituation retVal = null;
            #region [COM variables]
            McadHideSituations hideSituations;
            object referredToAs;
            IMcadFolder folderView;
            AXDBLib.AcadEntity comEntFrom;
            AXDBLib.AcadEntity comEntTo;
            #endregion
            //AXDBLib.AcadEntity comEnt = (AXDBLib.AcadEntity)ent.AcadObject;

            try
            {
                comEntFrom = acDoc.ObjectIdToObject((long)idMap.Key.OldIdPtr);
                comEntTo = acDoc.ObjectIdToObject((long)idMap.Value.OldIdPtr);
                folderView = mgr.GetStructureFromEntity(comEntFrom);
            }
            catch (System.Exception ex)
            {
                errMsg = ex.Message;
                return retVal;
            }

            try
            {
                rootDef.FindHideSituations(folderView, out hideSituations, out referredToAs);
                if (hideSituations.Count == 0)
                {
                    errMsg = "\nCannot get hide situation.";
                    return retVal;
                }
                else if (hideSituations.Count > 1)
                {
                    int countVal = 0;
                    int[] intArr = (int[])referredToAs;

                    //Iterate each selection 
                    foreach (McadHideSituation hideSitu in hideSituations)
                    {
                        //hideSitu.Copy();
                        int bgIndex = intArr[countVal];
                        McadHideSituationSubentType style;
                        if (bgIndex == 1)
                        {
                            style = McadHideSituationSubentType.mc2DSFGEnt;
                        }
                        else
                        {
                            style = McadHideSituationSubentType.mc2DSBGEnt;
                        }


                        hideSitu.AddMSSubent(comEntTo, style);

                        countVal += 1;
                    }

                    ////errMsg = "\nHide situation is too difficult.";
                    //Document doc = CommonCommands.doc();
                    //Editor ed = doc.Editor;
                    //ed.WriteMessage($"\nreferredToAs : {intArr[0]}");

                    retVal = hideSituations.Item(0);
                }
            }
            catch (System.Exception ex)
            {
                errMsg = ex.Message;
                return retVal;
            }

            return retVal;
        }

        //Method to clone hide situation:
        private bool CloneHideSituation(AcadDocument acDoc,
                    IMcad2DStructureMgr mgr, McadFolderDefinition rootDef, IMcadUtility acmUti,
                    ObjectIdCollection hasHideObjIds, IdMapping idMap, out string errMsg)
        {
            //Initialize default return value:
            errMsg = "";
            bool retVal = false;

            #region [COM declarations]
            McadHideSituations hideSituations;
            object referredToAs;
            #endregion

            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;

            //AXDBLib.AcadEntity comEnt = (AXDBLib.AcadEntity)ent.AcadObject;

            #region [Create list of tupple]
            //Create list of  tupple that contains :
            //[source COM entity] - [cloned COM entity] - [HideClonedStatus].
            List<Tuple<AXDBLib.AcadEntity, AXDBLib.AcadEntity, bool>> comMap =
                new List<Tuple<AXDBLib.AcadEntity, AXDBLib.AcadEntity, bool>>();

            try
            {
                //folderView = mgr.GetStructureFromEntity(comEntFrom);
                foreach (ObjectId id in hasHideObjIds)
                {
                    if (idMap.Contains(id))
                    {
                        AXDBLib.AcadEntity comEntFrom = acDoc.ObjectIdToObject((long)id.OldIdPtr);
                        AXDBLib.AcadEntity comEntTo = acDoc.ObjectIdToObject((long)idMap[id].Value.OldIdPtr);

                        comMap.Add(new Tuple<AXDBLib.AcadEntity, AXDBLib.AcadEntity, bool>(
                            comEntFrom, comEntTo, false));
                        //hideCOMpairs.Add(new KeyValuePair<AXDBLib.AcadEntity, AXDBLib.AcadEntity>(comEntFrom, comEntTo));
                        //hideIdpairs.Add(new KeyValuePair<ObjectId, ObjectId>(id, idMap[id].Value));
                    }
                }
            }
            catch (System.Exception ex)
            {
                errMsg = ex.Message;
                return retVal;
            }
            #endregion

            #region [Clone hide situation]
            //Iterate COMpair and clone hide situation:
            try
            {
                foreach (var item in comMap)
                {
                    //Process for uncloned entity only:
                    if (!item.Item3)
                    {
                        IMcadFolder folderView = mgr.GetStructureFromEntity(item.Item1);
                        rootDef.FindHideSituations(folderView, out hideSituations, out referredToAs);
                        if (hideSituations.Count == 0)
                        {
                            errMsg = "\nCannot get hide situation.";
                            return retVal;
                        }
                        else
                        {
                            //Get group information for connection objects:
                            ed.WriteMessage($"\nHide counts: {hideSituations.Count}");

                            //object fgIds;
                            foreach (McadHideSituation hideSitu in hideSituations)
                            {
                                //McadHideSituation newHideSitu;
                                ed.WriteMessage($"\nHide {hideSitu.Definition}");

                                //List of fg ids:
                                McadFolders fgFdrs = hideSitu.Subents[McadHideSituationSubentType.mc2DSFGEnt];
                                List<long> fgIds = new List<long>();
                                foreach (McadFolder fdr in fgFdrs)
                                {
                                    foreach (var comItem in fdr.Entities)
                                    {
                                        AXDBLib.AcadEntity comEnt = acDoc.ObjectIdToObject(comItem);
                                        fgIds.Add(comEnt.ObjectID);
                                    }
                                }

                                //List of bg ids:
                                McadFolders bgFdrs = hideSitu.Subents[McadHideSituationSubentType.mc2DSBGEnt];
                                List<long> bgIds = new List<long>();
                                foreach (McadFolder fdr in bgFdrs)
                                {
                                    foreach (var comItem in fdr.Entities)
                                    {
                                        AXDBLib.AcadEntity comEnt = acDoc.ObjectIdToObject(comItem);
                                        bgIds.Add(comEnt.ObjectID);
                                    }
                                }

                                ed.WriteMessage("\n-----------------------");

                                //Create new hide situation:
                                string newHideName = "*";
                                McadHideSituation newHide;
                                rootDef.AddHideSituation(newHideName, out newHide, fgIds, bgIds);
                            }

                            //    //CAN NOT COPY HIDE -> USE another way:
                            //    //McadHideSituation cHideSitu = hideSitu.Copy();
                            //    //ed.WriteMessage($"\nHide cloned : {cHideSitu}");

                            //    ////int numFG = hideSitu.Subents[McadHideSituationSubentType.mc2DSFGEnt].Count;
                            //    ////ed.WriteMessage($"\nHide's FG num : {numFG}");
                            //    //foreach (McadFolder folder in hideSitu.Subents[McadHideSituationSubentType.mc2DSFGEnt])
                            //    //{
                            //    //    foreach (var comItem in folder.Entities)
                            //    //    {
                            //    //        AXDBLib.AcadEntity comEnt = acDoc.ObjectIdToObject(comItem);

                            //    //        var foundTuple = comMap.FirstOrDefault(eri => eri.Item1 == comEnt);

                            //    //        if (foundTuple != null)
                            //    //        {
                            //    //            cHideSitu.AddMSSubent(foundTuple.Item2, McadHideSituationSubentType.mc2DSFGEnt);
                            //    //            int index = comMap.IndexOf(foundTuple);
                            //    //            comMap.RemoveAt(index);
                            //    //            Tuple<AXDBLib.AcadEntity, AXDBLib.AcadEntity, bool> newTup =
                            //    //                new Tuple<AXDBLib.AcadEntity, AXDBLib.AcadEntity, bool>(comEnt, foundTuple.Item2, true);
                            //    //            comMap.Insert(index, newTup);
                            //    //        }
                            //    //        else
                            //    //        {
                            //    //            ed.WriteMessage("\n(FG)Tuple cannot be found!");
                            //    //        }
                            //    //        //ed.WriteMessage($"\nType : {comEnt.GetType().Name}");
                            //    //    }
                            //    //}

                            //    ////ed.WriteMessage("\n-----------------------------------");
                            //    ////int numBG = hideSitu.Subents[McadHideSituationSubentType.mc2DSBGEnt].Count;
                            //    ////ed.WriteMessage($"\nHide's BG num : {numBG}");
                            //    //foreach (McadFolder folder in hideSitu.Subents[McadHideSituationSubentType.mc2DSBGEnt])
                            //    //{
                            //    //    //foreach (var comItem in folder.Entities)
                            //    //    //{
                            //    //    //    AXDBLib.AcadEntity comEnt = acDoc.ObjectIdToObject(comItem);
                            //    //    //    ed.WriteMessage($"\nType : {comEnt.GetType().Name}");
                            //    //    //}

                            //    //    foreach (var comItem in folder.Entities)
                            //    //    {
                            //    //        AXDBLib.AcadEntity comEnt = acDoc.ObjectIdToObject(comItem);

                            //    //        var foundTuple = comMap.FirstOrDefault(eri => eri.Item1 == comEnt);

                            //    //        if (foundTuple != null)
                            //    //        {
                            //    //            cHideSitu.AddMSSubent(foundTuple.Item2, McadHideSituationSubentType.mc2DSBGEnt);
                            //    //            int index = comMap.IndexOf(foundTuple);
                            //    //            comMap.RemoveAt(index);
                            //    //            Tuple<AXDBLib.AcadEntity, AXDBLib.AcadEntity, bool> newTup =
                            //    //                new Tuple<AXDBLib.AcadEntity, AXDBLib.AcadEntity, bool>(comEnt, foundTuple.Item2, true);
                            //    //            comMap.Insert(index, newTup);
                            //    //        }
                            //    //        else
                            //    //        {
                            //    //            ed.WriteMessage("\n(BG)Tuple cannot be found!");
                            //    //        }
                            //    //        //ed.WriteMessage($"\nType : {comEnt.GetType().Name}");
                            //    //    }
                            //    //}
                            //}

                        }
                    }
                }

                retVal = true;

                #region [OldCodes]
                //int countVal = 0;
                //int[] intArr = (int[])referredToAs;

                ////Iterate each selection 
                //foreach (McadHideSituation hideSitu in hideSituations)
                //{
                //    hideSitu.Copy();
                //    int bgIndex = intArr[countVal];
                //    McadHideSituationSubentType style;
                //    if (bgIndex == 1)
                //    {
                //        style = McadHideSituationSubentType.mc2DSFGEnt;
                //    }
                //    else
                //    {
                //        style = McadHideSituationSubentType.mc2DSBGEnt;
                //    }


                //    //hideSitu.AddMSSubent(comEntTo, style);

                //    countVal += 1;
                //}

                //////errMsg = "\nHide situation is too difficult.";
                ////Document doc = CommonCommands.doc();
                ////Editor ed = doc.Editor;
                #endregion
            }
            catch (System.Exception ex)
            {
                errMsg = ex.Message;
                return retVal;
            }
            #endregion

            return retVal;
        }

        //Subfunction for common usage:
        private void MoveByDisDir(DisplacementDir disDir)
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            try
            {
                //Start main transaction.
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    PromptSelectionOptions pso = new PromptSelectionOptions()
                    {
                        MessageForAdding = "\nSelect entities to add: ",
                        MessageForRemoval = "\nSelect entities to remove: ",
                        RejectObjectsOnLockedLayers = true,
                    };

                    //Ask user to get select on screen:
                    PromptSelectionResult selRes = ed.GetSelection(pso);
                    if (selRes.Status != PromptStatus.OK ||
                        selRes.Value.Count == 0)
                    {
                        ed.WriteMessage("\nYou selected nothing!");
                        tr.Abort();
                        return;
                    }
                    else
                    {
                        // + Use auto highlight
                        // + Use auto reset 'ORTHOMODE'
                        List<KeyValuePair<string, object>> resetList = new List<KeyValuePair<string, object>>()
                        {
                            new KeyValuePair<string, object>("ORTHOMODE",0),
                            new KeyValuePair<string, object>("CMDECHO",0)
                        };
                        using (KRUnhighlight myUnhighlight = new KRUnhighlight())
                        using (KRResetSystemVar myReset = new KRResetSystemVar(resetList))
                        {
                            //Create new jig:
                            MoveByDrawJig moveJig = new MoveByDrawJig(Point3d.Origin, disDir);

                            //Iterate Selection Set to highlight:
                            foreach (ObjectId id in selRes.Value.GetObjectIds())
                            {
                                Entity ent = (Entity)tr.GetObject(id, OpenMode.ForWrite);
                                if (ent != null)
                                {
                                    // --- Solution 1:
                                    //Highlight entity:
                                    ent.Highlight();
                                    myUnhighlight.Add(ent.ObjectId);

                                    ////Highlight entity with style:
                                    //FullSubentityPath path = new FullSubentityPath(new ObjectId[] { ent.ObjectId },
                                    //    new SubentityId(SubentityType.Null, IntPtr.Zero));
                                    //ent.PushHighlight(path, HighlightStyle.Custom);
                                    //myUnhighlight.Add(ent.ObjectId);

                                    //Add entity to Jig:
                                    moveJig.AddEntity(ent);
                                }
                            }

                            #region [Get base point & copy mode]
                            PromptPointOptions ppo = new PromptPointOptions("\nBase point: ");
                            if (disDir == DisplacementDir.F)
                            {
                                ppo.Keywords.Add("X");
                                ppo.Keywords.Add("Y");
                                ppo.Keywords.Add("Reference");
                            }
                            ppo.AllowNone = false;
                            ppo.BasePoint = Point3d.Origin;
                            ppo.UseBasePoint = true;
                            ppo.AllowArbitraryInput = false;

                            //Vector for direction(Only used for reference mode):
                            Vector3d dirVector = default;

                            //base point:
                            Point3d pt;
                            PromptPointResult ppr = ed.GetPoint(ppo);
                            if (ppr.Status == PromptStatus.OK)
                            {
                                pt = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
                            }
                            else if (ppr.Status == PromptStatus.Keyword)
                            {
                                #region [Old codes]
                                //PromptEntityOptions peo = new PromptEntityOptions("\nSelect curve: ");
                                //peo.Keywords.Add("Points");
                                //peo.AllowNone = false;
                                //peo.SetRejectMessage("\nInvalid selection. Please select curve !");
                                //peo.AddAllowedClass(typeof(Curve), false);

                                ////Prompt result :
                                //PromptEntityResult per = ed.GetEntity(peo);
                                //if (per.Status != PromptStatus.OK && per.Status != PromptStatus.Keyword)
                                //{
                                //    tr.Abort();
                                //    return;
                                //}
                                //else if (per.Status == PromptStatus.OK)
                                //{
                                //    //Open curve for write :
                                //    Curve boCurv = (Curve)tr.GetObject(per.ObjectId, OpenMode.ForRead);

                                //    //Get direction vector:
                                //    try
                                //    {
                                //        Point3d pickedPnt = per.PickedPoint.TransformBy(ed.CurrentUserCoordinateSystem);
                                //        Point3d cloPnt = boCurv.GetClosestPointTo(pickedPnt, true);
                                //        dirVector = boCurv.GetFirstDerivative(cloPnt);
                                //        moveJig.DirVector = dirVector;
                                //        pt = cloPnt;
                                //    }
                                //    catch (System.Exception ex)
                                //    {
                                //        ed.WriteMessage(ex.Message);
                                //        tr.Abort();
                                //        return;
                                //    }
                                //}
                                //else
                                //{
                                //    pt = new Point3d();
                                //    if (KRGetPoint(ed, "\nFirst point: ", Point3d.Origin, ref pt) != PromptStatus.OK)
                                //    {
                                //        tr.Abort();
                                //        return;
                                //    }
                                //    else
                                //    {
                                //        Point3d pt2 = new Point3d();
                                //        if (KRGetPoint(ed, "\nSecond point: ", pt , ref pt2) != PromptStatus.OK)
                                //        {
                                //            tr.Abort();
                                //            return;
                                //        }
                                //        else
                                //        {
                                //            dirVector = pt.GetVectorTo(pt2);
                                //            moveJig.DirVector = dirVector;
                                //            pt = pt.TransformBy(ed.CurrentUserCoordinateSystem);
                                //        }
                                //    }
                                //}
                                #endregion
                                if (ppr.StringResult == "Reference")
                                {
                                    pt = new Point3d();
                                    if (KRGetPoint(ed, "\nFirst point: ", Point3d.Origin, ref pt) != PromptStatus.OK)
                                    {
                                        tr.Abort();
                                        return;
                                    }
                                    else
                                    {
                                        Point3d pt2 = new Point3d();
                                        if (KRGetPoint(ed, "\nSecond point: ", pt, ref pt2) != PromptStatus.OK)
                                        {
                                            tr.Abort();
                                            return;
                                        }
                                        else
                                        {
                                            pt = pt.TransformBy(ed.CurrentUserCoordinateSystem);
                                            pt2 = pt2.TransformBy(ed.CurrentUserCoordinateSystem);
                                            dirVector = pt.GetVectorTo(pt2);
                                            moveJig.DirVector = dirVector;
                                        }
                                    }
                                }
                                else
                                {
                                    if (ppr.StringResult == "X")
                                    {
                                        moveJig.DisplacementType = DisplacementDir.X;
                                    }
                                    else
                                    {
                                        moveJig.DisplacementType = DisplacementDir.Y;
                                    }

                                    ppo.Keywords.Clear();

                                    ppr = ed.GetPoint(ppo);
                                    if (ppr.Status != PromptStatus.OK)
                                    {
                                        tr.Abort();
                                        return;
                                    }

                                    pt = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
                                }
                            }
                            else
                            {
                                tr.Abort();
                                return;
                            }
                            #endregion

                            //Reset Jig's basepoint:
                            moveJig.BasePoint = pt;

                            PromptResult jigRes;

                            //For copy mode:
                            bool isCopyMode = false;

                            //Change UCS when in need:
                            if (dirVector != default)
                            {
                                #region [Solution 1 - on hold]
                                ////https://forums.autodesk.com/t5/autocad-forum/change-ucs-zaxis-in-net/m-p/4658535#M96357

                                //Get current UCS:
                                Matrix3d curUcs = ed.CurrentUserCoordinateSystem;

                                //Get current coordinate system:
                                CoordinateSystem3d coor3d = curUcs.CoordinateSystem3d;

                                Plane plane = new Plane(pt, coor3d.Xaxis, coor3d.Yaxis);

                                //Get rotation angle:
                                double rotAng = dirVector.AngleOnPlane(plane) + UcsWcsAngle();

                                //Get rotated UCS:
                                Matrix3d rotUcs = Matrix3d.Rotation(rotAng, coor3d.Zaxis, pt);

                                //Change UCS:
                                ed.CurrentUserCoordinateSystem = rotUcs;
                                #endregion

                                #region [Solution 2 - on hold]
                                ////Get current UCS:
                                //Matrix3d curUcs = ed.CurrentUserCoordinateSystem;

                                //// Open the UCS table for read
                                //Database db = doc.Database;

                                ////Get UCS table:
                                //UcsTable acUCSTbl = tr.GetObject(db.UcsTableId, OpenMode.ForRead) as UcsTable;

                                ////Variable for new UCS record:
                                //UcsTableRecord acUCSTblRec;

                                //// Check to see if the "New_UCS" UCS table record exists
                                //string tempUCSname = "KMove_UCS";
                                //if (acUCSTbl.Has(tempUCSname) == false)
                                //{
                                //    acUCSTblRec = new UcsTableRecord();
                                //    acUCSTblRec.Name = tempUCSname;

                                //    // Open the UCSTable for write
                                //    tr.GetObject(db.UcsTableId, OpenMode.ForWrite);

                                //    // Add the new UCS table record
                                //    acUCSTbl.Add(acUCSTblRec);
                                //    tr.AddNewlyCreatedDBObject(acUCSTblRec, true);
                                //}
                                //else
                                //{
                                //    acUCSTblRec = tr.GetObject(acUCSTbl[tempUCSname],
                                //                                    OpenMode.ForWrite) as UcsTableRecord;
                                //}

                                //acUCSTblRec.Origin = pt.TransformBy(ed.CurrentUserCoordinateSystem.Inverse());
                                //acUCSTblRec.XAxis = dirVector;
                                //acUCSTblRec.YAxis = dirVector.GetPerpendicularVector();

                                //// Open the active viewport
                                //ViewportTableRecord acVportTblRec;
                                //acVportTblRec = tr.GetObject(ed.ActiveViewportId,
                                //                                    OpenMode.ForWrite) as ViewportTableRecord;

                                //// Display the UCS Icon at the origin of the current viewport
                                //acVportTblRec.IconAtOrigin = true;
                                //acVportTblRec.IconEnabled = true;

                                //// Set the UCS current
                                //acVportTblRec.SetUcs(acUCSTblRec.ObjectId);
                                //ed.UpdateTiledViewportsFromDatabase();
                                #endregion

                                //Start to drag-loop:
                                jigRes = ed.Drag(moveJig);
                                if (jigRes.Status == PromptStatus.OK)
                                {
                                    //Check control key is pressed:
                                    System.Windows.Forms.Keys mods = System.Windows.Forms.Control.ModifierKeys;
                                    isCopyMode = (mods & System.Windows.Forms.Keys.Control) > 0;

                                    if (isCopyMode)
                                    {
                                        //Transform entites:
                                        moveJig.CloneAndTransform(tr);

                                        //Commit changes:
                                        tr.Commit();

                                        jigRes = ed.Drag(moveJig);
                                        while (jigRes.Status == PromptStatus.OK)
                                        {
                                            using (Transaction subTr = db.TransactionManager.StartTransaction())
                                            {
                                                //Transform entites:
                                                moveJig.CloneAndTransform(subTr);

                                                subTr.Commit();
                                            }

                                            jigRes = ed.Drag(moveJig);
                                        }
                                    }
                                    else
                                    {
                                        //Transform entites:
                                        moveJig.TransformEntities(tr);

                                        //Commit changes:
                                        tr.Commit();
                                    }

                                    //Return UCS:
                                    ed.CurrentUserCoordinateSystem = curUcs;
                                    //acUCSTblRec.Erase();//For solution 2 only
                                }
                                else
                                {
                                    tr.Abort();
                                    return;
                                }
                            }
                            else
                            {
                                //Start to drag-loop:
                                jigRes = ed.Drag(moveJig);
                                if (jigRes.Status == PromptStatus.OK)
                                {
                                    //Check control key is pressed:
                                    System.Windows.Forms.Keys mods = System.Windows.Forms.Control.ModifierKeys;
                                    isCopyMode = (mods & System.Windows.Forms.Keys.Control) > 0;

                                    if (isCopyMode)
                                    {
                                        //Transform entites:
                                        moveJig.CloneAndTransform(tr);

                                        //Commit changes:
                                        tr.Commit();

                                        jigRes = ed.Drag(moveJig);
                                        while (jigRes.Status == PromptStatus.OK)
                                        {
                                            using (Transaction subTr = db.TransactionManager.StartTransaction())
                                            {
                                                //Transform entites:
                                                moveJig.CloneAndTransform(subTr);

                                                subTr.Commit();
                                            }

                                            jigRes = ed.Drag(moveJig);
                                        }
                                    }
                                    else
                                    {
                                        //Transform entites:
                                        moveJig.TransformEntities(tr);

                                        //Commit changes:
                                        tr.Commit();
                                    }
                                }
                                else
                                {
                                    tr.Abort();
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        //Subfunction for common usage(Move + clone):
        private void MoveAndCloneByDisDir(DisplacementDir disDir)
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;

            ////Start main loop:
            //while (true)
            //{
            try
            {
                //Start main transaction.
                using (Transaction tr = doc.TransactionManager.StartTransaction())
                {
                    PromptSelectionOptions pso = new PromptSelectionOptions()
                    {
                        MessageForAdding = "\nSelect entities to add: ",
                        MessageForRemoval = "\nSelect entities to remove: ",
                    };

                    //Ask user to get select on screen:
                    PromptSelectionResult selRes = ed.GetSelection(pso);
                    if (selRes.Status != PromptStatus.OK ||
                        selRes.Value.Count == 0)
                    {
                        ed.WriteMessage("\nYou selected nothing!");
                        tr.Abort();
                        return;
                    }
                    else
                    {
                        // + Use auto highlight
                        // + Use auto reset 'ORTHOMODE'
                        List<KeyValuePair<string, object>> resetList = new List<KeyValuePair<string, object>>()
                        {
                            new KeyValuePair<string, object>("ORTHOMODE",0),
                            new KeyValuePair<string, object>("CMDECHO",0)
                        };
                        using (KRUnhighlight myUnhighlight = new KRUnhighlight())
                        using (KRResetSystemVar myReset = new KRResetSystemVar(resetList))
                        #region [Bak]
                        //using (KRResetSystemVar myResetOrtho = new KRResetSystemVar("ORTHOMODE",0))
                        //using (KRResetSystemVar myResetCMD = new KRResetSystemVar("CMDECHO", 0))
                        //using (KRResetSystemVar myResetCmd = new KRResetSystemVar("CMDECHO", 0))
                        //using (KRResetSystemVar myResetSSEffect = new KRResetSystemVar("SELECTIONEFFECT",
                        //                                            SelectionColorIndex.SelectionEffect))
                        //using (KRResetSystemVar myResetSSEffectColor = new KRResetSystemVar("SELECTIONEFFECTCOLOR",
                        //                                            SelectionColorIndex.PositionTransform))
                        #endregion
                        {
                            //Create new jig:
                            MoveByDrawJig moveJig = new MoveByDrawJig(Point3d.Origin, disDir);

                            //Initualize hide situation numbers:
                            int hideSituNum = -1;

                            #region [Com variables]
                            AcadApplication acApp;
                            AcadmApplication acMApp;
                            AcadDocument acDoc;
                            IMcad2DStructureMgr mgr;
                            IMcadUtility acmUti;
                            McadFolderDefinition rootDef;
                            #endregion

                            //Check cad is mechanical or not:
                            //In case mechanical get COM's interface:
                            bool IsMechanical = IsCadMechanical.Status();
                            if (IsMechanical)
                            {
                                //Get acad interface:
                                acApp = (AcadApplication)AcAp.AcadApplication;
                                if (acApp == null)
                                {
                                    ed.WriteMessage("\nCannot get acad's COM interface!");
                                    return;
                                }

                                //Get mechanical interface:
                                acMApp = acApp.GetInterfaceObject("AcadmAuto.AcadmApplication");
                                if (acMApp == null)
                                {
                                    ed.WriteMessage("\nCannot get acad Mechanical's COM interface!");
                                    return;
                                }

                                //Get document interface:
                                acDoc = acApp.ActiveDocument;
                                if (acDoc == null)
                                {
                                    ed.WriteMessage("\nCannot get document's COM interface!");
                                    return;
                                }

                                //Get structures:
                                mgr = acMApp.ActiveDocument.StructureMgr2D;
                                if (mgr == null)
                                {
                                    ed.WriteMessage("\nCannot get structure's COM interface!");
                                    return;
                                }

                                //Get mechanical utility:
                                acmUti = acMApp.ActiveDocument.Utility;
                                if (acmUti == null)
                                {
                                    ed.WriteMessage("\nCannot get mechanical utility's COM interface!");
                                    return;
                                }

                                //acmUti.CreateCollection(McadCollectionType.mcHideSituations);

                                //Get root definition:
                                try
                                {
                                    rootDef = mgr.RootViewDefinition[acDoc.Database];
                                    if (rootDef == null)
                                    {
                                        ed.WriteMessage("\nCannot get root view definition!");
                                        return;
                                    }
                                    else
                                    {
                                        hideSituNum = rootDef.HideSituations.Count;
                                    }

                                }
                                catch (System.Exception)
                                {
                                    hideSituNum = 0;
                                    rootDef = null;
                                }
                            }
                            else
                            {
                                acApp = null;
                                acMApp = null;
                                acDoc = null;
                                mgr = null;
                                acmUti = null;
                                rootDef = null;
                            }

                            //Iterate Selection Set to highlight:
                            //Also check for selection set contain any 'Hide situation'
                            ObjectIdCollection hasHideObjIds = new ObjectIdCollection();//Contains ObjectIds has hide only
                            foreach (ObjectId id in selRes.Value.GetObjectIds())
                            {
                                #region [Old codes]
                                //if (id != ObjectId.Null)
                                //{
                                //    Entity ent = (Entity)tr.GetObject(id, OpenMode.ForWrite);
                                //    if (ent != null)
                                //    {
                                //        //Highlight entity with style:
                                //        FullSubentityPath path = new FullSubentityPath(new ObjectId[] { ent.ObjectId },
                                //            new SubentityId(SubentityType.Null, IntPtr.Zero));
                                //        ent.PushHighlight(path, HighlightStyle.DashedAndThicken | HighlightStyle.Glow);
                                //        myUnhighlight.Add(ent.ObjectId);

                                //        //Add entity to Jig:
                                //        moveJig.AddEntity(ent);
                                //    }
                                //}
                                #endregion
                                Entity ent = (Entity)tr.GetObject(id, OpenMode.ForWrite);
                                if (ent != null)
                                {
                                    ////Highlight entity with style:
                                    //FullSubentityPath path = new FullSubentityPath(new ObjectId[] { ent.ObjectId },
                                    //    new SubentityId(SubentityType.Null, IntPtr.Zero));
                                    //ent.PushHighlight(path, HighlightStyle.DashedAndThicken | HighlightStyle.Glow);

                                    ent.Highlight();
                                    myUnhighlight.Add(ent.ObjectId);

                                    //Add entity to Jig:
                                    moveJig.AddEntity(ent);

                                    //Add ObjectId which has hide situation to collection:
                                    if (mgr != null && hideSituNum > 0)
                                    {
                                        if (HasHideSituation(mgr, ent))
                                        {
                                            hasHideObjIds.Add(ent.ObjectId);
                                        }
                                    }
                                }
                            }

                            #region [Get base point & copy mode]

                            #region [Old codes]
                            //Point3d pt = new Point3d();

                            ////Prompt option:
                            //if (KRGetPoint(ed, "\nBase point: ", Point3d.Origin, ref pt) != PromptStatus.OK)
                            //{
                            //    tr.Abort();
                            //    return;
                            //}
                            //else
                            //    pt = pt.TransformBy(ed.CurrentUserCoordinateSystem);
                            #endregion
                            bool isCopyMode = false;
                            PromptPointOptions ppo = new PromptPointOptions("\nBase point: ");
                            ppo.Keywords.Add("Copy");
                            ppo.AllowNone = false;
                            ppo.BasePoint = Point3d.Origin;
                            ppo.UseBasePoint = true;
                            ppo.AllowArbitraryInput = false;

                            Point3d pt;
                            PromptPointResult ppr = ed.GetPoint(ppo);
                            if (ppr.Status == PromptStatus.OK)
                            {
                                pt = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
                            }
                            else if (ppr.Status == PromptStatus.Keyword)
                            {
                                //Prompt option:
                                pt = new Point3d();
                                if (KRGetPoint(ed, "\nBase point: ", Point3d.Origin, ref pt) != PromptStatus.OK)
                                {
                                    tr.Abort();
                                    return;
                                }
                                else
                                {
                                    pt = pt.TransformBy(ed.CurrentUserCoordinateSystem);
                                    isCopyMode = true;
                                }
                            }
                            else
                            {
                                tr.Abort();
                                return;
                            }
                            #endregion

                            //Reset Jig's basepoint:
                            moveJig.BasePoint = pt;

                            //Start to drag-loop:
                            PromptResult jigRes = ed.Drag(moveJig);
                            if (jigRes.Status == PromptStatus.OK)
                            {
                                //Transform entites (inlude commit changes):
                                moveJig.TransformEntities(out bool isDone, isCopyMode, tr);

                                tr.Commit();

                                //Clone hide situation:
                                #region [Clone hide situation]
                                // - Check isDone:
                                // - Compare return map & hasHideObjIds
                                //   => list of objectids with hide connection.
                                // - Create new hide situation reflect this connection.
                                // - Add map ids to this hide situation.

                                if (hasHideObjIds.Count > 0 && isDone == false)
                                {
                                    //https://forums.autodesk.com/t5/net/unable-to-find-an-entry-point-in-dll-acad-exe/m-p/5522036/highlight/true#M43404
                                    //https://www.autodesk.com/autodesk-university/class/Bridging-Gap-Extending-AutoLISP-NET-2021#downloads
                                    #region [Old codes]
                                    //foreach (ObjectId id in hasHideObjIds)
                                    //{
                                    //    if (moveJig.IdMap.Contains(id))
                                    //    {

                                    //        KeyValuePair<ObjectId, ObjectId> idMap =
                                    //            new KeyValuePair<ObjectId, ObjectId>(id, moveJig.IdMap[id].Value);
                                    //        McadHideSituation hideSitu = SearchForHide(acDoc, mgr, rootDef, acmUti,
                                    //        idMap, out string errMsg);
                                    //        if (hideSitu == null)
                                    //        {
                                    //            ed.WriteMessage("\nCannot clone hide situation.");
                                    //            ed.WriteMessage(errMsg);
                                    //            return;
                                    //        }
                                    //        else
                                    //        {
                                    //            ed.WriteMessage("\nDoneEEEEEEE!");
                                    //            //ed.WriteMessage($"\nHide bgname : {hideSitu.BgSelectionName}");
                                    //            //McadHideSituation cloneSitua = hideSitu.Copy();
                                    //        }
                                    //    }
                                    //}
                                    #endregion

                                    #region [Solution1 - on building]
                                    //if (!CloneHideSituation(acDoc,mgr,rootDef,
                                    //    acmUti,hasHideObjIds,moveJig.IdMap,out string errMsg))
                                    //{
                                    //    ed.WriteMessage("\nCannot clone hide situation.");
                                    //    ed.WriteMessage(errMsg);
                                    //}
                                    #endregion

                                    #region [Solution2 - on testing]
                                    //ResultBuffer args = new ResultBuffer(
                                    //    new TypedValue((int)LispDataType.Text, "CloneHideSitua"),

                                    //    new TypedValue((int)LispDataType.ListBegin),
                                    //    new TypedValue((int)LispDataType.Double,0.0),
                                    //    new TypedValue((int)LispDataType.Double, 0.0),
                                    //    new TypedValue((int)LispDataType.Double, 0.0),
                                    //    new TypedValue((int)LispDataType.ListEnd),

                                    //    new TypedValue((int)LispDataType.ListBegin),
                                    //    new TypedValue((int)LispDataType.Double, 50.0),
                                    //    new TypedValue((int)LispDataType.Double, 25.0),
                                    //    new TypedValue((int)LispDataType.Double, 0.0),
                                    //    new TypedValue((int)LispDataType.ListEnd)
                                    //);


                                    ////Call the Lisp function:
                                    //try
                                    //{
                                    //    //With getting return value:
                                    //    //ResultBuffer result = Application.Invoke(args);

                                    //    //Without getting return value:
                                    //    AcAp.Invoke(args);
                                    //}
                                    //catch (System.Exception ex)
                                    //{
                                    //    ed.WriteMessage(ex.Message);
                                    //    return;
                                    //}
                                    #endregion

                                    #region [Solution3 - on running]
                                    if (hasHideObjIds.Count == 1)
                                    {
                                        ed.WriteMessage($"\n{hasHideObjIds.Count} hide situation has been removed!");
                                    }
                                    else
                                    {
                                        ed.WriteMessage($"\n{hasHideObjIds.Count} hide situations has been removed!");
                                    }
                                    #endregion
                                }
                                #endregion

                                //Loop for copy:
                                while (!isDone)
                                {
                                    using (Transaction subTrans = doc.TransactionManager.StartTransaction())
                                    {
                                        jigRes = ed.Drag(moveJig);
                                        if (jigRes.Status == PromptStatus.OK)
                                        {
                                            //Transform entites(include commit changes):
                                            moveJig.TransformEntities(out isDone, isCopyMode, subTrans);

                                            subTrans.Commit();

                                            if (hasHideObjIds.Count > 0 && isDone == false)
                                            {
                                                if (hasHideObjIds.Count == 1)
                                                {
                                                    ed.WriteMessage($"\n{hasHideObjIds.Count} hide situation has been removed!");
                                                }
                                                else
                                                {
                                                    ed.WriteMessage($"\n{hasHideObjIds.Count} hide situations has been removed!");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            subTrans.Abort();
                                            return;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                tr.Abort();
                                return;
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
            //}
        }

        ////Command to clone entities by X (Using Jig):
        //[CommandMethod("KK", CommandFlags.UsePickSet)]
        //public void CmdKK()
        //{
        //    MoveAndCloneByDisDir(DisplacementDir.F);
        //}

        //Command to move entities by X (Using Jig):
        [CommandMethod("KH", CommandFlags.UsePickSet)]
        public void CmdKH()
        {
            MoveByDisDir(DisplacementDir.X);
        }

        //Command to move entities by Y (Using Jig):
        [CommandMethod("KV", CommandFlags.UsePickSet)]
        public void CmdKV()
        {
            MoveByDisDir(DisplacementDir.Y);
        }

        //Command to move entities by free (Using Jig):
        [CommandMethod("K", CommandFlags.UsePickSet)]
        public void CmdK()
        {
            MoveByDisDir(DisplacementDir.F);
        }
        #endregion

        #region [Nhóm lệnh Array/ Copy dùng Jig]
        private void ArrayBy2Points(bool isAssoc)
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            try
            {
                //Ask user to get select on screen:
                PromptSelectionOptions pso = new PromptSelectionOptions()
                {
                    RejectObjectsOnLockedLayers = true
                };

                PromptSelectionResult selRes = ed.GetSelection(pso);
                if (selRes.Status != PromptStatus.OK ||
                    selRes.Value.Count == 0)
                {
                    ed.WriteMessage("\nYou selected nothing!");
                    return;
                }

                #region [Get number of array's members]
                int numArr;//Variable for number of pitch amount

                PromptIntegerOptions pio = new PromptIntegerOptions("\nPitch's amount: ")
                {
                    AllowZero = false,
                    AllowNegative = false,
                    AllowArbitraryInput = false,
                    LowerLimit = 2 //Minimum is 2 pitch
                };

                PromptIntegerResult pir = ed.GetInteger(pio);
                if (pir.Status != PromptStatus.OK)
                    return;
                else
                    numArr = pir.Value;
                #endregion

                #region [Get start point]
                //Start point:
                Point3d startPnt = new Point3d();

                //Prompt option:
                if (KRGetPoint(ed, "\nStart point: ", Point3d.Origin, ref startPnt) != PromptStatus.OK)
                    return;
                else
                    startPnt = startPnt.TransformBy(ed.CurrentUserCoordinateSystem);
                #endregion

                //Start main transaction:
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Create new jig:
                    ArrayEntsBy2Pnt arrJig = new ArrayEntsBy2Pnt(tr, startPnt, numArr);

                    //Iterate Selection Set then add members to jig:
                    foreach (ObjectId id in selRes.Value.GetObjectIds())
                    {
                        if (id != ObjectId.Null)
                        {
                            Entity ent = (Entity)tr.GetObject(id, OpenMode.ForWrite);
                            arrJig.AddEntity(ent);
                        }
                    }

                    //Start to drag-loop:
                    PromptResult jigRes = ed.Drag(arrJig);
                    if (jigRes.Status == PromptStatus.OK)
                    {
                        PromptKeywordOptions pkw = new PromptKeywordOptions("\nHas object at last vertex?");
                        pkw.Keywords.Add("Yes");
                        pkw.Keywords.Add("No");
                        pkw.Keywords.Default = "No";

                        PromptResult pr = ed.GetKeywords(pkw);
                        if (pr.Status != PromptStatus.OK)
                        {
                            tr.Abort();
                        }
                        else
                        {
                            switch (pr.StringResult)
                            {
                                case "Yes":
                                    if (isAssoc)
                                    {
                                        arrJig.AssoArrayMembers(tr, true);
                                    }
                                    else
                                    {
                                        arrJig.NonAssoArrayMembers(true);
                                    }
                                    break;

                                case "No":
                                    if (isAssoc)
                                    {
                                        arrJig.AssoArrayMembers(tr, false);
                                    }
                                    else
                                    {
                                        arrJig.NonAssoArrayMembers(false);
                                    }
                                    break;

                                default:
                                    ed.WriteMessage("\nCannot get array's type!");
                                    break;
                            }

                            //arrJig.ArrayMembers();
                            tr.Commit();
                        }
                    }
                    else
                        tr.Abort();
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        //Non-associative array: 
        [CommandMethod("Arr2", CommandFlags.UsePickSet)]
        public void CmdArr2()
        {
            ArrayBy2Points(false);
        }

        //Associative array:
        [CommandMethod("Arr2A", CommandFlags.UsePickSet)]
        public void CmdArrc2A()
        {
            ArrayBy2Points(true);
        }

        #endregion

        #region [Nhóm lệnh Dim Jig]
        //Deprecated. Use DMAN instead:
        private void CmdDman_Test()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            #region [Get start point]
            Point3d startPnt = new Point3d();
            if (KRGetPoint(ed, "\nStart point: ", Point3d.Origin, ref startPnt) != PromptStatus.OK)
            {
                ed.WriteMessage("\nCannot get start point!");
                return;
            }
            #endregion

            #region [Get end point]
            Point3d endPnt = new Point3d();
            if (KRGetPoint(ed, "\nEnd point: ", startPnt, ref endPnt) != PromptStatus.OK)
            {
                ed.WriteMessage("\nCannot get end point!");
                return;
            }
            #endregion

            #region [Transform point WCS->UCS]
            startPnt = startPnt.TransformBy(ed.CurrentUserCoordinateSystem);
            endPnt = endPnt.TransformBy(ed.CurrentUserCoordinateSystem);
            #endregion

            try
            {
                using (AlignedDimension alDim = new AlignedDimension())
                {
                    alDim.XLine1Point = startPnt;
                    alDim.XLine2Point = endPnt;
                    alDim.Layer = KRLayer.Scale;

                    //alDim.TransformBy(ed.CurrentUserCoordinateSystem);
                    ObliqueDimJig obDimJig = new ObliqueDimJig(alDim, "\nLocation: ");
                    PromptResult pr = ed.Drag(obDimJig);
                    if (pr.Status == PromptStatus.OK)
                    {
                        using (Transaction tr = db.TransactionManager.StartTransaction())
                        {
                            //Add Xline to database:
                            AppendEnt(tr, obDimJig.JigEntity);

                            //Commit changes:
                            tr.Commit();
                        }
                    }
                    else
                    {
                        return;
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.ToString());
                return;
            }
        }

        //Lệnh vẽ Aligned dimension + oblique angle using Jig:
        [CommandMethod("DMAN")]
        public void CmdDman()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            #region [Get start point]
            Point3d startPnt = new Point3d();
            if (KRGetPoint(ed, "\nStart point: ", Point3d.Origin, ref startPnt) != PromptStatus.OK)
            {
                ed.WriteMessage("\nCannot get start point!");
                return;
            }
            else
                startPnt = startPnt.TransformBy(ed.CurrentUserCoordinateSystem);
            #endregion

            try
            {
                Point3d lastEndPnt = new Point3d(); //Last end point of aligned dimension
                Point3d lastObPnt = new Point3d();  //Last oblique point of aligned dimension

                double dimScale = 1.0;
                bool isInModel = IsInModel();
                bool isInLayout = IsInLayout();
                bool isInLayoutPaper = IsInLayoutPaper();
                bool isInLayoutVPort = IsInLayoutViewport();

                if (isInModel == true ||
                    (isInModel == false && isInLayout == true && isInLayoutPaper == false && isInLayoutVPort == true))
                {
                    dimScale = ToDouble(GetSystemVariable("DIMSCALE"));
                }

                //ed.WriteMessage($"\nIsInModel : {IsInModel()}");
                //ed.WriteMessage($"\nIsInLayout : {IsInLayout()}");
                //ed.WriteMessage($"\nIsInLayoutPaper : {IsInLayoutPaper()}");
                //ed.WriteMessage($"\nIsInLayoutVP : {IsInLayoutViewport()}");

                //Check layer :
                string layerName = "0";
                if (!KRCADLayer.HasLayer(KRCADLayer.LayerScale.Item1))
                {
                    if (!KRCADLayer.CreateLayer(KRCADLayer.LayerScale))
                    {
                        ed.WriteMessage($"\nCannot create '{KRCADLayer.LayerScale.Item1}' layer. Use '0' layer instead !");
                        layerName = "0";
                    }
                    else
                    {
                        layerName = KRCADLayer.LayerScale.Item1;
                    }
                }
                else
                {
                    layerName = KRCADLayer.LayerScale.Item1;
                }

                //Check dim style :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Check dim style :
                    DimStyleTable dimStyleTb = tr.GetObject(db.DimStyleTableId, OpenMode.ForRead) as DimStyleTable;
                    if (!dimStyleTb.Has(KRCADDimStyle.KRDimStyleName))
                    {
                        if (!KRCADDimStyle.ImportDimStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADDimStyle.KRDimStyleName))
                        {
                            ed.WriteMessage($"\nCannot import {KRCADDimStyle.KRDimStyleName}. Command ended!");
                            tr.Abort();
                            return;
                        }
                    }

                    //Activate dim style :
                    DimStyleTableRecord dimStyleTbRc = tr.GetObject(dimStyleTb[KRCADDimStyle.KRDimStyleName], OpenMode.ForRead) as DimStyleTableRecord;
                    if (db.Dimstyle != dimStyleTbRc.ObjectId)
                    {
                        db.Dimstyle = dimStyleTbRc.ObjectId;
                        db.SetDimstyleData(dimStyleTbRc);
                    }

                    tr.Commit();
                }

                using (KRResetSystemVar myResetDIMTMOVE = new KRResetSystemVar("DIMTMOVE", 0))
                using (KRResetSystemVar myResetDIMSCALE = new KRResetSystemVar("DIMSCALE", dimScale))
                {
                    //Create first Oblique dimension:
                    using (AlignedDimension alDim = new AlignedDimension())
                    {
                        alDim.XLine1Point = startPnt;
                        alDim.Layer = layerName;

                        //Create new jig for align dimension:
                        AlignDimJig alDimJig = new AlignDimJig(alDim, "\nEnd point: ");
                        PromptResult pr = ed.Drag(alDimJig);
                        if (pr.Status == PromptStatus.OK)
                        {
                            //Create new jig for change oblique angle of align dimension:
                            AlignDimObJig alDimObJig = new AlignDimObJig(alDim, "\nLocation: ");
                            pr = ed.Drag(alDimObJig);
                            if (pr.Status == PromptStatus.OK || pr.Status == PromptStatus.Keyword)
                            {
                                lastEndPnt = (alDimObJig.JigEntity as AlignedDimension).XLine2Point;
                                lastObPnt = alDimObJig.LastObliquePoint;

                                using (Transaction tr = db.TransactionManager.StartTransaction())
                                {
                                    //Add Xline to database:
                                    AppendEnt(tr, alDimObJig.JigEntity);

                                    //Commit changes:
                                    tr.Commit();

                                    //Update graphic:
                                    tr.TransactionManager.QueueForGraphicsFlush();
                                }
                            }
                            else
                                return;
                        }
                        else
                        {
                            return;
                        }
                    }

                    //Start loop for chain dimensioning:
                    while (true)
                    {
                        startPnt = lastEndPnt;

                        //Create first Oblique dimension:
                        using (AlignedDimension alDim = new AlignedDimension())
                        {
                            alDim.XLine1Point = startPnt;
                            alDim.Layer = layerName;

                            //Create new jig for align dimension:
                            AlignDimJig alDimJig = new AlignDimJig(alDim, "\nNext point: ", lastObPnt);
                            PromptResult pr = ed.Drag(alDimJig);
                            if (pr.Status == PromptStatus.OK)
                            {
                                lastEndPnt = (alDimJig.JigEntity as AlignedDimension).XLine2Point;
                                lastObPnt = alDimJig.LastObliquePoint();

                                using (Transaction tr = db.TransactionManager.StartTransaction())
                                {
                                    //Add Xline to database:
                                    AppendEnt(tr, alDimJig.JigEntity);

                                    //Commit changes:
                                    tr.Commit();

                                    //Update graphic:
                                    tr.TransactionManager.QueueForGraphicsFlush();
                                }
                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.ToString());
                return;
            }
        }

        //Lệnh kéo kích thước 2 điểm dùng Jig:
        [CommandMethod("D2P")]
        public void CmdD2P()
        {
            Document doc = CommonCommands.doc();
            Database db = doc.Database;
            Editor ed = doc.Editor;

            #region [Get start point]
            Point3d startPnt = new Point3d();
            if (KRGetPoint(ed, "\nStart point: ", Point3d.Origin, ref startPnt) != PromptStatus.OK)
            {
                ed.WriteMessage("\nCannot get start point!");
                return;
            }
            else
                startPnt = startPnt.TransformBy(ed.CurrentUserCoordinateSystem);
            #endregion

            try
            {
                double dimScale = 1.0;
                if (IsInModel())
                {
                    dimScale = ToDouble(GetSystemVariable("DIMSCALE"));
                }

                //Check layer :
                string layerName = "0";
                if (!KRCADLayer.HasLayer(KRCADLayer.LayerScale.Item1))
                {
                    if (!KRCADLayer.CreateLayer(KRCADLayer.LayerScale))
                    {
                        ed.WriteMessage($"\nCannot create '{KRCADLayer.LayerScale.Item1}' layer. Use '0' layer instead !");
                        layerName = "0";
                    }
                    else
                    {
                        layerName = KRCADLayer.LayerScale.Item1;
                    }
                }
                else
                {
                    layerName = KRCADLayer.LayerScale.Item1;
                }

                //Check dim style :
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Check dim style :
                    DimStyleTable dimStyleTb = tr.GetObject(db.DimStyleTableId, OpenMode.ForRead) as DimStyleTable;
                    if (!dimStyleTb.Has(KRCADDimStyle.KRDimStyleName))
                    {
                        if (!KRCADDimStyle.ImportDimStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADDimStyle.KRDimStyleName))
                        {
                            ed.WriteMessage($"\nCannot import {KRCADDimStyle.KRDimStyleName}. Command ended!");
                            tr.Abort();
                            return;
                        }
                    }

                    //Activate dim style :
                    DimStyleTableRecord dimStyleTbRc = tr.GetObject(dimStyleTb[KRCADDimStyle.KRDimStyleName], OpenMode.ForRead) as DimStyleTableRecord;
                    if (db.Dimstyle != dimStyleTbRc.ObjectId)
                    {
                        db.Dimstyle = dimStyleTbRc.ObjectId;
                        db.SetDimstyleData(dimStyleTbRc);
                    }

                    tr.Commit();
                }

                using (KRResetSystemVar myResetDIMTMOVE = new KRResetSystemVar("DIMTMOVE", 0))
                using (KRResetSystemVar myResetDIMSCALE = new KRResetSystemVar("DIMSCALE", dimScale))
                {
                    //Main loop:
                    while (true)
                    {
                        //Create first Oblique dimension:
                        using (AlignedDimension alDim = new AlignedDimension())
                        {
                            alDim.XLine1Point = startPnt;
                            alDim.Layer = layerName;

                            //Create new jig for align dimension:
                            AlignDimJig alDimJig = new AlignDimJig(alDim, "\nNext point: ");
                            PromptResult pr = ed.Drag(alDimJig);
                            if (pr.Status == PromptStatus.OK)
                            {
                                using (Transaction tr = db.TransactionManager.StartTransaction())
                                {
                                    //Suppress extension lines:
                                    (alDimJig.JigEntity as AlignedDimension).Dimse1 = true;
                                    (alDimJig.JigEntity as AlignedDimension).Dimse2 = true;

                                    //Add Xline to database:
                                    AppendEnt(tr, alDimJig.JigEntity);

                                    //Commit changes:
                                    tr.Commit();

                                    //Update graphic:
                                    tr.TransactionManager.QueueForGraphicsFlush();
                                }

                                startPnt = (alDimJig.JigEntity as AlignedDimension).XLine2Point;
                            }
                            else
                                return;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        private enum HoleType
        {
            Drill = 1,
            Tap = 2,
            Sink = 3,
        }

        //[CommandMethod("TestCountHole")]
        private void TestCountHoleInArray()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;
            Database db = doc.Database;

            PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("")
            {
                Message = "\nSelect the standard hole: "
            };
            pneo.AllowNone = false;

            PromptNestedEntityResult per = ed.GetNestedEntity(pneo);
            if (per.Status != PromptStatus.OK)
            {
                return;
            }
            else
            {
                bool isCircle = per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Circle)));

                while (isCircle == false)
                {
                    ed.WriteMessage("\nInvalid selection!");
                    per = ed.GetNestedEntity(pneo);
                    if (per.Status != PromptStatus.OK)
                    {
                        return;
                    }
                    else
                    {
                        isCircle = per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Circle)));
                    }
                }
            }

            ObjectId[] containers = per.GetContainers();
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {

                foreach (ObjectId id in containers)
                {
                    //if (id != ObjectId.Null)
                    //{
                    //    DBObject dbObj = tr.GetObject(id, OpenMode.ForWrite) as DBObject;


                    //}
                    //ed.WriteMessage($"\n container's id : {id}");

                    Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
                    ed.WriteMessage($"\nEntity 's type : {ent.GetType()}");

                    try
                    {
                        Entity parEnt = tr.GetObject(ent.OwnerId, OpenMode.ForRead) as Entity;
                        ed.WriteMessage($"\nFather entity 's type : {parEnt.GetType()}");
                    }
                    catch (System.Exception ex)
                    {
                        ed.WriteMessage("\n" + ex.Message);
                    }

                    //ed.WriteMessage($"\n {id.ObjectClass}");

                }
            }

            //ed.WriteMessage($"\nOwner : {per.ObjectId.}")
        }

        #region [DHole - V2(Running)]
        [CommandMethod("DH")]
        public void CmdDHB()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;

            PromptKeywordOptions pko = new PromptKeywordOptions("\nHole's type: ");
            pko.Keywords.Add("Drill");
            pko.Keywords.Add("Tap");
            pko.Keywords.Add("Sink");
            pko.Keywords.Default = "Drill";
            pko.AllowArbitraryInput = false;
            pko.AllowNone = true;

            PromptResult pr = ed.GetKeywords(pko);
            if (pr.Status != PromptStatus.OK)
            {
                return;
            }
            else
            {
                switch (pr.StringResult)
                {
                    case "Drill":
                        DHBHole(HoleType.Drill, doc, ed);
                        break;

                    case "Tap":
                        DHBHole(HoleType.Tap, doc, ed);
                        break;

                    case "Sink":
                        DHBHole(HoleType.Sink, doc, ed);
                        break;

                    default:
                        ed.WriteMessage("\nCannot get hole's type. Command ended!");
                        return;
                }
            }
        }

        //Sub method called by 'DHB':
        private void DHBHole(HoleType hType, Document doc, Editor ed)
        {
            Database db = doc.Database;

            #region [Get nested entity]
            PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("\nSelect Circle: ")
            {
                AllowNone = true
            };

            PromptNestedEntityResult pner = ed.GetNestedEntity(pneo);
            if (pner.Status != PromptStatus.OK)
            {
                return;
            }

            bool isCircle = (pner.ObjectId.ObjectClass.Name == "AcDbCircle");
            while (!isCircle)
            {
                ed.WriteMessage("\nInvalid selection!");
                pner = ed.GetNestedEntity(pneo);
                if (pner.Status != PromptStatus.OK)
                {
                    return;
                }
                else
                {
                    isCircle = (pner.ObjectId.ObjectClass.Name == "AcDbCircle");
                }
            }
            #endregion

            #region [Highlight]
            ObjectId[] objIds = pner.GetContainers();
            ObjectId ensel = pner.ObjectId;
            int len = objIds.Length;

            // Reverse the "containers" list
            ObjectId[] revIds = new ObjectId[len + 1];
            for (int i = 0; i < len; i++)
            {
                ObjectId id = (ObjectId)objIds.GetValue(len - i - 1);
                revIds.SetValue(id, i);
            }

            //Now add the selected entity to the end
            revIds.SetValue(ensel, len);

            //Retrieve the sub-entity path for this entity
            SubentityId subEnt = new SubentityId(SubentityType.Null, IntPtr.Zero);

            //Get full path to highlight:
            FullSubentityPath path = new FullSubentityPath(revIds, subEnt);

            //Declare objectid for outer most container:
            ObjectId outerMost = (ObjectId)revIds.GetValue(0);

            //Highlight standard circle:
            DHB_HighlightNest(db, revIds, path, true);
            #endregion

            #region [Get SelectionSet]
            //Get circle radius:
            double radius;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Get standard hole & its radius:
                Circle stdCir = tr.GetObject(pner.ObjectId, OpenMode.ForRead) as Circle;
                radius = stdCir.Radius;

                //Commit changes:
                tr.Commit();
            }

            // Create a TypedValue array to define the filter criteria
            TypedValue[] acTypValAr = new TypedValue[7];
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<or"), 0);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "INSERT"), 1);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<and"), 2);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "CIRCLE"), 3);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Real, radius), 4);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "and>"), 5);
            acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "or>"), 6);

            // Assign the filter criteria to a SelectionFilter object
            SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

            //Prompt option:
            PromptSelectionOptions pso = new PromptSelectionOptions
            {
                MessageForAdding = "\nSelect holes/ block: ",
                RejectObjectsOnLockedLayers = true,
            };

            PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);
            if (acSSPrompt.Status == PromptStatus.Cancel)
            {
                //Unhilight standard circle:
                DHB_HighlightNest(db, revIds, path, false);
                return;
            }

            //Collection contains all selected objectid include standard hole:
            ObjectIdCollection ssIds = new ObjectIdCollection();
            ssIds.Add(pner.ObjectId);
            if (acSSPrompt.Status != PromptStatus.Error)
            {
                ObjectId[] tempIds = acSSPrompt.Value.GetObjectIds();
                foreach (ObjectId id in tempIds)
                {
                    if (id != ObjectId.Null && id != pner.ObjectId)
                    {
                        ssIds.Add(id);
                    }
                }
            }
            #endregion

            //Unhilight standard circle:
            DHB_HighlightNest(db, revIds, path, false);

            //List to store block information:
            List<KeyValuePair<string, int>> blkList = new List<KeyValuePair<string, int>>();

            //Flag to determine SelectionSet contain standard hole or not:
            bool ssContainStd = false;

            //Initialize hole's count:
            //int holeCount;
            if (!DHBHole_Count(db, ed, pner, outerMost, radius, ssIds,
                ref blkList, ref ssContainStd, out int holeCount))
            {
                return;
            }

            //Start to jig:
            //Using try-catch to prevent crash:
            try
            {
                using (KRResetSystemVar myResetFeval = new KRResetSystemVar("FIELDEVAL", 0))
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    #region [Get number of faces]
                    PromptIntegerOptions pio = new PromptIntegerOptions("")
                    {
                        Message = "\nNumber of faces: ",
                        AllowNegative = false,
                        AllowArbitraryInput = false,
                        AllowZero = false,
                        DefaultValue = 1
                    };

                    PromptIntegerResult pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }
                    #endregion

                    #region [Set dimension text]
                    //Prompt keywords option:
                    PromptKeywordOptions pkw = new PromptKeywordOptions("\nBelow note: ");
                    pkw.AllowNone = true;
                    pkw.Keywords.Add("Center");
                    pkw.Keywords.Add("Pitch");
                    pkw.Keywords.Add("Input");
                    pkw.Keywords.Add("None");
                    pkw.Keywords.Default = "None";

                    //Prompt result:
                    PromptResult prd = ed.GetKeywords(pkw);
                    if (prd.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }

                    //Variable for dimension text:
                    string dimContent = "<>";

                    switch (prd.StringResult)
                    {
                        case "Center":
                            dimContent = "<>\\X(センター孔)";
                            break;

                        case "Pitch":
                            PromptDoubleOptions pdod = new PromptDoubleOptions("\nPitch: ");
                            pdod.AllowNone = false;
                            pdod.AllowZero = false;
                            pdod.AllowArbitraryInput = false;
                            pdod.AllowNegative = false;
                            pdod.DefaultValue = 50.0;

                            PromptDoubleResult pdrd = ed.GetDouble(pdod);
                            if (pdrd.Status != PromptStatus.OK)
                            {
                                tr.Abort();
                                return;
                            }
                            string pitchStr = RoundOff(pdrd.Value, 0.5).ToString();
                            dimContent = "<>\\X(P=" + pitchStr + ")";
                            break;

                        case "Input":
                            PromptStringOptions psod = new PromptStringOptions("\nInput string: ");
                            psod.AllowSpaces = true;

                            prd = ed.GetString(psod);
                            if (prd.Status != PromptStatus.OK)
                            {
                                tr.Abort();
                                return;
                            }

                            dimContent = "<>\\X" + prd.StringResult;
                            break;

                        case "None":
                            dimContent = "<>";
                            break;

                        default:
                            ed.WriteMessage("\nCannot get below text. Command ended!");
                            tr.Abort();
                            return;
                    }
                    #endregion

                    //Check layer :
                    string layerName = "0";
                    if (!KRCADLayer.HasLayer(KRCADLayer.LayerScale.Item1))
                    {
                        if (!KRCADLayer.CreateLayer(KRCADLayer.LayerScale))
                        {
                            ed.WriteMessage($"\nCannot create '{KRCADLayer.LayerScale.Item1}' layer. Use '0' layer instead !");
                            layerName = "0";
                        }
                        else
                        {
                            layerName = KRCADLayer.LayerScale.Item1;
                        }
                    }
                    else
                    {
                        layerName = KRCADLayer.LayerScale.Item1;
                    }

                    //Check dim style :
                    DimStyleTable dimStyleTb = tr.GetObject(db.DimStyleTableId, OpenMode.ForRead) as DimStyleTable;
                    if (!dimStyleTb.Has(KRCADDimStyle.KRDimStyleName))
                    {
                        if (!KRCADDimStyle.ImportDimStyleFromFile(CommonDeclaration.GetCommonBlkPath(), KRCADDimStyle.KRDimStyleName))
                        {
                            ed.WriteMessage($"\nCannot import {KRCADDimStyle.KRDimStyleName}. Command ended!");
                            tr.Abort();
                            return;
                        }
                    }

                    //Activate dim style :
                    DimStyleTableRecord dimStyleTbRc = tr.GetObject(dimStyleTb[KRCADDimStyle.KRDimStyleName], OpenMode.ForRead) as DimStyleTableRecord;
                    if (db.Dimstyle != dimStyleTbRc.ObjectId)
                    {
                        db.Dimstyle = dimStyleTbRc.ObjectId;
                        db.SetDimstyleData(dimStyleTbRc);
                    }

                    //Jigging:
                    using (DiametricDimension diaDim = new DiametricDimension())
                    {
                        //Open standard circle for read:
                        Circle cirObj = tr.GetObject(pner.ObjectId, OpenMode.ForRead) as Circle;

                        //Create new jig:
                        DiaDimJig jigObj = new DiaDimJig(tr, diaDim, cirObj, pner, "\nLocation: ");

                        //Set dimension's text:
                        jigObj.DiaDim.DimensionText = dimContent;
                        jigObj.DiaDim.Layer = layerName;

                        #region [Set prefix]
                        if (hType == HoleType.Drill)
                        {
                            jigObj.DimPrefix = pir.Value.ToString() + "x" +
                                          holeCount.ToString() + "-%%c";
                        }
                        else if (hType == HoleType.Tap || hType == HoleType.Sink)
                        {
                            jigObj.DimPrefix = pir.Value.ToString() + "x" +
                                           holeCount.ToString() + "-M";
                        }
                        else
                        {
                            ed.WriteMessage("\nCannot define dimension prefix. Command ended!");
                            tr.Abort();
                            return;
                        }
                        #endregion

                        #region [Set suffix]
                        if (hType == HoleType.Drill)
                        {
                            if (pir.Value == 1)
                            {
                                jigObj.DimSuffix = "孔";
                            }
                            else
                            {
                                jigObj.DimSuffix = "貫通孔";
                            }

                        }
                        else if (hType == HoleType.Tap)
                        {
                            jigObj.DimSuffix = "タップ";
                        }
                        else if (hType == HoleType.Sink)
                        {
                            jigObj.DimSuffix = "皿孔";
                        }
                        else
                        {
                            ed.WriteMessage("\nCannot define dimension suffix. Command ended!");
                            tr.Abort();
                            return;
                        }
                        #endregion

                        //Start to drag:
                        PromptResult pr = ed.Drag(jigObj);
                        if (pr.Status == PromptStatus.OK)
                        {
                            AppendEnt(tr, jigObj.DiaDim);

                            //Commit changes:
                            tr.Commit();
                        }
                        else if (pr.Status == PromptStatus.Keyword)
                        {
                            bool isDone = false;
                            PromptDoubleResult pdr;

                            while (!isDone)
                            {
                                switch (pr.StringResult)
                                {
                                    case "Size":

                                        #region [Input new size]
                                        PromptDoubleOptions pdo = new PromptDoubleOptions("\nInput new size: ");
                                        pdo.AllowArbitraryInput = false;
                                        pdo.AllowNegative = false;
                                        pdo.AllowZero = false;
                                        pdo.AllowNone = true;
                                        pdo.DefaultValue = cirObj.Diameter;

                                        pdr = ed.GetDouble(pdo);
                                        if (pdr.Status != PromptStatus.OK)
                                        {
                                            tr.Abort();
                                            return;
                                        }
                                        #endregion

                                        //Change holes' size:
                                        if (!DHBHole_UpdateSize(ed, db, tr,
                                                                ref pr, pdr,
                                                                cirObj, outerMost,
                                                                ssIds, blkList,
                                                                jigObj, ref isDone, ssContainStd))
                                        {
                                            tr.Abort();
                                            return;
                                        }

                                        break;

                                    case "Angle":

                                        #region [Input new angle]
                                        PromptAngleOptions pao = new PromptAngleOptions("\nAngle: ");
                                        pao.AllowArbitraryInput = false;
                                        pao.AllowNone = true;
                                        pao.DefaultValue = 0.0;

                                        pdr = ed.GetAngle(pao);
                                        if (pdr.Status != PromptStatus.OK)
                                        {
                                            tr.Abort();
                                            return;
                                        }
                                        #endregion

                                        #region [Change angle]
                                        //jigObj.DiaDim.TextRotation = pdr.Value;
                                        jigObj.BaseAngle = pdr.Value + UcsWcsAngle();

                                        //Drag jig again:
                                        pr = ed.Drag(jigObj);
                                        if (pr.Status == PromptStatus.OK)
                                        {
                                            isDone = true;
                                        }
                                        else if (pr.Status == PromptStatus.Keyword)
                                        {
                                            isDone = false;
                                        }
                                        else
                                        {
                                            tr.Abort();
                                            return;
                                        }
                                        #endregion

                                        break;

                                    default:
                                        ed.WriteMessage("\nCannot get jig's keyword. Command ended!");
                                        tr.Abort();
                                        return;
                                }
                            }

                            //Append entity to database:
                            AppendEnt(tr, jigObj.DiaDim);

                            //Commit changes:
                            tr.Commit();
                        }
                        else
                        {
                            tr.Abort();
                            return;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        //Sub method for highlight/ unhighlight nested entity:
        private void DHB_HighlightNest(Database db, ObjectId[] revIds, FullSubentityPath path, bool isHighlight = true)
        {
            //Unhilight standard circle:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                // Open the outermost container...
                ObjectId id = (ObjectId)revIds.GetValue(0);
                Entity ent = (Entity)tr.GetObject(id, OpenMode.ForRead);

                //Highlight/ unhighlight:
                if (isHighlight)
                {
                    ent.Highlight(path, false);
                }
                else
                {
                    ent.Unhighlight(path, false);
                }

                //Commit changes:
                tr.Commit();
            }
        }

        //Sub method to get holes' count:
        private bool DHBHole_Count(Database db, Editor ed,
                                    PromptNestedEntityResult pner, ObjectId outerMost,
                                    double radius, ObjectIdCollection ssIds,
                                    ref List<KeyValuePair<string, int>> blkList, ref bool ssContainStd,
                                    out int holeCount)
        {
            //Initialize hole's count:
            holeCount = 0;

            //Main transaction:
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                //Get block table:
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                //Iterate SelectionSet:
                foreach (ObjectId id in ssIds)
                {
                    if (id.ObjectClass.Name == "AcDbBlockReference")
                    {
                        if (!DHBHole_ListUpdate(ed, tr, id, pner.ObjectId, radius, 1,
                            ref blkList, ref ssContainStd))
                        {
                            return false;
                        }
                    }
                    else
                    {
                        Circle cirObj = tr.GetObject(id, OpenMode.ForRead) as Circle;
                        if (Abs(cirObj.Radius - radius) <= KRTolerance)
                        {
                            //Update hole's count:
                            holeCount += 1;

                            //Check id equal to standard id:
                            if (id.Equals(pner.ObjectId))
                            {
                                ssContainStd = true;
                                //overLapCount += 1;
                            }
                        }
                    }
                }

                #region [Calculate holes' count]
                foreach (var item in blkList)
                {
                    holeCount += item.Value;
                }
                if (pner.GetContainers().Length > 0 && ssIds.Contains(outerMost))
                {
                    holeCount -= 1;
                }
                #endregion

                //Print out hole's count:
                ed.WriteMessage($"\nHole number: {holeCount}");

                //Commit changes:
                tr.Commit();
            }

            return true;
        }

        //Sub method for update block's list:
        private bool DHBHole_ListUpdate(Editor ed, Transaction tr, ObjectId blkRefId, ObjectId stdId,
                                        double radius, int arrItems,
                                        ref List<KeyValuePair<string, int>> blkList,
                                        ref bool ssContainStd)
        {
            try
            {
                //Get BlockReference:
                BlockReference blkRef = tr.GetObject(blkRefId, OpenMode.ForRead) as BlockReference;

                //Get BlockDefinition:
                BlockTableRecord blkDef = tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead) as BlockTableRecord;

                int blkHoleNum = 0;

                //Check whether BlockDefinition contains appropriate circle: 
                foreach (ObjectId id in blkDef)
                {
                    //Entity is circle:
                    if (id.ObjectClass.Name == "AcDbCircle")
                    {
                        Circle tempCir = tr.GetObject(id, OpenMode.ForRead) as Circle;
                        if (Abs(tempCir.Radius - radius) <= KRTolerance)
                        {
                            //Update hole numbers:
                            blkHoleNum += 1;

                            //Check id equal to standard id:
                            if (id.Equals(stdId))
                            {
                                ssContainStd = true;
                            }
                        }
                    }

                    //Entity is BlockReference:
                    else if (id.ObjectClass.Name == "AcDbBlockReference")
                    {
                        #region [Array count]
                        //Get assoc array's item count:
                        AssocArray assArr = AssocArray.GetAssociativeArray(id);
                        //int arrItems;
                        if (assArr != null)
                        {
                            ObjectIdCollection arrSrcIds = assArr.SourceEntities;
                            arrItems = assArr.getItems(true).Length;
                            using (Transaction subTr = tr.TransactionManager.StartTransaction())
                            {
                                bool hasCircle = false;

                                foreach (ObjectId arrSrcId in arrSrcIds)
                                {
                                    if (arrSrcId.ObjectClass.Name == "AcDbCircle")
                                    {
                                        Circle srcCir = subTr.GetObject(arrSrcId, OpenMode.ForRead) as Circle;
                                        if (Abs(srcCir.Radius - radius) <= KRTolerance)
                                        {
                                            hasCircle = true;
                                            break;
                                        }
                                    }
                                }

                                if (hasCircle == false)
                                {
                                    arrItems = 1;
                                }

                                //Commit changes;
                                subTr.Commit();
                            }
                        }
                        else
                        {
                            arrItems = 1;
                        }
                        #endregion

                        //Using Recursion:
                        if (!DHBHole_ListUpdate(ed, tr, id, stdId, radius, arrItems,
                            ref blkList, ref ssContainStd))
                        {
                            return false;
                        }
                    }
                }

                //Update list:
                if (blkHoleNum > 0)
                {
                    blkHoleNum *= arrItems;

                    //Check list contain block definition or not.
                    //If contain, update count number.
                    //If not, add new block definiton.
                    if (blkList.Exists(i => i.Key == blkDef.Name))
                    {
                        //Find already exist item:
                        var oldMember = blkList.Find(i => i.Key == blkDef.Name);

                        //Create new member:
                        KeyValuePair<string, int> newMember = new KeyValuePair<string, int>(blkDef.Name,
                           oldMember.Value + blkHoleNum);

                        //Replace old item with the new item:
                        blkList.Remove(oldMember);
                        blkList.Add(newMember);
                    }
                    else
                    {
                        blkList.Add(new KeyValuePair<string, int>(blkDef.Name, blkHoleNum));
                    }
                }

                //Return value:
                return true;
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return false;
            }
        }

        //Sub method for update Block reference graphics:
        private void DHBHole_UpdateBlkRef(ObjectIdCollection ssIds, ObjectId outerMost, Transaction subTr)
        {
            //Force BlockReference only update(NOT ALL DRAWING):
            //We don't use Editor.Regen() to improve performance:
            if (ssIds.Count == 1 && outerMost != ObjectId.Null)
            {
                if (outerMost.ObjectClass.Name == "AcDbBlockReference")
                {
                    BlockReference blkRef = subTr.GetObject(outerMost, OpenMode.ForWrite) as BlockReference;
                    blkRef.RecordGraphicsModified(true);
                }
            }
            else
            {
                foreach (ObjectId id in ssIds)
                {
                    if (id != ObjectId.Null && id.ObjectClass.Name == "AcDbBlockReference")
                    {
                        BlockReference blkRef = subTr.GetObject(id, OpenMode.ForWrite) as BlockReference;
                        blkRef.RecordGraphicsModified(true);
                    }
                }
            }
        }

        //Sub method for change hole's size in block's list:
        private bool DHBHole_UpdateSize(Editor ed, Database db, Transaction tr,
                                        ref PromptResult pr, PromptDoubleResult pdr,
                                        Circle cirObj, ObjectId outerMost,
                                        ObjectIdCollection ssIds, List<KeyValuePair<string, int>> blkList,
                                        DiaDimJig jigObj, ref bool isDone, bool ssContainStd)
        {
            //Main transaction:
            using (Transaction subTr = db.TransactionManager.StartTransaction())
            {
                //Get old circle diameter:
                double oldDia = cirObj.Diameter;

                //Edit standard hole
                if (!ssContainStd)
                {
                    cirObj.UpgradeOpen();
                    cirObj.Diameter = pdr.Value;
                    cirObj.DowngradeOpen();
                }

                //Edit blocks:
                if (blkList.Count > 0)
                {
                    //Get BlockTable:
                    BlockTable bt = subTr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;

                    //Iterate Block's list:
                    foreach (var item in blkList)
                    {
                        //Get BlockDefinition:
                        BlockTableRecord blkDef = subTr.GetObject(bt[item.Key], OpenMode.ForWrite) as BlockTableRecord;

                        foreach (ObjectId id in blkDef)
                        {
                            if (id.ObjectClass.Name == "AcDbCircle")
                            {
                                Circle cirObj2 = subTr.GetObject(id, OpenMode.ForWrite) as Circle;
                                if (Abs(cirObj2.Diameter - oldDia) <= KRTolerance)
                                {
                                    cirObj2.Diameter = pdr.Value;
                                }
                            }
                        }
                    }
                }

                //Edit other circles:
                foreach (ObjectId id in ssIds)
                {
                    if (id.ObjectClass.Name == "AcDbCircle")
                    {
                        Circle cirObj2 = subTr.GetObject(id, OpenMode.ForWrite) as Circle;
                        if (Abs(cirObj2.Diameter - oldDia) <= KRTolerance)
                        {
                            cirObj2.Diameter = pdr.Value;
                        }
                    }
                }

                //Update BlkRef graphics
                DHBHole_UpdateBlkRef(ssIds, outerMost, subTr);

                //Update entities' graphic:
                db.TransactionManager.QueueForGraphicsFlush();

                //Start to Jig again:
                pr = ed.Drag(jigObj);
                if (pr.Status == PromptStatus.OK)
                {
                    subTr.Commit();
                    isDone = true;
                }
                else if (pr.Status == PromptStatus.Keyword)
                {
                    subTr.Commit();
                    isDone = false;
                }
                else
                {
                    //Update BlkRef graphics
                    DHBHole_UpdateBlkRef(ssIds, outerMost, subTr);
                    subTr.Abort();
                    return false;
                }
            }

            return true;
        }

        #endregion

        #region [DHole - V1(Old)]
        //Common method for hole dimension:
        private void DHole(HoleType hType, Document doc, Editor ed)
        {
            //Document doc = CommonCommands.doc();
            //Editor ed = doc.Editor;
            Database db = doc.Database;

            #region [Select standard hole]

            #region [Solution 1 - On running]
            PromptEntityOptions peo = new PromptEntityOptions("")
            {
                Message = "\nSelect the standard hole: "
            };
            peo.SetRejectMessage("\nInvalid selection!");
            peo.AddAllowedClass(typeof(Circle), true);
            peo.AllowNone = false;

            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK)
            {
                return;
            }
            #endregion

            #region [Solution 2 - on testing]
            //PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("")
            //{
            //    Message = "\nSelect the standard hole: "
            //};
            //pneo.AllowNone = false;

            //PromptEntityResult per = ed.GetNestedEntity(pneo);
            //if (per.Status != PromptStatus.OK)
            //{
            //    return;
            //}
            //else
            //{
            //    bool isCircle = per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Circle)));

            //    while (isCircle == false)
            //    {
            //        ed.WriteMessage("\nInvalid selection!");
            //        per = ed.GetNestedEntity(pneo);
            //        if (per.Status != PromptStatus.OK)
            //        {
            //            return;
            //        }
            //        else
            //        {
            //            isCircle = per.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Circle)));
            //        }
            //    }
            //}
            #endregion

            #endregion

            //Using try-catch to prevent crash:
            try
            {
                //Main transaction:
                using (KRUnhighlight myUnhighlight = new KRUnhighlight())
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Get base circle:
                    Circle cirObj = (Circle)tr.GetObject(per.ObjectId, OpenMode.ForRead);

                    //Highlight circle with style:
                    FullSubentityPath path = new FullSubentityPath(new ObjectId[] { cirObj.ObjectId },
                        new SubentityId(SubentityType.Null, IntPtr.Zero));
                    cirObj.PushHighlight(path, HighlightStyle.DashedAndThicken | HighlightStyle.Glow);
                    myUnhighlight.Add(cirObj.ObjectId);

                    #region [Get selection set based on the standard hole]
                    // Create a TypedValue array to define the filter criteria
                    TypedValue[] acTypValAr = new TypedValue[4];
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<and"), 0);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "CIRCLE"), 1);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Real, cirObj.Radius), 2);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "and>"), 3);

                    // Assign the filter criteria to a SelectionFilter object
                    SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

                    //Prompt option:
                    PromptSelectionOptions pso = new PromptSelectionOptions
                    {
                        MessageForAdding = "Select holes or next: ",
                        MessageForRemoval = "Remove holes: "
                    };

                    // Request for objects to be selected in the drawing area
                    PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);
                    int holeNum;

                    //if (acSSPrompt.Status != PromptStatus.OK || acSSPrompt.Value.Count == 0) 
                    //    return;

                    if (acSSPrompt.Status == PromptStatus.OK)
                    {
                        bool isDuplicated = false;

                        foreach (SelectedObject sObj in acSSPrompt.Value)
                        {
                            if (sObj.ObjectId == per.ObjectId)
                            {
                                isDuplicated = true;
                                break;
                            }
                        }

                        if (isDuplicated)
                        {
                            holeNum = acSSPrompt.Value.Count;
                        }
                        else
                        {
                            holeNum = acSSPrompt.Value.Count + 1;
                        }
                    }
                    else if (acSSPrompt.Status == PromptStatus.None ||
                            acSSPrompt.Status == PromptStatus.Error)
                    {
                        holeNum = 1;
                    }
                    else
                    {
                        tr.Abort();
                        return;
                    }
                    #endregion

                    #region [Get number of faces]
                    PromptIntegerOptions pio = new PromptIntegerOptions("")
                    {
                        Message = "\nNumber of faces: ",
                        AllowNegative = false,
                        AllowArbitraryInput = false,
                        AllowZero = false,
                        DefaultValue = 1
                    };

                    PromptIntegerResult pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }
                    #endregion

                    #region [Set dimension text]
                    //Prompt keywords option:
                    PromptKeywordOptions pkw = new PromptKeywordOptions("\nBelow note: ");
                    pkw.AllowNone = true;
                    pkw.Keywords.Add("Center");
                    pkw.Keywords.Add("Pitch");
                    pkw.Keywords.Add("Input");
                    pkw.Keywords.Add("None");
                    pkw.Keywords.Default = "None";

                    //Prompt result:
                    PromptResult prd = ed.GetKeywords(pkw);
                    if (prd.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }

                    //Variable for dimension text:
                    string dimContent = "<>";

                    switch (prd.StringResult)
                    {
                        case "Center":
                            dimContent = "<>\\X(センター孔)";
                            break;

                        case "Pitch":
                            PromptDoubleOptions pdod = new PromptDoubleOptions("\nPitch: ");
                            pdod.AllowNone = false;
                            pdod.AllowZero = false;
                            pdod.AllowArbitraryInput = false;
                            pdod.AllowNegative = false;
                            pdod.DefaultValue = 50.0;

                            PromptDoubleResult pdrd = ed.GetDouble(pdod);
                            if (pdrd.Status != PromptStatus.OK)
                            {
                                tr.Abort();
                                return;
                            }
                            string pitchStr = RoundOff(pdrd.Value, 0.5).ToString();
                            dimContent = "<>\\X(P=" + pitchStr + ")";
                            break;

                        case "Input":
                            PromptStringOptions psod = new PromptStringOptions("\nInput string: ");
                            psod.AllowSpaces = true;

                            prd = ed.GetString(psod);
                            if (prd.Status != PromptStatus.OK)
                            {
                                tr.Abort();
                                return;
                            }

                            dimContent = "<>\\X" + prd.StringResult;
                            break;

                        case "None":
                            dimContent = "<>";
                            break;

                        default:
                            ed.WriteMessage("\nCannot get below text. Command ended!");
                            tr.Abort();
                            return;
                    }
                    #endregion

                    //Jigging:
                    using (DiametricDimension diaDim = new DiametricDimension())
                    {
                        //Create new jig:
                        ObjectIdCollection objIds = new ObjectIdCollection();
                        if (acSSPrompt.Value != null)
                        {
                            ObjectId[] idsArray = acSSPrompt.Value.GetObjectIds();

                            foreach (var item in idsArray)
                            {
                                if (item != null)
                                {
                                    objIds.Add(item);
                                }
                            }

                            if (!objIds.Contains(per.ObjectId))
                            {
                                objIds.Add(per.ObjectId);
                            }
                        }
                        else
                        {
                            objIds.Add(per.ObjectId);
                        }

                        //DiaDimJig jigObj = new DiaDimJig(tr, diaDim, cirObj, objIds, "\nLocation: ");
                        DiaDimJig jigObj = new DiaDimJig(tr, diaDim, cirObj, "\nLocation: ");

                        //Set dimension's text:
                        jigObj.DiaDim.DimensionText = dimContent;

                        //Set dimension's prefix:
                        if (hType == HoleType.Drill)
                        {
                            jigObj.DimPrefix = pir.Value.ToString() + "x" +
                                           holeNum.ToString() + "-%%c";
                        }
                        else if (hType == HoleType.Tap || hType == HoleType.Sink)
                        {
                            jigObj.DimPrefix = pir.Value.ToString() + "x" +
                                           holeNum.ToString() + "-M";
                        }
                        else
                        {
                            ed.WriteMessage("\nCannot define dimension prefix. Command ended!");
                            tr.Abort();
                            return;
                        }

                        //Set dimension's suffix:
                        if (hType == HoleType.Drill)
                        {
                            if (pir.Value == 1)
                            {
                                jigObj.DimSuffix = "孔";
                            }
                            else
                            {
                                jigObj.DimSuffix = "貫通孔";
                            }
                        }
                        else if (hType == HoleType.Tap)
                        {
                            jigObj.DimSuffix = "タップ";
                        }
                        else if (hType == HoleType.Sink)
                        {
                            jigObj.DimSuffix = "皿孔";
                        }
                        else
                        {
                            ed.WriteMessage("\nCannot define dimension suffix. Command ended!");
                            tr.Abort();
                            return;
                        }

                        //Start to drag:
                        PromptResult pr = ed.Drag(jigObj);
                        if (pr.Status == PromptStatus.OK)
                        {
                            AppendEnt(tr, jigObj.DiaDim);
                            tr.Commit();
                        }
                        else if (pr.Status == PromptStatus.Keyword)
                        {
                            bool isDone = false;
                            PromptDoubleResult pdr;

                            while (!isDone)
                            {
                                switch (pr.StringResult)
                                {
                                    case "Size":
                                        PromptDoubleOptions pdo = new PromptDoubleOptions("\nInput new size: ");
                                        pdo.AllowArbitraryInput = false;
                                        pdo.AllowNegative = false;
                                        pdo.AllowZero = false;
                                        pdo.AllowNone = true;
                                        pdo.DefaultValue = cirObj.Diameter;

                                        pdr = ed.GetDouble(pdo);
                                        if (pdr.Status != PromptStatus.OK)
                                        {
                                            tr.Abort();
                                            return;
                                        }

                                        using (Transaction subTr = db.TransactionManager.StartTransaction())
                                        {
                                            foreach (ObjectId id in objIds)
                                            {
                                                if (id == per.ObjectId)
                                                {
                                                    cirObj.UpgradeOpen();
                                                    cirObj.Diameter = pdr.Value;
                                                    cirObj.DowngradeOpen();
                                                }
                                                else
                                                {
                                                    Circle tempCir = subTr.GetObject(id, OpenMode.ForWrite) as Circle;
                                                    tempCir.Diameter = pdr.Value;
                                                }
                                            }
                                            db.TransactionManager.QueueForGraphicsFlush();

                                            pr = ed.Drag(jigObj);

                                            if (pr.Status == PromptStatus.OK)
                                            {
                                                subTr.Commit();
                                                isDone = true;
                                            }
                                            else if (pr.Status == PromptStatus.Keyword)
                                            {
                                                subTr.Commit();
                                                isDone = false;
                                            }
                                            else
                                            {
                                                subTr.Abort();
                                                tr.Abort();
                                                return;
                                            }
                                        }
                                        break;

                                    case "Angle":
                                        PromptAngleOptions pao = new PromptAngleOptions("\nAngle: ");
                                        pao.AllowArbitraryInput = false;
                                        pao.AllowNone = true;
                                        pao.DefaultValue = 0.0;

                                        pdr = ed.GetAngle(pao);
                                        if (pdr.Status != PromptStatus.OK)
                                        {
                                            tr.Abort();
                                            return;
                                        }

                                        //jigObj.DiaDim.TextRotation = pdr.Value;
                                        jigObj.BaseAngle = pdr.Value + UcsWcsAngle();

                                        //Drag jig again:
                                        pr = ed.Drag(jigObj);
                                        if (pr.Status == PromptStatus.OK)
                                        {
                                            isDone = true;
                                        }
                                        else if (pr.Status == PromptStatus.Keyword)
                                        {
                                            isDone = false;
                                        }
                                        else
                                        {
                                            tr.Abort();
                                            return;
                                        }
                                        break;

                                    default:
                                        ed.WriteMessage("\nCannot get jig's keyword. Command ended!");
                                        tr.Abort();
                                        return;
                                }
                            }

                            //Append entity to database:
                            AppendEnt(tr, jigObj.DiaDim);

                            //Commit changes:
                            tr.Commit();
                        }
                        else
                        {
                            tr.Abort();
                            return;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }

        //Lệnh kéo kích thước lỗ Drill/ Tap/ Sink(Jig):
        //[CommandMethod("DH")]
        private void CmdDH()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;

            PromptKeywordOptions pko = new PromptKeywordOptions("\nHole's type: ");
            pko.Keywords.Add("Drill");
            pko.Keywords.Add("Tap");
            pko.Keywords.Add("Sink");
            pko.Keywords.Default = "Drill";
            pko.AllowArbitraryInput = false;
            pko.AllowNone = true;

            PromptResult pr = ed.GetKeywords(pko);
            if (pr.Status != PromptStatus.OK)
            {
                return;
            }
            else
            {
                switch (pr.StringResult)
                {
                    case "Drill":
                        DHole(HoleType.Drill, doc, ed);
                        break;

                    case "Tap":
                        DHole(HoleType.Tap, doc, ed);
                        break;

                    case "Sink":
                        DHole(HoleType.Sink, doc, ed);
                        break;

                    default:
                        ed.WriteMessage("\nCannot get hole's type. Command ended!");
                        return;
                }
            }
        }

        [Obsolete("Use DHole method instead!")]
        private void CmdDHoleOld()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;
            Database db = doc.Database;

            #region [Select standard hole]
            PromptEntityOptions peo = new PromptEntityOptions("")
            {
                Message = "\nSelect the standard hole: "
            };
            peo.SetRejectMessage("\nInvalid selection!");
            peo.AddAllowedClass(typeof(Circle), true);
            peo.AllowNone = false;

            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK)
            {
                return;
            }
            #endregion

            //Using try-catch to prevent crash:
            try
            {
                //Main transaction:
                using (KRUnhighlight myUnhighlight = new KRUnhighlight())
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    //Get base circle:
                    Circle cirObj = (Circle)tr.GetObject(per.ObjectId, OpenMode.ForRead);

                    //Highlight circle with style:
                    FullSubentityPath path = new FullSubentityPath(new ObjectId[] { cirObj.ObjectId },
                        new SubentityId(SubentityType.Null, IntPtr.Zero));
                    cirObj.PushHighlight(path, HighlightStyle.DashedAndThicken | HighlightStyle.Glow);
                    myUnhighlight.Add(cirObj.ObjectId);

                    #region [Get selection set based on the standard hole]
                    // Create a TypedValue array to define the filter criteria
                    TypedValue[] acTypValAr = new TypedValue[4];
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "<and"), 0);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Start, "CIRCLE"), 1);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Real, cirObj.Radius), 2);
                    acTypValAr.SetValue(new TypedValue((int)DxfCode.Operator, "and>"), 3);

                    // Assign the filter criteria to a SelectionFilter object
                    SelectionFilter acSelFtr = new SelectionFilter(acTypValAr);

                    //Prompt option:
                    PromptSelectionOptions pso = new PromptSelectionOptions
                    {
                        MessageForAdding = "Select holes or next: ",
                        MessageForRemoval = "Remove holes: "
                    };

                    // Request for objects to be selected in the drawing area
                    PromptSelectionResult acSSPrompt = ed.GetSelection(pso, acSelFtr);
                    int holeNum;

                    //if (acSSPrompt.Status != PromptStatus.OK || acSSPrompt.Value.Count == 0) 
                    //    return;

                    if (acSSPrompt.Status == PromptStatus.OK)
                    {
                        bool isDuplicated = false;

                        foreach (SelectedObject sObj in acSSPrompt.Value)
                        {
                            if (sObj.ObjectId == per.ObjectId)
                            {
                                isDuplicated = true;
                                break;
                            }
                        }

                        if (isDuplicated)
                        {
                            holeNum = acSSPrompt.Value.Count;
                        }
                        else
                        {
                            holeNum = acSSPrompt.Value.Count + 1;
                        }
                    }
                    else if (acSSPrompt.Status == PromptStatus.None ||
                            acSSPrompt.Status == PromptStatus.Error)
                    {
                        holeNum = 1;
                    }
                    else
                    {
                        tr.Abort();
                        return;
                    }
                    #endregion

                    #region [Get number of faces]
                    PromptIntegerOptions pio = new PromptIntegerOptions("")
                    {
                        Message = "\nNumber of faces: ",
                        AllowNegative = false,
                        AllowArbitraryInput = false,
                        AllowZero = false,
                        DefaultValue = 1
                    };

                    PromptIntegerResult pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }
                    #endregion

                    #region [Set dimension text]
                    //Prompt keywords option:
                    PromptKeywordOptions pkw = new PromptKeywordOptions("\nBelow note: ");
                    pkw.AllowNone = true;
                    pkw.Keywords.Add("Center");
                    pkw.Keywords.Add("Pitch");
                    pkw.Keywords.Add("Input");
                    pkw.Keywords.Add("None");
                    pkw.Keywords.Default = "None";

                    //Prompt result:
                    PromptResult prd = ed.GetKeywords(pkw);
                    if (prd.Status != PromptStatus.OK)
                    {
                        tr.Abort();
                        return;
                    }

                    //Variable for dimension text:
                    string dimContent = "<>";

                    switch (prd.StringResult)
                    {
                        case "Center":
                            dimContent = "<>\\X(センター孔)";
                            break;

                        case "Pitch":
                            PromptDoubleOptions pdod = new PromptDoubleOptions("\nPitch: ");
                            pdod.AllowNone = false;
                            pdod.AllowZero = false;
                            pdod.AllowArbitraryInput = false;
                            pdod.AllowNegative = false;
                            pdod.DefaultValue = 50.0;

                            PromptDoubleResult pdrd = ed.GetDouble(pdod);
                            if (pdrd.Status != PromptStatus.OK)
                            {
                                tr.Abort();
                                return;
                            }
                            string pitchStr = RoundOff(pdrd.Value, 0.5).ToString();
                            dimContent = "<>\\X(P=" + pitchStr + ")";
                            break;

                        case "Input":
                            PromptStringOptions psod = new PromptStringOptions("\nInput string: ");
                            psod.AllowSpaces = true;

                            prd = ed.GetString(psod);
                            if (prd.Status != PromptStatus.OK)
                            {
                                tr.Abort();
                                return;
                            }

                            dimContent = "<>\\X" + prd.StringResult;
                            break;

                        case "None":
                            dimContent = "<>";
                            break;

                        default:
                            ed.WriteMessage("\nCannot get below text. Command ended!");
                            tr.Abort();
                            return;
                    }
                    #endregion

                    //Jigging:
                    using (DiametricDimension diaDim = new DiametricDimension())
                    {
                        //Create new jig:
                        ObjectIdCollection objIds = new ObjectIdCollection();
                        if (acSSPrompt.Value != null)
                        {
                            ObjectId[] idsArray = acSSPrompt.Value.GetObjectIds();

                            foreach (var item in idsArray)
                            {
                                if (item != null)
                                {
                                    objIds.Add(item);
                                }
                            }

                            if (!objIds.Contains(per.ObjectId))
                            {
                                objIds.Add(per.ObjectId);
                            }
                        }
                        else
                        {
                            objIds.Add(per.ObjectId);
                        }

                        DiaDimJig jigObj = new DiaDimJig(tr, diaDim, cirObj, objIds, "\nLocation: ");

                        //Set dimension's text:
                        jigObj.DiaDim.DimensionText = dimContent;

                        //ed.WriteMessage($"\nASSOC : {GetSystemVariable("DIMASSOC")}");

                        //Set dimension's prefix:
                        jigObj.DimPrefix = pir.Value.ToString() + "x" +
                                           holeNum.ToString() + "-%%c";

                        //Set dimension's suffix:
                        if (pir.Value == 1)
                        {
                            jigObj.DimSuffix = "孔";
                        }
                        else
                        {
                            jigObj.DimSuffix = "貫通孔";
                        }

                        //Start to drag:
                        PromptResult pr = ed.Drag(jigObj);
                        if (pr.Status == PromptStatus.OK)
                        {
                            AppendEnt(tr, jigObj.DiaDim);
                            tr.Commit();
                        }
                        else if (pr.Status == PromptStatus.Keyword)
                        {

                            bool isDone = false;
                            PromptDoubleResult pdr;

                            while (!isDone)
                            {
                                switch (pr.StringResult)
                                {
                                    case "Size":
                                        PromptDoubleOptions pdo = new PromptDoubleOptions("\nInput new size: ");
                                        pdo.AllowArbitraryInput = false;
                                        pdo.AllowNegative = false;
                                        pdo.AllowZero = false;
                                        pdo.AllowNone = true;
                                        pdo.DefaultValue = cirObj.Diameter;

                                        pdr = ed.GetDouble(pdo);
                                        if (pdr.Status != PromptStatus.OK)
                                        {
                                            tr.Abort();
                                            return;
                                        }

                                        using (Transaction subTr = db.TransactionManager.StartTransaction())
                                        {
                                            foreach (ObjectId id in objIds)
                                            {
                                                if (id == per.ObjectId)
                                                {
                                                    cirObj.UpgradeOpen();
                                                    cirObj.Diameter = pdr.Value;
                                                    cirObj.DowngradeOpen();
                                                }
                                                else
                                                {
                                                    Circle tempCir = subTr.GetObject(id, OpenMode.ForWrite) as Circle;
                                                    tempCir.Diameter = pdr.Value;
                                                }
                                            }
                                            db.TransactionManager.QueueForGraphicsFlush();

                                            pr = ed.Drag(jigObj);

                                            if (pr.Status == PromptStatus.OK)
                                            {
                                                subTr.Commit();
                                                isDone = true;
                                            }
                                            else if (pr.Status == PromptStatus.Keyword)
                                            {
                                                subTr.Commit();
                                                isDone = false;
                                            }
                                            else
                                            {
                                                subTr.Abort();
                                                tr.Abort();
                                                return;
                                            }
                                        }
                                        break;

                                    case "Angle":
                                        PromptAngleOptions pao = new PromptAngleOptions("\nAngle: ");
                                        pao.AllowArbitraryInput = false;
                                        pao.AllowNone = true;
                                        pao.DefaultValue = 0.0;

                                        pdr = ed.GetAngle(pao);
                                        if (pdr.Status != PromptStatus.OK)
                                        {
                                            tr.Abort();
                                            return;
                                        }

                                        //jigObj.DiaDim.TextRotation = pdr.Value;
                                        jigObj.BaseAngle = pdr.Value + UcsWcsAngle();

                                        //Drag jig again:
                                        pr = ed.Drag(jigObj);
                                        if (pr.Status == PromptStatus.OK)
                                        {
                                            isDone = true;
                                        }
                                        else if (pr.Status == PromptStatus.Keyword)
                                        {
                                            isDone = false;
                                        }
                                        else
                                        {
                                            tr.Abort();
                                            return;
                                        }
                                        break;

                                    default:
                                        ed.WriteMessage("\nCannot get jig's keyword. Command ended!");
                                        tr.Abort();
                                        return;
                                }
                            }


                            //Append entity to database:
                            AppendEnt(tr, jigObj.DiaDim);

                            //Commit changes:
                            tr.Commit();
                        }
                        else
                        {
                            tr.Abort();
                            return;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage(ex.Message);
                return;
            }
        }
        #endregion

        //Lệnh kéo MLeader dùng Jig
        [CommandMethod("MH")]
        public void CmdMHole()
        {
            Document doc = CommonCommands.doc();
            Editor ed = doc.Editor;
            Database db = doc.Database;

            #region [Old codes]
            ////Get base point:
            //Point3d basePnt = new Point3d();
            //if (KRGetPoint(ed,"\nBase point: ",Point3d.Origin,ref basePnt) != PromptStatus.OK)
            //{
            //    return;
            //}

            //using (Transaction tr = db.TransactionManager.StartTransaction())
            //{
            //    using (MLeader mldrObj = new MLeader())
            //    {
            //        MLeaderJig mldrJig = new MLeaderJig(mldrObj, basePnt, "\nNew location: ");
            //        PromptResult pr =  ed.Drag(mldrJig);
            //        if (pr.Status == PromptStatus.OK)
            //        {
            //            ed.WriteMessage("\nSuccessed!");
            //            tr.Commit();
            //        }
            //        else
            //        {
            //            tr.Abort();
            //            return;
            //        }
            //    }
            //}
            #endregion

            PromptKeywordOptions pkw = new PromptKeywordOptions("\nSelect:");
            pkw.Keywords.Add("Tap");
            pkw.Keywords.Add("THrough");
            pkw.Keywords.Add("Other");

            //PromptResult pr = ed.GetString(pso);
            PromptResult pr = ed.GetKeywords(pkw);
            if (pr.Status == PromptStatus.OK)
            {
                #region [Common variables's declaration]
                int holeNum = 1;
                int faceNum = 1;
                string size = "TestSize";
                string prefix;
                string suffix;
                PromptIntegerOptions pio = new PromptIntegerOptions("")
                {
                    AllowNegative = false,
                    AllowArbitraryInput = false,
                    AllowZero = false,
                    DefaultValue = 1
                };
                PromptDoubleOptions pdo = new PromptDoubleOptions("")
                {
                    AllowArbitraryInput = false,
                    AllowZero = false,
                    AllowNegative = false,
                    AllowNone = false
                };
                PromptStringOptions pso;
                PromptIntegerResult pir;
                PromptDoubleResult pdr;
                #endregion

                if (pr.StringResult == "Tap")
                {
                    #region [Get tap size]
                    pdo.Message = "\nTap's size: ";

                    List<double> standardSizes = new List<double>()
                    {
                        1.0,1.2,1.4,1.6,1.7,1.8,
                        2.0,2.2,2.3,2.5,2.6,
                        3.0,3.5,
                        4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,
                        12.0,14.0,16.0,18.0,20.0,22.0,24.0,27.0,
                        30.0,33.0,36.0,39.0,42.0,45.0,48.0,52.0,
                        56.0,60.0,64.0,68.0,72.0,80.0,90.0,100.0
                    };

                    pdr = ed.GetDouble(pdo);
                    if (pdr.Status != PromptStatus.OK)
                    {
                        return;
                    }

                    while (!standardSizes.Contains(pdr.Value))
                    {
                        ed.WriteMessage("\nInvalid tap size. Please try again!");
                        pdr = ed.GetDouble(pdo);
                        if (pdr.Status != PromptStatus.OK)
                        {
                            return;
                        }
                    }
                    #endregion

                    #region [Hole's faces number]
                    pio.Message = "\nFaces' numbers: ";
                    pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                    {
                        return;
                    }
                    else
                    {
                        faceNum = pir.Value;
                    }
                    #endregion

                    #region [Hole's number]
                    pio.Message = "\nHole's numbers: ";
                    pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                    {
                        return;
                    }
                    else
                    {
                        holeNum = pir.Value;
                    }
                    #endregion

                    size = pdr.Value.ToString().Trim();
                    prefix = faceNum.ToString().Trim() + "x" +
                             holeNum.ToString().Trim() + "-M";
                    suffix = "タップ";
                }
                else if (pr.StringResult == "THrough")
                {
                    #region [Get tap size]
                    pdo.Message = "\nHole's size: ";
                    pdr = ed.GetDouble(pdo);
                    if (pdr.Status != PromptStatus.OK)
                    {
                        return;
                    }
                    #endregion

                    #region [Hole's faces number]
                    pio.Message = "\nFaces' numbers: ";
                    pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                    {
                        return;
                    }
                    else
                    {
                        faceNum = pir.Value;
                    }
                    #endregion

                    #region [Hole's number]
                    pio.Message = "\nHole's numbers: ";
                    pir = ed.GetInteger(pio);
                    if (pir.Status != PromptStatus.OK)
                    {
                        return;
                    }
                    else
                    {
                        holeNum = pir.Value;
                    }
                    #endregion

                    size = pdr.Value.ToString().Trim();
                    prefix = faceNum.ToString().Trim() + "x" +
                             holeNum.ToString().Trim() + "-%%c";
                    if (faceNum > 1)
                    {
                        suffix = "貫通孔";
                    }
                    else
                    {
                        suffix = "孔";
                    }
                }
                else
                {
                    //Get the text outside of the jig
                    pso = new PromptStringOptions("\nInput text: ")
                    {
                        AllowSpaces = true,
                    };

                    pr = ed.GetString(pso);
                    if (pr.Status != PromptStatus.OK)
                    {
                        return;
                    }

                    prefix = "";
                    size = pr.StringResult.Trim();
                    suffix = "";

                }

                // Create MleaderJig
                MLeaderJig jig = new MLeaderJig(prefix + size + suffix);

                // Loop to set vertices
                bool bSuccess = true, bComplete = false;
                while (bSuccess && !bComplete)
                {
                    PromptResult dragres = ed.Drag(jig);
                    bSuccess = (dragres.Status == PromptStatus.OK);
                    if (bSuccess)
                        jig.AddVertex();

                    bComplete = (dragres.Status == PromptStatus.None);
                    if (bComplete)
                        jig.RemoveLastVertex();
                }

                //Add entity to database:
                if (bComplete)
                {
                    // Append entity
                    using (Transaction tr = db.TransactionManager.StartTransaction())
                    {
                        AppendEnt(tr, jig.JigEntity);
                        tr.Commit();
                        //Point3d lastPnt = jig.pnts[jig.pnts.Count - 1];
                        //ed.WriteMessage($"\nLast point : {lastPnt.X} , {lastPnt.Y}");
                    }
                }
            }
        }

        #endregion
    }
}

namespace AcadAddin.UcsCmd
{
    //https://forums.autodesk.com/t5/net/do-zoom-extents-in-c-net-autocad/td-p/7735556
    public static class EditorExtension
    {
        public static void Zoom(this Editor ed, Extents3d ext)
        {
            if (ed == null)
                throw new ArgumentNullException("ed");
            using (ViewTableRecord view = ed.GetCurrentView())
            {
                Matrix3d worldToEye = Matrix3d.WorldToPlane(view.ViewDirection) *
                    Matrix3d.Displacement(Point3d.Origin - view.Target) *
                    Matrix3d.Rotation(view.ViewTwist, view.ViewDirection, view.Target);
                ext.TransformBy(worldToEye);
                view.Width = ext.MaxPoint.X - ext.MinPoint.X;
                view.Height = ext.MaxPoint.Y - ext.MinPoint.Y;
                view.CenterPoint = new Point2d(
                    (ext.MaxPoint.X + ext.MinPoint.X) / 2.0,
                    (ext.MaxPoint.Y + ext.MinPoint.Y) / 2.0);
                ed.SetCurrentView(view);
            }
        }

        public static void ZoomExtents(this Editor ed)
        {
            Database db = ed.Document.Database;
            db.UpdateExt(false);
            Extents3d ext = (short)Application.GetSystemVariable("cvport") == 1 ?
                new Extents3d(db.Pextmin, db.Pextmax) :
                new Extents3d(db.Extmin, db.Extmax);
            ed.Zoom(ext);
        }
    }

    public class Commands
    {
        //https://www.c-sharpcorner.com/UploadFile/c210df/difference-between-const-readonly-and-static-readonly-in-C-Sharp/
        //https://adndevblog.typepad.com/autocad/2012/12/how-to-programmatically-create-named-ucs-and-set-it-current.html
        //https://adndevblog.typepad.com/autocad/2013/03/settingcreating-a-named-view-with-associated-ucs.html
        //https://adndevblog.typepad.com/autocad/2012/12/how-to-programmatically-create-named-ucs-and-set-it-current.html

        private readonly static Vector3d _IsoMetricViewVector = new Vector3d(-1.0, -1.0, 1.0);

        class HelpMethod
        {
            public static void SetViewDirection(Vector3d viewVec)
            {
                Document doc = CommonCommands.doc();
                Editor ed = doc.Editor;
                Database db = doc.Database;

                //Change view to Isometric:
                //https://forums.autodesk.com/t5/net/changing-3d-view-to-top-view/td-p/4352166
                using (var isoView = ed.GetCurrentView())
                {
                    if (!viewVec.Equals(_IsoMetricViewVector))
                    {
                        viewVec = viewVec.TransformBy(ed.CurrentUserCoordinateSystem);
                    }

                    isoView.ViewDirection = viewVec;
                    ed.SetCurrentView(isoView);
                    db.UpdateExt(true);
                }
            }
        }

        //View isometric:
        [CommandMethod("VISO", CommandFlags.NoPaperSpace)]
        public void CmdVISO()
        {
            HelpMethod.SetViewDirection(_IsoMetricViewVector);
        }

        //View top:
        [CommandMethod("VIT", CommandFlags.NoPaperSpace)]
        public void CmdVIT()
        {
            Vector3d viewVec = Vector3d.ZAxis;
            HelpMethod.SetViewDirection(viewVec);
        }

        //View bottom:
        [CommandMethod("VIBO", CommandFlags.NoPaperSpace)]
        public void CmdVIBO()
        {
            Vector3d viewVec = Vector3d.ZAxis.Negate();
            HelpMethod.SetViewDirection(viewVec);
        }

        //View left:
        [CommandMethod("VIL", CommandFlags.NoPaperSpace)]
        public void CmdVIL()
        {
            Vector3d viewVec = Vector3d.XAxis.Negate();
            HelpMethod.SetViewDirection(viewVec);
        }

        //View right:
        [CommandMethod("VIR", CommandFlags.NoPaperSpace)]
        public void CmdVIR()
        {
            Vector3d viewVec = Vector3d.XAxis;
            HelpMethod.SetViewDirection(viewVec);
        }

        //View front:
        [CommandMethod("VIF", CommandFlags.NoPaperSpace)]
        public void CmdVIF()
        {
            Vector3d viewVec = Vector3d.YAxis.Negate();
            HelpMethod.SetViewDirection(viewVec);
        }

        //View back:
        [CommandMethod("VIBA", CommandFlags.NoPaperSpace)]
        public void CmdVIBA()
        {
            Vector3d viewVec = Vector3d.YAxis;
            HelpMethod.SetViewDirection(viewVec);
        }

        //Change UCS:
        [CommandMethod("KRUCS", CommandFlags.NoPaperSpace)]
        public void CmdKRUCS()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Do something to prevent user from using this command from layout:
            if (!CommonCommands.IsInModel())
            {
                ed.WriteMessage("\nThis command can only be used in model!");
                return;
            }

            //Get UCS's type:
            PromptKeywordOptions pkwo = new PromptKeywordOptions("\nSelect:");
            pkwo.AllowArbitraryInput = false;
            pkwo.AllowNone = false;
            List<KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>> kwLst = 
                                        new List<KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>>()
            {
                    new KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>("Top",KRCADUcs.KRUcs_Top),
                    new KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>("Bottom",KRCADUcs.KRUcs_Bottom),
                    new KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>("Front",KRCADUcs.KRUcs_Front),
                    new KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>("Back",KRCADUcs.KRUcs_Back),
                    new KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>("Left",KRCADUcs.KRUcs_Left),
                    new KeyValuePair<string, Tuple<string, Vector3d, Vector3d>>("Right",KRCADUcs.KRUcs_Right),
            };

            for (int i = 0; i < kwLst.Count; i++)
            {
                pkwo.Keywords.Add(kwLst[i].Key);
            }
            pkwo.Keywords.Add("Axis");
            pkwo.Keywords.Default = kwLst[0].Key;
          
            PromptResult pr = ed.GetKeywords(pkwo);
            if (pr.Status != PromptStatus.OK)
            {
                ed.WriteMessage("\nCannot get Ucs's type!");
                return;
            }

            //Change UCS:
            if (pr.StringResult != "Axis")
            {
                //Get base point(WCS):
                PromptPointOptions ppo = new PromptPointOptions("\nSelect base point:");
                ppo.AllowArbitraryInput = false;
                ppo.AllowNone = false;
                ppo.UseBasePoint = true;
                ppo.BasePoint = Point3d.Origin;
                ppo.Keywords.Add("Origin");
                ppo.Keywords.Default = "Origin";

                Point3d basePntWcs;
                PromptPointResult ppr = ed.GetPoint(ppo);
                if (ppr.Status == PromptStatus.Cancel ||
                    ppr.Status == PromptStatus.Error)
                {
                    ed.WriteMessage("\nCannot get base point!");
                    return;
                }
                else if (ppr.Status == PromptStatus.Keyword)
                {
                    //basePntWcs = Point3d.Origin.TransformBy(ed.CurrentUserCoordinateSystem);
                    basePntWcs = Point3d.Origin;
                }
                else
                {
                    basePntWcs = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
                }

                if (kwLst.Exists(a => a.Key == pr.StringResult))
                {
                    var foundItem = kwLst.Find(a => a.Key == pr.StringResult);

                    //Create & set location:
                    if (!KRCADUcs.HasUcs(foundItem.Value))
                    {
                        if (KRCADUcs.CreateUcs(foundItem.Value, basePntWcs) == ObjectId.Null)
                        {
                            ed.WriteMessage($"\nCannot create '{foundItem.Value.Item1}'!");
                            return;
                        }
                    }
                    else
                    {
                        if (!KRCADUcs.SetUcsLocation(foundItem.Value.Item1, basePntWcs))
                        {
                            ed.WriteMessage("\nCannot set location for UCS!");
                            return;
                        }
                    }

                    //Activate Ucs:
                    using (KRResetSystemVar resetViewCube = new KRResetSystemVar("DISPLAYVIEWCUBEIN2D", 0))
                    {
                        using (Transaction tr = db.TransactionManager.StartTransaction())
                        {
                            UcsTable ucsTb = tr.GetObject(db.UcsTableId, OpenMode.ForRead) as UcsTable;

                            if (!ucsTb.Has(foundItem.Value.Item1))
                            {
                                ed.WriteMessage($"\nCannot read '{foundItem.Value.Item1}'");
                                tr.Abort();
                                return;
                            }
                            else
                            {
                                //Get viewport:
                                ObjectId ucsTbRcId = ucsTb[foundItem.Value.Item1];

                                //Get current ViewportTableRecord:
                                ViewportTableRecord vpTbRc = null;
                                //vpTbRc = tr.GetObject(doc.Editor.ActiveViewportId, OpenMode.ForWrite) as ViewportTableRecord;
                                if (db.CurrentViewportTableRecordId == ObjectId.Null)
                                {
                                    ed.WriteMessage("\nCannot get current Database's ViewportTableRecordId!");
                                    tr.Abort();
                                    return;
                                }
                                else
                                {
                                    try
                                    {
                                        vpTbRc = tr.GetObject(db.CurrentViewportTableRecordId, OpenMode.ForWrite) as ViewportTableRecord;

                                        if (vpTbRc == null)
                                        {
                                            ed.WriteMessage("\nCannot open current Database's ViewportTableRecord for write!");
                                            tr.Abort();
                                            return;
                                        }
                                    }
                                    catch (System.Exception ex)
                                    {
                                        ed.WriteMessage($"\nError when opening current Database's ViewportTableRecord.\nError: {ex.Message}");
                                        tr.Abort();
                                        return;
                                    }
                                }

                                //Display the UCS Icon at the origin of the current viewport:
                                vpTbRc.IconAtOrigin = true;
                                vpTbRc.IconEnabled = true;

                                //Set ucs:
                                bool oldUcsSaved = vpTbRc.UcsSavedWithViewport;

                                try
                                {
                                    if (!vpTbRc.UcsSavedWithViewport)
                                    {
                                        vpTbRc.UcsSavedWithViewport = true;
                                    }

                                    vpTbRc.SetUcs(ucsTbRcId);
                                    doc.Editor.UpdateTiledViewportsFromDatabase();
                                }
                                catch (System.Exception ex)
                                {
                                    ed.WriteMessage($"\nError when setting Ucs to current view.\nError: {ex.Message}");
                                    tr.Abort();
                                    return;
                                }
                                finally
                                {
                                    if (oldUcsSaved != vpTbRc.UcsSavedWithViewport)
                                    {
                                        vpTbRc.UcsSavedWithViewport = oldUcsSaved;
                                    }
                                }
                            }

                            tr.Commit();
                        }

                        //Set view to isometric:
                        HelpMethod.SetViewDirection(_IsoMetricViewVector);

                        ////Zoom extent:
                        //ed.ZoomExtents();
                        dynamic comAcAp = Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication;
                        comAcAp.ZoomExtents();
                    }
                }
                else
                {
                    ed.WriteMessage("\nCannot find valid keyword!");
                    return;
                }
            }
            else
            {
                //ed.WriteMessage("\nOn building!");

                #region [Get nested curve]
                PromptNestedEntityOptions pneo = new PromptNestedEntityOptions("\nSelect curve: ")
                {
                    AllowNone = true,
                };

                PromptNestedEntityResult pner = ed.GetNestedEntity(pneo);
                if (pner.Status == PromptStatus.Cancel ||
                    pner.Status == PromptStatus.Error)
                {
                    //tr.Abort();
                    return;
                }

                bool isValidInput = pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Curve)));
                if (isValidInput == false && pner.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                    isValidInput = true;

                while (!isValidInput)
                {
                    ed.WriteMessage("\nInvalid selection!");
                    pner = ed.GetNestedEntity(pneo);
                    if (pner.Status == PromptStatus.Cancel ||
                        pner.Status == PromptStatus.Error)
                    {
                        //tr.Abort();
                        return;
                    }
                    else
                    {
                        isValidInput = pner.ObjectId.ObjectClass.IsDerivedFrom(RXClass.GetClass(typeof(Curve)));
                        if (isValidInput == false && pner.ObjectId.ObjectClass.Name == "AcDb2dVertex")
                            isValidInput = true;
                    }
                }
                #endregion

                //Get new UCS's base information:
                Point3d basePntUcs , basePntWcs , xAxisPntWcs , yAxisPntWcs;
                Vector3d newXAxisVec , newYAxisVec;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    Entity ent = tr.GetObject(pner.ObjectId, OpenMode.ForRead) as Entity;
                    Curve dirCurv;
                    if (ent is Vertex2d ver2d)
                    {
                        dirCurv = tr.GetObject(ver2d.OwnerId, OpenMode.ForRead) as Curve;
                    }
                    else
                    {
                        dirCurv = (Curve)ent;
                    }

                    Point3d pickPntUcs = pner.PickedPoint;
                    Point3d pickPntWcs = pickPntUcs.TransformBy(ed.CurrentUserCoordinateSystem);
                    Point3d pickPntEcs = pickPntWcs.TransformBy(pner.Transform.Inverse());
                    Point3d cloPntEcs = dirCurv.GetClosestPointTo(pickPntEcs, false);
                    Vector3d dirVecEcs;

                    try
                    {
                        dirVecEcs = dirCurv.GetFirstDerivative(cloPntEcs);
                    }
                    catch (System.Exception ex)
                    {
                        ed.WriteMessage($"\nCannot get direction vector. Error: {ex.Message}");
                        return;
                    }
                    Vector3d dirVecWcs = dirVecEcs.TransformBy(pner.Transform);

                    //Get base point(WCS):
                    PromptPointOptions ppo = new PromptPointOptions("\nSelect base point:");
                    ppo.AllowArbitraryInput = false;
                    ppo.AllowNone = false;
                    ppo.UseBasePoint = true;
                    ppo.BasePoint = Point3d.Origin;
                    ppo.Keywords.Add("Origin");
                    ppo.Keywords.Default = "Origin";

                    PromptPointResult ppr = ed.GetPoint(ppo);
                    if (ppr.Status == PromptStatus.Cancel || 
                        ppr.Status == PromptStatus.Error)
                    {
                        ed.WriteMessage("\nCannot get base point!");
                        tr.Commit();
                        return;
                    }
                    else if (ppr.Status == PromptStatus.Keyword)
                    {
                        basePntUcs = basePntWcs = Point3d.Origin;
                    }
                    else
                    {
                        basePntUcs = ppr.Value;
                        basePntWcs = basePntUcs.TransformBy(ed.CurrentUserCoordinateSystem);
                    }

                    //Normal plane (WCS):
                    Plane normalPl = new Plane(basePntWcs, dirVecWcs);

                    //Pick 1 point for XAxis:
                    ppo.BasePoint = basePntUcs;
                    ppo.Message = "\nPoint for XAxis: ";
                    ppr = ed.GetPoint(ppo);
                    if (ppr.Status == PromptStatus.Cancel || 
                        ppr.Status == PromptStatus.Error)
                    {
                        ed.WriteMessage("\nCannot get point for XAxis!");
                        tr.Commit();
                        return;
                    }
                    else
                    {
                        xAxisPntWcs = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
                        xAxisPntWcs = xAxisPntWcs.OrthoProject(normalPl);
                    }

                    //Vector for new XAxis:
                    newXAxisVec = basePntWcs.GetVectorTo(xAxisPntWcs);
                    if (newXAxisVec.IsZeroLength())
                    {
                        ed.WriteMessage("\nXAxis vector is not valid!");
                        return;
                    }

                    //One 1 point for XAxis:
                    ppo.BasePoint = basePntUcs;
                    ppo.Message = "\nPoint for YAxis: ";
                    ppr = ed.GetPoint(ppo);
                    if (ppr.Status == PromptStatus.Cancel ||
                        ppr.Status == PromptStatus.Error)
                    {
                        ed.WriteMessage("\nCannot get point for YAxis!");
                        tr.Commit();
                        return;
                    }
                    else
                    {
                        yAxisPntWcs = ppr.Value.TransformBy(ed.CurrentUserCoordinateSystem);
                        yAxisPntWcs = yAxisPntWcs.OrthoProject(normalPl);
                        Plane vecContainPl = new Plane(basePntWcs, newXAxisVec);
                        yAxisPntWcs = yAxisPntWcs.OrthoProject(vecContainPl);
                    }

                    //Vector for new YAxis:
                    newYAxisVec = basePntWcs.GetVectorTo(yAxisPntWcs);
                    if (newYAxisVec.IsZeroLength())
                    {
                        ed.WriteMessage("\nYAxis vector is not valid!");
                        return;
                    }

                    //Check XAxis & YAxis is perpendicular ?
                    if (!newXAxisVec.IsPerpendicularTo(newYAxisVec))
                    {
                        ed.WriteMessage("\nXAxis & YAxis is not perpendicular!");
                        return;
                    }

                    tr.Commit();
                }

                //Create new UCS:
                try
                {
                    using (Transaction tr = db.TransactionManager.StartTransaction())
                    {
                        UcsTable ucsTb = tr.GetObject(db.UcsTableId, OpenMode.ForRead) as UcsTable;
                        string cusUcsTbName = "KRUcs_Custom";
                        ObjectId ucsTbRcId = ObjectId.Null;
                        if (!ucsTb.Has(cusUcsTbName))
                        {
                            using (UcsTableRecord ucsTbRc = new UcsTableRecord())
                            {
                                ucsTbRc.Name = cusUcsTbName;

                                ucsTbRc.Origin = basePntWcs;
                                ucsTbRc.XAxis = newXAxisVec;
                                ucsTbRc.YAxis = newYAxisVec;

                                ucsTb.UpgradeOpen();
                                ucsTbRcId = ucsTb.Add(ucsTbRc);
                                tr.AddNewlyCreatedDBObject(ucsTbRc, true);
                            }
                        }
                        else
                        {
                            UcsTableRecord ucsTbRc = tr.GetObject(ucsTb[cusUcsTbName], OpenMode.ForWrite) as UcsTableRecord;

                            ucsTbRc.Origin = basePntWcs;
                            ucsTbRc.XAxis = newXAxisVec;
                            ucsTbRc.YAxis = newYAxisVec;

                            ucsTbRcId = ucsTbRc.ObjectId;
                        }

                        if (ucsTbRcId != ObjectId.Null)
                        {
                            //Get current ViewportTableRecord:
                            ViewportTableRecord vpTbRc = null;
                            //vpTbRc = tr.GetObject(doc.Editor.ActiveViewportId, OpenMode.ForWrite) as ViewportTableRecord;
                            if (db.CurrentViewportTableRecordId == ObjectId.Null)
                            {
                                ed.WriteMessage("\nCannot get current Database's ViewportTableRecordId!");
                                tr.Abort();
                                return;
                            }
                            else
                            {
                                try
                                {
                                    vpTbRc = tr.GetObject(db.CurrentViewportTableRecordId, OpenMode.ForWrite) as ViewportTableRecord;

                                    if (vpTbRc == null)
                                    {
                                        ed.WriteMessage("\nCannot open current Database's ViewportTableRecord for write!");
                                        tr.Abort();
                                        return;
                                    }
                                }
                                catch (System.Exception ex)
                                {
                                    ed.WriteMessage($"\nError when opening current Database's ViewportTableRecord.\nError: {ex.Message}");
                                    tr.Abort();
                                    return;
                                }
                            }

                            vpTbRc.IconAtOrigin = true;
                            vpTbRc.IconEnabled = true;

                            //vpTbRc.SetUcs(ucsTbRcId);
                            //ed.UpdateTiledViewportsFromDatabase();

                            //Set ucs:
                            bool oldUcsSaved = vpTbRc.UcsSavedWithViewport;

                            try
                            {
                                if (!vpTbRc.UcsSavedWithViewport)
                                {
                                    vpTbRc.UcsSavedWithViewport = true;
                                }

                                vpTbRc.SetUcs(ucsTbRcId);
                                doc.Editor.UpdateTiledViewportsFromDatabase();
                            }
                            catch (System.Exception ex)
                            {
                                ed.WriteMessage($"\nError when setting Ucs to current view.\nError: {ex.Message}");
                                tr.Abort();
                                return;
                            }
                            finally
                            {
                                if (oldUcsSaved != vpTbRc.UcsSavedWithViewport)
                                {
                                    vpTbRc.UcsSavedWithViewport = oldUcsSaved;
                                }
                            }
                        }
                        else
                        {
                            ed.WriteMessage("\nCannot get custom UCS's ObjectID!");
                            tr.Abort();
                            return;
                        }

                        tr.Commit();
                    }

                    //Set view to isometric:
                    HelpMethod.SetViewDirection(_IsoMetricViewVector);

                    ////Zoom extent:
                    //ed.ZoomExtents();
                    dynamic comAcAp = Autodesk.AutoCAD.ApplicationServices.Application.AcadApplication;
                    comAcAp.ZoomExtents();
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage($"\nCannot create UCS. Error: {ex.Message}");
                    return;
                }
            }
        }
    }
}

namespace AcadAddin.Sheetset
{
    //https://adndevblog.typepad.com/autocad/2013/09/using-sheetset-manager-api-in-vbnet.html
    //https://forums.autodesk.com/t5/net/default-directory-using-autodesk-autocad-windows-openfiledialog/td-p/8931314
    //https://forums.autodesk.com/t5/net/get-active-sheet-set-properties/td-p/9814065
    //https://blog.jtbworld.com/2005/01/sheet-set-manager-api-code-sample-for.html
    //https://blog.jtbworld.com/2006/04/sheet-set-manager-code-snippets.html

    public class AcSmType
    {
        public const string AcSmSheet = "AcSmSheet";
        public const string AcSmSubset = "AcSmSubset";
    }

    public class HelpMethods
    {
        //Method to lock sheet set database:
        //You need to do this before make change on database.
        public static bool LockSheetSetDb(ref AcSmDatabase ssDb, bool lockFlag)
        {
            if (lockFlag == true && ssDb.GetLockStatus() == 
                AcSmLockStatus.AcSmLockStatus_UnLocked)
            {
                ssDb.LockDb(ssDb);
                return true;
            }
            else if (lockFlag == false && ssDb.GetLockStatus() == 
                AcSmLockStatus.AcSmLockStatus_Locked_Local)
            {
                ssDb.UnlockDb(ssDb);
                return true;
            }
            else
            {
                return false;
            }
        }

        //Method to count number of opened sheetsets:
        public static int OpenedSheetSetNum()
        {
            int readError = -1;
            int count = 0;

            //Get a reference to the Sheet Set Manager object
            IAcSmSheetSetMgr ssMgr = new AcSmSheetSetMgr();
            if (ssMgr == null)
            {
                return readError;
            }

            //Get enum for database.
            //Use this to iterate SheetSet database object:
            IAcSmEnumDatabase databaseEnum = ssMgr.GetDatabaseEnumerator();
            if (databaseEnum == null)
            {
                return readError;
            }
            else
            {
                databaseEnum.Reset();
            }

            AcSmDatabase ssDb = null;
            try
            {
                //Get first database:
                ssDb = databaseEnum.Next();

                if (ssDb == null)
                {
                    return readError;
                }
                else
                {
                    while (ssDb != null)
                    {
                        count += 1;

                        ssDb = null;

                        //Get reference to next database:
                        ssDb = databaseEnum.Next();
                    }

                    return count;
                }
            }
            catch (System.Exception)
            {
                return readError;
            }
            //finally
            //{
            //    if (ssDb != null)
            //    {
            //        ssMgr.Close(ssDb);
            //    }
            //}
        }

        [Obsolete("Use method with skip number instead!")]
        public static void SheetSet_SubNumbering(IAcSmComponent component, ref int count)
        {
            IAcSmEnumComponent subEnum = (component as AcSmSubset).GetSheetEnumerator();

            IAcSmComponent subComponent = subEnum.Next();

            while (subComponent != null)
            {
                if (subComponent.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSheet)
                {
                    if (count != 0)
                    {
                        (subComponent as AcSmSheet).SetNumber(count.ToString());
                        count += 1;
                    }
                    else
                    {
                        (subComponent as AcSmSheet).SetNumber("　");
                    }
                }
                else if (subComponent.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSubset)
                {
                    //De quy:
                    SheetSet_SubNumbering(subComponent, ref count);
                }

                subComponent = subEnum.Next();
            }
        }

        //Method to renumber folder & its inside subfolders with skip numbers:
        public static void SheetSet_SubNumbering(IAcSmComponent component, ref int count, 
            ref System.Collections.Generic.List<int> skipNumbers , string newLayoutName = default)
        {
            IAcSmEnumComponent subEnum = (component as AcSmSubset).GetSheetEnumerator();

            IAcSmComponent subComponent = subEnum.Next();

            while (subComponent != null)
            {
                if (subComponent.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSheet)
                {
                    if (count != 0)
                    {
                        while (skipNumbers.Count > 0 && skipNumbers.Contains(count))
                        {
                            //Get value of count:
                            // - Do this because count is by ref.
                            int tempInt = count;

                            //Find item in list equal to count:
                            var findItem = skipNumbers.Find(a => a.Equals(tempInt));
                            if (findItem != default)
                            {
                                //Remove found list' item:
                                skipNumbers.RemoveAt(skipNumbers.IndexOf(findItem));
                            }

                            //Increase count:
                            count += 1;
                        }

                        AcSmSheet tempSheet = (subComponent as AcSmSheet);
                        tempSheet.SetNumber(count.ToString());

                        //Rename sheet tile:
                        if (newLayoutName != default)
                        {
                            tempSheet.SetTitle(newLayoutName + "-" + count.ToString());
                        }

                        count += 1;
                    }
                    else
                    {
                        //(subComponent as AcSmSheet).SetNumber("　");
                        AcSmSheet tempSheet = (subComponent as AcSmSheet);
                        tempSheet.SetNumber("　");

                        //Rename sheet tile:
                        if (newLayoutName != default)
                        {
                            tempSheet.SetTitle(newLayoutName);
                        }

                        //AcSmAcDbLayoutReference layout = tempSheet.GetLayout();
                        //layout.SetName(newLayoutName);
                        //tempSheet.SetLayout(layout);
                    }
                }
                else if (subComponent.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSubset)
                {
                    //De quy:
                    SheetSet_SubNumbering(subComponent , ref count , ref skipNumbers , newLayoutName);
                }

                subComponent = subEnum.Next();
            }
        }

        //Method to find component in entire sheet set by its handle:
        public static IAcSmComponent GetSheetComponent(AcSmSheetSet sSet, string comHnd)
        {
            IAcSmComponent retObj = null;

            IAcSmEnumComponent sheetEnum = sSet.GetSheetEnumerator();

            IAcSmComponent component = sheetEnum.Next();

            while (component != null)
            {
                if (component.GetObjectId().GetHandle() == comHnd)
                {
                    retObj = component;
                    return retObj;
                }

                if (component.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSubset)
                {
                    retObj = GetSheetComponent(component as AcSmSubset, comHnd);
                    if (retObj != null)
                    {
                        return retObj;
                    }
                }

                component = sheetEnum.Next();
            }

            return retObj;
        }

        //Method to find component in subset by its handle:
        public static IAcSmComponent GetSheetComponent(AcSmSubset subSet, string comHnd)
        {
            IAcSmComponent retObj = null;

            IAcSmEnumComponent subEnum = subSet.GetSheetEnumerator();

            IAcSmComponent subComponent = subEnum.Next();

            while (subComponent != null)
            {
                if (subComponent.GetObjectId().GetHandle() == comHnd)
                {
                    retObj = subComponent;
                    return retObj;
                }

                if (subComponent.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSubset)
                {
                    retObj = GetSheetComponent(subComponent as AcSmSubset, comHnd);
                    if (retObj != null)
                    {
                        return retObj;
                    }
                }

                subComponent = subEnum.Next();
            }

            return retObj;
        }

        //Method to get all file full paths for layouts inside subset:
        public static void GetFileFullPaths(AcSmSubset subSet,
                            ref System.Collections.Generic.List<string> fileFullPaths)
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;

            IAcSmEnumComponent subEnum = subSet.GetSheetEnumerator();
            IAcSmComponent subComponent = subEnum.Next();
            while (subComponent != null)
            {
                if (subComponent.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSheet)
                {
                    AcSmSheet memSheet = subComponent as AcSmSheet;
                    AcSmAcDbLayoutReference layout = memSheet.GetLayout();
                    string srcFileName;

                    try
                    {
                        //Get source file name
                        srcFileName = layout.ResolveFileName();

                        if (!string.IsNullOrEmpty(srcFileName) &&
                            !string.IsNullOrWhiteSpace(srcFileName) &&
                            !fileFullPaths.Contains(srcFileName))
                        {
                            //ed.WriteMessage($"\nSource file name {srcFileName}");
                            fileFullPaths.Add(srcFileName);
                        }
                    }
                    catch (System.Exception ex)
                    {
                        ed.WriteMessage($"\nError: {ex.Message}");
                        //continue;
                        //return;
                    }
                }
                else if (subComponent.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSubset)
                {
                    //De quy:
                    AcadAddin.Sheetset.HelpMethods.GetFileFullPaths(subComponent as AcSmSubset, ref fileFullPaths);
                }

                subComponent = subEnum.Next();
            }
            //return okRet;
        }

        //Method to synchronize Sheet tile and layout name in subset:
        //https://blog.jtbworld.com/2005/01/sheet-set-manager-api-code-sample-for.html
        //SheetTileLayoutNameSync
    }

    public class Commands
    {
        private static AcadAddin.Sheetset.SheetSetReNumForm _SheetSetReNumFrm;

        //Command to renumber sheet set:
        [CommandMethod("SSNum")]
        public void CmdSheetSetNumber()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            //Check number of opened sheet set:
            int openedSSNumber = AcadAddin.Sheetset.HelpMethods.OpenedSheetSetNum();
            if (openedSSNumber < 0)
            {
                ed.WriteMessage("\nError when reading Sheet Set!");
                return;
            }
            else if (openedSSNumber >= 2)
            {
                ed.WriteMessage("\nMore than one Sheet Set are open. Make sure only one is opened!");
                return;
            }

            //Get a reference to the Sheet Set Manager object
            IAcSmSheetSetMgr ssMgr = new AcSmSheetSetMgr();
            if (ssMgr == null)
            {
                ed.WriteMessage("\nCannot reference to Sheet Set Manager object!");
                return;
            }

            #region [Unlock this for select sheetset by dialog]
            //string ssPath = "";
            //var openFileDialog = new Autodesk.AutoCAD.Windows.OpenFileDialog(
            //         "Select SheetSet file",
            //         "",
            //         //@"C:\",
            //         "dst",
            //         "Open SheetSet",
            //         0
            //         //Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.SearchPath
            //         //Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.AllowAnyExtension
            //         //Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.AllowFoldersOnly |
            //         //Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.DefaultIsFolder |
            //         //Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.ForceDefaultFolder
            //         );

            //System.Windows.Forms.DialogResult dlgRes = openFileDialog.ShowDialog();
            //if (dlgRes != System.Windows.Forms.DialogResult.OK)
            //{
            //    ed.WriteMessage("\nInvalid selection!");
            //    return;
            //}
            //else
            //{
            //    ssPath = openFileDialog.Filename;
            //}

            //ed.WriteMessage($"\n{ssPath}");
            #endregion

            PromptKeywordOptions pko = new PromptKeywordOptions("");
            pko.Message = "\nSelect: ";
            pko.AllowArbitraryInput = false;
            pko.AllowNone = false;

            System.Collections.Generic.List<string> kwLst = new System.Collections.Generic.List<string>();
            kwLst.Add("All");
            kwLst.Add("Subfolder");

            for (int i = 0; i < kwLst.Count; i++)
            {
                pko.Keywords.Add(kwLst[i]);
            }
            pko.Keywords.Default = kwLst[1];

            PromptResult pr = ed.GetKeywords(pko);
            if (pr.Status == PromptStatus.Cancel)
            {
                return;
            }
            else if (pr.Status == PromptStatus.Error || 
                     pr.Status == PromptStatus.None)
            {
                ed.WriteMessage("\nCannot get renumbering type!");
                return;
            }

            if (pr.StringResult == kwLst[0])
            {
                //Get start number:
                PromptIntegerOptions pio = new PromptIntegerOptions("");
                pio.Message = "\nFirst number: ";
                pio.AllowNone = false;
                pio.AllowArbitraryInput = false;
                pio.AllowNegative = false;
                pio.AllowZero = true;
                pio.DefaultValue = 0;

                ed.WriteMessage("\n※Use '0' for dummy index.");
                PromptIntegerResult pir = ed.GetInteger(pio);
                if (pir.Status == PromptStatus.Cancel)
                {
                    return;
                }
                else if(pir.Status == PromptStatus.Error ||
                        pir.Status == PromptStatus.None)
                {
                    ed.WriteMessage("\nCannot get start number!");
                    return;
                }

                AcSmDatabase ssDb = null;
                try
                {
                    //ssDb = ssMgr.OpenDatabase(ssPath, false);
                    //ssDb = ssMgr.FindOpenDatabase(ssPath);

                    //Get enum for database:
                    IAcSmEnumDatabase databaseEnum = ssMgr.GetDatabaseEnumerator();

                    //Get first database:
                    ssDb = databaseEnum.Next();
                    if (ssDb == null)
                    {
                        ed.WriteMessage("\nCannot get Sheet Set database object!");
                        return;
                    }

                    //Get sheet set object:
                    AcSmSheetSet sSet = ssDb.GetSheetSet();
                    if (sSet == null)
                    {
                        ed.WriteMessage("\nCannot get Sheet Set object!");
                        return;
                    }

                    #region [Sheet selection - Sample]
                    //////Find current selected component location:
                    //AcSmSheetSelSets sheetSelSets = sSet.GetSheetSelSets();
                    //if (sheetSelSets == null)
                    //{
                    //    ed.WriteMessage("\nCannot get sheet selection set!");
                    //    return;
                    //}

                    ////IAcSmEnumComponent ssEnumCom;
                    //IAcSmEnumSheetSelSet ssEnumSelSet = sheetSelSets.GetEnumerator();
                    //if (ssEnumSelSet == null)
                    //{
                    //    ed.WriteMessage("\nCannot get enum for Sheet selection set!");
                    //    return;
                    //}

                    //int testCount = 0;

                    //AcSmSheetSelSet ssSelSet = null;
                    //ssSelSet = ssEnumSelSet.Next();
                    //while (ssSelSet != null)
                    //{
                    //    //ed.WriteMessage($"\nOwner: {ssSelSet.GetOwner()}");
                    //    //ssSelSet = null;
                    //    testCount += 1;
                    //    ssSelSet = null;
                    //    ssSelSet = ssEnumSelSet.Next();
                    //}

                    //ed.WriteMessage($"\nTest count : {testCount}");
                    #endregion

                    //Lock SheetSet database before make changes on it:
                    if (AcadAddin.Sheetset.HelpMethods.LockSheetSetDb(ref ssDb, true))
                    {
                        //IAcSmEnumPersist sEnumPer = ssDb.GetEnumerator();
                        //IAcSmComponent item = sheetEnum.Next();

                        IAcSmEnumComponent sheetEnum = sSet.GetSheetEnumerator();

                        IAcSmComponent component = sheetEnum.Next();

                        int count = pir.Value;

                        while (component != null)
                        {
                            if (component.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSheet)
                            {
                                if (count != 0 )
                                {
                                    (component as AcSmSheet).SetNumber(count.ToString());
                                    count += 1;
                                }
                                else
                                {
                                    (component as AcSmSheet).SetNumber("　");
                                }
                            }
                            else if (component.GetTypeName() == AcadAddin.Sheetset.AcSmType.AcSmSubset)
                            {
                                //Skip number list with no member indicate that no number need to be skipped:
                                System.Collections.Generic.List<int> skipNumLst = new System.Collections.Generic.List<int>();

                                //Call help method:
                                AcadAddin.Sheetset.HelpMethods.SheetSet_SubNumbering(component, ref count , ref skipNumLst);
                            }

                            component = sheetEnum.Next();
                        }

                        //object acComDb = db.AcadDatabase;
                        //sSet.Sync(acComDb as AXDBLib.AcadDatabase);

                        //Unlock SheetSet database:
                        if (!AcadAddin.Sheetset.HelpMethods.LockSheetSetDb(ref ssDb, false))
                        {
                            ed.WriteMessage("\nCannot unlock sheet set. Please reset it manually!");
                        }
                    }
                    else
                    {
                        ed.WriteMessage("\nSheet set cannot be opened for write!");
                        return;
                    }
                }
                catch (System.Exception ex)
                {
                    ed.WriteMessage($"\nError: {ex.Message}");
                    return;
                }
                finally
                {
                    //// ***Close database here can cause Sheet set have STRANGE BEHAVIOR
                    //// ***Consider to do this when work with external Sheet set database ???
                    //if (ssDb != null)
                    //{
                    //    ssMgr.Close(ssDb);
                    //}
                }
            }
            else
            {
                //ed.WriteMessage("\nOn building. Please come back later!");
                if (_SheetSetReNumFrm == null)
                    _SheetSetReNumFrm = new AcadAddin.Sheetset.SheetSetReNumForm(ssMgr);
                else if (_SheetSetReNumFrm.IsDisposed == true)
                {
                    //Clear old instance :
                    _SheetSetReNumFrm = null;

                    //Create new instance :
                    _SheetSetReNumFrm = new AcadAddin.Sheetset.SheetSetReNumForm(ssMgr);
                }

                if (_SheetSetReNumFrm.IsReadyToShow != true)
                {
                    _SheetSetReNumFrm.Dispose();
                    ed.WriteMessage("\nFail to show form!");
                    return;
                }

                if(_SheetSetReNumFrm.LoadTreeViewData(out string errMsg) != true)
                {
                    _SheetSetReNumFrm.Dispose();
                    ed.WriteMessage($"\nError: {errMsg}");
                    return;
                }

                //Show/ activate form:
                if (_SheetSetReNumFrm.Visible == false)
                {
                    AcAp.ShowModelessDialog(null, _SheetSetReNumFrm, false);
                }
                else
                {
                    _SheetSetReNumFrm.Activate();
                }
            }
        }
    }
}

#region [Namespaces for samples]

namespace SampleLinkCircles
{
    public class LinkedObjectManager
    {
        Dictionary<ObjectId, ObjectIdCollection> m_dict;

        // Constructor
        public LinkedObjectManager()
        {
            m_dict = new Dictionary<ObjectId, ObjectIdCollection>();
        }

        // Create a bi-directional link between two objects
        public void LinkObjects(ObjectId from, ObjectId to)

        {
            CreateLink(from, to);
            CreateLink(to, from);
        }

        // Helper function to create a one-way
        // link between objects
        private void CreateLink(ObjectId from, ObjectId to)
        {

            ObjectIdCollection existingList;
            if (m_dict.TryGetValue(from, out existingList))
            {
                if (!existingList.Contains(to))
                {
                    existingList.Add(to);
                    m_dict.Remove(from);
                    m_dict.Add(from, existingList);
                }
            }
            else
            {
                ObjectIdCollection newList = new ObjectIdCollection();
                newList.Add(to);
                m_dict.Add(from, newList);
            }

        }

        // Remove bi-directional links from an object
        public void RemoveLinks(ObjectId from)
        {
            ObjectIdCollection existingList;
            if (m_dict.TryGetValue(from, out existingList))
            {
                m_dict.Remove(from);
                foreach (ObjectId id in existingList)

                {
                    RemoveFromList(id, from);
                }
            }
        }

        // Helper function to remove an object reference
        // from a list (assumes the overall list should
        // remain)
        private void RemoveFromList(ObjectId key, ObjectId toremove)
        {
            ObjectIdCollection existingList;
            if (m_dict.TryGetValue(key, out existingList))
            {
                if (existingList.Contains(toremove))
                {
                    existingList.Remove(toremove);
                    m_dict.Remove(key);
                    m_dict.Add(key, existingList);
                }
            }
        }

        // Return the list of objects linked to
        // the one passed in
        public ObjectIdCollection GetLinkedObjects(ObjectId from)
        {
            ObjectIdCollection existingList;
            m_dict.TryGetValue(from, out existingList);
            return existingList;
        }

        // Check whether the dictionary contains
        // a particular key
        public bool Contains(ObjectId key)
        {
            return m_dict.ContainsKey(key);
        }
    }

    public class LinkingCommands
    {
        LinkedObjectManager m_linkManager;
        ObjectIdCollection m_entitiesToUpdate;
        public LinkingCommands()
        {
            Document doc =

            Application.DocumentManager.MdiActiveDocument;

            Database db = doc.Database;

            db.ObjectModified += new ObjectEventHandler(OnObjectModified);
            db.ObjectErased += new ObjectErasedEventHandler(OnObjectErased);
            doc.CommandEnded += new CommandEventHandler(OnCommandEnded);

            m_linkManager = new LinkedObjectManager();
            
            m_entitiesToUpdate = new ObjectIdCollection();
        }

        ~LinkingCommands()
        {
            try
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                Database db = doc.Database;
                db.ObjectModified -= new ObjectEventHandler(OnObjectModified);
                db.ObjectErased -= new ObjectErasedEventHandler(OnObjectErased);
                doc.CommandEnded += new CommandEventHandler(OnCommandEnded);
            }
            catch (System.Exception)
            {
                // The document or database may no longer
                // be available on unload



            }
        }

        // Define "LINK" command
        [CommandMethod("CirsLink")]
        public void LinkEntities()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            PromptEntityOptions opts = new PromptEntityOptions("\nSelect first circle to link: ");
            opts.AllowNone = true;
            opts.SetRejectMessage("\nOnly circles can be selected.");
            opts.AddAllowedClass(typeof(Circle), false);

            PromptEntityResult res = ed.GetEntity(opts);
            if (res.Status == PromptStatus.OK)
            {
                ObjectId from = res.ObjectId;
                opts.Message = "\nSelect second circle to link: ";
                res = ed.GetEntity(opts);
                if (res.Status == PromptStatus.OK)
                {
                    ObjectId to = res.ObjectId;
                    m_linkManager.LinkObjects(from, to);
                    m_entitiesToUpdate.Add(from);
                }
            }
        }

        // Define callback for Database.ObjectModified event
        private void OnObjectModified(object sender, ObjectEventArgs e)
        {
            ObjectId id = e.DBObject.ObjectId;
            if (m_linkManager.Contains(id) &&
                !m_entitiesToUpdate.Contains(id))
            {
                m_entitiesToUpdate.Add(id);
            }
        }

        // Define callback for Database.ObjectErased event
        private void OnObjectErased(object sender, ObjectErasedEventArgs e)
        {
            if (e.Erased)
            {
                m_linkManager.RemoveLinks(e.DBObject.ObjectId);
            }
        }

        // Define callback for Document.CommandEnded event
        private void OnCommandEnded(object sender, CommandEventArgs e)
        {
            foreach (ObjectId id in m_entitiesToUpdate)
            {
                UpdateLinkedEntities(id);
            }

            m_entitiesToUpdate.Clear();
        }

        // Helper function for OnCommandEnded
        private void UpdateLinkedEntities(ObjectId from)
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            ObjectIdCollection linked = m_linkManager.GetLinkedObjects(from);

            //Transaction tr =
            //db.TransactionManager.StartTransaction();
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {

                try
                {
                    Point3d firstCenter;
                    Point3d secondCenter;
                    double firstRadius;
                    double secondRadius;

                    Entity ent = (Entity)tr.GetObject(from, OpenMode.ForRead);

                    if (GetCenterAndRadius(ent,out firstCenter,out firstRadius))
                    {
                        foreach (ObjectId to in linked)
                        {
                            Entity ent2 = (Entity)tr.GetObject(to, OpenMode.ForRead);
                            if (GetCenterAndRadius(ent2,out secondCenter,out secondRadius))
                            {
                                Vector3d vec = firstCenter - secondCenter;
                                
                                if (!vec.IsZeroLength())
                                {
                                    // Only move the linked circle if it's not
                                    // already near enough               
                                    double apart = vec.Length - (firstRadius + secondRadius);

                                    if (apart < 0.0)
                                        apart = -apart;

                                    if (apart > 0.00001)
                                    {
                                        ent2.UpgradeOpen();
                                        ent2.TransformBy(Matrix3d.Displacement(vec.GetNormal() * apart)
                                       );
                                    }
                                }
                            }
                        }
                    }
                }
                catch (System.Exception ex)
                {

                    Autodesk.AutoCAD.Runtime.Exception ex2 = ex as Autodesk.AutoCAD.Runtime.Exception;

                    if (ex2 != null && ex2.ErrorStatus != ErrorStatus.WasOpenForUndo)
                    {
                        ed.WriteMessage("\nAutoCAD exception: {0}", ex2);
                    }
                    else if (ex2 == null)
                    {
                        ed.WriteMessage("\nSystem exception: {0}", ex);
                    }
                }

                tr.Commit();
            }
        }

        // Helper function to get the center and radius
        // for all supported circular objects
        private bool GetCenterAndRadius(Entity ent, out Point3d center, out double radius)
        {
            // For circles it's easy...
            Circle circle = ent as Circle;
            if (circle != null)
            {
                center = circle.Center;
                radius = circle.Radius;
                return true;
            }
            else
            {
                // Throw in some empty values...
                // Returning false indicates the object
                // passed in was not useable
                center = Point3d.Origin;
                radius = 0.0;
                return false;
            }
        }
    }

    public class Command
    {
        string appName = "MY_APP";

        [CommandMethod("SetXData")]
        public void AttachXDataToSelectionSetObjects()
        {
            // Get the current database and start a transaction
            Database acCurDb;
            acCurDb = Application.DocumentManager.MdiActiveDocument.Database;

            Document acDoc = Application.DocumentManager.MdiActiveDocument;

            //string appName = "MY_APP";
            string xdataStr = "This is some xdata";

            using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
            {
                // Request objects to be selected in the drawing area
                PromptSelectionResult acSSPrompt = acDoc.Editor.GetSelection();

                // If the prompt status is OK, objects were selected
                if (acSSPrompt.Status == PromptStatus.OK)
                {
                    // Open the Registered Applications table for read
                    RegAppTable acRegAppTbl;
                    acRegAppTbl = acTrans.GetObject(acCurDb.RegAppTableId, OpenMode.ForRead) as RegAppTable;

                    // Check to see if the Registered Applications table record for the custom app exists
                    if (acRegAppTbl.Has(appName) == false)
                    {
                        using (RegAppTableRecord acRegAppTblRec = new RegAppTableRecord())
                        {
                            acRegAppTblRec.Name = appName;

                            acTrans.GetObject(acCurDb.RegAppTableId, OpenMode.ForWrite);
                            acRegAppTbl.Add(acRegAppTblRec);
                            acTrans.AddNewlyCreatedDBObject(acRegAppTblRec, true);
                        }
                    }

                    // Define the Xdata to add to each selected object
                    using (ResultBuffer rb = new ResultBuffer())
                    {
                        rb.Add(new TypedValue((int)DxfCode.ExtendedDataRegAppName, appName));
                        rb.Add(new TypedValue((int)DxfCode.ExtendedDataAsciiString, xdataStr));

                        SelectionSet acSSet = acSSPrompt.Value;

                        // Step through the objects in the selection set
                        foreach (SelectedObject acSSObj in acSSet)
                        {
                            // Open the selected object for write
                            Entity acEnt = acTrans.GetObject(acSSObj.ObjectId,
                                                                OpenMode.ForWrite) as Entity;

                            // Append the extended data to each object
                            acEnt.XData = rb;
                        }
                    }
                }

                // Save the new object to the database
                acTrans.Commit();

                // Dispose of the transaction
            }
        }

        [CommandMethod("ViewXData")]
        public void ViewXData()
        {
            // Get the current database and start a transaction
            Database acCurDb;
            acCurDb = Application.DocumentManager.MdiActiveDocument.Database;

            Document acDoc = Application.DocumentManager.MdiActiveDocument;

            //string appName = "MY_APP";
            string msgstr = "";

            using (Transaction acTrans = acCurDb.TransactionManager.StartTransaction())
            {
                // Request objects to be selected in the drawing area
                PromptSelectionResult acSSPrompt = acDoc.Editor.GetSelection();

                // If the prompt status is OK, objects were selected
                if (acSSPrompt.Status == PromptStatus.OK)
                {
                    SelectionSet acSSet = acSSPrompt.Value;

                    // Step through the objects in the selection set
                    foreach (SelectedObject acSSObj in acSSet)
                    {
                        // Open the selected object for read
                        Entity acEnt = acTrans.GetObject(acSSObj.ObjectId,
                                                         OpenMode.ForRead) as Entity;

                        // Get the extended data attached to each object for MY_APP
                        ResultBuffer rb = acEnt.GetXDataForApplication(appName);

                        // Make sure the Xdata is not empty
                        if (rb != null)
                        {
                            // Get the values in the xdata
                            foreach (TypedValue typeVal in rb)
                            {
                                msgstr = msgstr + "\n" + typeVal.TypeCode.ToString() + ":" + typeVal.Value;
                            }
                        }
                        else
                        {
                            msgstr = "NONE";
                        }

                        // Display the values returned
                        Application.ShowAlertDialog(appName + " xdata on " + acEnt.GetType().ToString() + ":\n" + msgstr);

                        msgstr = "";
                    }
                }

                // Ends the transaction and ensures any changes made are ignored
                acTrans.Abort();

                // Dispose of the transaction
            }
        }

        //Idea 
        //1) Cần 1 XData app bên trong mỗi bãn vẽ có assoc center lines:
        //tên app này là KR-AssocCenterLines
        // mỗi circle có lưu XData app tên trên + value là 1 list các handle đến
        // lines liên kết.

        //2) cần 1 method được gọi lúc mở bản vẽ.
        //Mục đích là gán event objectmodified của các circle trên:

        //3) khi circle modified => app biết lines nào kiên kết => modifiled line đó.

        private const string AssocCenterAppName = "KR-AssocCenterLines";

        [CommandMethod("ACenterLine")]
        public void CmdACenterLine()
        {
            Document doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            PromptEntityOptions peo = new PromptEntityOptions("");
            peo.Message = "\nSelect a circle: ";
            peo.AllowNone = false;
            peo.AllowObjectOnLockedLayer = false;
            peo.SetRejectMessage("\nOnly circles can be selected!");
            peo.AddAllowedClass(typeof(Circle), true);

            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK)
            {
                return;
            }


            //ObjectId cirId = per.ObjectId;

            //peo.Message = "\nSelect first center line: ";
            //peo.SetRejectMessage("\nOnly lines can be selected!");
            //peo.AddAllowedClass(typeof(Line), true);
            //per = ed.GetEntity(peo);
            //if (per.Status != PromptStatus.OK)
            //{
            //    return;
            //}

            //ObjectId line1Id = per.ObjectId;

            //peo.Message = "\nSelect second center line: ";
            //per = ed.GetEntity(peo);
            //if (per.Status != PromptStatus.OK)
            //{
            //    return;
            //}





        }

        private void LinkCirLines(ObjectId cirId,ObjectId line1Id , ObjectId line2Id)
        {




        }
    }

}

namespace SampleSectionLine
{
    class NetSectionLine
    {
        AcadApplication acadApp;
        AcadDocument thisDrawing;

        public string DocName
        {
            get { return thisDrawing.Name; }
        }

        public NetSectionLine ()
        {
            acadApp = (AcadApplication)Autodesk.AutoCAD.ApplicationServices.
                        Application.AcadApplication;
            thisDrawing = acadApp.ActiveDocument;
        }

        public void CreateSectionLine()
        {
            McadSectionLine sectionline = thisDrawing.ModelSpace.AddCustomObject("AmdtSectionSym");

            // Set properties
            sectionline.ArrowVisibility = true;
            sectionline.PlaneSymbolsVisibility = true;
            sectionline.LineVisibility = McadLineVisibility.sbBetweenPlanes;

            //Set vertexes of section line
            double[] points = {12,13,0,
                                14,10,0 ,
                                13,8,0,
                                16,6,0
                              };

            double[] ArcPoints = { 13.5, 9, 0 };

            //' Set segment type of section line
            McadSectionLineSegmentType[] segmentTypes = {
                McadSectionLineSegmentType.sbLineSegment,
                McadSectionLineSegmentType.sbArcSegmentCenter,
                McadSectionLineSegmentType.sbLineSegment,
                McadSectionLineSegmentType.sbLineSegment
            };
            sectionline.SetSectionPoints(points, ArcPoints, segmentTypes);

            //' Section side
            double[] sidePoint = { 12, 10, 0 };
            sectionline.SectionSide = sidePoint;

            //' Set label name
            sectionline.LabelName = "D";

            //' Get the number of label names
            //int noOfNames = sectionline.LabelNamesCount;

            //Set origin of section view. This function must be invoked after posting section line to database.
            double[] labelPoint = { 16, 11, 0 };
            sectionline.SetSectionViewOrigin(labelPoint);
            sectionline.Update();
        }
    }

    class Commands
    {
        [CommandMethod("KRSectionLine")]
        public void KRSectionLine()
        {
            Document doc = AcadAddin.CommonCommands.doc();
            Editor ed = doc.Editor;

            NetSectionLine netSecObj = new NetSectionLine();
            netSecObj.CreateSectionLine();

            //ed.WriteMessage($"\nDocument name:{netSecObj.DocName}");
        }
    }
}

namespace SampleNestedBlock
{
    public class BlockCmds

    {
        [CommandMethod("CCNESTED")]

        public void ChangeColor()

        {

            Document doc =

              Application.DocumentManager.MdiActiveDocument;

            Database db = doc.Database;

            Editor ed = doc.Editor;


            PromptIntegerResult pr =

              ed.GetInteger(

                "\nEnter color index to change all entities to: "

              );


            if (pr.Status == PromptStatus.OK)

            {

                short newColorIndex = (short)pr.Value;

                ObjectId msId;

                Transaction tr =

                  doc.TransactionManager.StartTransaction();

                using (tr)

                {

                    BlockTable bt =

                      (BlockTable)tr.GetObject(

                        db.BlockTableId,

                        OpenMode.ForRead

                      );

                    msId =

                      bt[BlockTableRecord.ModelSpace];


                    // Not needed, but quicker than aborting

                    tr.Commit();

                }

                int count =

                  ChangeNestedEntitiesToColor(msId, newColorIndex);

                ed.Regen();

                ed.WriteMessage(

                  "\nChanged {0} entit{1} to color {2}.",

                  count,

                  count == 1 ? "y" : "ies",

                  newColorIndex

                );

            }

        }


        private int ChangeNestedEntitiesToColor(

          ObjectId btrId, short colorIndex)

        {

            int changedCount = 0;

            Document doc =

              Application.DocumentManager.MdiActiveDocument;

            Database db = doc.Database;

            Editor ed = doc.Editor;

            Transaction tr =

              doc.TransactionManager.StartTransaction();

            using (tr)

            {

                BlockTableRecord btr =

                  (BlockTableRecord)tr.GetObject(

                    btrId,

                    OpenMode.ForRead

                  );

                foreach (ObjectId entId in btr)

                {

                    Entity ent =

                      tr.GetObject(entId, OpenMode.ForRead)

                      as Entity;


                    if (ent != null)

                    {

                        BlockReference br = ent as BlockReference;

                        if (br != null)

                        {

                            // Recurse for nested blocks

                            changedCount +=

                              ChangeNestedEntitiesToColor(

                                br.BlockTableRecord,

                                colorIndex

                              );

                        }

                        else

                        {

                            if (ent.ColorIndex != colorIndex)

                            {

                                changedCount++;

                                // Entity is only open for read

                                ent.UpgradeOpen();

                                ent.ColorIndex = colorIndex;

                                ent.DowngradeOpen();

                            }

                        }

                    }

                }

                tr.Commit();

            }

            return changedCount;
        }

    }
}

namespace SampleHighlightOverrule
{
    //https://adndevblog.typepad.com/autocad/2016/07/adding-highlight-overrules-to-selected-entities-only-and-set-color.html
    public class MyHighlightOverrule : HighlightOverrule
    {
        private int _colorIndex = 1;
        private int _oldColorIndex;
        public MyHighlightOverrule()
        {
            AddOverrule(RXClass.GetClass(typeof(Entity)), this, true);
        }
        public int ColorIndex
        {
            set { _colorIndex = value; }
            get { return _colorIndex; }
        }

        public override void Highlight(Entity entity, FullSubentityPath subId, bool highlightAll)
        {
            Database db = entity.Database;
            Document dwg = Application.DocumentManager.MdiActiveDocument;


            using (DocumentLock dl = dwg.LockDocument())
            {
                using (Transaction tran = db.TransactionManager.StartTransaction())
                {
                    entity.UpgradeOpen();
                    _oldColorIndex = entity.ColorIndex;
                    entity.ColorIndex = _colorIndex;
                    entity.DowngradeOpen();
                }
            }

            base.Highlight(entity, subId, highlightAll);
        }
    }
    public class Commands
    {
        private static MyHighlightOverrule _hlOverRule = null;
        [CommandMethod("SelectObjectsToAddOverrule")]
        public void SelectObjectsToAddOverrule()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Transaction tr = doc.TransactionManager.StartTransaction();
            using (tr)
            {
                if (_hlOverRule == null)
                {
                    _hlOverRule = new MyHighlightOverrule();
                }
                // Loop until or completed
                List<ObjectId> ids = new List<ObjectId>();
                List<FullSubentityPath> paths = new List<FullSubentityPath>();
                PromptNestedEntityResult rs;
                do
                {
                    rs = ed.GetNestedEntity(String.Format("\nSelect entity to highlight color"));
                    if (rs.Status == PromptStatus.OK)
                    {
                        ids.Add(rs.ObjectId);
                        FullSubentityPath path = FullSubentityPath.Null;
                        path = GetSubEntityPath(rs);
                        if (path != FullSubentityPath.Null)
                            paths.Add(path);
                    }
                } while (rs.Status == PromptStatus.OK);
                _hlOverRule.SetIdFilter(ids.ToArray());
                tr.Commit();
            }
            ed.Regen();
        }

        private static FullSubentityPath GetSubEntityPath(PromptNestedEntityResult rs)
        {
            // Extract relevant information from the prompt object
            ObjectId selId = rs.ObjectId;
            List<ObjectId> objIds = new List<ObjectId>(rs.GetContainers());

            // Reverse the "containers" list
            objIds.Reverse();

            // Now append the selected entity
            objIds.Add(selId);

            // Retrieve the sub-entity path for this entity
            SubentityId subEnt = new SubentityId(SubentityType.Null, System.IntPtr.Zero);
            FullSubentityPath path = new FullSubentityPath(objIds.ToArray(), subEnt);

            // Open the outermost container, relying on the open transaction...
            Entity ent = objIds[0].GetObject(OpenMode.ForRead) as Entity;

            // ... and highlight the nested entity
            if (ent == null)
                return FullSubentityPath.Null;

            // Return the sub-entity path 
            return path;
        }

        [CommandMethod("ChangeHighlightColor")]
        public void ChangeHighlightColor()
        {
            Document dwg = Autodesk.AutoCAD.ApplicationServices.
            Application.DocumentManager.MdiActiveDocument;
            Editor ed = dwg.Editor;
            PromptIntegerOptions opt = new PromptIntegerOptions(
            "\nEnter color index (a number form 0 to 7):");
            PromptIntegerResult res = ed.GetInteger(opt);
            if (res.Status == PromptStatus.OK)
            {
                _hlOverRule.ColorIndex = res.Value;
            }
        }
    }
}

namespace SampleSelectionWithCoors
{
    //Link:
    //https://forums.autodesk.com/t5/net/any-way-to-get-points-used-in-getselection/td-p/5706564?fbclid=IwAR2tWiqvXmFPRHx57Yf2mXOnop2MTU988mCYBQxolgYg3PqbhcgAukjNNSE
    class Commands
    {
        [CommandMethod("TestSelectWithCoors")]
        public static void TestSelection()
        {
            Document doc = null;
            Database db = null;
            Editor ed = null;

            try
            {
                doc = AcadAddin.CommonCommands.doc();
                if (doc == null)
                    throw new System.Exception("\n Drawing Document required");
                db = doc.Database;
                ed = doc.Editor;

                //Select Objects, use ed.GetSelection to benefit from Window/Crossing selection visual feedback
                PromptSelectionOptions pso = new PromptSelectionOptions();
                pso.MessageForAdding = "Select  Objects";
                pso.SingleOnly = false;
                PromptSelectionResult psr = ed.GetSelection(pso);
                if (psr.Status != PromptStatus.OK)
                    return;

                SelectionSetDelayMarshalled ssMarshal = (SelectionSetDelayMarshalled)psr.Value;
                AdsName name = ssMarshal.Name;
                var selObjIds = ssMarshal.GetObjectIds();
                ed.WriteMessage("\n {0} Objects selected", selObjIds.Length);
                for (int i = 0; i < selObjIds.Length; i++)
                    ed.WriteMessage("\n\t [{0}]: {1} ({2})", i, selObjIds[i].ObjectClass.DxfName, selObjIds[i].Handle);

                SelectionSet selSet = (SelectionSet)ssMarshal;
                ed.WriteMessage("\n {0} Selections in SelectionSet", selSet.Count);

                foreach (SelectedObject ssItem in selSet)
                {
                    ed.WriteMessage("\n\t {0} Selected: {1} ({2})", Enum.GetName(typeof(SelectionMethod), 
                        ssItem.SelectionMethod), ssItem.ObjectId.ObjectClass.DxfName, ssItem.ObjectId.Handle);
                    switch (ssItem.SelectionMethod)
                    {
                        case SelectionMethod.PickPoint:
                            PickPointSelectedObject ppSelObj = ssItem as PickPointSelectedObject;
                            Point3d pickedPoint = ppSelObj.PickPoint.PointOnLine;
                            ed.WriteMessage("\n\t\t Selected at: {0}", pickedPoint.ToString());
                            break;

                        case SelectionMethod.Crossing:
                            CrossingOrWindowSelectedObject crossSelObj = ssItem as CrossingOrWindowSelectedObject;
                            PickPointDescriptor[] crossSelPickedPoints = crossSelObj.GetPickPoints();
                            ed.WriteMessage("\n\t\t Crossing at: {0}..{1}", crossSelPickedPoints[0].PointOnLine.ToString(), 
                                crossSelPickedPoints[1].PointOnLine.ToString());
                            break;

                        case SelectionMethod.Window:
                            CrossingOrWindowSelectedObject windSelObj = ssItem as CrossingOrWindowSelectedObject;
                            PickPointDescriptor[] winSelPickedPoints = windSelObj.GetPickPoints();
                            ed.WriteMessage("\n\t\t Window at: {0}..{1}", winSelPickedPoints[0].PointOnLine.ToString(), 
                                winSelPickedPoints[1].PointOnLine.ToString());
                            break;

                    }
                }
            }
            catch (System.Exception ex)
            {
                if (ed != null)
                    ed.WriteMessage(ex.Message);
                else
                    System.Windows.Forms.MessageBox.Show(ex.Message,
                                "TestSelection",
                                System.Windows.Forms.MessageBoxButtons.OK,
                                System.Windows.Forms.MessageBoxIcon.Error);
            }
        }
    }
}

namespace SampleMLeaderJig
{
    //Link:
    //https://www.keanw.com/2007/09/creating-a-mult.html?fbclid=IwAR2SWiMQW7gxUM0kPeCN2q387jwmPXS18Sbhz2swcgFFZCPoKj4dUJ2dLLY

    public class Commands

    {
        class MLeaderJig : EntityJig

        {

            Point3dCollection m_pts;

            Point3d m_tempPoint;

            string m_contents;

            int m_leaderIndex;

            int m_leaderLineIndex;


            public MLeaderJig(string contents)

              : base(new MLeader())

            {
                // Store the string passed in
                m_contents = contents;

                // Create a point collection to store our vertices
                m_pts = new Point3dCollection();

                // Create mleader and set defaults
                MLeader ml = Entity as MLeader;
                ml.SetDatabaseDefaults();

                // Set up the MText contents
                ml.ContentType = ContentType.MTextContent;
                MText mt = new MText();
                mt.SetDatabaseDefaults();
                mt.Contents = m_contents;
                ml.MText = mt;
                ml.TextAlignmentType = TextAlignmentType.LeftAlignment;
                ml.TextAttachmentType = TextAttachmentType.AttachmentMiddle;

                // Set the frame and landing properties
                ml.EnableDogleg = true;
                ml.EnableFrameText = true;
                ml.EnableLanding = true;

                // Reduce the standard landing gap
                ml.LandingGap = 0.05;

                // Add a leader, but not a leader line (for now)
                m_leaderIndex = ml.AddLeader();
                m_leaderLineIndex = -1;
            }


            protected override SamplerStatus Sampler(JigPrompts prompts)
            {

                JigPromptPointOptions opts = new JigPromptPointOptions();

                // Not all options accept null response
                opts.UserInputControls = (UserInputControls.Accept3dCoordinates |
                                         UserInputControls.NoNegativeResponseAccepted
                                            );
                
                // Get the first point
                if (m_pts.Count == 0)
                {
                    opts.UserInputControls |=
                      UserInputControls.NullResponseAccepted;
                    opts.Message =
                      "\nStart point of multileader: ";
                    opts.UseBasePoint = false;
                }

                // And the second
                else if (m_pts.Count == 1)
                {
                    opts.BasePoint = m_pts[m_pts.Count - 1];
                    opts.UseBasePoint = true;
                    opts.Message =
                      "\nSpecify multileader vertex: ";
                }
                // And subsequent points
                else if (m_pts.Count > 1)

                {
                    opts.UserInputControls |=
                      UserInputControls.NullResponseAccepted;
                    opts.BasePoint = m_pts[m_pts.Count - 1];
                    opts.UseBasePoint = true;
                    opts.SetMessageAndKeywords(
                      "\nSpecify multileader vertex or [End]: ",
                      "End"
                    );

                }

                else // Should never happen
                    return SamplerStatus.Cancel;

                PromptPointResult res = prompts.AcquirePoint(opts);
                if (res.Status == PromptStatus.Keyword)
                {
                    if (res.StringResult == "End")
                    {
                        return SamplerStatus.Cancel;
                    }
                }

                if (m_tempPoint == res.Value)
                {
                    return SamplerStatus.NoChange;
                }
                else if (res.Status == PromptStatus.OK)

                {
                    m_tempPoint = res.Value;
                    return SamplerStatus.OK;
                }

                return SamplerStatus.Cancel;
            }


            protected override bool Update()

            {
                try
                {
                    if (m_pts.Count > 0)
                    {
                        // Set the last vertex to the new value
                        MLeader ml = Entity as MLeader;
                        ml.SetLastVertex(
                          m_leaderLineIndex,
                          m_tempPoint
                        );


                        // Adjust the text location
                        Vector3d dogvec =
                          ml.GetDogleg(m_leaderIndex);
                        
                        double doglen = ml.DoglegLength;

                        double landgap = ml.LandingGap;

                        ml.TextLocation = m_tempPoint +
                                        ((doglen + landgap) * dogvec);

                    }
                }

                catch (System.Exception ex)
                {
                    Document doc =
                      Application.DocumentManager.MdiActiveDocument;
                    doc.Editor.WriteMessage(
                      "\nException: " + ex.Message
                    );

                    return false;
                }

                return true;
            }

            public void AddVertex()

            {
                MLeader ml = Entity as MLeader;
                // For the first point...


                if (m_pts.Count == 0)
                {
                    // Add a leader line
                    m_leaderLineIndex =

                      ml.AddLeaderLine(m_leaderIndex);


                    // And a start vertex


                    ml.AddFirstVertex(

                      m_leaderLineIndex,

                      m_tempPoint

                    );


                    // Add a second vertex that will be set

                    // within the jig


                    ml.AddLastVertex(

                      m_leaderLineIndex,

                      new Point3d(0, 0, 0)

                    );

                }

                else

                {

                    // For subsequent points,

                    // just add a vertex


                    ml.AddLastVertex(

                      m_leaderLineIndex,

                      m_tempPoint

                    );

                }


                // Reset the attachment point, otherwise

                // it seems to get forgotten


                ml.TextAttachmentType =

                  TextAttachmentType.AttachmentMiddle;


                // Add the latest point to our history


                m_pts.Add(m_tempPoint);

            }


            public void RemoveLastVertex()

            {

                // We don't need to actually remove

                // the vertex, just reset it


                MLeader ml = Entity as MLeader;

                if (m_pts.Count >= 1)

                {

                    Vector3d dogvec =

                      ml.GetDogleg(m_leaderIndex);

                    double doglen =

                      ml.DoglegLength;

                    double landgap =

                      ml.LandingGap;

                    ml.TextLocation =

                      m_pts[m_pts.Count - 1] +

                      ((doglen + landgap) * dogvec);

                }

            }


            public Entity GetEntity()

            {

                return Entity;

            }

        }

        [CommandMethod("MyMleader")]
        public void MyMLeaderJig()

        {

            Document doc =

              Application.DocumentManager.MdiActiveDocument;

            Editor ed = doc.Editor;

            Database db = doc.Database;


            // Get the text outside of the jig


            PromptStringOptions pso =

              new PromptStringOptions(

                "\nEnter text: "

              );

            pso.AllowSpaces = true;

            PromptResult pr =

              ed.GetString(pso);

            if (pr.Status == PromptStatus.OK)

            {

                // Create MleaderJig


                MLeaderJig jig =

                  new MLeaderJig(pr.StringResult);


                // Loop to set vertices


                bool bSuccess = true, bComplete = false;

                while (bSuccess && !bComplete)

                {

                    PromptResult dragres = ed.Drag(jig);

                    bSuccess =

                      (dragres.Status == PromptStatus.OK);

                    if (bSuccess)

                        jig.AddVertex();

                    bComplete =

                      (dragres.Status == PromptStatus.None);

                    if (bComplete)

                        jig.RemoveLastVertex();

                }


                if (bComplete)

                {

                    // Append entity


                    Transaction tr =

                      db.TransactionManager.StartTransaction();

                    using (tr)

                    {

                        BlockTable bt =

                          (BlockTable)tr.GetObject(

                            db.BlockTableId,

                            OpenMode.ForRead,

                            false

                          );

                        BlockTableRecord btr =

                          (BlockTableRecord)tr.GetObject(

                            bt[BlockTableRecord.ModelSpace],

                            OpenMode.ForWrite,

                            false

                          );

                        btr.AppendEntity(jig.GetEntity());

                        tr.AddNewlyCreatedDBObject(

                          jig.GetEntity(),

                          true

                        );

                        tr.Commit();

                    }

                }

            }

        }

    }

}

//Check arx/ DLL loaded:
//https://forums.autodesk.com/t5/net/check-if-arx-is-loaded/td-p/11574435?fbclid=IwAR2wXgnD_sSHYnpiIO29lgX42KlJQT1kAq5_RdkVHZ9QMXuxdHh_kYyxv48

//Preview in autocad:
//https://www.theswamp.org/index.php?topic=52567.0&fbclid=IwAR3g4H3OPuS2dRe9sXkg_jzMxxqBFuo6jK6DX7aaq0V7A9pz8YFhPxwA8sc

//Ribbon in autocad:
//https://forums.autodesk.com/t5/net/net-c-ribbon-tab/td-p/3920030?fbclid=IwAR3ZX4I-VYx9pKiQQjIZRJSKW1Wr245RcQxnFzfhnuHwdFzudyEofO51B_k

//Deepclone samples:
//https://forums.autodesk.com/t5/net/copy-entity-deepclone/td-p/5236023
//https://forums.autodesk.com/t5/net/copy-entities-in-code/td-p/8570414

//Get group name:
//https://forums.autodesk.com/t5/net/get-the-groupname-groupid-which-an-entity-belongs-to/td-p/1636310

namespace SampleCollectionCreation
{
    public class Commands
    {
        [CommandMethod("CB")]
        public void CreateBlock()
        {
            Document doc =
              Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            Transaction tr = db.TransactionManager.StartTransaction();
            using (tr)
            {
                // Get the block table from the drawing
                BlockTable bt =

                  (BlockTable)tr.GetObject(

                    db.BlockTableId,

                    OpenMode.ForRead

                  );



                // Check the block name, to see whether it's

                // already in use



                PromptStringOptions pso =

                  new PromptStringOptions(

                    "\nEnter new block name: "

                  );

                pso.AllowSpaces = true;



                // A variable for the block's name



                string blkName = "";



                do

                {

                    PromptResult pr = ed.GetString(pso);



                    // Just return if the user cancelled

                    // (will abort the transaction as we drop out of the using

                    // statement's scope)



                    if (pr.Status != PromptStatus.OK)

                        return;



                    try

                    {

                        // Validate the provided symbol table name



                        SymbolUtilityServices.ValidateSymbolName(

                          pr.StringResult,

                          false

                        );



                        // Only set the block name if it isn't in use



                        if (bt.Has(pr.StringResult))

                            ed.WriteMessage(

                              "\nA block with this name already exists."

                            );

                        else

                            blkName = pr.StringResult;

                    }

                    catch

                    {

                        // An exception has been thrown, indicating the

                        // name is invalid



                        ed.WriteMessage(

                          "\nInvalid block name."

                        );

                    }



                } while (blkName == "");



                // Create our new block table record...



                BlockTableRecord btr = new BlockTableRecord();



                // ... and set its properties



                btr.Name = blkName;



                // Add the new block to the block table



                bt.UpgradeOpen();

                ObjectId btrId = bt.Add(btr);

                tr.AddNewlyCreatedDBObject(btr, true);



                // Add some lines to the block to form a square

                // (the entities belong directly to the block)



                DBObjectCollection ents = SquareOfLines(5);

                foreach (Entity ent in ents)

                {

                    btr.AppendEntity(ent);

                    tr.AddNewlyCreatedDBObject(ent, true);

                }



                // Add a block reference to the model space



                BlockTableRecord ms =

                  (BlockTableRecord)tr.GetObject(

                    bt[BlockTableRecord.ModelSpace],

                    OpenMode.ForWrite

                  );



                BlockReference br =

                  new BlockReference(Point3d.Origin, btrId);



                ms.AppendEntity(br);

                tr.AddNewlyCreatedDBObject(br, true);



                // Commit the transaction



                tr.Commit();



                // Report what we've done



                ed.WriteMessage(

                  "\nCreated block named \"{0}\" containing {1} entities.",

                  blkName, ents.Count

                );

            }

        }

        [CommandMethod("CG")]
        public void CreateGroup()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            Transaction tr = db.TransactionManager.StartTransaction();
            using (tr)
            {
                // Get the group dictionary from the drawing
                DBDictionary gd =

                  (DBDictionary)tr.GetObject(

                    db.GroupDictionaryId,

                    OpenMode.ForRead

                  );



                // Check the group name, to see whether it's

                // already in use



                PromptStringOptions pso =

                  new PromptStringOptions(

                    "\nEnter new group name: "

                  );

                pso.AllowSpaces = true;



                // A variable for the group's name



                string grpName = "";



                do

                {

                    PromptResult pr = ed.GetString(pso);



                    // Just return if the user cancelled

                    // (will abort the transaction as we drop out of the using

                    // statement's scope)



                    if (pr.Status != PromptStatus.OK)

                        return;



                    try

                    {

                        // Validate the provided symbol table name



                        SymbolUtilityServices.ValidateSymbolName(

                          pr.StringResult,

                          false

                        );



                        // Only set the block name if it isn't in use



                        if (gd.Contains(pr.StringResult))

                            ed.WriteMessage(

                              "\nA group with this name already exists."

                            );

                        else

                            grpName = pr.StringResult;

                    }

                    catch

                    {

                        // An exception has been thrown, indicating the

                        // name is invalid



                        ed.WriteMessage(

                          "\nInvalid group name."

                        );

                    }



                } while (grpName == "");



                // Create our new group...



                Group grp = new Group("Test group", true);



                // Add the new group to the dictionary



                gd.UpgradeOpen();

                ObjectId grpId = gd.SetAt(grpName, grp);

                tr.AddNewlyCreatedDBObject(grp, true);



                // Open the model-space



                BlockTable bt =

                  (BlockTable)tr.GetObject(

                    db.BlockTableId,

                    OpenMode.ForRead

                  );



                BlockTableRecord ms =

                  (BlockTableRecord)tr.GetObject(

                    bt[BlockTableRecord.ModelSpace],

                    OpenMode.ForWrite

                  );



                // Add some lines to the group to form a square

                // (the entities belong to the model-space)
                ObjectIdCollection ids = new ObjectIdCollection();
                DBObjectCollection ents = SquareOfLines(8);
                foreach (Entity ent in ents)
                {
                    ObjectId id = ms.AppendEntity(ent);
                    ids.Add(id);
                    tr.AddNewlyCreatedDBObject(ent, true);
                }

                grp.InsertAt(0, ids);

                // Commit the transaction
                tr.Commit();

                // Report what we've done
                ed.WriteMessage(

                  "\nCreated group named \"{0}\" containing {1} entities.",

                  grpName, ents.Count
                );
            }
        }

        private DBObjectCollection SquareOfLines(double size)
        {

            // A function to generate a set of entities for our block
            DBObjectCollection ents = new DBObjectCollection();
            Point3d[] pts =

                { new Point3d(-size, -size, 0),

            new Point3d(size, -size, 0),

            new Point3d(size, size, 0),

            new Point3d(-size, size, 0)

          };

            int max = pts.GetUpperBound(0);

            for (int i = 0; i <= max; i++)

            {

                int j = (i == max ? 0 : i + 1);

                Line ln = new Line(pts[i], pts[j]);

                ents.Add(ln);

            }

            return ents;

        }

    }

}

//https://through-the-interface.typepad.com/through_the_interface/2011/11/creating-a-simple-associative-autocad-array-along-a-path-using-net.html
namespace SampleAssociativeArrays
{
    public class Commands
    {
        [CommandMethod("AAP")]
        public void CreateAssocArrayPath()
        {
            Database db = Application.DocumentManager.MdiActiveDocument.Database;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                // Add profile entities: a Circle and a Line
                Circle cir = new Circle(
                    new Point3d(-10, 0, 0),
                    new Vector3d(0, 0, 1),
                    1.0
                  );
                cir.ColorIndex = 3; // Green
                btr.AppendEntity(cir);
                tr.AddNewlyCreatedDBObject(cir, true);

                Line ln =
                  new Line(
                    new Point3d(-11, -1, 0),
                    new Point3d(-9, 1, 0)
                  );
                ln.ColorIndex = 3; // Green
                btr.AppendEntity(ln);
                tr.AddNewlyCreatedDBObject(ln, true);

                // Add path entity: a Spline, in this case
                double fitTol = 0.0;
                int order = 4;

                // An array of doubles to define the points
                // in our spline
                double[] ptAr =
                  new double[]{
            -6.8447, 0.9430,  0,
            -5.1409, -3.0562, 0,
            -2.4095, 2.1049,  0,
            3.4590, -3.9479, 0,
            7.1370, 6.3472,  0
                  };

                // We'll add the points to a collection
                Point3dCollection pts = new Point3dCollection();

                for (int i = 0, j = 0; i < ptAr.Length / 3; i++)
                {
                    pts.Add(new Point3d(ptAr[j++], ptAr[j++], ptAr[j++]));
                }

                // Create the spline path and add it to the database
                Spline sp = new Spline(pts, order, fitTol);
                btr.AppendEntity(sp);
                tr.AddNewlyCreatedDBObject(sp, true);

                // Offset the Circle, Line and Spline by a fixed amount

                Matrix3d offset =
                  Matrix3d.Displacement(new Vector3d(60, 10, 0));

                cir.TransformBy(offset);
                ln.TransformBy(offset);
                sp.TransformBy(offset);

                ObjectIdCollection srcEnts = new ObjectIdCollection();

                srcEnts.Add(cir.ObjectId);
                srcEnts.Add(ln.ObjectId);

                // Take the base point as the center of our Circle
                VertexRef basePt = new VertexRef(cir.Center);

                // Set some variables to define parameters for our path
                int itemCount = 6;
                double itemSpacing = sp.GetDistanceAtParameter(sp.EndParam) / itemCount;
                double rowSpacing = 0.0;
                double levelSpacing = 0.0;
                int rowCount = 0;
                int levelCount = 0;
                double rowElevation = 0.0;

                // Create the parameters for our associative path array

                AssocArrayPathParameters pars =
                  new AssocArrayPathParameters(
                    itemSpacing,
                    rowSpacing,
                    levelSpacing,
                    itemCount,
                    rowCount,
                    levelCount,
                    rowElevation
                  );

                pars.Method = AssocArrayPathParameters.MethodType.Measure;
                pars.Path = new EdgeRef(sp);

                // Create the associative array itself:
                AssocArray array = AssocArray.CreateArray(srcEnts, basePt, pars);

                // Evaluate the array:
                AssocManager.EvaluateTopLevelNetwork(db, null, 0);
                tr.Commit();
            }
        }
    }
}

namespace SampleTextEditor
{
    public class Commands
    {
        //https://forums.autodesk.com/t5/net/detect-keys-during-inplacetexteditor/m-p/6470628#M49632

        //[CommandMethod("TestIS")]
        //public void Test()
        //{
        //    Document doc = AcAp.DocumentManager.MdiActiveDocument;
        //    Database db = doc.Database;
        //    Editor ed = doc.Editor;

        //    AcadAddin.KeysFilter filter = new AcadAddin.KeysFilter();
        //    System.Windows.Forms.Application.AddMessageFilter(filter);

        //    while (filter.KeyPressed == null)
        //    {
        //        PromptStringOptions pso = new PromptStringOptions("\nInput string: ")
        //        {
        //            AllowSpaces = true
        //        };

        //        PromptResult pr;

        //        pr = ed.GetString(pso);
        //        if (pr.Status == PromptStatus.OK)
        //        {
        //            ed.WriteMessage($"\nContent : {pr.StringResult}");
        //        }

        //    }

        //    System.Windows.Forms.Application.RemoveMessageFilter(filter);

        //}


        [CommandMethod("TestIS")]
        public void Test()
        {
            Document doc = AcAp.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            var psr = ed.GetSelection(new SelectionFilter(new[] { new TypedValue(0, "TEXT") }));
            if (psr.Status != PromptStatus.OK)
                return;
            EditSelectedText(psr.Value.GetObjectIds());
        }

        private void EditSelectedText(ObjectId[] textIds)
        {
            Database db = textIds[0].Database;
            AcadAddin.KeysFilter filter = new AcadAddin.KeysFilter();
            System.Windows.Forms.Application.AddMessageFilter(filter);
            ObjectId[] ids = new ObjectId[0];
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                foreach (ObjectId id in textIds)
                {
                    DBText text = (DBText)tr.GetObject(id, OpenMode.ForWrite);
                    InplaceTextEditor.Invoke(text, ref ids);
                    if (filter.KeyPressed == "Alt")
                    {
                        break;
                    }
                }
                tr.Commit();
            }
            System.Windows.Forms.Application.RemoveMessageFilter(filter);
        }
    }
}

//When we need to dispose:
//https://www.keanw.com/2008/06/cleaning-up-aft.html

//http://www.theswamp.org/index.php?topic=42399.0

//https://adndevblog.typepad.com/autocad/2012/07/forcing-the-gc-to-run-on-the-main-thread.html

//https://www.keanw.com/2012/08/calling-dispose-on-autocad-objects.html

//=> DISPOSE ALL TEMPORARY DBOBJECT & GEOMETRY.
//If dbobject added to database by transaction => no need to dispose.
//If dbojbect opened by transaction => no need to dispose.

namespace SampleTraceBoundary
{
    public class Commands
    {
        static int _index = 1;

        [CommandMethod("TB")]
        public void TraceBoundary()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;

            // Select a seed point for our boundary
            PromptPointResult ppr = ed.GetPoint("\nSelect internal point: ");
            if (ppr.Status != PromptStatus.OK)
                return;

            // Get the objects making up our boundary
            DBObjectCollection objs = ed.TraceBoundary(ppr.Value, true);
            if (objs.Count > 0)
            {
                using (Transaction tr = doc.TransactionManager.StartTransaction())
                {
                    // We'll add the objects to the model space
                    BlockTable bt = (BlockTable)tr.GetObject( doc.Database.BlockTableId, OpenMode.ForRead);
                    BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace],
                        OpenMode.ForWrite);

                    // Add our boundary objects to the drawing and
                    // collect their ObjectIds for later use
                    ObjectIdCollection ids = new ObjectIdCollection();
                    foreach (DBObject obj in objs)
                    {
                        Entity ent = obj as Entity;
                        if (ent != null)
                        {
                            // Set our boundary objects to be of
                            // our auto-incremented colour index
                            ent.ColorIndex = _index;

                            // Set the lineweight of our object
                            ent.LineWeight = LineWeight.LineWeight050;

                            // Add each boundary object to the modelspace
                            // and add its ID to a collection
                            ids.Add(btr.AppendEntity(ent));
                            tr.AddNewlyCreatedDBObject(ent, true);
                        }
                    }

                    // Increment our colour index
                    _index++;

                    // Commit the transaction
                    tr.Commit();
                }
            }
        }
    }
}

namespace SampleDynamicDimJig
{
    using MgdAcApplication = Autodesk.AutoCAD.ApplicationServices.Application;
    using MgdAcDocument = Autodesk.AutoCAD.ApplicationServices.Document;
    using AcWindowsNS = Autodesk.AutoCAD.Windows;

    public class DynDimLineJigger : EntityJig
    {
        #region Fields

        public int mCurJigFactorIndex = 1;  // Jig Factor Index

        public Point3d mStartPoint; // Jig Factor #1
        public Point3d mEndPoint;   // Jig Factor #2

        private DynamicDimensionDataCollection dddCollection = new DynamicDimensionDataCollection();

        #endregion

        #region Constructors

        public DynDimLineJigger(Line ent)
            : base(ent)
        {
            // Initialize and transform the Entity.
            Entity.SetDatabaseDefaults();
            Entity.TransformBy(UCS);

            // Build up the Dynamic Dimension objects.
            Dimension dim1 = new AlignedDimension();
            dim1.SetDatabaseDefaults();
            dim1.TransformBy(UCS);
            dddCollection.Add(new DynamicDimensionData(dim1,true,true));
            dddCollection[0].Focal = false;
            dddCollection[0].Editable = false;
        }

        #endregion

        #region Properties

        private Editor Editor
        {
            get
            {
                return MgdAcApplication.DocumentManager.MdiActiveDocument.Editor;
            }
        }

        private Matrix3d UCS
        {
            get
            {
                return MgdAcApplication.DocumentManager.MdiActiveDocument.Editor.CurrentUserCoordinateSystem;
            }
        }

        #endregion

        #region Overrides

        public new Line Entity  // Overload the Entity property for convenience.
        {
            get
            {
                return base.Entity as Line;
            }
        }

        protected override bool Update()
        {
            switch (mCurJigFactorIndex)
            {
                case 1:
                    Entity.StartPoint = Entity.EndPoint = mStartPoint;
                    Entity.StartPoint.TransformBy(UCS);
                    Entity.EndPoint.TransformBy(UCS);
                    break;

                case 2:
                    Entity.EndPoint = mEndPoint;
                    Entity.EndPoint.TransformBy(UCS);

                    // Change the Dynamic Dimension data below if necessary
                    AlignedDimension dim1 = (AlignedDimension)dddCollection[0].Dimension;
                    dim1.XLine1Point = mStartPoint;
                    dim1.XLine1Point.TransformBy(UCS);

                    dim1.XLine2Point = mEndPoint;
                    dim1.XLine2Point.TransformBy(UCS);
                    
                    dim1.DimLinePoint = mEndPoint.RotateBy(Math.PI / 10, Vector3d.ZAxis, mStartPoint);
                    dim1.DimLinePoint.TransformBy(UCS);
                    break;

                default:
                    return false;
            }

            return true;
        }

        protected override SamplerStatus Sampler(JigPrompts prompts)
        {
            switch (mCurJigFactorIndex)
            {
                case 1:
                    JigPromptPointOptions prOptions1 = new JigPromptPointOptions("\nStart point:");
                    prOptions1.UseBasePoint = false;

                    PromptPointResult prResult1 = prompts.AcquirePoint(prOptions1);
                    if (prResult1.Status == PromptStatus.Cancel) 
                        return SamplerStatus.Cancel;
                    if (prResult1.Status == PromptStatus.Error) 
                        return SamplerStatus.Cancel;

                    if (prResult1.Value.Equals(mStartPoint))  //Use better comparison method if necessary.
                    {
                        return SamplerStatus.NoChange;
                    }
                    else
                    {
                        mStartPoint = prResult1.Value;
                        return SamplerStatus.OK;
                    }

                case 2:
                    JigPromptPointOptions prOptions2 = new JigPromptPointOptions("\nEnd point:");
                    prOptions2.BasePoint = Entity.StartPoint;
                    prOptions2.UseBasePoint = true;

                    PromptPointResult prResult2 = prompts.AcquirePoint(prOptions2);
                    if (prResult2.Status == PromptStatus.Cancel) 
                        return SamplerStatus.Cancel;
                    if (prResult2.Status == PromptStatus.Error) 
                        return SamplerStatus.Cancel;

                    if (prResult2.Value.Equals(mEndPoint))  //Use better comparison method if necessary.
                    {
                        return SamplerStatus.NoChange;
                    }
                    else
                    {
                        mEndPoint = prResult2.Value;
                        return SamplerStatus.OK;
                    }

                default:
                    break;
            }

            return SamplerStatus.OK;
        }

        protected override DynamicDimensionDataCollection GetDynamicDimensionData(double dimScale)
        {
            base.GetDynamicDimensionData(dimScale);
            return dddCollection;
        }

        #endregion

        #region Method to Call

        public static Line Jig()
        {
            DynDimLineJigger jigger = null;
            try
            {
                Editor ed = MgdAcApplication.DocumentManager.MdiActiveDocument.Editor;
                jigger = new DynDimLineJigger(new Line());
                PromptResult pr;
                do
                {
                    pr = ed.Drag(jigger);
                    if (pr.Status == PromptStatus.Keyword)
                    {
                        // Add keyword handling code below

                    }
                    else
                    {
                        jigger.mCurJigFactorIndex++;
                    }
                } while (pr.Status != PromptStatus.Cancel && pr.Status != PromptStatus.Error && jigger.mCurJigFactorIndex <= 2);

                return jigger.Entity;
            }
            catch
            {
                if (jigger != null && jigger.Entity != null) 
                    jigger.Entity.Dispose();
                
                return null;
            }
        }

        #endregion

        #region Test Command

        [CommandMethod("TestDynDimLineJigger")]
        public static void TestDynDimLineJigger_Method()
        {
            try
            {
                Entity jigEnt = DynDimLineJigger.Jig();
                if (jigEnt != null)
                {
                    Database db = HostApplicationServices.WorkingDatabase;
                    using (Transaction tr = db.TransactionManager.StartTransaction())
                    {
                        BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                        BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);
                        btr.AppendEntity(jigEnt);
                        tr.AddNewlyCreatedDBObject(jigEnt, true);
                        tr.Commit();
                    }
                }
            }
            catch (System.Exception ex)
            {
                MgdAcApplication.DocumentManager.MdiActiveDocument.Editor.WriteMessage(ex.ToString());
            }
        }

        #endregion

    }
}

#endregion
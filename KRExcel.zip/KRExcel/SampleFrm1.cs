﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//https://github.com/dotnet/winforms/blob/main/docs/designer/designer-high-dpi-mode.md
namespace KRExcel.Sample
{
    public partial class SampleFrm1 : Form
    {
        public SampleFrm1()
        {
            InitializeComponent();
        }

        private void ClickMeBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello world", KRExcel.Utils.CommonDeclaration.Owner,
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void HideBtn_Click(object sender, EventArgs e)
        {
            this.Hide();

            if (this.Modal)
            {
                this.DialogResult = DialogResult.Continue;
            }
        }
    }
}
